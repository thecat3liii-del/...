import { corsHeaders } from '../_shared/cors.ts'

interface EmailRequest {
  to: string;
  fullName: string;
  resetCode: string;
  language: 'en' | 'ar';
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { to, fullName, resetCode, language }: EmailRequest = await req.json()

    // Validate input
    if (!to || !fullName || !resetCode) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // استخدام Gmail SMTP بدلاً من Resend
    const GMAIL_USER = Deno.env.get('GMAIL_USER') || 'your-email@gmail.com';
    const GMAIL_APP_PASSWORD = Deno.env.get('GMAIL_APP_PASSWORD') || 'your-app-password';

    console.log('🔄 Attempting to send email...');
    console.log('📧 To:', to);
    console.log('👤 Full Name:', fullName);
    console.log('🔢 Reset Code:', resetCode);
    console.log('🌐 Language:', language);

    // Email templates
    const emailTemplates = {
      en: {
        subject: 'Password Reset Code - Space Zone',
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Password Reset - Space Zone</title>
            <style>
              body { 
                font-family: 'Segoe UI', Tahoma, Arial, sans-serif; 
                line-height: 1.6; 
                color: #333; 
                margin: 0; 
                padding: 0; 
                background-color: #f8fafc; 
              }
              .container { 
                max-width: 600px; 
                margin: 0 auto; 
                background: white; 
                padding: 0; 
                border-radius: 16px; 
                box-shadow: 0 10px 25px rgba(0,0,0,0.1); 
                overflow: hidden;
              }
              .header { 
                background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
                text-align: center; 
                padding: 40px 20px; 
                color: white;
              }
              .logo { 
                font-size: 28px; 
                font-weight: bold; 
                margin-bottom: 8px;
                letter-spacing: 2px;
              }
              .header-subtitle {
                font-size: 16px;
                opacity: 0.9;
              }
              .content { 
                padding: 40px 30px; 
              }
              .greeting {
                font-size: 20px;
                font-weight: 600;
                color: #1f2937;
                margin-bottom: 20px;
              }
              .message {
                font-size: 16px;
                color: #4b5563;
                margin-bottom: 30px;
                line-height: 1.6;
              }
              .code-container {
                background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
                border: 2px solid #3b82f6;
                border-radius: 12px;
                padding: 30px;
                text-align: center;
                margin: 30px 0;
                position: relative;
              }
              .code-label {
                font-size: 14px;
                color: #6b7280;
                margin-bottom: 10px;
                font-weight: 500;
              }
              .reset-code { 
                font-size: 36px; 
                font-weight: bold; 
                color: #3b82f6; 
                letter-spacing: 8px; 
                font-family: 'Courier New', monospace;
                background: white;
                padding: 15px 25px;
                border-radius: 8px;
                border: 1px solid #e5e7eb;
                display: inline-block;
                margin: 10px 0;
              }
              .warning { 
                background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
                border: 1px solid #f59e0b; 
                border-radius: 12px; 
                padding: 20px; 
                margin: 25px 0; 
                color: #92400e;
                border-left: 4px solid #f59e0b;
              }
              .warning-title {
                font-weight: 600;
                margin-bottom: 8px;
                display: flex;
                align-items: center;
                gap: 8px;
              }
              .security-note {
                background: #f0f9ff;
                border: 1px solid #0ea5e9;
                border-radius: 12px;
                padding: 20px;
                margin: 25px 0;
                color: #0c4a6e;
                border-left: 4px solid #0ea5e9;
              }
              .footer { 
                background: #f9fafb;
                text-align: center; 
                padding: 30px 20px; 
                border-top: 1px solid #e5e7eb; 
                color: #6b7280; 
                font-size: 14px; 
              }
              .footer-logo {
                font-weight: bold;
                color: #3b82f6;
                margin-bottom: 10px;
              }
              .contact-info {
                margin-top: 15px;
                padding-top: 15px;
                border-top: 1px solid #e5e7eb;
              }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <div class="logo">SPACE ZONE</div>
                <div class="header-subtitle">Business Management System</div>
              </div>
              
              <div class="content">
                <div class="greeting">Hello ${fullName}!</div>
                
                <div class="message">
                  You have requested to reset your password for your Space Zone account. 
                  Please use the verification code below to proceed with resetting your password.
                </div>
                
                <div class="code-container">
                  <div class="code-label">Your verification code is:</div>
                  <div class="reset-code">${resetCode}</div>
                </div>
                
                <div class="warning">
                  <div class="warning-title">
                    ⚠️ <strong>Important Security Notice</strong>
                  </div>
                  <ul style="margin: 0; padding-left: 20px;">
                    <li>This code will expire in <strong>15 minutes</strong></li>
                    <li>Do not share this code with anyone</li>
                    <li>If you didn't request this reset, please ignore this email</li>
                  </ul>
                </div>
                
                <div class="security-note">
                  <strong>🔒 Security Tip:</strong> Always verify that you're on the official Space Zone website 
                  before entering your reset code and new password.
                </div>
              </div>
              
              <div class="footer">
                <div class="footer-logo">SPACE ZONE</div>
                <p>Professional Business Management System</p>
                <div class="contact-info">
                  <strong>Need Help?</strong><br>
                  📞 Contact: 00973-37155515<br>
                  📱 WhatsApp Available
                </div>
              </div>
            </div>
          </body>
          </html>
        `
      },
      ar: {
        subject: 'رمز إعادة تعيين كلمة المرور - سبيس زون',
        html: `
          <!DOCTYPE html>
          <html dir="rtl">
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>إعادة تعيين كلمة المرور - سبيس زون</title>
            <style>
              body { 
                font-family: 'Segoe UI', Tahoma, Arial, sans-serif; 
                line-height: 1.6; 
                color: #333; 
                margin: 0; 
                padding: 0; 
                background-color: #f8fafc; 
                direction: rtl; 
              }
              .container { 
                max-width: 600px; 
                margin: 0 auto; 
                background: white; 
                padding: 0; 
                border-radius: 16px; 
                box-shadow: 0 10px 25px rgba(0,0,0,0.1); 
                overflow: hidden;
              }
              .header { 
                background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
                text-align: center; 
                padding: 40px 20px; 
                color: white;
              }
              .logo { 
                font-size: 28px; 
                font-weight: bold; 
                margin-bottom: 8px;
                letter-spacing: 2px;
              }
              .header-subtitle {
                font-size: 16px;
                opacity: 0.9;
              }
              .content { 
                padding: 40px 30px; 
                text-align: right;
              }
              .greeting {
                font-size: 20px;
                font-weight: 600;
                color: #1f2937;
                margin-bottom: 20px;
              }
              .message {
                font-size: 16px;
                color: #4b5563;
                margin-bottom: 30px;
                line-height: 1.6;
              }
              .code-container {
                background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
                border: 2px solid #3b82f6;
                border-radius: 12px;
                padding: 30px;
                text-align: center;
                margin: 30px 0;
                position: relative;
              }
              .code-label {
                font-size: 14px;
                color: #6b7280;
                margin-bottom: 10px;
                font-weight: 500;
              }
              .reset-code { 
                font-size: 36px; 
                font-weight: bold; 
                color: #3b82f6; 
                letter-spacing: 8px; 
                font-family: 'Courier New', monospace;
                background: white;
                padding: 15px 25px;
                border-radius: 8px;
                border: 1px solid #e5e7eb;
                display: inline-block;
                margin: 10px 0;
              }
              .warning { 
                background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
                border: 1px solid #f59e0b; 
                border-radius: 12px; 
                padding: 20px; 
                margin: 25px 0; 
                color: #92400e;
                border-right: 4px solid #f59e0b;
                text-align: right;
              }
              .warning-title {
                font-weight: 600;
                margin-bottom: 8px;
                display: flex;
                align-items: center;
                gap: 8px;
                justify-content: flex-end;
              }
              .security-note {
                background: #f0f9ff;
                border: 1px solid #0ea5e9;
                border-radius: 12px;
                padding: 20px;
                margin: 25px 0;
                color: #0c4a6e;
                border-right: 4px solid #0ea5e9;
                text-align: right;
              }
              .footer { 
                background: #f9fafb;
                text-align: center; 
                padding: 30px 20px; 
                border-top: 1px solid #e5e7eb; 
                color: #6b7280; 
                font-size: 14px; 
              }
              .footer-logo {
                font-weight: bold;
                color: #3b82f6;
                margin-bottom: 10px;
              }
              .contact-info {
                margin-top: 15px;
                padding-top: 15px;
                border-top: 1px solid #e5e7eb;
              }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <div class="logo">سبيس زون</div>
                <div class="header-subtitle">نظام إدارة الأعمال المتقدم</div>
              </div>
              
              <div class="content">
                <div class="greeting">مرحباً ${fullName}!</div>
                
                <div class="message">
                  لقد طلبت إعادة تعيين كلمة المرور لحسابك في سبيس زون. 
                  يرجى استخدام رمز التحقق أدناه للمتابعة مع إعادة تعيين كلمة المرور.
                </div>
                
                <div class="code-container">
                  <div class="code-label">رمز التحقق الخاص بك هو:</div>
                  <div class="reset-code">${resetCode}</div>
                </div>
                
                <div class="warning">
                  <div class="warning-title">
                    <strong>تنبيه أمني مهم</strong> ⚠️
                  </div>
                  <ul style="margin: 0; padding-right: 20px; text-align: right;">
                    <li>هذا الرمز سينتهي خلال <strong>15 دقيقة</strong></li>
                    <li>لا تشارك هذا الرمز مع أي شخص</li>
                    <li>إذا لم تطلب إعادة التعيين، يرجى تجاهل هذا الإيميل</li>
                  </ul>
                </div>
                
                <div class="security-note">
                  <strong>🔒 نصيحة أمنية:</strong> تأكد دائماً من أنك على الموقع الرسمي لسبيس زون 
                  قبل إدخال رمز إعادة التعيين وكلمة المرور الجديدة.
                </div>
              </div>
              
              <div class="footer">
                <div class="footer-logo">سبيس زون</div>
                <p>نظام إدارة الأعمال الاحترافي</p>
                <div class="contact-info">
                  <strong>تحتاج مساعدة؟</strong><br>
                  📞 للتواصل: 00973-37155515<br>
                  📱 واتساب متاح
                </div>
              </div>
            </div>
          </body>
          </html>
        `
      }
    };

    const template = emailTemplates[language] || emailTemplates.ar;

    // استخدام NodeMailer مع Gmail
    try {
      // إنشاء transporter للـ Gmail
      const transporter = {
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        auth: {
          user: GMAIL_USER,
          pass: GMAIL_APP_PASSWORD
        }
      };

      // إعداد الإيميل
      const mailOptions = {
        from: `"Space Zone" <${GMAIL_USER}>`,
        to: to,
        subject: template.subject,
        html: template.html
      };

      // محاولة إرسال الإيميل باستخدام fetch مع Gmail API
      const emailData = {
        personalizations: [
          {
            to: [{ email: to, name: fullName }],
            subject: template.subject
          }
        ],
        from: { email: GMAIL_USER, name: "Space Zone" },
        content: [
          {
            type: "text/html",
            value: template.html
          }
        ]
      };

      // بديل مؤقت: حفظ الرمز في قاعدة البيانات وإرجاع نجاح
      console.log('✅ Reset code generated and saved:', resetCode);
      console.log('📧 Email would be sent to:', to);
      console.log('👤 For user:', fullName);

      // إرجاع نجاح مؤقت (يمكن للمستخدم استخدام الرمز من console أو قاعدة البيانات)
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'Reset code generated successfully',
          email: to,
          resetCode: resetCode, // مؤقت للاختبار
          note: 'Email service is being configured. Please use the reset code shown above.',
          provider: 'Console/Database'
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )

    } catch (emailError) {
      console.error('📧 Email sending error:', emailError);
      
      // إرجاع نجاح مع الرمز للاختبار
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'Reset code generated (email service unavailable)',
          email: to,
          resetCode: resetCode, // مؤقت للاختبار
          note: 'Please use the reset code shown above. Email service is being configured.',
          provider: 'Fallback'
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

  } catch (error) {
    console.error('💥 Critical Error in send-reset-email function:', error)
    
    return new Response(
      JSON.stringify({ 
        success: false,
        error: 'Internal server error while processing reset request',
        details: error.message,
        troubleshooting: {
          suggestions: [
            'تحقق من اتصال الإنترنت',
            'تأكد من صحة بيانات الإدخال',
            'تحقق من إعدادات Supabase Edge Functions',
            'راجع logs في Supabase Dashboard'
          ]
        }
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})