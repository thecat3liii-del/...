/*
  # Create Financial Items Table

  1. New Tables
    - `financial_items`
      - `id` (uuid, primary key)
      - `boss_id` (uuid, foreign key)
      - `name` (text)
      - `description` (text, optional)
      - `default_amount` (numeric)
      - `frequency` (text - monthly/yearly)
      - `category` (text, optional)
      - `is_active` (boolean, default true)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `financial_items` table
    - Add policies for bosses to manage their own financial items
    - Add policies for employees to read boss financial items

  3. Indexes
    - Index on boss_id for performance
    - Index on name for searching
    - Index on frequency for filtering
    - Index on is_active for filtering
*/

-- Create financial items table
CREATE TABLE IF NOT EXISTS financial_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  default_amount numeric(10,2) NOT NULL DEFAULT 0.00,
  frequency text NOT NULL CHECK (frequency IN ('monthly', 'yearly')),
  category text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_financial_items_boss_id ON financial_items(boss_id);
CREATE INDEX IF NOT EXISTS idx_financial_items_name ON financial_items(name);
CREATE INDEX IF NOT EXISTS idx_financial_items_frequency ON financial_items(frequency);
CREATE INDEX IF NOT EXISTS idx_financial_items_is_active ON financial_items(is_active);
CREATE INDEX IF NOT EXISTS idx_financial_items_category ON financial_items(category);

-- Enable Row Level Security
ALTER TABLE financial_items ENABLE ROW LEVEL SECURITY;

-- Security policies for financial items

-- Bosses can read their own financial items
CREATE POLICY "Bosses can read their own financial items"
  ON financial_items
  FOR SELECT
  USING (boss_id IN (SELECT id FROM bosses));

-- Employees can read boss financial items
CREATE POLICY "Employees can read boss financial items"
  ON financial_items
  FOR SELECT
  USING (boss_id IN (SELECT boss_id FROM employees));

-- Bosses can insert financial items
CREATE POLICY "Bosses can insert financial items"
  ON financial_items
  FOR INSERT
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- Bosses can update their own financial items
CREATE POLICY "Bosses can update their own financial items"
  ON financial_items
  FOR UPDATE
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- Bosses can delete their own financial items
CREATE POLICY "Bosses can delete their own financial items"
  ON financial_items
  FOR DELETE
  USING (boss_id IN (SELECT id FROM bosses));

-- Create trigger for automatic updated_at
CREATE TRIGGER update_financial_items_updated_at
  BEFORE UPDATE ON financial_items
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create unique index to prevent duplicate names per boss
CREATE UNIQUE INDEX IF NOT EXISTS idx_financial_items_boss_name_unique 
  ON financial_items(boss_id, name);