/*
  # إنشاء جداول المصادقة للنظام

  1. الجداول الجديدة
    - `bosses` - جدول المديرين
      - `id` (uuid, primary key)
      - `full_name` (text)
      - `email` (text, unique)
      - `password` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `employees` - جدول الموظفين
      - `id` (uuid, primary key)
      - `boss_id` (uuid, foreign key)
      - `full_name` (text)
      - `email` (text, unique)
      - `password` (text)
      - `is_active` (boolean)
      - `permissions` (jsonb)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. الأمان
    - تفعيل RLS على جميع الجداول
    - إضافة سياسات للوصول الآمن للبيانات
*/

-- إنشاء جدول المديرين
CREATE TABLE IF NOT EXISTS bosses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  email text UNIQUE NOT NULL,
  password text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء جدول الموظفين
CREATE TABLE IF NOT EXISTS employees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  email text UNIQUE NOT NULL,
  password text NOT NULL,
  is_active boolean DEFAULT true,
  permissions jsonb DEFAULT '{
    "transactions": {"view": false, "add": false, "edit": false, "delete": false},
    "clients": {"view": false, "add": false, "edit": false, "delete": false},
    "suppliers": {"view": false, "add": false, "edit": false, "delete": false},
    "services": {"view": false, "add": false, "edit": false, "delete": false},
    "reports": {"view": false, "generate": false, "export": false}
  }'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء فهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_bosses_email ON bosses(email);
CREATE INDEX IF NOT EXISTS idx_employees_email ON employees(email);
CREATE INDEX IF NOT EXISTS idx_employees_boss_id ON employees(boss_id);
CREATE INDEX IF NOT EXISTS idx_employees_is_active ON employees(is_active);

-- تفعيل Row Level Security
ALTER TABLE bosses ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;

-- سياسات الأمان للمديرين
CREATE POLICY "Bosses can read their own data"
  ON bosses
  FOR SELECT
  USING (true); -- يمكن للجميع قراءة بيانات المديرين للمصادقة

CREATE POLICY "Anyone can insert boss data"
  ON bosses
  FOR INSERT
  WITH CHECK (true); -- يمكن لأي شخص إنشاء حساب مدير

CREATE POLICY "Bosses can update their own data"
  ON bosses
  FOR UPDATE
  USING (true)
  WITH CHECK (true);

-- سياسات الأمان للموظفين
CREATE POLICY "Anyone can read employee data for authentication"
  ON employees
  FOR SELECT
  USING (true); -- يمكن للجميع قراءة بيانات الموظفين للمصادقة

CREATE POLICY "Anyone can insert employee data"
  ON employees
  FOR INSERT
  WITH CHECK (true); -- يمكن للمديرين إضافة موظفين

CREATE POLICY "Anyone can update employee data"
  ON employees
  FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete employee data"
  ON employees
  FOR DELETE
  USING (true);

-- إنشاء trigger لتحديث updated_at تلقائياً
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- تطبيق trigger على الجداول
DROP TRIGGER IF EXISTS update_bosses_updated_at ON bosses;
CREATE TRIGGER update_bosses_updated_at
  BEFORE UPDATE ON bosses
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_employees_updated_at ON employees;
CREATE TRIGGER update_employees_updated_at
  BEFORE UPDATE ON employees
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();