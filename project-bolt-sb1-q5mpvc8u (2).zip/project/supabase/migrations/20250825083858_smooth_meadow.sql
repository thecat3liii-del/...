/*
  # إنشاء نظام إعادة تعيين كلمة المرور

  1. الجداول الجديدة
    - `password_reset_codes`
      - `id` (uuid, primary key)
      - `boss_id` (uuid, foreign key)
      - `email` (text)
      - `reset_code` (text)
      - `expires_at` (timestamp)
      - `is_used` (boolean, default false)
      - `created_at` (timestamp)

  2. الأمان
    - تفعيل RLS على جدول password_reset_codes
    - إضافة سياسات للوصول الآمن

  3. الفهارس
    - فهرس على boss_id
    - فهرس على email
    - فهرس على reset_code
    - فهرس على expires_at
*/

-- إنشاء جدول رموز إعادة تعيين كلمة المرور
CREATE TABLE IF NOT EXISTS password_reset_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  email text NOT NULL,
  reset_code text NOT NULL,
  expires_at timestamptz NOT NULL,
  is_used boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- إنشاء فهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_password_reset_codes_boss_id ON password_reset_codes(boss_id);
CREATE INDEX IF NOT EXISTS idx_password_reset_codes_email ON password_reset_codes(email);
CREATE INDEX IF NOT EXISTS idx_password_reset_codes_reset_code ON password_reset_codes(reset_code);
CREATE INDEX IF NOT EXISTS idx_password_reset_codes_expires_at ON password_reset_codes(expires_at);
CREATE INDEX IF NOT EXISTS idx_password_reset_codes_is_used ON password_reset_codes(is_used);

-- تفعيل Row Level Security
ALTER TABLE password_reset_codes ENABLE ROW LEVEL SECURITY;

-- سياسات الأمان لرموز إعادة التعيين

-- يمكن للجميع قراءة رموز إعادة التعيين للتحقق منها
CREATE POLICY "Anyone can read password reset codes for verification"
  ON password_reset_codes
  FOR SELECT
  USING (true);

-- يمكن للجميع إدراج رموز إعادة تعيين جديدة
CREATE POLICY "Anyone can insert password reset codes"
  ON password_reset_codes
  FOR INSERT
  WITH CHECK (true);

-- يمكن للجميع تحديث رموز إعادة التعيين (لتمييزها كمستخدمة)
CREATE POLICY "Anyone can update password reset codes"
  ON password_reset_codes
  FOR UPDATE
  USING (true)
  WITH CHECK (true);

-- وظيفة لتنظيف الرموز المنتهية الصلاحية
CREATE OR REPLACE FUNCTION cleanup_expired_reset_codes()
RETURNS void AS $$
BEGIN
  DELETE FROM password_reset_codes 
  WHERE expires_at < now() OR is_used = true;
END;
$$ language 'plpgsql';

-- إنشاء وظيفة لتوليد رمز إعادة تعيين
CREATE OR REPLACE FUNCTION generate_reset_code()
RETURNS text AS $$
BEGIN
  RETURN LPAD(FLOOR(RANDOM() * 1000000)::text, 6, '0');
END;
$$ language 'plpgsql';