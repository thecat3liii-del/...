/*
  # إنشاء جداول الفواتير وإشعارات التسليم

  1. جداول جديدة
    - `invoices` - جدول الفواتير
      - `id` (uuid, primary key)
      - `boss_id` (uuid, foreign key)
      - `invoice_number` (text, unique per boss)
      - `client_id` (uuid, foreign key, optional)
      - `client_name` (text)
      - `client_email` (text, optional)
      - `client_phone` (text, optional)
      - `client_address` (text, optional)
      - `issue_date` (date)
      - `due_date` (date)
      - `items` (jsonb)
      - `subtotal` (numeric)
      - `tax_rate` (numeric)
      - `tax_amount` (numeric)
      - `discount_rate` (numeric)
      - `discount_amount` (numeric)
      - `total_amount` (numeric)
      - `notes` (text, optional)
      - `status` (text)
      - `is_active` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `delivery_notes` - جدول إشعارات التسليم
      - `id` (uuid, primary key)
      - `boss_id` (uuid, foreign key)
      - `delivery_number` (text, unique per boss)
      - `client_id` (uuid, foreign key, optional)
      - `client_name` (text)
      - `client_email` (text, optional)
      - `client_phone` (text, optional)
      - `client_address` (text, optional)
      - `delivery_address` (text, optional)
      - `delivery_date` (date)
      - `items` (jsonb)
      - `notes` (text, optional)
      - `driver_name` (text, optional)
      - `driver_phone` (text, optional)
      - `recipient_name` (text, optional)
      - `recipient_email` (text, optional)
      - `recipient_phone` (text, optional)
      - `recipient_signature` (text, optional)
      - `status` (text)
      - `is_active` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. الأمان
    - تفعيل RLS على الجدولين
    - إضافة سياسات للمديرين والموظفين
    - فهارس للبحث السريع
*/

-- إنشاء جدول الفواتير
CREATE TABLE IF NOT EXISTS invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  invoice_number text NOT NULL,
  client_id uuid REFERENCES clients(id) ON DELETE SET NULL,
  client_name text,
  client_email text,
  client_phone text,
  client_address text,
  issue_date date NOT NULL DEFAULT CURRENT_DATE,
  due_date date NOT NULL,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  subtotal numeric(12,2) NOT NULL DEFAULT 0.00,
  tax_rate numeric(5,2) DEFAULT 0.00,
  tax_amount numeric(12,2) DEFAULT 0.00,
  discount_rate numeric(5,2) DEFAULT 0.00,
  discount_amount numeric(12,2) DEFAULT 0.00,
  total_amount numeric(12,2) NOT NULL DEFAULT 0.00,
  notes text,
  status text DEFAULT 'draft' CHECK (status IN ('draft', 'sent', 'paid', 'overdue', 'cancelled')),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء جدول إشعارات التسليم
CREATE TABLE IF NOT EXISTS delivery_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  delivery_number text NOT NULL,
  client_id uuid REFERENCES clients(id) ON DELETE SET NULL,
  client_name text,
  client_email text,
  client_phone text,
  client_address text,
  delivery_address text,
  delivery_date date NOT NULL DEFAULT CURRENT_DATE,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  notes text,
  driver_name text,
  driver_phone text,
  recipient_name text,
  recipient_email text,
  recipient_phone text,
  recipient_signature text,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'in_transit', 'delivered', 'cancelled')),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء فهارس للفواتير
CREATE INDEX IF NOT EXISTS idx_invoices_boss_id ON invoices(boss_id);
CREATE INDEX IF NOT EXISTS idx_invoices_client_id ON invoices(client_id);
CREATE INDEX IF NOT EXISTS idx_invoices_invoice_number ON invoices(invoice_number);
CREATE INDEX IF NOT EXISTS idx_invoices_issue_date ON invoices(issue_date);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_invoices_is_active ON invoices(is_active);
CREATE UNIQUE INDEX IF NOT EXISTS idx_invoices_boss_number_unique ON invoices(boss_id, invoice_number);

-- إنشاء فهارس لإشعارات التسليم
CREATE INDEX IF NOT EXISTS idx_delivery_notes_boss_id ON delivery_notes(boss_id);
CREATE INDEX IF NOT EXISTS idx_delivery_notes_client_id ON delivery_notes(client_id);
CREATE INDEX IF NOT EXISTS idx_delivery_notes_delivery_number ON delivery_notes(delivery_number);
CREATE INDEX IF NOT EXISTS idx_delivery_notes_delivery_date ON delivery_notes(delivery_date);
CREATE INDEX IF NOT EXISTS idx_delivery_notes_status ON delivery_notes(status);
CREATE INDEX IF NOT EXISTS idx_delivery_notes_is_active ON delivery_notes(is_active);
CREATE UNIQUE INDEX IF NOT EXISTS idx_delivery_notes_boss_number_unique ON delivery_notes(boss_id, delivery_number);

-- تفعيل RLS على جدول الفواتير
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;

-- سياسات الفواتير للمديرين
CREATE POLICY "Bosses can manage their own invoices"
  ON invoices
  FOR ALL
  TO public
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- سياسات الفواتير للموظفين
CREATE POLICY "Employees can access boss invoices"
  ON invoices
  FOR ALL
  TO public
  USING (boss_id IN (SELECT boss_id FROM employees))
  WITH CHECK (boss_id IN (SELECT boss_id FROM employees));

-- تفعيل RLS على جدول إشعارات التسليم
ALTER TABLE delivery_notes ENABLE ROW LEVEL SECURITY;

-- سياسات إشعارات التسليم للمديرين
CREATE POLICY "Bosses can manage their own delivery notes"
  ON delivery_notes
  FOR ALL
  TO public
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- سياسات إشعارات التسليم للموظفين
CREATE POLICY "Employees can access boss delivery notes"
  ON delivery_notes
  FOR ALL
  TO public
  USING (boss_id IN (SELECT boss_id FROM employees))
  WITH CHECK (boss_id IN (SELECT boss_id FROM employees));

-- إضافة triggers لتحديث updated_at
CREATE TRIGGER update_invoices_updated_at
  BEFORE UPDATE ON invoices
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_delivery_notes_updated_at
  BEFORE UPDATE ON delivery_notes
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();