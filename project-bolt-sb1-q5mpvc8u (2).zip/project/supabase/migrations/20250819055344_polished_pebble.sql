/*
  # Create Detailed Employee Permissions System

  1. New Tables
    - `employee_detailed_permissions`
      - `id` (uuid, primary key)
      - `employee_id` (uuid, foreign key to employees)
      - `boss_id` (uuid, foreign key to bosses)
      - `page_name` (text) - name of the page
      - `can_view` (boolean) - can view the page
      - `can_add` (boolean) - can add new records
      - `can_edit` (boolean) - can edit existing records
      - `can_delete` (boolean) - can delete records
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `employee_detailed_permissions` table
    - Add policies for bosses to manage their employees' detailed permissions
    - Add policies for employees to read their own detailed permissions

  3. Indexes
    - Index on employee_id for performance
    - Index on boss_id for performance
    - Index on page_name for filtering
    - Unique index on (employee_id, page_name) to prevent duplicates
*/

-- Create detailed employee permissions table
CREATE TABLE IF NOT EXISTS employee_detailed_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  page_name text NOT NULL CHECK (page_name IN (
    'home', 'transactions', 'quotations-invoices', 'reports', 
    'clients', 'suppliers', 'services', 'settings'
  )),
  can_view boolean NOT NULL DEFAULT false,
  can_add boolean NOT NULL DEFAULT false,
  can_edit boolean NOT NULL DEFAULT false,
  can_delete boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_employee_detailed_permissions_employee_id ON employee_detailed_permissions(employee_id);
CREATE INDEX IF NOT EXISTS idx_employee_detailed_permissions_boss_id ON employee_detailed_permissions(boss_id);
CREATE INDEX IF NOT EXISTS idx_employee_detailed_permissions_page_name ON employee_detailed_permissions(page_name);

-- Create unique index to prevent duplicate permissions for same employee and page
CREATE UNIQUE INDEX IF NOT EXISTS idx_employee_detailed_permissions_unique 
  ON employee_detailed_permissions(employee_id, page_name);

-- Enable Row Level Security
ALTER TABLE employee_detailed_permissions ENABLE ROW LEVEL SECURITY;

-- Security policies for detailed employee permissions

-- Bosses can read their employees' detailed permissions
CREATE POLICY "Bosses can read their employees detailed permissions"
  ON employee_detailed_permissions
  FOR SELECT
  USING (boss_id IN (SELECT id FROM bosses));

-- Employees can read their own detailed permissions
CREATE POLICY "Employees can read their own detailed permissions"
  ON employee_detailed_permissions
  FOR SELECT
  USING (employee_id IN (SELECT id FROM employees));

-- Bosses can insert detailed permissions for their employees
CREATE POLICY "Bosses can insert employee detailed permissions"
  ON employee_detailed_permissions
  FOR INSERT
  WITH CHECK (boss_id IN (SELECT id FROM bosses) AND employee_id IN (
    SELECT id FROM employees WHERE boss_id = employee_detailed_permissions.boss_id
  ));

-- Bosses can update their employees' detailed permissions
CREATE POLICY "Bosses can update employee detailed permissions"
  ON employee_detailed_permissions
  FOR UPDATE
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- Bosses can delete their employees' detailed permissions
CREATE POLICY "Bosses can delete employee detailed permissions"
  ON employee_detailed_permissions
  FOR DELETE
  USING (boss_id IN (SELECT id FROM bosses));

-- Create trigger for automatic updated_at
CREATE TRIGGER update_employee_detailed_permissions_updated_at
  BEFORE UPDATE ON employee_detailed_permissions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create function to initialize default detailed permissions for new employees
CREATE OR REPLACE FUNCTION initialize_employee_detailed_permissions()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert default detailed permissions (all denied except home and settings view)
  INSERT INTO employee_detailed_permissions (employee_id, boss_id, page_name, can_view, can_add, can_edit, can_delete)
  VALUES 
    (NEW.id, NEW.boss_id, 'home', true, false, false, false),
    (NEW.id, NEW.boss_id, 'transactions', false, false, false, false),
    (NEW.id, NEW.boss_id, 'quotations-invoices', false, false, false, false),
    (NEW.id, NEW.boss_id, 'reports', false, false, false, false),
    (NEW.id, NEW.boss_id, 'clients', false, false, false, false),
    (NEW.id, NEW.boss_id, 'suppliers', false, false, false, false),
    (NEW.id, NEW.boss_id, 'services', false, false, false, false),
    (NEW.id, NEW.boss_id, 'settings', true, false, false, false);
  
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically initialize detailed permissions for new employees
CREATE TRIGGER initialize_employee_detailed_permissions_trigger
  AFTER INSERT ON employees
  FOR EACH ROW
  EXECUTE FUNCTION initialize_employee_detailed_permissions();