/*
  # إنشاء نظام إدارة المهام والمشاريع

  1. الجداول الجديدة
    - `projects` - جدول المشاريع
      - `id` (uuid, primary key)
      - `boss_id` (uuid, foreign key)
      - `name` (text)
      - `description` (text, optional)
      - `start_date` (date)
      - `end_date` (date, optional)
      - `status` (text)
      - `priority` (text)
      - `budget` (numeric, optional)
      - `progress` (integer, 0-100)
      - `color` (text, optional)
      - `is_active` (boolean, default true)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `tasks` - جدول المهام
      - `id` (uuid, primary key)
      - `boss_id` (uuid, foreign key)
      - `project_id` (uuid, foreign key, optional)
      - `title` (text)
      - `description` (text, optional)
      - `start_date` (date)
      - `end_date` (date, optional)
      - `start_time` (time, optional)
      - `end_time` (time, optional)
      - `status` (text)
      - `priority` (text)
      - `assigned_to` (uuid, foreign key to employees, optional)
      - `category` (text, optional)
      - `tags` (jsonb array)
      - `reminder_date` (timestamp, optional)
      - `is_recurring` (boolean, default false)
      - `recurrence_pattern` (text, optional)
      - `completion_percentage` (integer, 0-100)
      - `estimated_hours` (numeric, optional)
      - `actual_hours` (numeric, optional)
      - `is_active` (boolean, default true)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `task_comments` - جدول تعليقات المهام
      - `id` (uuid, primary key)
      - `task_id` (uuid, foreign key)
      - `user_id` (uuid)
      - `user_name` (text)
      - `comment` (text)
      - `created_at` (timestamp)

  2. الأمان
    - تفعيل RLS على جميع الجداول
    - إضافة سياسات للمديرين والموظفين
    - فهارس للبحث السريع

  3. الفهارس
    - فهارس على التواريخ للتقويم
    - فهارس على الحالة والأولوية
    - فهارس على المشاريع والمستخدمين المعينين
*/

-- إنشاء جدول المشاريع
CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  start_date date NOT NULL DEFAULT CURRENT_DATE,
  end_date date,
  status text DEFAULT 'planning' CHECK (status IN ('planning', 'active', 'on_hold', 'completed', 'cancelled')),
  priority text DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  budget numeric(12,2) DEFAULT 0.00,
  progress integer DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
  color text DEFAULT '#3b82f6',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء جدول المهام
CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  project_id uuid REFERENCES projects(id) ON DELETE SET NULL,
  title text NOT NULL,
  description text,
  start_date date NOT NULL DEFAULT CURRENT_DATE,
  end_date date,
  start_time time,
  end_time time,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled', 'on_hold')),
  priority text DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  assigned_to uuid REFERENCES employees(id) ON DELETE SET NULL,
  category text,
  tags jsonb DEFAULT '[]'::jsonb,
  reminder_date timestamptz,
  is_recurring boolean DEFAULT false,
  recurrence_pattern text CHECK (recurrence_pattern IN ('daily', 'weekly', 'monthly', 'yearly') OR recurrence_pattern IS NULL),
  completion_percentage integer DEFAULT 0 CHECK (completion_percentage >= 0 AND completion_percentage <= 100),
  estimated_hours numeric(5,2) DEFAULT 0.00,
  actual_hours numeric(5,2) DEFAULT 0.00,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء جدول تعليقات المهام
CREATE TABLE IF NOT EXISTS task_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  user_name text NOT NULL,
  comment text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- إنشاء فهارس للمشاريع
CREATE INDEX IF NOT EXISTS idx_projects_boss_id ON projects(boss_id);
CREATE INDEX IF NOT EXISTS idx_projects_start_date ON projects(start_date);
CREATE INDEX IF NOT EXISTS idx_projects_end_date ON projects(end_date);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
CREATE INDEX IF NOT EXISTS idx_projects_priority ON projects(priority);
CREATE INDEX IF NOT EXISTS idx_projects_is_active ON projects(is_active);

-- إنشاء فهارس للمهام
CREATE INDEX IF NOT EXISTS idx_tasks_boss_id ON tasks(boss_id);
CREATE INDEX IF NOT EXISTS idx_tasks_project_id ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_tasks_start_date ON tasks(start_date);
CREATE INDEX IF NOT EXISTS idx_tasks_end_date ON tasks(end_date);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_priority ON tasks(priority);
CREATE INDEX IF NOT EXISTS idx_tasks_assigned_to ON tasks(assigned_to);
CREATE INDEX IF NOT EXISTS idx_tasks_category ON tasks(category);
CREATE INDEX IF NOT EXISTS idx_tasks_is_recurring ON tasks(is_recurring);
CREATE INDEX IF NOT EXISTS idx_tasks_reminder_date ON tasks(reminder_date);
CREATE INDEX IF NOT EXISTS idx_tasks_is_active ON tasks(is_active);

-- إنشاء فهارس لتعليقات المهام
CREATE INDEX IF NOT EXISTS idx_task_comments_task_id ON task_comments(task_id);
CREATE INDEX IF NOT EXISTS idx_task_comments_user_id ON task_comments(user_id);
CREATE INDEX IF NOT EXISTS idx_task_comments_created_at ON task_comments(created_at);

-- تفعيل RLS على جميع الجداول
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_comments ENABLE ROW LEVEL SECURITY;

-- سياسات المشاريع للمديرين
CREATE POLICY "Bosses can manage their own projects"
  ON projects
  FOR ALL
  TO public
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- سياسات المشاريع للموظفين
CREATE POLICY "Employees can access boss projects"
  ON projects
  FOR ALL
  TO public
  USING (boss_id IN (SELECT boss_id FROM employees))
  WITH CHECK (boss_id IN (SELECT boss_id FROM employees));

-- سياسات المهام للمديرين
CREATE POLICY "Bosses can manage their own tasks"
  ON tasks
  FOR ALL
  TO public
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- سياسات المهام للموظفين
CREATE POLICY "Employees can access boss tasks"
  ON tasks
  FOR ALL
  TO public
  USING (boss_id IN (SELECT boss_id FROM employees))
  WITH CHECK (boss_id IN (SELECT boss_id FROM employees));

-- سياسات تعليقات المهام للمديرين
CREATE POLICY "Bosses can manage task comments"
  ON task_comments
  FOR ALL
  TO public
  USING (task_id IN (SELECT id FROM tasks WHERE boss_id IN (SELECT id FROM bosses)))
  WITH CHECK (task_id IN (SELECT id FROM tasks WHERE boss_id IN (SELECT id FROM bosses)));

-- سياسات تعليقات المهام للموظفين
CREATE POLICY "Employees can manage task comments"
  ON task_comments
  FOR ALL
  TO public
  USING (task_id IN (SELECT id FROM tasks WHERE boss_id IN (SELECT boss_id FROM employees)))
  WITH CHECK (task_id IN (SELECT id FROM tasks WHERE boss_id IN (SELECT boss_id FROM employees)));

-- إضافة triggers لتحديث updated_at
CREATE TRIGGER update_projects_updated_at
  BEFORE UPDATE ON projects
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_tasks_updated_at
  BEFORE UPDATE ON tasks
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();