/*
  # إنشاء جدول الموردين

  1. الجداول الجديدة
    - `suppliers` - جدول الموردين
      - `id` (uuid, primary key)
      - `boss_id` (uuid, foreign key)
      - `name` (text)
      - `company` (text)
      - `email` (text)
      - `phone` (text)
      - `website` (text, optional)
      - `address` (text, optional)
      - `contact_person` (text, optional)
      - `payment_method` (text, optional)
      - `rating` (integer, default 5)
      - `supplier_provides` (jsonb, array of strings)
      - `notes` (text, optional)
      - `total_orders` (integer, default 0)
      - `total_amount` (decimal, default 0)
      - `is_active` (boolean, default true)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. الأمان
    - تفعيل RLS على جدول suppliers
    - إضافة سياسات للوصول الآمن للبيانات
    - المديرين يمكنهم إدارة مورديهم فقط
    - الموظفين يمكنهم الوصول لموردي المدير حسب الصلاحيات

  3. الفهارس
    - فهرس على boss_id لتحسين الأداء
    - فهرس على email للبحث السريع
    - فهرس على is_active للتصفية
    - فهرس على name للبحث
*/

-- إنشاء جدول الموردين
CREATE TABLE IF NOT EXISTS suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  name text NOT NULL,
  company text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  website text,
  address text,
  contact_person text,
  payment_method text,
  rating integer DEFAULT 5 CHECK (rating >= 1 AND rating <= 5),
  supplier_provides jsonb DEFAULT '[]'::jsonb,
  notes text,
  total_orders integer DEFAULT 0,
  total_amount decimal(10,2) DEFAULT 0.00,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء فهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_suppliers_boss_id ON suppliers(boss_id);
CREATE INDEX IF NOT EXISTS idx_suppliers_email ON suppliers(email);
CREATE INDEX IF NOT EXISTS idx_suppliers_is_active ON suppliers(is_active);
CREATE INDEX IF NOT EXISTS idx_suppliers_name ON suppliers(name);
CREATE INDEX IF NOT EXISTS idx_suppliers_company ON suppliers(company);
CREATE INDEX IF NOT EXISTS idx_suppliers_rating ON suppliers(rating);

-- تفعيل Row Level Security
ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;

-- سياسات الأمان للموردين

-- المديرين يمكنهم قراءة مورديهم
CREATE POLICY "Bosses can read their own suppliers"
  ON suppliers
  FOR SELECT
  USING (boss_id IN (SELECT id FROM bosses));

-- الموظفين يمكنهم قراءة موردي المدير
CREATE POLICY "Employees can read boss suppliers"
  ON suppliers
  FOR SELECT
  USING (boss_id IN (SELECT boss_id FROM employees));

-- المديرين يمكنهم إضافة موردين جدد
CREATE POLICY "Bosses can insert suppliers"
  ON suppliers
  FOR INSERT
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- الموظفين يمكنهم إضافة موردين (حسب الصلاحيات)
CREATE POLICY "Employees can insert suppliers for their boss"
  ON suppliers
  FOR INSERT
  WITH CHECK (boss_id IN (SELECT boss_id FROM employees));

-- المديرين يمكنهم تحديث مورديهم
CREATE POLICY "Bosses can update their own suppliers"
  ON suppliers
  FOR UPDATE
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- الموظفين يمكنهم تحديث موردي المدير (حسب الصلاحيات)
CREATE POLICY "Employees can update boss suppliers"
  ON suppliers
  FOR UPDATE
  USING (boss_id IN (SELECT boss_id FROM employees))
  WITH CHECK (boss_id IN (SELECT boss_id FROM employees));

-- المديرين يمكنهم حذف مورديهم
CREATE POLICY "Bosses can delete their own suppliers"
  ON suppliers
  FOR DELETE
  USING (boss_id IN (SELECT id FROM bosses));

-- الموظفين يمكنهم حذف موردي المدير (حسب الصلاحيات)
CREATE POLICY "Employees can delete boss suppliers"
  ON suppliers
  FOR DELETE
  USING (boss_id IN (SELECT boss_id FROM employees));

-- إنشاء trigger لتحديث updated_at تلقائياً
DROP TRIGGER IF EXISTS update_suppliers_updated_at ON suppliers;
CREATE TRIGGER update_suppliers_updated_at
  BEFORE UPDATE ON suppliers
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- إضافة قيود فريدة مركبة لضمان عدم تكرار الإيميل لنفس المدير
CREATE UNIQUE INDEX IF NOT EXISTS idx_suppliers_boss_email_unique 
  ON suppliers(boss_id, email);