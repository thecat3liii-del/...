/*
  # Create Quotations Table

  1. New Tables
    - `quotations`
      - `id` (uuid, primary key)
      - `boss_id` (uuid, foreign key)
      - `quotation_number` (text, unique)
      - `client_id` (uuid, foreign key, optional)
      - `client_name` (text, optional)
      - `client_email` (text, optional)
      - `client_phone` (text, optional)
      - `client_address` (text, optional)
      - `issue_date` (date)
      - `valid_until` (date)
      - `items` (jsonb) - array of quotation items
      - `subtotal` (numeric)
      - `tax_rate` (numeric)
      - `tax_amount` (numeric)
      - `discount_rate` (numeric)
      - `discount_amount` (numeric)
      - `total_amount` (numeric)
      - `notes` (text, optional)
      - `status` (text, default 'draft')
      - `is_active` (boolean, default true)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `quotations` table
    - Add policies for bosses to manage their own quotations
    - Add policies for employees to access boss quotations based on permissions

  3. Indexes
    - Index on boss_id for performance
    - Index on quotation_number for searching
    - Index on client_id for filtering
    - Index on issue_date for sorting
    - Index on status for filtering
*/

-- Create quotations table
CREATE TABLE IF NOT EXISTS quotations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  quotation_number text NOT NULL,
  client_id uuid REFERENCES clients(id) ON DELETE SET NULL,
  client_name text,
  client_email text,
  client_phone text,
  client_address text,
  issue_date date NOT NULL DEFAULT CURRENT_DATE,
  valid_until date NOT NULL,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  subtotal numeric(12,2) NOT NULL DEFAULT 0.00,
  tax_rate numeric(5,2) DEFAULT 0.00,
  tax_amount numeric(12,2) DEFAULT 0.00,
  discount_rate numeric(5,2) DEFAULT 0.00,
  discount_amount numeric(12,2) DEFAULT 0.00,
  total_amount numeric(12,2) NOT NULL DEFAULT 0.00,
  notes text,
  status text DEFAULT 'draft' CHECK (status IN ('draft', 'sent', 'accepted', 'rejected', 'expired')),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_quotations_boss_id ON quotations(boss_id);
CREATE INDEX IF NOT EXISTS idx_quotations_quotation_number ON quotations(quotation_number);
CREATE INDEX IF NOT EXISTS idx_quotations_client_id ON quotations(client_id);
CREATE INDEX IF NOT EXISTS idx_quotations_issue_date ON quotations(issue_date);
CREATE INDEX IF NOT EXISTS idx_quotations_status ON quotations(status);
CREATE INDEX IF NOT EXISTS idx_quotations_is_active ON quotations(is_active);

-- Create unique index for quotation number per boss
CREATE UNIQUE INDEX IF NOT EXISTS idx_quotations_boss_number_unique 
  ON quotations(boss_id, quotation_number);

-- Enable Row Level Security
ALTER TABLE quotations ENABLE ROW LEVEL SECURITY;

-- Security policies for quotations

-- Bosses can read their own quotations
CREATE POLICY "Bosses can read their own quotations"
  ON quotations
  FOR SELECT
  USING (boss_id IN (SELECT id FROM bosses));

-- Employees can read boss quotations
CREATE POLICY "Employees can read boss quotations"
  ON quotations
  FOR SELECT
  USING (boss_id IN (SELECT boss_id FROM employees));

-- Bosses can insert quotations
CREATE POLICY "Bosses can insert quotations"
  ON quotations
  FOR INSERT
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- Employees can insert quotations for their boss
CREATE POLICY "Employees can insert quotations for their boss"
  ON quotations
  FOR INSERT
  WITH CHECK (boss_id IN (SELECT boss_id FROM employees));

-- Bosses can update their own quotations
CREATE POLICY "Bosses can update their own quotations"
  ON quotations
  FOR UPDATE
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- Employees can update boss quotations
CREATE POLICY "Employees can update boss quotations"
  ON quotations
  FOR UPDATE
  USING (boss_id IN (SELECT boss_id FROM employees))
  WITH CHECK (boss_id IN (SELECT boss_id FROM employees));

-- Bosses can delete their own quotations
CREATE POLICY "Bosses can delete their own quotations"
  ON quotations
  FOR DELETE
  USING (boss_id IN (SELECT id FROM bosses));

-- Employees can delete boss quotations
CREATE POLICY "Employees can delete boss quotations"
  ON quotations
  FOR DELETE
  USING (boss_id IN (SELECT boss_id FROM employees));

-- Create trigger for automatic updated_at
CREATE TRIGGER update_quotations_updated_at
  BEFORE UPDATE ON quotations
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();