/*
  # إضافة عمود صورة الملف الشخصي

  1. التغييرات
    - إضافة عمود `profile_image_url` لجدول المديرين
    - إضافة عمود `profile_image_url` لجدول الموظفين
    - إنشاء buckets للتخزين في Supabase Storage

  2. الأمان
    - إضافة سياسات للوصول لصور الملف الشخصي
    - إضافة سياسات للشعارات المخصصة
*/

-- إضافة عمود صورة الملف الشخصي لجدول المديرين
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'bosses' AND column_name = 'profile_image_url'
  ) THEN
    ALTER TABLE bosses ADD COLUMN profile_image_url text;
  END IF;
END $$;

-- إضافة عمود صورة الملف الشخصي لجدول الموظفين
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'employees' AND column_name = 'profile_image_url'
  ) THEN
    ALTER TABLE employees ADD COLUMN profile_image_url text;
  END IF;
END $$;

-- إنشاء bucket لصور الملف الشخصي
INSERT INTO storage.buckets (id, name, public)
VALUES ('profile-images', 'profile-images', true)
ON CONFLICT (id) DO NOTHING;

-- إنشاء bucket للشعارات المخصصة
INSERT INTO storage.buckets (id, name, public)
VALUES ('custom-logos', 'custom-logos', true)
ON CONFLICT (id) DO NOTHING;

-- سياسات التخزين لصور الملف الشخصي
CREATE POLICY "Anyone can view profile images"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'profile-images');

CREATE POLICY "Users can upload their own profile images"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'profile-images');

CREATE POLICY "Users can update their own profile images"
  ON storage.objects FOR UPDATE
  USING (bucket_id = 'profile-images');

CREATE POLICY "Users can delete their own profile images"
  ON storage.objects FOR DELETE
  USING (bucket_id = 'profile-images');

-- سياسات التخزين للشعارات المخصصة
CREATE POLICY "Anyone can view custom logos"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'custom-logos');

CREATE POLICY "Users can upload their own custom logos"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'custom-logos');

CREATE POLICY "Users can update their own custom logos"
  ON storage.objects FOR UPDATE
  USING (bucket_id = 'custom-logos');

CREATE POLICY "Users can delete their own custom logos"
  ON storage.objects FOR DELETE
  USING (bucket_id = 'custom-logos');