/*
  # إضافة حقول إضافية للموظفين ونظام المصاريف

  1. التغييرات على جدول employees
    - إضافة حقول إضافية مطلوبة واختيارية
    - إضافة حقل الراتب الشهري
    - إضافة معلومات شخصية ومهنية

  2. جدول جديد employee_expenses
    - `id` (uuid, primary key)
    - `employee_id` (uuid, foreign key)
    - `boss_id` (uuid, foreign key)
    - `expense_type` (text)
    - `amount` (numeric)
    - `frequency` (text - monthly/yearly)
    - `description` (text, optional)
    - `is_active` (boolean, default true)
    - `created_at` (timestamp)
    - `updated_at` (timestamp)

  3. الأمان
    - تفعيل RLS على الجدول الجديد
    - إضافة سياسات للوصول الآمن
*/

-- إضافة الحقول الجديدة لجدول الموظفين
DO $$
BEGIN
  -- Phone Number (mandatory)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'employees' AND column_name = 'phone'
  ) THEN
    ALTER TABLE employees ADD COLUMN phone text NOT NULL DEFAULT '';
  END IF;

  -- Salary (mandatory)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'employees' AND column_name = 'salary'
  ) THEN
    ALTER TABLE employees ADD COLUMN salary numeric(10,2) NOT NULL DEFAULT 0.00;
  END IF;

  -- Description (optional)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'employees' AND column_name = 'description'
  ) THEN
    ALTER TABLE employees ADD COLUMN description text;
  END IF;

  -- Residence Location (optional)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'employees' AND column_name = 'residence_location'
  ) THEN
    ALTER TABLE employees ADD COLUMN residence_location text;
  END IF;

  -- Position (optional)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'employees' AND column_name = 'position'
  ) THEN
    ALTER TABLE employees ADD COLUMN position text;
  END IF;

  -- Rating (optional)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'employees' AND column_name = 'rating'
  ) THEN
    ALTER TABLE employees ADD COLUMN rating integer DEFAULT 5 CHECK (rating >= 1 AND rating <= 5);
  END IF;

  -- Visa (optional)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'employees' AND column_name = 'visa'
  ) THEN
    ALTER TABLE employees ADD COLUMN visa text;
  END IF;

  -- Transportation Allowance (optional)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'employees' AND column_name = 'transportation_allowance'
  ) THEN
    ALTER TABLE employees ADD COLUMN transportation_allowance numeric(10,2) DEFAULT 0.00;
  END IF;

  -- Insurance (optional)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'employees' AND column_name = 'insurance'
  ) THEN
    ALTER TABLE employees ADD COLUMN insurance numeric(10,2) DEFAULT 0.00;
  END IF;

  -- Years of Experience (optional)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'employees' AND column_name = 'years_of_experience'
  ) THEN
    ALTER TABLE employees ADD COLUMN years_of_experience integer DEFAULT 0;
  END IF;

  -- Skills (optional)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'employees' AND column_name = 'skills'
  ) THEN
    ALTER TABLE employees ADD COLUMN skills jsonb DEFAULT '[]'::jsonb;
  END IF;

  -- Year of Birth (optional)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'employees' AND column_name = 'year_of_birth'
  ) THEN
    ALTER TABLE employees ADD COLUMN year_of_birth integer;
  END IF;
END $$;

-- إنشاء جدول مصاريف الموظفين
CREATE TABLE IF NOT EXISTS employee_expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  expense_type text NOT NULL,
  amount numeric(10,2) NOT NULL DEFAULT 0.00,
  frequency text NOT NULL CHECK (frequency IN ('monthly', 'yearly')),
  description text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء فهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_employee_expenses_employee_id ON employee_expenses(employee_id);
CREATE INDEX IF NOT EXISTS idx_employee_expenses_boss_id ON employee_expenses(boss_id);
CREATE INDEX IF NOT EXISTS idx_employee_expenses_frequency ON employee_expenses(frequency);
CREATE INDEX IF NOT EXISTS idx_employee_expenses_is_active ON employee_expenses(is_active);

-- تفعيل Row Level Security
ALTER TABLE employee_expenses ENABLE ROW LEVEL SECURITY;

-- سياسات الأمان لمصاريف الموظفين

-- المديرين يمكنهم قراءة مصاريف موظفيهم
CREATE POLICY "Bosses can read their employees expenses"
  ON employee_expenses
  FOR SELECT
  USING (boss_id IN (SELECT id FROM bosses));

-- الموظفين يمكنهم قراءة مصاريفهم الخاصة
CREATE POLICY "Employees can read their own expenses"
  ON employee_expenses
  FOR SELECT
  USING (employee_id IN (SELECT id FROM employees));

-- المديرين يمكنهم إضافة مصاريف لموظفيهم
CREATE POLICY "Bosses can insert employee expenses"
  ON employee_expenses
  FOR INSERT
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- المديرين يمكنهم تحديث مصاريف موظفيهم
CREATE POLICY "Bosses can update employee expenses"
  ON employee_expenses
  FOR UPDATE
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- المديرين يمكنهم حذف مصاريف موظفيهم
CREATE POLICY "Bosses can delete employee expenses"
  ON employee_expenses
  FOR DELETE
  USING (boss_id IN (SELECT id FROM bosses));

-- إنشاء trigger لتحديث updated_at تلقائياً
CREATE TRIGGER update_employee_expenses_updated_at
  BEFORE UPDATE ON employee_expenses
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- إضافة فهارس إضافية للحقول الجديدة في جدول employees
CREATE INDEX IF NOT EXISTS idx_employees_phone ON employees(phone);
CREATE INDEX IF NOT EXISTS idx_employees_position ON employees(position);
CREATE INDEX IF NOT EXISTS idx_employees_rating ON employees(rating);
CREATE INDEX IF NOT EXISTS idx_employees_salary ON employees(salary);