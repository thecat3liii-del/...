/*
  # إنشاء جدول المعاملات

  1. الجداول الجديدة
    - `transactions` - جدول المعاملات
      - `id` (uuid, primary key)
      - `boss_id` (uuid, foreign key)
      - `amount` (numeric)
      - `cost` (numeric)
      - `vat` (numeric, optional)
      - `profit` (numeric)
      - `client_id` (uuid, foreign key, optional)
      - `client_name` (text, optional)
      - `supplier_id` (uuid, foreign key, optional)
      - `supplier_name` (text, optional)
      - `service_ids` (jsonb array, optional)
      - `service_names` (jsonb array, optional)
      - `transaction_date` (date)
      - `payment_method` (text, optional)
      - `status` (text, optional)
      - `description` (text, optional)
      - `priority` (text, optional)
      - `category` (text, optional)
      - `vat_percentage` (numeric, optional)
      - `total_with_vat` (numeric, optional)
      - `month` (integer)
      - `year` (integer)
      - `is_active` (boolean, default true)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. الأمان
    - تفعيل RLS على جدول transactions
    - إضافة سياسات للوصول الآمن للبيانات
    - المديرين يمكنهم إدارة معاملاتهم فقط
    - الموظفين يمكنهم الوصول لمعاملات المدير حسب الصلاحيات

  3. الفهارس
    - فهرس على boss_id لتحسين الأداء
    - فهرس على client_id للبحث السريع
    - فهرس على supplier_id للبحث السريع
    - فهرس على transaction_date للتصفية
    - فهرس على month و year للتقارير
*/

-- إنشاء جدول المعاملات
CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  amount numeric(12,2) NOT NULL DEFAULT 0.00,
  cost numeric(12,2) NOT NULL DEFAULT 0.00,
  vat numeric(12,2) DEFAULT 0.00,
  profit numeric(12,2) NOT NULL DEFAULT 0.00,
  client_id uuid REFERENCES clients(id) ON DELETE SET NULL,
  client_name text,
  supplier_id uuid REFERENCES suppliers(id) ON DELETE SET NULL,
  supplier_name text,
  service_ids jsonb DEFAULT '[]'::jsonb,
  service_names jsonb DEFAULT '[]'::jsonb,
  transaction_date date NOT NULL DEFAULT CURRENT_DATE,
  payment_method text,
  status text,
  description text,
  priority text,
  category text,
  vat_percentage numeric(5,2) DEFAULT 0.00,
  total_with_vat numeric(12,2) DEFAULT 0.00,
  month integer NOT NULL,
  year integer NOT NULL,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء فهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_transactions_boss_id ON transactions(boss_id);
CREATE INDEX IF NOT EXISTS idx_transactions_client_id ON transactions(client_id);
CREATE INDEX IF NOT EXISTS idx_transactions_supplier_id ON transactions(supplier_id);
CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(transaction_date);
CREATE INDEX IF NOT EXISTS idx_transactions_month_year ON transactions(month, year);
CREATE INDEX IF NOT EXISTS idx_transactions_amount ON transactions(amount);
CREATE INDEX IF NOT EXISTS idx_transactions_profit ON transactions(profit);
CREATE INDEX IF NOT EXISTS idx_transactions_is_active ON transactions(is_active);

-- تفعيل Row Level Security
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

-- سياسات الأمان للمعاملات

-- المديرين يمكنهم قراءة معاملاتهم
CREATE POLICY "Bosses can read their own transactions"
  ON transactions
  FOR SELECT
  USING (boss_id IN (SELECT id FROM bosses));

-- الموظفين يمكنهم قراءة معاملات المدير
CREATE POLICY "Employees can read boss transactions"
  ON transactions
  FOR SELECT
  USING (boss_id IN (SELECT boss_id FROM employees));

-- المديرين يمكنهم إضافة معاملات جديدة
CREATE POLICY "Bosses can insert transactions"
  ON transactions
  FOR INSERT
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- الموظفين يمكنهم إضافة معاملات (حسب الصلاحيات)
CREATE POLICY "Employees can insert transactions for their boss"
  ON transactions
  FOR INSERT
  WITH CHECK (boss_id IN (SELECT boss_id FROM employees));

-- المديرين يمكنهم تحديث معاملاتهم
CREATE POLICY "Bosses can update their own transactions"
  ON transactions
  FOR UPDATE
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- الموظفين يمكنهم تحديث معاملات المدير (حسب الصلاحيات)
CREATE POLICY "Employees can update boss transactions"
  ON transactions
  FOR UPDATE
  USING (boss_id IN (SELECT boss_id FROM employees))
  WITH CHECK (boss_id IN (SELECT boss_id FROM employees));

-- المديرين يمكنهم حذف معاملاتهم
CREATE POLICY "Bosses can delete their own transactions"
  ON transactions
  FOR DELETE
  USING (boss_id IN (SELECT id FROM bosses));

-- الموظفين يمكنهم حذف معاملات المدير (حسب الصلاحيات)
CREATE POLICY "Employees can delete boss transactions"
  ON transactions
  FOR DELETE
  USING (boss_id IN (SELECT boss_id FROM employees));

-- إنشاء trigger لتحديث updated_at تلقائياً
CREATE TRIGGER update_transactions_updated_at
  BEFORE UPDATE ON transactions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- إنشاء trigger لحساب الشهر والسنة تلقائياً
CREATE OR REPLACE FUNCTION update_transaction_month_year()
RETURNS TRIGGER AS $$
BEGIN
  NEW.month = EXTRACT(MONTH FROM NEW.transaction_date);
  NEW.year = EXTRACT(YEAR FROM NEW.transaction_date);
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_transaction_month_year_trigger
  BEFORE INSERT OR UPDATE ON transactions
  FOR EACH ROW
  EXECUTE FUNCTION update_transaction_month_year();