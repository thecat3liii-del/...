/*
  # إضافة أرقام الفواتير وإشعارات التسليم لجدول المعاملات

  1. التغييرات
    - إضافة حقل `invoice_number` لحفظ رقم الفاتورة المرتبطة بالمعاملة
    - إضافة حقل `delivery_number` لحفظ رقم إشعار التسليم المرتبط بالمعاملة
    - إضافة حقل `invoice_generated` لتتبع ما إذا تم إنشاء فاتورة للمعاملة
    - إضافة حقل `delivery_generated` لتتبع ما إذا تم إنشاء إشعار تسليم للمعاملة

  2. الفهارس
    - فهرس على invoice_number للبحث السريع
    - فهرس على delivery_number للبحث السريع
    - فهرس على invoice_generated للتصفية
    - فهرس على delivery_generated للتصفية

  3. ملاحظات
    - هذه الحقول ستساعد في ربط كل معاملة برقم فاتورة ورقم توصيل ثابت
    - لن يتم إنشاء أرقام جديدة إذا كانت موجودة مسبقاً
*/

-- إضافة الحقول الجديدة لجدول المعاملات
DO $$
BEGIN
  -- إضافة حقل رقم الفاتورة
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'transactions' AND column_name = 'invoice_number'
  ) THEN
    ALTER TABLE transactions ADD COLUMN invoice_number text;
  END IF;

  -- إضافة حقل رقم إشعار التسليم
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'transactions' AND column_name = 'delivery_number'
  ) THEN
    ALTER TABLE transactions ADD COLUMN delivery_number text;
  END IF;

  -- إضافة حقل تتبع إنشاء الفاتورة
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'transactions' AND column_name = 'invoice_generated'
  ) THEN
    ALTER TABLE transactions ADD COLUMN invoice_generated boolean DEFAULT false;
  END IF;

  -- إضافة حقل تتبع إنشاء إشعار التسليم
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'transactions' AND column_name = 'delivery_generated'
  ) THEN
    ALTER TABLE transactions ADD COLUMN delivery_generated boolean DEFAULT false;
  END IF;
END $$;

-- إنشاء فهارس للحقول الجديدة
CREATE INDEX IF NOT EXISTS idx_transactions_invoice_number ON transactions(invoice_number);
CREATE INDEX IF NOT EXISTS idx_transactions_delivery_number ON transactions(delivery_number);
CREATE INDEX IF NOT EXISTS idx_transactions_invoice_generated ON transactions(invoice_generated);
CREATE INDEX IF NOT EXISTS idx_transactions_delivery_generated ON transactions(delivery_generated);

-- إنشاء فهرس فريد لرقم الفاتورة لكل مدير (إذا كان موجود)
CREATE UNIQUE INDEX IF NOT EXISTS idx_transactions_boss_invoice_unique 
  ON transactions(boss_id, invoice_number) 
  WHERE invoice_number IS NOT NULL;

-- إنشاء فهرس فريد لرقم إشعار التسليم لكل مدير (إذا كان موجود)
CREATE UNIQUE INDEX IF NOT EXISTS idx_transactions_boss_delivery_unique 
  ON transactions(boss_id, delivery_number) 
  WHERE delivery_number IS NOT NULL;