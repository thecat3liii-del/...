/*
  # إنشاء جدول العملاء

  1. الجداول الجديدة
    - `clients` - جدول العملاء
      - `id` (uuid, primary key)
      - `boss_id` (uuid, foreign key)
      - `name` (text)
      - `email` (text)
      - `phone` (text)
      - `address` (text, optional)
      - `company` (text, optional)
      - `website` (text, optional)
      - `social_media` (jsonb, optional)
      - `notes` (text, optional)
      - `is_active` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. الأمان
    - تفعيل RLS على جدول clients
    - إضافة سياسات للوصول الآمن للبيانات
    - المديرين يمكنهم إدارة عملائهم فقط
    - الموظفين يمكنهم الوصول لعملاء المدير حسب الصلاحيات

  3. الفهارس
    - فهرس على boss_id لتحسين الأداء
    - فهرس على email للبحث السريع
    - فهرس على is_active للتصفية
*/

-- إنشاء جدول العملاء
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  address text,
  company text,
  website text,
  social_media jsonb DEFAULT '[]'::jsonb,
  notes text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء فهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_clients_boss_id ON clients(boss_id);
CREATE INDEX IF NOT EXISTS idx_clients_email ON clients(email);
CREATE INDEX IF NOT EXISTS idx_clients_is_active ON clients(is_active);
CREATE INDEX IF NOT EXISTS idx_clients_name ON clients(name);

-- تفعيل Row Level Security
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;

-- سياسات الأمان للعملاء

-- المديرين يمكنهم قراءة عملائهم
CREATE POLICY "Bosses can read their own clients"
  ON clients
  FOR SELECT
  USING (boss_id IN (SELECT id FROM bosses));

-- الموظفين يمكنهم قراءة عملاء المدير
CREATE POLICY "Employees can read boss clients"
  ON clients
  FOR SELECT
  USING (boss_id IN (SELECT boss_id FROM employees));

-- المديرين يمكنهم إضافة عملاء جدد
CREATE POLICY "Bosses can insert clients"
  ON clients
  FOR INSERT
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- الموظفين يمكنهم إضافة عملاء (حسب الصلاحيات)
CREATE POLICY "Employees can insert clients for their boss"
  ON clients
  FOR INSERT
  WITH CHECK (boss_id IN (SELECT boss_id FROM employees));

-- المديرين يمكنهم تحديث عملائهم
CREATE POLICY "Bosses can update their own clients"
  ON clients
  FOR UPDATE
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- الموظفين يمكنهم تحديث عملاء المدير (حسب الصلاحيات)
CREATE POLICY "Employees can update boss clients"
  ON clients
  FOR UPDATE
  USING (boss_id IN (SELECT boss_id FROM employees))
  WITH CHECK (boss_id IN (SELECT boss_id FROM employees));

-- المديرين يمكنهم حذف عملائهم
CREATE POLICY "Bosses can delete their own clients"
  ON clients
  FOR DELETE
  USING (boss_id IN (SELECT id FROM bosses));

-- الموظفين يمكنهم حذف عملاء المدير (حسب الصلاحيات)
CREATE POLICY "Employees can delete boss clients"
  ON clients
  FOR DELETE
  USING (boss_id IN (SELECT boss_id FROM employees));

-- إنشاء trigger لتحديث updated_at تلقائياً
DROP TRIGGER IF EXISTS update_clients_updated_at ON clients;
CREATE TRIGGER update_clients_updated_at
  BEFORE UPDATE ON clients
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- إضافة قيود فريدة مركبة لضمان عدم تكرار الإيميل لنفس المدير
CREATE UNIQUE INDEX IF NOT EXISTS idx_clients_boss_email_unique 
  ON clients(boss_id, email);