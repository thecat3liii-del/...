/*
  # Create Employee Page Permissions Table

  1. New Tables
    - `employee_page_permissions`
      - `id` (uuid, primary key)
      - `employee_id` (uuid, foreign key to employees)
      - `boss_id` (uuid, foreign key to bosses)
      - `page_name` (text) - name of the page (home, transactions, clients, etc.)
      - `is_allowed` (boolean) - whether employee can access this page
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `employee_page_permissions` table
    - Add policies for bosses to manage their employees' page permissions
    - Add policies for employees to read their own page permissions

  3. Indexes
    - Index on employee_id for performance
    - Index on boss_id for performance
    - Index on page_name for filtering
    - Unique index on (employee_id, page_name) to prevent duplicates
*/

-- Create employee page permissions table
CREATE TABLE IF NOT EXISTS employee_page_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  page_name text NOT NULL CHECK (page_name IN (
    'home', 'transactions', 'quotations-invoices', 'reports', 
    'clients', 'suppliers', 'services', 'settings'
  )),
  is_allowed boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_employee_page_permissions_employee_id ON employee_page_permissions(employee_id);
CREATE INDEX IF NOT EXISTS idx_employee_page_permissions_boss_id ON employee_page_permissions(boss_id);
CREATE INDEX IF NOT EXISTS idx_employee_page_permissions_page_name ON employee_page_permissions(page_name);
CREATE INDEX IF NOT EXISTS idx_employee_page_permissions_is_allowed ON employee_page_permissions(is_allowed);

-- Create unique index to prevent duplicate permissions for same employee and page
CREATE UNIQUE INDEX IF NOT EXISTS idx_employee_page_permissions_unique 
  ON employee_page_permissions(employee_id, page_name);

-- Enable Row Level Security
ALTER TABLE employee_page_permissions ENABLE ROW LEVEL SECURITY;

-- Security policies for employee page permissions

-- Bosses can read their employees' page permissions
CREATE POLICY "Bosses can read their employees page permissions"
  ON employee_page_permissions
  FOR SELECT
  USING (boss_id IN (SELECT id FROM bosses));

-- Employees can read their own page permissions
CREATE POLICY "Employees can read their own page permissions"
  ON employee_page_permissions
  FOR SELECT
  USING (employee_id IN (SELECT id FROM employees));

-- Bosses can insert page permissions for their employees
CREATE POLICY "Bosses can insert employee page permissions"
  ON employee_page_permissions
  FOR INSERT
  WITH CHECK (boss_id IN (SELECT id FROM bosses) AND employee_id IN (
    SELECT id FROM employees WHERE boss_id = employee_page_permissions.boss_id
  ));

-- Bosses can update their employees' page permissions
CREATE POLICY "Bosses can update employee page permissions"
  ON employee_page_permissions
  FOR UPDATE
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- Bosses can delete their employees' page permissions
CREATE POLICY "Bosses can delete employee page permissions"
  ON employee_page_permissions
  FOR DELETE
  USING (boss_id IN (SELECT id FROM bosses));

-- Create trigger for automatic updated_at
CREATE TRIGGER update_employee_page_permissions_updated_at
  BEFORE UPDATE ON employee_page_permissions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create function to initialize default page permissions for new employees
CREATE OR REPLACE FUNCTION initialize_employee_page_permissions()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert default page permissions (all denied by default)
  INSERT INTO employee_page_permissions (employee_id, boss_id, page_name, is_allowed)
  VALUES 
    (NEW.id, NEW.boss_id, 'home', true),  -- Home is allowed by default
    (NEW.id, NEW.boss_id, 'transactions', false),
    (NEW.id, NEW.boss_id, 'quotations-invoices', false),
    (NEW.id, NEW.boss_id, 'reports', false),
    (NEW.id, NEW.boss_id, 'clients', false),
    (NEW.id, NEW.boss_id, 'suppliers', false),
    (NEW.id, NEW.boss_id, 'services', false),
    (NEW.id, NEW.boss_id, 'settings', true);  -- Settings is allowed by default
  
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically initialize page permissions for new employees
CREATE TRIGGER initialize_employee_page_permissions_trigger
  AFTER INSERT ON employees
  FOR EACH ROW
  EXECUTE FUNCTION initialize_employee_page_permissions();