/*
  # إضافة حقول جديدة لجدول الخدمات

  1. الحقول الجديدة
    - `subtypes_variants` (jsonb) - أنواع فرعية أو متغيرات للخدمة
    - `image_media` (text) - رابط الصورة أو الوسائط
    - `availability_active` (boolean) - حالة التوفر/النشاط
    - `expiration_validity` (date) - تاريخ انتهاء الصلاحية

  2. الفهارس
    - فهرس على حقل availability_active
    - فهرس على حقل expiration_validity

  3. ملاحظات
    - جميع الحقول اختيارية
    - الحقول الجديدة لا تؤثر على الوظائف الموجودة
*/

-- إضافة الحقول الجديدة لجدول الخدمات
DO $$
BEGIN
  -- إضافة حقل subtypes_variants
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'services' AND column_name = 'subtypes_variants'
  ) THEN
    ALTER TABLE services ADD COLUMN subtypes_variants jsonb DEFAULT '[]'::jsonb;
  END IF;

  -- إضافة حقل image_media
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'services' AND column_name = 'image_media'
  ) THEN
    ALTER TABLE services ADD COLUMN image_media text;
  END IF;

  -- إضافة حقل availability_active
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'services' AND column_name = 'availability_active'
  ) THEN
    ALTER TABLE services ADD COLUMN availability_active boolean DEFAULT true;
  END IF;

  -- إضافة حقل expiration_validity
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'services' AND column_name = 'expiration_validity'
  ) THEN
    ALTER TABLE services ADD COLUMN expiration_validity date;
  END IF;
END $$;

-- إضافة فهارس للحقول الجديدة
CREATE INDEX IF NOT EXISTS idx_services_availability_active ON services (availability_active);
CREATE INDEX IF NOT EXISTS idx_services_expiration_validity ON services (expiration_validity);
CREATE INDEX IF NOT EXISTS idx_services_subtypes_variants ON services USING gin (subtypes_variants);