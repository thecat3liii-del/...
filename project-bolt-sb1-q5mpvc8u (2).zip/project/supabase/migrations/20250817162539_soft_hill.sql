/*
  # إنشاء جداول الخدمات والمنتجات

  1. الجداول الجديدة
    - `services`
      - `id` (uuid, primary key)
      - `boss_id` (uuid, foreign key)
      - `name` (text)
      - `description` (text, optional)
      - `price` (numeric)
      - `category` (text, optional)
      - `subcategory` (text, optional)
      - `vat` (numeric, optional)
      - `storage_duration` (text, optional)
      - `is_active` (boolean, default true)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `service_categories`
      - `id` (uuid, primary key)
      - `boss_id` (uuid, foreign key)
      - `name` (text)
      - `subcategories` (jsonb array)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. الأمان
    - تفعيل RLS على جميع الجداول
    - إضافة سياسات للمديرين والموظفين
    - فهارس للبحث السريع

  3. التغييرات
    - إنشاء جداول جديدة للخدمات وفئاتها
    - إضافة العلاقات والقيود المناسبة
    - تفعيل التحديث التلقائي للتواريخ
*/

-- إنشاء جدول الخدمات والمنتجات
CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  price numeric(10,2) NOT NULL DEFAULT 0.00,
  category text,
  subcategory text,
  vat numeric(5,2) DEFAULT 0.00,
  storage_duration text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء جدول فئات الخدمات
CREATE TABLE IF NOT EXISTS service_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  name text NOT NULL,
  subcategories jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- تفعيل RLS
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_categories ENABLE ROW LEVEL SECURITY;

-- سياسات الخدمات للمديرين
CREATE POLICY "Bosses can manage their own services"
  ON services
  FOR ALL
  TO public
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- سياسات الخدمات للموظفين
CREATE POLICY "Employees can access boss services"
  ON services
  FOR ALL
  TO public
  USING (boss_id IN (SELECT boss_id FROM employees))
  WITH CHECK (boss_id IN (SELECT boss_id FROM employees));

-- سياسات فئات الخدمات للمديرين
CREATE POLICY "Bosses can manage their own service categories"
  ON service_categories
  FOR ALL
  TO public
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- سياسات فئات الخدمات للموظفين
CREATE POLICY "Employees can access boss service categories"
  ON service_categories
  FOR ALL
  TO public
  USING (boss_id IN (SELECT boss_id FROM employees))
  WITH CHECK (boss_id IN (SELECT boss_id FROM employees));

-- إنشاء فهارس للأداء
CREATE INDEX IF NOT EXISTS idx_services_boss_id ON services(boss_id);
CREATE INDEX IF NOT EXISTS idx_services_name ON services(name);
CREATE INDEX IF NOT EXISTS idx_services_category ON services(category);
CREATE INDEX IF NOT EXISTS idx_services_is_active ON services(is_active);
CREATE INDEX IF NOT EXISTS idx_services_price ON services(price);

CREATE INDEX IF NOT EXISTS idx_service_categories_boss_id ON service_categories(boss_id);
CREATE INDEX IF NOT EXISTS idx_service_categories_name ON service_categories(name);

-- إنشاء فهرس فريد لاسم الخدمة لكل مدير
CREATE UNIQUE INDEX IF NOT EXISTS idx_services_boss_name_unique ON services(boss_id, name);

-- إنشاء فهرس فريد لاسم الفئة لكل مدير
CREATE UNIQUE INDEX IF NOT EXISTS idx_service_categories_boss_name_unique ON service_categories(boss_id, name);

-- إضافة trigger لتحديث updated_at تلقائياً
CREATE TRIGGER update_services_updated_at
  BEFORE UPDATE ON services
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_service_categories_updated_at
  BEFORE UPDATE ON service_categories
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();