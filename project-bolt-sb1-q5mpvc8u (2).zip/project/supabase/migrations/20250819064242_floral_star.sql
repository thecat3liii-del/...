/*
  # استعادة جدول صلاحيات صفحات الموظفين

  1. الجداول المستعادة
    - `employee_page_permissions`
      - `id` (uuid, primary key)
      - `employee_id` (uuid, foreign key to employees)
      - `boss_id` (uuid, foreign key to bosses)
      - `page_name` (text) - اسم الصفحة
      - `is_allowed` (boolean) - صلاحية الوصول للصفحة
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. الأمان
    - تفعيل RLS على جدول employee_page_permissions
    - إضافة سياسات للمديرين لإدارة صلاحيات موظفيهم
    - إضافة سياسات للموظفين لقراءة صلاحياتهم

  3. الفهارس والقيود
    - فهارس للأداء
    - قيد فريد لمنع التكرار
    - triggers للتحديث التلقائي

  4. الوظائف
    - وظيفة تهيئة الصلاحيات الافتراضية للموظفين الجدد
    - trigger لتطبيق الصلاحيات تلقائياً
*/

-- إنشاء جدول صلاحيات صفحات الموظفين
CREATE TABLE IF NOT EXISTS employee_page_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  boss_id uuid NOT NULL REFERENCES bosses(id) ON DELETE CASCADE,
  page_name text NOT NULL CHECK (page_name IN (
    'home', 'transactions', 'quotations-invoices', 'reports', 
    'clients', 'suppliers', 'services', 'settings'
  )),
  is_allowed boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء فهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_employee_page_permissions_employee_id ON employee_page_permissions(employee_id);
CREATE INDEX IF NOT EXISTS idx_employee_page_permissions_boss_id ON employee_page_permissions(boss_id);
CREATE INDEX IF NOT EXISTS idx_employee_page_permissions_page_name ON employee_page_permissions(page_name);
CREATE INDEX IF NOT EXISTS idx_employee_page_permissions_is_allowed ON employee_page_permissions(is_allowed);

-- إنشاء فهرس فريد لمنع تكرار الصلاحيات لنفس الموظف والصفحة
CREATE UNIQUE INDEX IF NOT EXISTS idx_employee_page_permissions_unique 
  ON employee_page_permissions(employee_id, page_name);

-- تفعيل Row Level Security
ALTER TABLE employee_page_permissions ENABLE ROW LEVEL SECURITY;

-- سياسات الأمان لصلاحيات صفحات الموظفين

-- المديرين يمكنهم قراءة صلاحيات صفحات موظفيهم
CREATE POLICY "Bosses can read their employees page permissions"
  ON employee_page_permissions
  FOR SELECT
  USING (boss_id IN (SELECT id FROM bosses));

-- الموظفين يمكنهم قراءة صلاحياتهم الخاصة
CREATE POLICY "Employees can read their own page permissions"
  ON employee_page_permissions
  FOR SELECT
  USING (employee_id IN (SELECT id FROM employees));

-- المديرين يمكنهم إضافة صلاحيات صفحات لموظفيهم
CREATE POLICY "Bosses can insert employee page permissions"
  ON employee_page_permissions
  FOR INSERT
  WITH CHECK (boss_id IN (SELECT id FROM bosses) AND employee_id IN (
    SELECT id FROM employees WHERE boss_id = employee_page_permissions.boss_id
  ));

-- المديرين يمكنهم تحديث صلاحيات صفحات موظفيهم
CREATE POLICY "Bosses can update employee page permissions"
  ON employee_page_permissions
  FOR UPDATE
  USING (boss_id IN (SELECT id FROM bosses))
  WITH CHECK (boss_id IN (SELECT id FROM bosses));

-- المديرين يمكنهم حذف صلاحيات صفحات موظفيهم
CREATE POLICY "Bosses can delete employee page permissions"
  ON employee_page_permissions
  FOR DELETE
  USING (boss_id IN (SELECT id FROM bosses));

-- إنشاء trigger لتحديث updated_at تلقائياً
CREATE TRIGGER update_employee_page_permissions_updated_at
  BEFORE UPDATE ON employee_page_permissions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- إنشاء وظيفة لتهيئة صلاحيات الصفحات الافتراضية للموظفين الجدد
CREATE OR REPLACE FUNCTION initialize_employee_page_permissions()
RETURNS TRIGGER AS $$
BEGIN
  -- إدراج صلاحيات الصفحات الافتراضية (جميعها مرفوضة عدا الرئيسية والإعدادات)
  INSERT INTO employee_page_permissions (employee_id, boss_id, page_name, is_allowed)
  VALUES 
    (NEW.id, NEW.boss_id, 'home', true),  -- الصفحة الرئيسية مسموحة افتراضياً
    (NEW.id, NEW.boss_id, 'transactions', false),
    (NEW.id, NEW.boss_id, 'quotations-invoices', false),
    (NEW.id, NEW.boss_id, 'reports', false),
    (NEW.id, NEW.boss_id, 'clients', false),
    (NEW.id, NEW.boss_id, 'suppliers', false),
    (NEW.id, NEW.boss_id, 'services', false),
    (NEW.id, NEW.boss_id, 'settings', true);  -- الإعدادات مسموحة افتراضياً
  
  RETURN NEW;
END;
$$ language 'plpgsql';

-- إنشاء trigger لتهيئة صلاحيات الصفحات تلقائياً للموظفين الجدد
DROP TRIGGER IF EXISTS initialize_employee_page_permissions_trigger ON employees;
CREATE TRIGGER initialize_employee_page_permissions_trigger
  AFTER INSERT ON employees
  FOR EACH ROW
  EXECUTE FUNCTION initialize_employee_page_permissions();

-- إضافة صلاحيات افتراضية للموظفين الموجودين (إذا لم تكن موجودة)
DO $$
DECLARE
  emp_record RECORD;
  page_names text[] := ARRAY['home', 'transactions', 'quotations-invoices', 'reports', 'clients', 'suppliers', 'services', 'settings'];
  page_name text;
BEGIN
  -- التكرار عبر جميع الموظفين الموجودين
  FOR emp_record IN SELECT id, boss_id FROM employees
  LOOP
    -- التكرار عبر جميع أسماء الصفحات
    FOREACH page_name IN ARRAY page_names
    LOOP
      -- التحقق من وجود الصلاحية، وإضافتها إذا لم تكن موجودة
      IF NOT EXISTS (
        SELECT 1 FROM employee_page_permissions 
        WHERE employee_id = emp_record.id AND page_name = page_name
      ) THEN
        INSERT INTO employee_page_permissions (employee_id, boss_id, page_name, is_allowed)
        VALUES (
          emp_record.id, 
          emp_record.boss_id, 
          page_name, 
          CASE 
            WHEN page_name IN ('home', 'settings') THEN true 
            ELSE false 
          END
        );
      END IF;
    END LOOP;
  END LOOP;
END $$;