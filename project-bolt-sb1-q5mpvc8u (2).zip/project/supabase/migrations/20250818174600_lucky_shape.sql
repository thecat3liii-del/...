/*
  # Add selected services field to suppliers table

  1. Changes
    - Add `selected_service_ids` column to suppliers table
    - This will store an array of service IDs that the supplier provides
    - Links suppliers to specific services from the services table

  2. Security
    - No changes to existing RLS policies needed
    - The new column follows existing security patterns

  3. Indexes
    - Add index on selected_service_ids for performance
*/

-- Add selected_service_ids column to suppliers table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'suppliers' AND column_name = 'selected_service_ids'
  ) THEN
    ALTER TABLE suppliers ADD COLUMN selected_service_ids jsonb DEFAULT '[]'::jsonb;
  END IF;
END $$;

-- Create index for performance on the new column
CREATE INDEX IF NOT EXISTS idx_suppliers_selected_service_ids ON suppliers USING GIN (selected_service_ids);

-- Add comment for documentation
COMMENT ON COLUMN suppliers.selected_service_ids IS 'Array of service IDs that this supplier provides from the services table';