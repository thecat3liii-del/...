# Space Zone - Business Management System

A comprehensive business management system built with React, TypeScript, and Supabase.

## Features

- **Authentication System**: Secure login for bosses and employees
- **Transaction Management**: Track revenue, expenses, and profits
- **Client Management**: Manage client relationships and information
- **Supplier Management**: Handle supplier data and relationships
- **Service Management**: Organize services and products
- **Quotations & Invoices**: Generate professional quotations and invoices
- **Financial Reports**: Comprehensive financial analysis and insights
- **Employee Management**: Manage employees with role-based permissions
- **Task & Project Management**: Organize tasks and projects
- **Password Reset**: Secure password reset via EmailJS

## EmailJS Integration

### ⚠️ Critical Setup Requirements

Before deploying, you **MUST** configure EmailJS properly:

1. **Create EmailJS Account**: Go to [EmailJS.com](https://www.emailjs.com/)
2. **Create Email Service**: Set up your email service (Gmail, Outlook, etc.)
3. **Create Email Template**: Use the template structure below
4. **Update Configuration**: Replace the default values in `src/lib/emailService.ts`

### EmailJS Configuration

Current configuration in `src/lib/emailService.ts`:

```typescript
const EMAILJS_CONFIG = {
  serviceId: 'service_ohtwfr1',     // ⚠️ Replace with your service ID
  templateId: 'template_mej43mu',   // ⚠️ Replace with your template ID
  publicKey: 'A_pI7Vi2oYJ2KnP8z'   // ⚠️ Replace with your public key
};
```

### Email Template Setup

Create a template in EmailJS with these variables:

- `{{user_email}}` - Recipient's registered email (mandatory)
- `{{user_name}}` - Recipient full name
- `{{reset_code}}` - 6-digit reset code

**Template Example:**

```
Subject: Password Reset Request - Space Zone

Hello {{user_name}},

You requested a password reset for {{user_email}}.

Your reset code: {{reset_code}}

Enter this code in the program to set a new password.
This code expires in 10 minutes.

If you did not request this, ignore this email.

Best regards,
SPACE ZONE Support Team
```

### Testing EmailJS

Before going live, test the email functionality:

1. Use the `emailService.testEmailConfiguration()` method
2. Send a test email to a real email address
3. Verify the email is received and formatted correctly
4. Test the complete password reset flow

### Security Notes

- Reset codes expire after **10 minutes**
- Codes are automatically deleted after use
- Only one active code per user at a time
- All email sending is logged for debugging

## Database Setup

The application uses Supabase for data storage. All necessary migrations are included in the `supabase/migrations` folder.

### Key Tables

- `bosses` - Business owners/managers
- `employees` - Staff members with role-based permissions
- `clients` - Customer information
- `suppliers` - Vendor information
- `services` - Products and services offered
- `transactions` - Financial transactions
- `quotations` - Price quotations
- `invoices` - Generated invoices
- `delivery_notes` - Delivery documentation
- `projects` - Project management
- `tasks` - Task management
- `password_reset_codes` - Secure password reset system

## Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Environment Variables

Create a `.env` file with your Supabase credentials:

```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

## Deployment Checklist

- [ ] Configure EmailJS service, template, and public key
- [ ] Test password reset email functionality
- [ ] Set up Supabase project and run migrations
- [ ] Configure environment variables
- [ ] Test all authentication flows
- [ ] Verify RLS policies are working
- [ ] Test employee permissions system
- [ ] Validate quotation and invoice generation

## Support

For technical support or questions about the EmailJS integration, refer to:
- [EmailJS Documentation](https://www.emailjs.com/docs/)
- [EmailJS React Integration](https://www.emailjs.com/docs/examples/reactjs/)

---

**⚠️ Important**: Always test the email functionality with real email addresses before deploying to production. The current configuration includes fallback logging for development purposes.