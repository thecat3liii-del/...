import React, { useState, useEffect } from 'react';
import { 
  Calculator, 
  Users, 
  DollarSign, 
  Calendar,
  TrendingUp,
  Briefcase,
  Car,
  Shield,
  FileText,
  PieChart
} from 'lucide-react';
import { authService, financialItemService } from '../lib/supabase';
import type { Employee, FinancialItem } from '../lib/supabase';

interface EmployeeExpenseCardProps {
  language: 'en' | 'ar';
  bossId?: string;
}

const EmployeeExpenseCard: React.FC<EmployeeExpenseCardProps> = ({ language, bossId }) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [financialItems, setFinancialItems] = useState<FinancialItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [animatedValues, setAnimatedValues] = useState({
    monthlyExpenses: 0,
    yearlyExpenses: 0,
    avgMonthly: 0,
    avgYearly: 0,
    salaries: 0,
    transportation: 0,
    insurance: 0,
    visaCosts: 0,
    otherItems: 0
  });

  const isRTL = language === 'ar';

  // Get current user from localStorage
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  const translations = {
    en: {
      title: 'Employee Expense Calculation',
      subtitle: 'Expense Insights',
      monthlyExpenses: 'Monthly Expenses',
      yearlyExpenses: 'Yearly Expenses',
      activeEmployees: 'Active Employees',
      avgMonthlyCost: 'Average Monthly Cost',
      avgYearlyCost: 'Average Yearly Cost',
      expenseBreakdown: 'Expense Breakdown',
      salaries: 'Salaries',
      transportation: 'Transportation',
      insurance: 'Insurance',
      visaCosts: 'Visa Costs',
      otherItems: 'Other Financial Items',
      perEmployee: 'per employee',
      monthly: 'Monthly',
      yearly: 'Yearly',
      bhd: 'BHD',
      includingVisa: 'Including visa costs',
      noEmployees: 'No active employees',
      noData: 'No expense data available'
    },
    ar: {
      title: 'حساب مصاريف الموظفين',
      subtitle: 'رؤى المصاريف',
      monthlyExpenses: 'المصاريف الشهرية',
      yearlyExpenses: 'المصاريف السنوية',
      activeEmployees: 'عدد الموظفين النشطين',
      avgMonthlyCost: 'متوسط التكلفة الشهرية',
      avgYearlyCost: 'متوسط التكلفة السنوية',
      expenseBreakdown: 'تفصيل المصاريف',
      salaries: 'الرواتب',
      transportation: 'المواصلات',
      insurance: 'التأمين',
      visaCosts: 'تكاليف الفيزا',
      otherItems: 'بنود مالية أخرى',
      perEmployee: 'لكل موظف',
      monthly: 'شهرياً',
      yearly: 'سنوياً',
      bhd: 'د.ب',
      includingVisa: 'شاملة تكاليف الفيزا',
      noEmployees: 'لا يوجد موظفين نشطين',
      noData: 'لا توجد بيانات مصاريف متاحة'
    }
  };

  const t = translations[language];

  // Load data
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      const currentUser = getCurrentUser();
      
      if (!currentUser) {
        setIsLoading(false);
        return;
      }

      const targetBossId = bossId || currentUser.id;

      try {
        // Load employees
        const employeesResult = await authService.getEmployees(targetBossId);
        if (employeesResult.success) {
          setEmployees(employeesResult.data);
        }

        // Load financial items
        const financialResult = await financialItemService.getFinancialItems(targetBossId);
        if (financialResult.success) {
          setFinancialItems(financialResult.data);
        }
      } catch (error) {
        console.error('Error loading data:', error);
      }
      
      setIsLoading(false);
    };

    loadData();
  }, [bossId]);

  // Calculate expenses
  const calculateExpenses = () => {
    const activeEmployees = employees.filter(emp => emp.is_active);
    const activeEmployeeCount = activeEmployees.length;

    if (activeEmployeeCount === 0) {
      return {
        monthlyExpenses: 0,
        yearlyExpenses: 0,
        avgMonthly: 0,
        avgYearly: 0,
        breakdown: {
          salaries: 0,
          transportation: 0,
          insurance: 0,
          visaCosts: 0,
          otherMonthly: 0,
          otherYearly: 0
        }
      };
    }

    // Calculate employee-related expenses
    let totalSalaries = 0;
    let totalTransportation = 0;
    let totalInsurance = 0;
    let totalVisaCosts = 0;

    activeEmployees.forEach(employee => {
      totalSalaries += employee.salary || 0;
      totalTransportation += employee.transportation_allowance || 0;
      totalInsurance += employee.insurance || 0;
      
      // Visa cost calculation (one month salary per year if visa exists and salary > 0)
      if (employee.visa && (employee.salary || 0) > 0) {
        totalVisaCosts += employee.salary || 0;
      }
    });

    // Calculate financial items
    let otherMonthlyItems = 0;
    let otherYearlyItems = 0;

    financialItems.forEach(item => {
      if (item.frequency === 'monthly') {
        otherMonthlyItems += item.default_amount;
      } else if (item.frequency === 'yearly') {
        otherYearlyItems += item.default_amount;
      }
    });

    // Calculate totals
    const monthlyExpenses = totalSalaries + totalTransportation + totalInsurance + otherMonthlyItems;
    const yearlyExpenses = (monthlyExpenses * 12) + totalVisaCosts + otherYearlyItems;

    const avgMonthly = activeEmployeeCount > 0 ? monthlyExpenses / activeEmployeeCount : 0;
    const avgYearly = activeEmployeeCount > 0 ? yearlyExpenses / activeEmployeeCount : 0;

    return {
      monthlyExpenses,
      yearlyExpenses,
      avgMonthly,
      avgYearly,
      activeEmployeeCount,
      breakdown: {
        salaries: totalSalaries,
        transportation: totalTransportation,
        insurance: totalInsurance,
        visaCosts: totalVisaCosts,
        otherMonthly: otherMonthlyItems,
        otherYearly: otherYearlyItems
      }
    };
  };

  const expenses = calculateExpenses();

  // Animate values
  useEffect(() => {
    if (isLoading) return;

    const duration = 1500;
    const steps = 60;
    const interval = duration / steps;

    const targets = {
      monthlyExpenses: expenses.monthlyExpenses,
      yearlyExpenses: expenses.yearlyExpenses,
      avgMonthly: expenses.avgMonthly,
      avgYearly: expenses.avgYearly,
      salaries: expenses.breakdown.salaries,
      transportation: expenses.breakdown.transportation,
      insurance: expenses.breakdown.insurance,
      visaCosts: expenses.breakdown.visaCosts,
      otherItems: expenses.breakdown.otherMonthly + expenses.breakdown.otherYearly
    };

    const increments = Object.keys(targets).reduce((acc, key) => {
      acc[key] = targets[key as keyof typeof targets] / steps;
      return acc;
    }, {} as Record<string, number>);

    let currentStep = 0;
    const timer = setInterval(() => {
      currentStep++;
      
      setAnimatedValues(prev => {
        const newValues = { ...prev };
        Object.keys(targets).forEach(key => {
          const targetValue = targets[key as keyof typeof targets];
          const increment = increments[key];
          const currentValue = prev[key as keyof typeof prev];
          
          if (currentStep >= steps) {
            newValues[key as keyof typeof newValues] = targetValue;
          } else {
            newValues[key as keyof typeof newValues] = Math.min(targetValue, currentValue + increment);
          }
        });
        return newValues;
      });

      if (currentStep >= steps) {
        clearInterval(timer);
      }
    }, interval);

    return () => clearInterval(timer);
  }, [expenses, isLoading]);

  if (isLoading) {
    return (
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 shadow-xl">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Loading expense data...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/20">
      {/* Header */}
      <div className={`mb-8 ${isRTL ? 'text-right' : 'text-left'}`}>
        <div className={`flex items-center gap-3 mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl">
            <Calculator className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-gray-800">{t.title}</h3>
            <p className="text-gray-600 text-sm">{t.subtitle}</p>
          </div>
        </div>
      </div>

      {expenses.activeEmployeeCount === 0 ? (
        <div className="text-center py-12">
          <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 mb-2">{t.noEmployees}</h3>
          <p className="text-gray-500">{t.noData}</p>
        </div>
      ) : (
        <div className="space-y-8">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Monthly Expenses */}
            <div className="bg-gradient-to-br from-blue-500 to-indigo-500 rounded-2xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Calendar className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-blue-100 text-sm">{t.monthlyExpenses}</div>
                  <div className="text-2xl font-bold">
                    {Math.round(animatedValues.monthlyExpenses).toLocaleString()} {t.bhd}
                  </div>
                </div>
              </div>
            </div>

            {/* Active Employees */}
            <div className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-2xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Users className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-green-100 text-sm">{t.activeEmployees}</div>
                  <div className="text-2xl font-bold">{expenses.activeEmployeeCount}</div>
                </div>
              </div>
            </div>

            {/* Yearly Expenses */}
            <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <TrendingUp className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-purple-100 text-sm">{t.yearlyExpenses}</div>
                  <div className="text-2xl font-bold">
                    {Math.round(animatedValues.yearlyExpenses).toLocaleString()} {t.bhd}
                  </div>
                  <div className="text-purple-200 text-xs mt-1">{t.includingVisa}</div>
                </div>
              </div>
            </div>

            {/* Average Costs */}
            <div className="bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <DollarSign className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-orange-100 text-sm">{t.avgMonthlyCost}</div>
                  <div className="text-xl font-bold">
                    {Math.round(animatedValues.avgMonthly).toLocaleString()} {t.bhd}
                  </div>
                  <div className="text-orange-200 text-xs">{t.perEmployee}</div>
                </div>
              </div>
              <div className="border-t border-orange-400/30 pt-3 mt-3">
                <div className="text-orange-100 text-xs">{t.avgYearlyCost}</div>
                <div className="text-lg font-bold">
                  {Math.round(animatedValues.avgYearly).toLocaleString()} {t.bhd} {t.perEmployee}
                </div>
              </div>
            </div>
          </div>

          {/* Expense Breakdown */}
          <div className="bg-gradient-to-r from-gray-50 to-blue-50 rounded-2xl p-8">
            <div className={`flex items-center gap-3 mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <div className="p-3 bg-blue-100 rounded-xl">
                <PieChart className="w-6 h-6 text-blue-600" />
              </div>
              <h4 className={`text-xl font-bold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.expenseBreakdown}
              </h4>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Salaries */}
              <div className="bg-white/80 rounded-xl p-6 border border-gray-200">
                <div className={`flex items-center gap-3 mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Briefcase className="w-5 h-5 text-blue-600" />
                  </div>
                  <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                    <div className="text-gray-600 text-sm">{t.salaries}</div>
                    <div className="text-lg font-bold text-gray-800">
                      {Math.round(animatedValues.salaries).toLocaleString()} {t.bhd}
                    </div>
                    <div className="text-gray-500 text-xs">({t.monthly})</div>
                  </div>
                </div>
              </div>

              {/* Transportation */}
              <div className="bg-white/80 rounded-xl p-6 border border-gray-200">
                <div className={`flex items-center gap-3 mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className="p-2 bg-green-100 rounded-lg">
                    <Car className="w-5 h-5 text-green-600" />
                  </div>
                  <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                    <div className="text-gray-600 text-sm">{t.transportation}</div>
                    <div className="text-lg font-bold text-gray-800">
                      {Math.round(animatedValues.transportation).toLocaleString()} {t.bhd}
                    </div>
                    <div className="text-gray-500 text-xs">({t.monthly})</div>
                  </div>
                </div>
              </div>

              {/* Insurance */}
              <div className="bg-white/80 rounded-xl p-6 border border-gray-200">
                <div className={`flex items-center gap-3 mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <Shield className="w-5 h-5 text-purple-600" />
                  </div>
                  <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                    <div className="text-gray-600 text-sm">{t.insurance}</div>
                    <div className="text-lg font-bold text-gray-800">
                      {Math.round(animatedValues.insurance).toLocaleString()} {t.bhd}
                    </div>
                    <div className="text-gray-500 text-xs">({t.monthly})</div>
                  </div>
                </div>
              </div>

              {/* Visa Costs */}
              <div className="bg-white/80 rounded-xl p-6 border border-gray-200">
                <div className={`flex items-center gap-3 mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className="p-2 bg-yellow-100 rounded-lg">
                    <FileText className="w-5 h-5 text-yellow-600" />
                  </div>
                  <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                    <div className="text-gray-600 text-sm">{t.visaCosts}</div>
                    <div className="text-lg font-bold text-gray-800">
                      {Math.round(animatedValues.visaCosts).toLocaleString()} {t.bhd}
                    </div>
                    <div className="text-gray-500 text-xs">({t.yearly})</div>
                  </div>
                </div>
              </div>

              {/* Other Financial Items */}
              <div className="bg-white/80 rounded-xl p-6 border border-gray-200 md:col-span-2">
                <div className={`flex items-center gap-3 mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className="p-2 bg-indigo-100 rounded-lg">
                    <Calculator className="w-5 h-5 text-indigo-600" />
                  </div>
                  <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                    <div className="text-gray-600 text-sm">{t.otherItems}</div>
                    <div className="flex items-center gap-4">
                      <div>
                        <div className="text-lg font-bold text-gray-800">
                          {Math.round(expenses.breakdown.otherMonthly).toLocaleString()} {t.bhd}
                        </div>
                        <div className="text-gray-500 text-xs">({t.monthly})</div>
                      </div>
                      {expenses.breakdown.otherYearly > 0 && (
                        <div>
                          <div className="text-lg font-bold text-gray-800">
                            {Math.round(expenses.breakdown.otherYearly).toLocaleString()} {t.bhd}
                          </div>
                          <div className="text-gray-500 text-xs">({t.yearly})</div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Financial Items List */}
            {financialItems.length > 0 && (
              <div className="mt-6 pt-6 border-t border-gray-200">
                <h5 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {language === 'en' ? 'Financial Items Details' : 'تفاصيل البنود المالية'}
                </h5>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {financialItems.map((item, index) => (
                    <div 
                      key={item.id} 
                      className={`bg-white/60 rounded-lg p-4 border border-gray-200 animate-fadeIn`}
                      style={{ animationDelay: `${index * 100}ms` }}
                    >
                      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                          <div className="font-medium text-gray-800">{item.name}</div>
                          {item.description && (
                            <div className="text-gray-600 text-sm mt-1">{item.description}</div>
                          )}
                          {item.category && (
                            <div className="text-gray-500 text-xs mt-1">{item.category}</div>
                          )}
                        </div>
                        <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                          <div className="text-lg font-bold text-gray-800">
                            {item.default_amount.toLocaleString()} {t.bhd}
                          </div>
                          <div className={`text-xs px-2 py-1 rounded-full ${
                            item.frequency === 'monthly' 
                              ? 'bg-blue-100 text-blue-700' 
                              : 'bg-purple-100 text-purple-700'
                          }`}>
                            {item.frequency === 'monthly' ? t.monthly : t.yearly}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeeExpenseCard;