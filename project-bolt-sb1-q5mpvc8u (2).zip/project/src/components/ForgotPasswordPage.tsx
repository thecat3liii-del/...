import React, { useState } from 'react';
import { ArrowLeft, User, Send, CheckCircle, AlertCircle, Key, Lock, Shield, Eye, EyeOff } from 'lucide-react';
import { passwordResetService } from '../lib/passwordResetService';
import { emailService } from '../lib/emailService';

interface ForgotPasswordPageProps {
  language: 'en' | 'ar';
  onBack: () => void;
  onResetSuccess?: () => void;
}

const ForgotPasswordPage: React.FC<ForgotPasswordPageProps> = ({ language, onBack, onResetSuccess }) => {
  const [fullName, setFullName] = useState('');
  const [userEmail, setUserEmail] = useState(''); // لحفظ الإيميل المسترجع من قاعدة البيانات
  const [resetCode, setResetCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [emailConfigValid, setEmailConfigValid] = useState(true);
  const [step, setStep] = useState<'name' | 'code' | 'password' | 'success'>('name');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const isRTL = language === 'ar';

  const translations = {
    en: {
      title: 'Reset Password',
      subtitle: 'Enter your full name to reset your password',
      fullName: 'Full Name',
      enterFullName: 'Enter your full name as registered',
      sendResetCode: 'Send Reset Code',
      resetCode: 'Reset Code',
      enterResetCode: 'Enter the 6-digit code sent to your email',
      newPassword: 'New Password',
      confirmPassword: 'Confirm Password',
      enterNewPassword: 'Enter your new password (min 6 characters)',
      enterConfirmPassword: 'Confirm your new password',
      resetPassword: 'Reset Password',
      backToLogin: 'Back to Login',
      codeTitle: 'Enter Reset Code',
      codeSubtitle: 'We sent a 6-digit code to your registered email',
      passwordTitle: 'Create New Password',
      passwordSubtitle: 'Enter your new password',
      successTitle: 'Password Reset Successfully!',
      successMessage: 'Your password has been updated successfully. You can now login with your new password.',
      errorTitle: 'Error',
      nameNotFound: 'Account name not found. Please check your name and try again.',
      fillFullName: 'Please enter your full name',
      fillResetCode: 'Please enter the reset code',
      fillNewPassword: 'Please enter your new password',
      fillConfirmPassword: 'Please confirm your password',
      passwordMismatch: 'Passwords do not match',
      invalidName: 'Please enter a valid full name (at least 2 characters)',
      invalidCode: 'Invalid or expired reset code',
      codeExpired: 'Reset code has expired. Please request a new one.',
      passwordTooShort: 'Password must be at least 6 characters long',
      tryAgain: 'Try Again',
      checkEmail: 'Check your email for the reset code',
      instructions: 'Enter the full name you used when creating your account. We will send a 6-digit reset code to your registered email.',
      codeInstructions: 'Enter the 6-digit code we sent to your registered email. The code expires in 15 minutes.',
      passwordInstructions: 'Create a strong password with at least 6 characters. Make sure both passwords match.',
      securityNote: 'For security reasons, the reset code expires in 15 minutes.',
      sending: 'Sending...',
      verifying: 'Verifying...',
      resetting: 'Resetting...',
      resendCode: 'Resend Code',
      codeNotReceived: 'Did not receive the code?',
      backToName: 'Back to Name',
      loginNow: 'Login Now',
      showPassword: 'Show password',
      hidePassword: 'Hide password',
      passwordStrength: 'Password strength:',
      weak: 'Weak',
      medium: 'Medium',
      strong: 'Strong',
      emailSentTo: 'Code sent to:',
      codeExpiresIn: 'Code expires in 15 minutes',
      enterValidName: 'Please enter your full name exactly as you registered it',
      processingRequest: 'Processing your request...'
    },
    ar: {
      title: 'إعادة تعيين كلمة المرور',
      subtitle: 'أدخل اسمك الكامل لإعادة تعيين كلمة المرور',
      fullName: 'الاسم الكامل',
      enterFullName: 'أدخل اسمك الكامل كما هو مسجل',
      sendResetCode: 'إرسال رمز الإعادة',
      resetCode: 'رمز الإعادة',
      enterResetCode: 'أدخل الرمز المكون من 6 أرقام المرسل لبريدك',
      newPassword: 'كلمة المرور الجديدة',
      confirmPassword: 'تأكيد كلمة المرور',
      enterNewPassword: 'أدخل كلمة المرور الجديدة (6 أحرف على الأقل)',
      enterConfirmPassword: 'أكد كلمة المرور الجديدة',
      resetPassword: 'إعادة تعيين كلمة المرور',
      backToLogin: 'العودة لتسجيل الدخول',
      codeTitle: 'أدخل رمز الإعادة',
      codeSubtitle: 'أرسلنا رمز مكون من 6 أرقام لبريدك المسجل',
      passwordTitle: 'إنشاء كلمة مرور جديدة',
      passwordSubtitle: 'أدخل كلمة المرور الجديدة',
      successTitle: 'تم إعادة تعيين كلمة المرور بنجاح!',
      successMessage: 'تم تحديث كلمة المرور بنجاح. يمكنك الآن تسجيل الدخول بكلمة المرور الجديدة.',
      errorTitle: 'خطأ',
      nameNotFound: 'اسم الحساب غير موجود. يرجى التحقق من الاسم والمحاولة مرة أخرى.',
      fillFullName: 'يرجى إدخال الاسم الكامل',
      fillResetCode: 'يرجى إدخال رمز الإعادة',
      fillNewPassword: 'يرجى إدخال كلمة المرور الجديدة',
      fillConfirmPassword: 'يرجى تأكيد كلمة المرور',
      passwordMismatch: 'كلمات المرور غير متطابقة',
      invalidName: 'يرجى إدخال اسم كامل صحيح (حرفين على الأقل)',
      invalidCode: 'رمز إعادة التعيين غير صحيح أو منتهي الصلاحية',
      codeExpired: 'انتهت صلاحية رمز الإعادة. يرجى طلب رمز جديد.',
      passwordTooShort: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل',
      tryAgain: 'حاول مرة أخرى',
      checkEmail: 'تحقق من بريدك الإلكتروني للحصول على رمز الإعادة',
      instructions: 'أدخل الاسم الكامل الذي استخدمته عند إنشاء حسابك. سنرسل رمز إعادة تعيين مكون من 6 أرقام لبريدك المسجل.',
      codeInstructions: 'أدخل الرمز المكون من 6 أرقام الذي أرسلناه لبريدك المسجل. ينتهي الرمز خلال 15 دقيقة.',
      passwordInstructions: 'أنشئ كلمة مرور قوية مكونة من 6 أحرف على الأقل. تأكد من تطابق كلمتي المرور.',
      securityNote: 'لأسباب أمنية، ينتهي رمز الإعادة خلال 15 دقيقة.',
      sending: 'جاري الإرسال...',
      verifying: 'جاري التحقق...',
      resetting: 'جاري إعادة التعيين...',
      resendCode: 'إعادة إرسال الرمز',
      codeNotReceived: 'لم تستلم الرمز؟',
      backToName: 'العودة للاسم',
      loginNow: 'تسجيل الدخول الآن',
      showPassword: 'إظهار كلمة المرور',
      hidePassword: 'إخفاء كلمة المرور',
      passwordStrength: 'قوة كلمة المرور:',
      weak: 'ضعيفة',
      medium: 'متوسطة',
      strong: 'قوية',
      emailSentTo: 'تم إرسال الرمز إلى:',
      codeExpiresIn: 'ينتهي الرمز خلال 15 دقيقة',
      enterValidName: 'يرجى إدخال اسمك الكامل كما هو مسجل بالضبط',
      processingRequest: 'جاري معالجة طلبك...'
    }
  };

  const t = translations[language];

  // Check EmailJS configuration on component mount
  React.useEffect(() => {
    const checkEmailConfig = () => {
      const validation = emailService.validateConfiguration();
      setEmailConfigValid(validation.valid);
      
      if (!validation.valid) {
        console.warn('⚠️ EmailJS Configuration Issues:', validation.errors);
      }
    };

    checkEmailConfig();
  }, []);

  // التحقق من صحة الاسم الكامل
  const validateFullName = (name: string): boolean => {
    const cleanName = name.trim();
    return cleanName.length >= 2 && /^[a-zA-Z\u0600-\u06FF\s]+$/.test(cleanName);
  };

  // تقييم قوة كلمة المرور
  const getPasswordStrength = (password: string): { strength: 'weak' | 'medium' | 'strong'; score: number } => {
    let score = 0;
    
    if (password.length >= 6) score += 1;
    if (password.length >= 8) score += 1;
    if (/[A-Z]/.test(password)) score += 1;
    if (/[a-z]/.test(password)) score += 1;
    if (/[0-9]/.test(password)) score += 1;
    if (/[^A-Za-z0-9]/.test(password)) score += 1;

    if (score <= 2) return { strength: 'weak', score };
    if (score <= 4) return { strength: 'medium', score };
    return { strength: 'strong', score };
  };

  const passwordStrength = getPasswordStrength(newPassword);

  // إرسال رمز إعادة التعيين
  const handleSendCode = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!fullName.trim()) {
      setError(t.fillFullName);
      return;
    }

    if (!validateFullName(fullName)) {
      setError(t.invalidName);
      return;
    }

    setIsLoading(true);
    setError('');
    setSuccessMessage('');

    try {
      const result = await passwordResetService.sendResetCode(fullName.trim());
      
      if (result.success) {
        setUserEmail(result.email || ''); // حفظ الإيميل المسترجع
        setStep('code');
        setSuccessMessage(result.message || t.checkEmail);
      } else {
        setError(result.error || t.nameNotFound);
      }
    } catch (error) {
      console.error('Error sending reset code:', error);
      setError(t.nameNotFound);
    }
    
    setIsLoading(false);
  };

  // التحقق من رمز الإعادة
  const handleVerifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!resetCode.trim()) {
      setError(t.fillResetCode);
      return;
    }

    if (resetCode.length !== 6 || !/^\d{6}$/.test(resetCode)) {
      setError(t.invalidCode);
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const result = await passwordResetService.verifyResetCode(fullName, resetCode);
      
      if (result.success) {
        setStep('password');
        setSuccessMessage('');
      } else {
        setError(result.error || t.invalidCode);
      }
    } catch (error) {
      console.error('Error verifying code:', error);
      setError(t.invalidCode);
    }
    
    setIsLoading(false);
  };

  // إعادة تعيين كلمة المرور
  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newPassword.trim()) {
      setError(t.fillNewPassword);
      return;
    }

    if (!confirmPassword.trim()) {
      setError(t.fillConfirmPassword);
      return;
    }

    if (newPassword.length < 6) {
      setError(t.passwordTooShort);
      return;
    }

    if (newPassword !== confirmPassword) {
      setError(t.passwordMismatch);
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const result = await passwordResetService.resetPassword(fullName, resetCode, newPassword);
      
      if (result.success) {
        setStep('success');
        setSuccessMessage(result.message || t.successMessage);
      } else {
        setError(result.error || 'Failed to reset password');
      }
    } catch (error) {
      console.error('Error resetting password:', error);
      setError('Failed to reset password. Please try again.');
    }
    
    setIsLoading(false);
  };

  // إعادة إرسال الرمز
  const handleResendCode = async () => {
    setIsLoading(true);
    setError('');

    try {
      const result = await passwordResetService.sendResetCode(fullName);
      
      if (result.success) {
        setSuccessMessage(result.message || 'New code sent successfully');
        setTimeout(() => setSuccessMessage(''), 5000);
      } else {
        setError(result.error || 'Failed to resend code');
      }
    } catch (error) {
      console.error('Error resending code:', error);
      setError('Failed to resend code');
    }
    
    setIsLoading(false);
  };

  const handleTryAgain = () => {
    setStep('name');
    setFullName('');
    setUserEmail('');
    setResetCode('');
    setNewPassword('');
    setConfirmPassword('');
    setError('');
    setSuccessMessage('');
  };

  const handleBackToLogin = () => {
    if (onResetSuccess) {
      onResetSuccess();
    } else {
      onBack();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-float-slow"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-float-medium animation-delay-2000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-indigo-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-float-fast animation-delay-4000"></div>
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-white rounded-full opacity-10 animate-pulse-slow"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 4}s`,
              animationDuration: `${4 + Math.random() * 4}s`
            }}
          />
        ))}
      </div>

      {/* Main Content */}
      <div className="relative z-10 w-full max-w-md">
        <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 shadow-2xl border border-white/20">
          
          {/* Header */}
          <div className={`text-center mb-8 ${isRTL ? 'text-right' : 'text-left'}`}>
            <div className="flex items-center justify-center mb-6">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
                {step === 'name' && <Key className="w-10 h-10 text-white" />}
                {step === 'code' && <Shield className="w-10 h-10 text-white" />}
                {step === 'password' && <Lock className="w-10 h-10 text-white" />}
                {step === 'success' && <CheckCircle className="w-10 h-10 text-white" />}
              </div>
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">
              {step === 'name' && t.title}
              {step === 'code' && t.codeTitle}
              {step === 'password' && t.passwordTitle}
              {step === 'success' && t.successTitle}
            </h1>
            <p className="text-slate-300 text-sm">
              {step === 'name' && t.subtitle}
              {step === 'code' && t.codeSubtitle}
              {step === 'password' && t.passwordSubtitle}
              {step === 'success' && t.successMessage}
            </p>
          </div>

          {/* Success Message */}
          {successMessage && step !== 'success' && (
            <div className="bg-green-500/20 border border-green-400/30 rounded-2xl p-4 mb-6 animate-fadeIn">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="text-green-100 text-sm">{successMessage}</span>
              </div>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="bg-red-500/20 border border-red-400/30 rounded-2xl p-4 mb-6 animate-fadeIn">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-red-400" />
                <span className="text-red-100 text-sm">{error}</span>
              </div>
            </div>
          )}

          {/* Instructions */}
          {step !== 'success' && (
            <div className="bg-blue-500/20 border border-blue-400/30 rounded-2xl p-4 mb-6">
              {!emailConfigValid && (
                <div className="bg-yellow-500/20 border border-yellow-400/30 rounded-xl p-3 mb-3">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-yellow-400" />
                    <span className="text-yellow-100 text-xs">
                      {language === 'en' 
                        ? 'Email service configuration needs verification' 
                        : 'إعدادات خدمة البريد الإلكتروني تحتاج للتحقق'
                      }
                    </span>
                  </div>
                </div>
              )}
              <p className="text-blue-100 text-sm leading-relaxed">
                {step === 'name' && t.instructions}
                {step === 'code' && t.codeInstructions}
                {step === 'password' && t.passwordInstructions}
              </p>
              {step !== 'name' && (
                <p className="text-blue-200 text-xs mt-2 opacity-80">
                  {t.securityNote}
                </p>
              )}
            </div>
          )}

          {/* Step 1: Full Name Input */}
          {step === 'name' && (
            <form onSubmit={handleSendCode} className="space-y-6">
              <div>
                <label className={`block text-sm font-medium text-slate-300 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.fullName}
                </label>
                <div className="relative">
                  <User className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5`} />
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => {
                      setFullName(e.target.value);
                      setError(''); // Clear error when typing
                    }}
                    placeholder={t.enterFullName}
                    className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-4 bg-white/10 border border-white/20 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 backdrop-blur-sm`}
                    disabled={isLoading}
                    autoComplete="name"
                  />
                </div>
                <p className="text-slate-400 text-xs mt-2">
                  {t.enterValidName}
                </p>
              </div>

              <button
                type="submit"
                disabled={isLoading || !fullName.trim()}
                className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-4 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-transparent transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform hover:-translate-y-1 disabled:transform-none"
              >
                {isLoading ? (
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    {t.sending}
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-2">
                    <Send className="w-5 h-5" />
                    {t.sendResetCode}
                  </div>
                )}
              </button>
            </form>
          )}

          {/* Step 2: Code Verification */}
          {step === 'code' && (
            <div className="space-y-6">
              {/* عرض الإيميل المرسل إليه الرمز */}
              {userEmail && (
                <div className="bg-blue-500/20 border border-blue-400/30 rounded-2xl p-4">
                  <div className="text-center">
                    <p className="text-blue-100 text-sm mb-1">
                      {t.emailSentTo}
                    </p>
                    <p className="text-blue-200 font-medium text-lg">{userEmail}</p>
                    <p className="text-blue-300 text-xs mt-2 opacity-80">
                      {t.codeExpiresIn}
                    </p>
                  </div>
                </div>
              )}

              <form onSubmit={handleVerifyCode} className="space-y-6">
                <div>
                  <label className={`block text-sm font-medium text-slate-300 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.resetCode}
                  </label>
                  <div className="relative">
                    <Shield className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5`} />
                    <input
                      type="text"
                      value={resetCode}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\D/g, '').slice(0, 6);
                        setResetCode(value);
                        setError(''); // Clear error when typing
                      }}
                      placeholder="000000"
                      className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-4 bg-white/10 border border-white/20 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 backdrop-blur-sm text-center text-2xl tracking-widest font-mono`}
                      disabled={isLoading}
                      maxLength={6}
                      autoComplete="one-time-code"
                    />
                  </div>
                  <p className="text-slate-400 text-xs mt-2 text-center">
                    {t.enterResetCode}
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={isLoading || resetCode.length !== 6}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-4 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-transparent transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform hover:-translate-y-1 disabled:transform-none"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      {t.verifying}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <CheckCircle className="w-5 h-5" />
                      {language === 'en' ? 'Verify Code' : 'تحقق من الرمز'}
                    </div>
                  )}
                </button>
              </form>

              {/* Resend Code */}
              <div className="text-center">
                <p className="text-slate-400 text-sm mb-3">{t.codeNotReceived}</p>
                <button
                  onClick={handleResendCode}
                  disabled={isLoading}
                  className="text-blue-300 hover:text-blue-100 text-sm font-medium transition-colors duration-200 disabled:opacity-50 underline"
                >
                  {t.resendCode}
                </button>
              </div>

              {/* Back to Name */}
              <button
                onClick={() => setStep('name')}
                className={`w-full flex items-center justify-center gap-2 text-slate-300 hover:text-white py-3 px-6 rounded-2xl font-medium hover:bg-white/10 transition-all duration-300 ${isRTL ? 'flex-row-reverse' : ''}`}
              >
                <ArrowLeft className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
                {t.backToName}
              </button>
            </div>
          )}

          {/* Step 3: New Password */}
          {step === 'password' && (
            <div className="space-y-6">
              <form onSubmit={handleResetPassword} className="space-y-6">
                <div>
                  <label className={`block text-sm font-medium text-slate-300 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.newPassword}
                  </label>
                  <div className="relative">
                    <Lock className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5`} />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={newPassword}
                      onChange={(e) => {
                        setNewPassword(e.target.value);
                        setError(''); // Clear error when typing
                      }}
                      placeholder={t.enterNewPassword}
                      className={`w-full ${isRTL ? 'pr-12 pl-12' : 'pl-12 pr-12'} py-4 bg-white/10 border border-white/20 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 backdrop-blur-sm`}
                      disabled={isLoading}
                      autoComplete="new-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className={`absolute ${isRTL ? 'left-3' : 'right-3'} top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-200 transition-colors`}
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                  
                  {/* Password Strength Indicator */}
                  {newPassword && (
                    <div className="mt-2">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-slate-400 text-xs">{t.passwordStrength}</span>
                        <span className={`text-xs font-medium ${
                          passwordStrength.strength === 'weak' ? 'text-red-400' :
                          passwordStrength.strength === 'medium' ? 'text-yellow-400' :
                          'text-green-400'
                        }`}>
                          {t[passwordStrength.strength]}
                        </span>
                      </div>
                      <div className="w-full bg-white/20 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full transition-all duration-300 ${
                            passwordStrength.strength === 'weak' ? 'bg-red-500' :
                            passwordStrength.strength === 'medium' ? 'bg-yellow-500' :
                            'bg-green-500'
                          }`}
                          style={{ width: `${(passwordStrength.score / 6) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <label className={`block text-sm font-medium text-slate-300 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.confirmPassword}
                  </label>
                  <div className="relative">
                    <Lock className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5`} />
                    <input
                      type={showConfirmPassword ? 'text' : 'password'}
                      value={confirmPassword}
                      onChange={(e) => {
                        setConfirmPassword(e.target.value);
                        setError(''); // Clear error when typing
                      }}
                      placeholder={t.enterConfirmPassword}
                      className={`w-full ${isRTL ? 'pr-12 pl-12' : 'pl-12 pr-12'} py-4 bg-white/10 border border-white/20 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 backdrop-blur-sm`}
                      disabled={isLoading}
                      autoComplete="new-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className={`absolute ${isRTL ? 'left-3' : 'right-3'} top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-200 transition-colors`}
                    >
                      {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                  
                  {/* Password Match Indicator */}
                  {confirmPassword && (
                    <div className="mt-2">
                      <div className={`flex items-center gap-2 text-xs ${
                        newPassword === confirmPassword ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {newPassword === confirmPassword ? (
                          <CheckCircle className="w-4 h-4" />
                        ) : (
                          <AlertCircle className="w-4 h-4" />
                        )}
                        <span>
                          {newPassword === confirmPassword 
                            ? (language === 'en' ? 'Passwords match' : 'كلمات المرور متطابقة')
                            : (language === 'en' ? 'Passwords do not match' : 'كلمات المرور غير متطابقة')
                          }
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isLoading || !newPassword || !confirmPassword || newPassword !== confirmPassword}
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-4 px-6 rounded-2xl font-semibold hover:from-green-600 hover:to-emerald-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 focus:ring-offset-transparent transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform hover:-translate-y-1 disabled:transform-none"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      {t.resetting}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <Lock className="w-5 h-5" />
                      {t.resetPassword}
                    </div>
                  )}
                </button>
              </form>

              {/* Back to Code */}
              <button
                onClick={() => setStep('code')}
                className={`w-full flex items-center justify-center gap-2 text-slate-300 hover:text-white py-3 px-6 rounded-2xl font-medium hover:bg-white/10 transition-all duration-300 ${isRTL ? 'flex-row-reverse' : ''}`}
              >
                <ArrowLeft className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
                {language === 'en' ? 'Back to Code' : 'العودة للرمز'}
              </button>
            </div>
          )}

          {/* Step 4: Success */}
          {step === 'success' && (
            <div className="text-center animate-fadeIn space-y-6">
              <div className="flex items-center justify-center mb-6">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center animate-pulse">
                  <CheckCircle className="w-8 h-8 text-white" />
                </div>
              </div>
              
              <div className="bg-green-500/20 border border-green-400/30 rounded-2xl p-6 mb-6">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <CheckCircle className="w-6 h-6 text-green-400" />
                  <span className="text-green-100 font-semibold">
                    {language === 'en' ? 'Password Reset Complete!' : 'تم إعادة تعيين كلمة المرور!'}
                  </span>
                </div>
                <p className="text-green-200 text-sm leading-relaxed">
                  {successMessage}
                </p>
              </div>

              <button
                onClick={handleBackToLogin}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-4 px-6 rounded-2xl font-semibold hover:from-green-600 hover:to-emerald-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
              >
                <div className="flex items-center justify-center gap-2">
                  <Key className="w-5 h-5" />
                  {t.loginNow}
                </div>
              </button>

              <button
                onClick={handleTryAgain}
                className={`w-full flex items-center justify-center gap-2 text-slate-300 hover:text-white py-3 px-6 rounded-2xl font-medium hover:bg-white/10 transition-all duration-300 ${isRTL ? 'flex-row-reverse' : ''}`}
              >
                <User className="w-5 h-5" />
                {language === 'en' ? 'Reset Another Account' : 'إعادة تعيين حساب آخر'}
              </button>
            </div>
          )}

          {/* Back to Login Button */}
          {step === 'name' && (
            <button
              onClick={onBack}
              className={`w-full flex items-center justify-center gap-2 text-slate-300 hover:text-white py-3 px-6 rounded-2xl font-medium hover:bg-white/10 transition-all duration-300 mt-6 ${isRTL ? 'flex-row-reverse' : ''}`}
            >
              <ArrowLeft className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
              {t.backToLogin}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ForgotPasswordPage;