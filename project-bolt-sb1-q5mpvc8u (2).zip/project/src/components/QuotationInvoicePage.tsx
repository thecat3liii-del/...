import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Receipt, 
  Truck,
  Plus,
  Search, 
  Filter, 
  Download, 
  Eye,
  Edit3,
  Trash2,
  Calendar,
  User,
  DollarSign,
  Package,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import InvoiceModal from './InvoiceModal';
import QuotationModal from './QuotationModal';
import DeliveryNoteModal from './DeliveryNoteModal';
import InvoiceEditModal from './InvoiceEditModal';
import DeliveryNoteEditModal from './DeliveryNoteEditModal';
import QuotationCreationModal from './QuotationCreationModal';
import QuotationEditModal from './QuotationEditModal';
import { transactionService, invoiceService, deliveryNoteService, supabase } from '../lib/supabase';
import { quotationService } from '../lib/quotationService';
import type { Transaction as SupabaseTransaction } from '../lib/supabase';
import type { Quotation } from '../lib/quotationService';

interface Transaction {
  id: string;
  amount: number;
  cost: number;
  vat?: number;
  profit: number;
  clientId?: string;
  clientName?: string;
  supplierId?: string;
  supplierName?: string;
  serviceIds?: string[];
  serviceNames?: string[];
  date: string;
  paymentMethod?: string;
  status?: string;
  description?: string;
  priority?: string;
  month: number;
  year: number;
  category?: string;
  vatPercentage?: number;
  totalWithVat?: number;
}

interface QuotationInvoicePageProps {
  language: 'en' | 'ar';
  bossId?: string;
}

const QuotationInvoicePage: React.FC<QuotationInvoicePageProps> = ({ language, bossId }) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);
  const [filteredQuotations, setFilteredQuotations] = useState<Quotation[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMonth, setFilterMonth] = useState<number>(0);
  const [filterYear, setFilterYear] = useState<number>(new Date().getFullYear());
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [selectedQuotation, setSelectedQuotation] = useState<Quotation | null>(null);
  const [selectedInvoice, setSelectedInvoice] = useState<any | null>(null);
  const [selectedDeliveryNote, setSelectedDeliveryNote] = useState<any | null>(null);
  const [modalType, setModalType] = useState<'invoice' | 'delivery' | 'quotation' | 'edit-quotation' | 'edit-invoice' | 'edit-delivery' | null>(null);
  const [showCreateQuotation, setShowCreateQuotation] = useState(false);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [deliveryNotes, setDeliveryNotes] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'transactions' | 'quotations' | 'invoices' | 'deliveries'>('transactions');
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const isRTL = language === 'ar';

  // Get current user from localStorage to access boss ID
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Generate unique database key for current boss
  const getBossDataKey = (dataType: string) => {
    const currentUser = getCurrentUser();
    if (!currentUser) return null;
    const targetBossId = bossId || currentUser.id;
    return `spaceZone_boss_${targetBossId}_${dataType}`;
  };

  const translations = {
    en: {
      title: 'Quotations & Invoices',
      subtitle: 'Generate quotations and invoices for your transactions',
      createQuotation: 'Create Quotation',
      transactionsTab: 'Transactions',
      quotationsTab: 'Quotations',
      invoicesTab: 'Invoices',
      deliveriesTab: 'Delivery Notes',
      searchPlaceholder: 'Search transactions...',
      searchQuotationsPlaceholder: 'Search quotations...',
      filterAll: 'All Months',
      noTransactions: 'No transactions found',
      noTransactionsDesc: 'Add transactions first to generate quotations and invoices',
      noQuotations: 'No quotations found',
      noQuotationsDesc: 'Create your first quotation to get started',
      date: 'Date',
      client: 'Client',
      amount: 'Amount',
      quotationNumber: 'Quotation Number',
      issueDate: 'Issue Date',
      validUntil: 'Valid Until',
      status: 'Status',
      services: 'Services',
      actions: 'Actions',
      generateInvoice: 'Generate Invoice',
      generateQuotation: 'Generate Quotation',
      generateDelivery: 'Generate Delivery Note',
      view: 'View',
      edit: 'Edit',
      delete: 'Delete',
      totalTransactions: 'Total Transactions',
      totalQuotations: 'Total Quotations',
      totalAmount: 'Total Amount',
      thisMonth: 'This Month',
      bhd: 'BHD',
      january: 'January',
      february: 'February',
      march: 'March',
      april: 'April',
      may: 'May',
      june: 'June',
      july: 'July',
      august: 'August',
      september: 'September',
      october: 'October',
      november: 'November',
      december: 'December',
      invoiceGenerated: 'Invoice generated successfully',
      invoiceUpdated: 'Invoice updated successfully',
      deliveryGenerated: 'Delivery note generated successfully',
      deliveryUpdated: 'Delivery note updated successfully',
      quotationCreated: 'Quotation created successfully',
      quotationUpdated: 'Quotation updated successfully',
      quotationDeleted: 'Quotation deleted successfully',
      confirmDelete: 'Are you sure you want to delete this quotation?',
      draft: 'Draft',
      sent: 'Sent',
      accepted: 'Accepted',
      rejected: 'Rejected',
      expired: 'Expired'
    },
    ar: {
      title: 'عروض الأسعار والفواتير',
      subtitle: 'إنشاء عروض الأسعار والفواتير للمعاملات',
      createQuotation: 'إنشاء عرض سعر',
      transactionsTab: 'المعاملات',
      quotationsTab: 'عروض الأسعار',
      invoicesTab: 'الفواتير',
      deliveriesTab: 'إشعارات التسليم',
      searchPlaceholder: 'البحث في المعاملات...',
      searchQuotationsPlaceholder: 'البحث في عروض الأسعار...',
      filterAll: 'جميع الشهور',
      noTransactions: 'لا توجد معاملات',
      noTransactionsDesc: 'أضف معاملات أولاً لإنشاء عروض الأسعار والفواتير',
      noQuotations: 'لا توجد عروض أسعار',
      noQuotationsDesc: 'أنشئ عرض السعر الأول للبدء',
      date: 'التاريخ',
      client: 'العميل',
      amount: 'المبلغ',
      quotationNumber: 'رقم عرض السعر',
      issueDate: 'تاريخ الإصدار',
      validUntil: 'صالح حتى',
      status: 'الحالة',
      services: 'الخدمات',
      actions: 'الإجراءات',
      generateInvoice: 'إنشاء فاتورة',
      generateQuotation: 'إنشاء عرض سعر',
      generateDelivery: 'إنشاء إشعار تسليم',
      view: 'عرض',
      edit: 'تعديل',
      delete: 'حذف',
      totalTransactions: 'إجمالي المعاملات',
      totalQuotations: 'إجمالي عروض الأسعار',
      totalAmount: 'إجمالي المبلغ',
      thisMonth: 'هذا الشهر',
      bhd: 'د.ب',
      january: 'يناير',
      february: 'فبراير',
      march: 'مارس',
      april: 'أبريل',
      may: 'مايو',
      june: 'يونيو',
      july: 'يوليو',
      august: 'أغسطس',
      september: 'سبتمبر',
      october: 'أكتوبر',
      november: 'نوفمبر',
      december: 'ديسمبر',
      invoiceGenerated: 'تم إنشاء الفاتورة بنجاح',
      invoiceUpdated: 'تم تحديث الفاتورة بنجاح',
      deliveryGenerated: 'تم إنشاء إشعار التسليم بنجاح',
      deliveryUpdated: 'تم تحديث إشعار التسليم بنجاح',
      quotationCreated: 'تم إنشاء عرض السعر بنجاح',
      quotationUpdated: 'تم تحديث عرض السعر بنجاح',
      quotationDeleted: 'تم حذف عرض السعر بنجاح',
      confirmDelete: 'هل أنت متأكد من حذف عرض السعر هذا؟',
      draft: 'مسودة',
      sent: 'مرسل',
      accepted: 'مقبول',
      rejected: 'مرفوض',
      expired: 'منتهي الصلاحية'
    }
  };

  const t = translations[language];

  const monthNames = [
    t.january, t.february, t.march, t.april, t.may, t.june,
    t.july, t.august, t.september, t.october, t.november, t.december
  ];

  // Load transactions from localStorage
  useEffect(() => {
    const loadTransactions = () => {
      const loadData = async () => {
        const currentUser = getCurrentUser();
        if (!currentUser) return;
        
        const targetBossId = bossId || currentUser.id;
        try {
          const result = await transactionService.getTransactions(targetBossId);
          if (result.success) {
            // Convert Supabase data to local format
            const convertedTransactions = result.data.map((t: SupabaseTransaction) => ({
              id: t.id,
              amount: t.amount,
              cost: t.cost,
              vat: t.vat,
              profit: t.profit,
              clientId: t.client_id,
              clientName: t.client_name,
              supplierId: t.supplier_id,
              supplierName: t.supplier_name,
              serviceIds: t.service_ids,
              serviceNames: t.service_names,
              date: t.transaction_date,
              paymentMethod: t.payment_method,
              status: t.status,
              description: t.description,
              priority: t.priority,
              category: t.category,
              vatPercentage: t.vat_percentage,
              totalWithVat: t.total_with_vat,
              month: t.month,
              year: t.year
            }));
            setTransactions(convertedTransactions);
          } else {
            console.error('Error loading transactions:', result.error);
            setTransactions([]);
          }
        } catch (error) {
          console.error('Error loading transactions:', error);
          setTransactions([]);
        }
      };
      
      loadData();
    };

    const loadInvoices = async () => {
      const currentUser = getCurrentUser();
      if (!currentUser) return;
      
      const targetBossId = bossId || currentUser.id;
      try {
        const result = await invoiceService.getInvoices(targetBossId);
        if (result.success) {
          setInvoices(result.data);
        } else {
          console.error('Error loading invoices:', result.error);
          setInvoices([]);
        }
      } catch (error) {
        console.error('Error loading invoices:', error);
        setInvoices([]);
      }
    };

    const loadDeliveryNotes = async () => {
      const currentUser = getCurrentUser();
      if (!currentUser) return;
      
      const targetBossId = bossId || currentUser.id;
      try {
        const result = await deliveryNoteService.getDeliveryNotes(targetBossId);
        if (result.success) {
          setDeliveryNotes(result.data);
        } else {
          console.error('Error loading delivery notes:', result.error);
          setDeliveryNotes([]);
        }
      } catch (error) {
        console.error('Error loading delivery notes:', error);
        setDeliveryNotes([]);
      }
    };

    const loadQuotations = async () => {
      const currentUser = getCurrentUser();
      if (!currentUser) return;
      
      const targetBossId = bossId || currentUser.id;
      try {
        const result = await quotationService.getQuotations(targetBossId);
        if (result.success) {
          setQuotations(result.data);
        } else {
          console.error('Error loading quotations:', result.error);
          setQuotations([]);
        }
      } catch (error) {
        console.error('Error loading quotations:', error);
        setQuotations([]);
      }
    };

    loadTransactions();
    loadQuotations();
    loadInvoices();
    loadDeliveryNotes();

  }, []);

  // Filter transactions
  useEffect(() => {
    let filtered = [...transactions];

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(transaction =>
        transaction.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.clientName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.serviceNames?.some(service => 
          service.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    }

    // Apply month filter
    if (filterMonth > 0) {
      filtered = filtered.filter(transaction => transaction.month === filterMonth);
    }

    // Apply year filter
    filtered = filtered.filter(transaction => transaction.year === filterYear);

    setFilteredTransactions(filtered);
  }, [transactions, searchTerm, filterMonth, filterYear]);

  // Filter quotations
  useEffect(() => {
    let filtered = [...quotations];

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(quotation =>
        quotation.quotation_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        quotation.client_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        quotation.notes?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply month filter
    if (filterMonth > 0) {
      const monthTransactions = filtered.filter(quotation => {
        const issueDate = new Date(quotation.issue_date);
        return issueDate.getMonth() + 1 === filterMonth;
      });
      filtered = monthTransactions;
    }

    // Apply year filter
    const yearFiltered = filtered.filter(quotation => {
      const issueDate = new Date(quotation.issue_date);
      return issueDate.getFullYear() === filterYear;
    });
    filtered = yearFiltered;

    setFilteredQuotations(filtered);
  }, [quotations, searchTerm, filterMonth, filterYear]);

  // Calculate totals
  const calculateTotals = () => {
    const totalAmount = filteredTransactions.reduce((sum, t) => sum + ((t.amount || 0) + (t.vat || 0)), 0);
    const totalQuotationAmount = filteredQuotations.reduce((sum, q) => sum + (q.total_amount || 0), 0);
    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();
    
    const thisMonthTransactions = transactions.filter(
      t => t.month === currentMonth && t.year === currentYear
    );
    const thisMonthAmount = thisMonthTransactions.reduce((sum, t) => sum + ((t.amount || 0) + (t.vat || 0)), 0);

    const thisMonthQuotations = quotations.filter(quotation => {
      const issueDate = new Date(quotation.issue_date);
      return issueDate.getMonth() + 1 === currentMonth && issueDate.getFullYear() === currentYear;
    });
    const thisMonthQuotationAmount = thisMonthQuotations.reduce((sum, q) => sum + (q.total_amount || 0), 0);

    return {
      totalTransactions: filteredTransactions.length,
      totalQuotations: filteredQuotations.length,
      totalAmount,
      totalQuotationAmount,
      thisMonthAmount,
      thisMonthQuotationAmount
    };
  };

  const totals = calculateTotals();

  // Handle modal actions
  const handleGenerateInvoice = (transaction: Transaction) => {
    setSelectedTransaction(transaction);
    setModalType('invoice');
  };

  const handleGenerateDelivery = (transaction: Transaction) => {
    setSelectedTransaction(transaction);
    setModalType('delivery');
  };

  const handleEditInvoice = (invoice: any) => {
    setSelectedInvoice(invoice);
    setModalType('edit-invoice');
  };

  const handleEditDeliveryNote = (deliveryNote: any) => {
    setSelectedDeliveryNote(deliveryNote);
    setModalType('edit-delivery');
  };

  const handleCloseModal = () => {
    setSelectedTransaction(null);
    setSelectedQuotation(null);
    setSelectedInvoice(null);
    setSelectedDeliveryNote(null);
    setModalType(null);
  };

  // Handle quotation actions
  const handleViewQuotation = (quotation: Quotation) => {
    setSelectedQuotation(quotation);
    setModalType('quotation');
  };

  const handleEditQuotation = (quotation: Quotation) => {
    setSelectedQuotation(quotation);
    setModalType('edit-quotation');
  };

  const handleDeleteQuotation = async (quotationId: string) => {
    if (window.confirm(t.confirmDelete)) {
      try {
        const result = await quotationService.deleteQuotation(quotationId);
        
        if (result.success) {
          setQuotations(prev => prev.filter(q => q.id !== quotationId));
          setSuccess(t.quotationDeleted);
        } else {
          setError(result.error || 'Failed to delete quotation');
        }
      } catch (error) {
        console.error('Error deleting quotation:', error);
        setError('Failed to delete quotation');
      }
      
      setTimeout(() => {
        setSuccess('');
        setError('');
      }, 3000);
    }
  };

  const handleQuotationSuccess = () => {
    reloadQuotations();
    setSuccess(t.quotationCreated);
    setTimeout(() => setSuccess(''), 3000);
  };

  const handleQuotationEditSuccess = () => {
    reloadQuotations();
    setSuccess(t.quotationUpdated);
    setTimeout(() => setSuccess(''), 3000);
  };

  const handleInvoiceEditSuccess = () => {
    reloadInvoices();
    setSuccess(t.invoiceUpdated);
    setTimeout(() => setSuccess(''), 3000);
  };

  const handleDeliveryEditSuccess = () => {
    reloadDeliveryNotes();
    setSuccess(t.deliveryUpdated);
    setTimeout(() => setSuccess(''), 3000);
  };

  // Reload quotations function
  const reloadQuotations = async () => {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    const targetBossId = bossId || currentUser.id;
    try {
      const result = await quotationService.getQuotations(targetBossId);
      if (result.success) {
        setQuotations(result.data);
      }
    } catch (error) {
      console.error('Error loading quotations:', error);
    }
  };

  // Reload invoices function
  const reloadInvoices = async () => {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    const targetBossId = bossId || currentUser.id;
    try {
      const result = await invoiceService.getInvoices(targetBossId);
      if (result.success) {
        setInvoices(result.data);
      }
    } catch (error) {
      console.error('Error loading invoices:', error);
    }
  };

  // Reload delivery notes function
  const reloadDeliveryNotes = async () => {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    const targetBossId = bossId || currentUser.id;
    try {
      const result = await deliveryNoteService.getDeliveryNotes(targetBossId);
      if (result.success) {
        setDeliveryNotes(result.data);
      }
    } catch (error) {
      console.error('Error loading delivery notes:', error);
    }
  };

  const handleModalSuccess = (type: 'quotation' | 'invoice' | 'delivery') => {
    setSuccess(
      type === 'invoice' ? t.invoiceGenerated : 
      t.deliveryGenerated
    );
    setTimeout(() => setSuccess(''), 3000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-gray-100 text-gray-800';
      case 'sent': return 'bg-blue-100 text-blue-800';
      case 'accepted': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'expired': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{t.title}</h1>
          <p className="text-gray-600">{t.subtitle}</p>
        </div>

        <button
          onClick={() => setShowCreateQuotation(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
        >
          <Plus className="w-5 h-5" />
          {t.createQuotation}
        </button>
      </div>

      {/* Success Message */}
      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {/* Tabs */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-2 shadow-lg">
        <div className={`grid grid-cols-2 md:grid-cols-4 gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <button
            onClick={() => setActiveTab('transactions')}
            className={`flex items-center justify-center gap-2 py-3 px-4 rounded-2xl font-semibold transition-all duration-200 ${
              activeTab === 'transactions'
                ? 'bg-blue-500 text-white shadow-lg'
                : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
            }`}
          >
            <Receipt className="w-5 h-5" />
            <span className="hidden sm:inline">{t.transactionsTab}</span>
          </button>
          <button
            onClick={() => setActiveTab('quotations')}
            className={`flex items-center justify-center gap-2 py-3 px-4 rounded-2xl font-semibold transition-all duration-200 ${
              activeTab === 'quotations'
                ? 'bg-green-500 text-white shadow-lg'
                : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
            }`}
          >
            <FileText className="w-5 h-5" />
            <span className="hidden sm:inline">{t.quotationsTab}</span>
          </button>
          <button
            onClick={() => setActiveTab('invoices')}
            className={`flex items-center justify-center gap-2 py-3 px-4 rounded-2xl font-semibold transition-all duration-200 ${
              activeTab === 'invoices'
                ? 'bg-purple-500 text-white shadow-lg'
                : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
            }`}
          >
            <Receipt className="w-5 h-5" />
            <span className="hidden sm:inline">{t.invoicesTab}</span>
          </button>
          <button
            onClick={() => setActiveTab('deliveries')}
            className={`flex items-center justify-center gap-2 py-3 px-4 rounded-2xl font-semibold transition-all duration-200 ${
              activeTab === 'deliveries'
                ? 'bg-orange-500 text-white shadow-lg'
                : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
            }`}
          >
            <Truck className="w-5 h-5" />
            <span className="hidden sm:inline">{t.deliveriesTab}</span>
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {activeTab === 'transactions' && (
          <>
            <div className="bg-gradient-to-br from-blue-500 to-indigo-500 rounded-3xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <FileText className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-blue-100 text-sm">{t.totalTransactions}</div>
                  <div className="text-2xl font-bold">{totals.totalTransactions}</div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-3xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <DollarSign className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-green-100 text-sm">{t.totalAmount}</div>
                  <div className="text-2xl font-bold">{totals.totalAmount.toLocaleString()} {t.bhd}</div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Calendar className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-purple-100 text-sm">{t.thisMonth}</div>
                  <div className="text-2xl font-bold">{totals.thisMonthAmount.toLocaleString()} {t.bhd}</div>
                </div>
              </div>
            </div>
          </>
        )}
        
        {activeTab === 'quotations' && (
          <>
            <div className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-3xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <FileText className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-green-100 text-sm">{t.totalQuotations}</div>
                  <div className="text-2xl font-bold">{totals.totalQuotations}</div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-500 to-indigo-500 rounded-3xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <DollarSign className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-blue-100 text-sm">{t.totalAmount}</div>
                  <div className="text-2xl font-bold">{totals.totalQuotationAmount.toLocaleString()} {t.bhd}</div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Calendar className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-purple-100 text-sm">{t.thisMonth}</div>
                  <div className="text-2xl font-bold">{totals.thisMonthQuotationAmount.toLocaleString()} {t.bhd}</div>
                </div>
              </div>
            </div>
          </>
        )}
        
        {activeTab === 'invoices' && (
          <>
            <div className="bg-gradient-to-br from-purple-500 to-indigo-500 rounded-3xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Receipt className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-purple-100 text-sm">{language === 'en' ? 'Total Invoices' : 'إجمالي الفواتير'}</div>
                  <div className="text-2xl font-bold">{invoices.length}</div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-500 to-indigo-500 rounded-3xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <DollarSign className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-blue-100 text-sm">{t.totalAmount}</div>
                  <div className="text-2xl font-bold">{invoices.reduce((sum, inv) => sum + (inv.total_amount || 0), 0).toLocaleString()} {t.bhd}</div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-3xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Calendar className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-green-100 text-sm">{t.thisMonth}</div>
                  <div className="text-2xl font-bold">
                    {invoices.filter(inv => {
                      const issueDate = new Date(inv.issue_date);
                      return issueDate.getMonth() + 1 === new Date().getMonth() + 1 && issueDate.getFullYear() === new Date().getFullYear();
                    }).reduce((sum, inv) => sum + (inv.total_amount || 0), 0).toLocaleString()} {t.bhd}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
        
        {activeTab === 'deliveries' && (
          <>
            <div className="bg-gradient-to-br from-orange-500 to-red-500 rounded-3xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Truck className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-orange-100 text-sm">{language === 'en' ? 'Total Deliveries' : 'إجمالي التوصيلات'}</div>
                  <div className="text-2xl font-bold">{deliveryNotes.length}</div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-500 to-indigo-500 rounded-3xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Package className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-blue-100 text-sm">{language === 'en' ? 'Items Delivered' : 'العناصر المسلمة'}</div>
                  <div className="text-2xl font-bold">
                    {deliveryNotes.reduce((sum, dn) => sum + (dn.items?.length || 0), 0)}
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-3xl p-6 text-white shadow-lg">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Calendar className="w-8 h-8" />
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <div className="text-green-100 text-sm">{t.thisMonth}</div>
                  <div className="text-2xl font-bold">
                    {deliveryNotes.filter(dn => {
                      const deliveryDate = new Date(dn.delivery_date);
                      return deliveryDate.getMonth() + 1 === new Date().getMonth() + 1 && deliveryDate.getFullYear() === new Date().getFullYear();
                    }).length}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Search and Filters */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-lg">
        <div className={`flex flex-col md:flex-row gap-4 ${isRTL ? 'md:flex-row-reverse' : ''}`}>
          {/* Search */}
          <div className="flex-1 relative">
            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5`} />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={
                activeTab === 'transactions' ? t.searchPlaceholder :
                activeTab === 'quotations' ? t.searchQuotationsPlaceholder :
                activeTab === 'invoices' ? (language === 'en' ? 'Search invoices...' : 'البحث في الفواتير...') :
                (language === 'en' ? 'Search delivery notes...' : 'البحث في إشعارات التسليم...')
              }
              className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200`}
            />
          </div>

          {/* Month Filter */}
          <select
            value={filterMonth}
            onChange={(e) => setFilterMonth(Number(e.target.value))}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            <option value={0}>{t.filterAll}</option>
            {monthNames.map((month, index) => (
              <option key={index + 1} value={index + 1}>{month}</option>
            ))}
          </select>

          {/* Year Filter */}
          <select
            value={filterYear}
            onChange={(e) => setFilterYear(Number(e.target.value))}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            {Array.from({ length: 21 }, (_, i) => 2025 + i).map(year => (
              <option key={year} value={year}>{year}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Content based on active tab */}
      {activeTab === 'transactions' && (
        /* Transactions Table */
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-lg overflow-hidden">
        {filteredTransactions.length === 0 ? (
          <div className="text-center py-16">
            <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">{t.noTransactions}</h3>
            <p className="text-gray-500 mb-6">{t.noTransactionsDesc}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.date}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.client}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.amount}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.services}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.actions}
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredTransactions.map((transaction, index) => (
                  <tr
                    key={transaction.id}
                    className={`border-b border-gray-100 hover:bg-gray-50 transition-colors animate-fadeIn`}
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        {new Date(transaction.date).toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA')}
                      </div>
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-gray-400" />
                        {transaction.clientName || 'N/A'}
                      </div>
                    </td>
                    <td className={`py-4 px-6 font-semibold text-green-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {((transaction.amount || 0) + (transaction.vat || 0)).toLocaleString()} {t.bhd}
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {transaction.serviceNames && transaction.serviceNames.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {transaction.serviceNames.slice(0, 2).map((service, idx) => (
                            <span key={idx} className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              {service}
                            </span>
                          ))}
                          {transaction.serviceNames.length > 2 && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
                              +{transaction.serviceNames.length - 2}
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className="py-4 px-6">
                      <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <button
                          onClick={() => handleGenerateInvoice(transaction)}
                          className="flex items-center gap-1 bg-blue-100 text-blue-700 px-3 py-2 rounded-lg hover:bg-blue-200 transition-colors duration-200 text-sm font-medium"
                          title={t.generateInvoice}
                        >
                          <Receipt className="w-4 h-4" />
                          {language === 'en' ? 'Invoice' : 'فاتورة'}
                        </button>
                        <button
                          onClick={() => handleGenerateDelivery(transaction)}
                          className="flex items-center gap-1 bg-orange-100 text-orange-700 px-3 py-2 rounded-lg hover:bg-orange-200 transition-colors duration-200 text-sm font-medium"
                          title={t.generateDelivery}
                        >
                          <Truck className="w-4 h-4" />
                          {language === 'en' ? 'Delivery' : 'تسليم'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      )}
      
      {activeTab === 'quotations' && (
        /* Quotations Table */
        <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-lg overflow-hidden">
          {filteredQuotations.length === 0 ? (
            <div className="text-center py-16">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">{t.noQuotations}</h3>
              <p className="text-gray-500 mb-6">{t.noQuotationsDesc}</p>
              <button
                onClick={() => setShowCreateQuotation(true)}
                className="flex items-center gap-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all duration-300 shadow-lg hover:shadow-xl mx-auto"
              >
                <Plus className="w-5 h-5" />
                {t.createQuotation}
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.quotationNumber}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.client}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.issueDate}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.validUntil}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.amount}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.status}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.actions}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredQuotations.map((quotation, index) => (
                    <tr
                      key={quotation.id}
                      className={`border-b border-gray-100 hover:bg-gray-50 transition-colors animate-fadeIn`}
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      <td className={`py-4 px-6 font-medium text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-gray-400" />
                          {quotation.quotation_number}
                        </div>
                      </td>
                      <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-gray-400" />
                          {quotation.client_name || 'N/A'}
                        </div>
                      </td>
                      <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          {new Date(quotation.issue_date).toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA')}
                        </div>
                      </td>
                      <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          {new Date(quotation.valid_until).toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA')}
                        </div>
                      </td>
                      <td className={`py-4 px-6 font-semibold text-green-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {quotation.total_amount.toLocaleString()} {t.bhd}
                      </td>
                      <td className="py-4 px-6">
                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(quotation.status)}`}>
                          {t[quotation.status as keyof typeof t] || quotation.status}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          <button
                            onClick={() => handleViewQuotation(quotation)}
                            className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                            title={t.view}
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleEditQuotation(quotation)}
                            className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors duration-200"
                            title={t.edit}
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteQuotation(quotation.id)}
                            className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors duration-200"
                            title={t.delete}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {activeTab === 'invoices' && (
        /* Invoices Table */
        <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-lg overflow-hidden">
          {invoices.length === 0 ? (
            <div className="text-center py-16">
              <Receipt className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">{language === 'en' ? 'No invoices found' : 'لا توجد فواتير'}</h3>
              <p className="text-gray-500 mb-6">{language === 'en' ? 'Generate invoices from transactions' : 'أنشئ فواتير من المعاملات'}</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {language === 'en' ? 'Invoice Number' : 'رقم الفاتورة'}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.client}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.issueDate}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.amount}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.status}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.actions}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {invoices.map((invoice, index) => (
                    <tr
                      key={invoice.id}
                      className={`border-b border-gray-100 hover:bg-gray-50 transition-colors animate-fadeIn`}
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      <td className={`py-4 px-6 font-medium text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                        <div className="flex items-center gap-2">
                          <Receipt className="w-4 h-4 text-gray-400" />
                          {invoice.invoice_number}
                        </div>
                      </td>
                      <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-gray-400" />
                          {invoice.client_name || 'N/A'}
                        </div>
                      </td>
                      <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          {new Date(invoice.issue_date).toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA')}
                        </div>
                      </td>
                      <td className={`py-4 px-6 font-semibold text-green-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {invoice.total_amount.toLocaleString()} {t.bhd}
                      </td>
                      <td className="py-4 px-6">
                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(invoice.status)}`}>
                          {invoice.status}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          <button
                            onClick={() => handleEditInvoice(invoice)}
                            className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors duration-200"
                            title={t.edit}
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {activeTab === 'deliveries' && (
        /* Delivery Notes Table */
        <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-lg overflow-hidden">
          {deliveryNotes.length === 0 ? (
            <div className="text-center py-16">
              <Truck className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">{language === 'en' ? 'No delivery notes found' : 'لا توجد إشعارات تسليم'}</h3>
              <p className="text-gray-500 mb-6">{language === 'en' ? 'Generate delivery notes from transactions' : 'أنشئ إشعارات تسليم من المعاملات'}</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {language === 'en' ? 'Delivery Number' : 'رقم التسليم'}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.client}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {language === 'en' ? 'Delivery Date' : 'تاريخ التسليم'}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {language === 'en' ? 'Items' : 'العناصر'}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.status}
                    </th>
                    <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.actions}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {deliveryNotes.map((deliveryNote, index) => (
                    <tr
                      key={deliveryNote.id}
                      className={`border-b border-gray-100 hover:bg-gray-50 transition-colors animate-fadeIn`}
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      <td className={`py-4 px-6 font-medium text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                        <div className="flex items-center gap-2">
                          <Truck className="w-4 h-4 text-gray-400" />
                          {deliveryNote.delivery_number}
                        </div>
                      </td>
                      <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-gray-400" />
                          {deliveryNote.client_name || 'N/A'}
                        </div>
                      </td>
                      <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          {new Date(deliveryNote.delivery_date).toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA')}
                        </div>
                      </td>
                      <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                        <div className="flex items-center gap-2">
                          <Package className="w-4 h-4 text-gray-400" />
                          {deliveryNote.items?.length || 0} {language === 'en' ? 'items' : 'عنصر'}
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(deliveryNote.status)}`}>
                          {deliveryNote.status}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          <button
                            onClick={() => handleEditDeliveryNote(deliveryNote)}
                            className="p-2 text-orange-600 hover:bg-orange-100 rounded-lg transition-colors duration-200"
                            title={t.edit}
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Modals */}
      {selectedTransaction && modalType === 'invoice' && (
        <InvoiceModal
          transaction={selectedTransaction}
          language={language}
          onClose={handleCloseModal}
        />
      )}

      {selectedQuotation && modalType === 'quotation' && (
        <QuotationModal
          quotation={selectedQuotation}
          language={language}
          onClose={handleCloseModal}
        />
      )}

      {selectedQuotation && modalType === 'edit-quotation' && (
        <QuotationEditModal
          quotation={selectedQuotation}
          language={language}
          onClose={handleCloseModal}
          onSuccess={handleQuotationEditSuccess}
        />
      )}

      {selectedInvoice && modalType === 'edit-invoice' && (
        <InvoiceEditModal
          invoice={selectedInvoice}
          language={language}
          onClose={handleCloseModal}
          onSuccess={handleInvoiceEditSuccess}
        />
      )}

      {selectedDeliveryNote && modalType === 'edit-delivery' && (
        <DeliveryNoteEditModal
          deliveryNote={selectedDeliveryNote}
          language={language}
          onClose={handleCloseModal}
          onSuccess={handleDeliveryEditSuccess}
        />
      )}

      {selectedTransaction && modalType === 'delivery' && (
        <DeliveryNoteModal
          transaction={selectedTransaction}
          language={language}
          onClose={handleCloseModal}
          onDeliveryCreated={() => handleModalSuccess('delivery')}
        />
      )}

      {showCreateQuotation && (
        <QuotationCreationModal
          language={language}
          onClose={() => setShowCreateQuotation(false)}
          onSuccess={handleQuotationSuccess}
          bossId={bossId}
        />
      )}
    </div>
  );
};

export default QuotationInvoicePage;