import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  Download, 
  Edit3, 
  Trash2, 
  Users,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Eye,
  X,
  Save,
  AlertCircle,
  User,
  Building,
  Globe,
  MessageSquare,
  CheckCircle,
  ExternalLink,
  UserPlus
} from 'lucide-react';
import { clientService } from '../lib/supabase';
import type { Client } from '../lib/supabase';

interface ClientsPageProps {
  language: 'en' | 'ar';
  bossId?: string;
  userPermissions?: {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
  };
}

const ClientsPage: React.FC<ClientsPageProps> = ({ language, bossId, userPermissions }) => {
  const [clients, setClients] = useState<Client[]>([]);
  const [filteredClients, setFilteredClients] = useState<Client[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [sortBy, setSortBy] = useState<'name' | 'email' | 'created_at'>('created_at');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [viewingClient, setViewingClient] = useState<Client | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const isRTL = language === 'ar';

  // Get current user from localStorage to access boss ID
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Form state for adding/editing clients
  const [clientForm, setClientForm] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    company: '',
    website: '',
    socialMedia: [] as { platform: string; url: string }[],
    notes: ''
  });

  const translations = {
    en: {
      title: 'Clients',
      subtitle: 'Manage your client relationships',
      addClient: 'Add Client',
      searchPlaceholder: 'Search clients...',
      filterAll: 'All Clients',
      filterActive: 'Active',
      filterInactive: 'Inactive',
      sortByName: 'Name',
      sortByEmail: 'Email',
      sortByDate: 'Date Added',
      name: 'Client Name',
      email: 'Email',
      phone: 'Phone Number',
      address: 'Physical Address',
      company: 'Company Name',
      website: 'Website URL',
      socialMedia: 'Social Media',
      notes: 'Client Notes',
      dateAdded: 'Date Added',
      status: 'Status',
      actions: 'Actions',
      active: 'Active',
      inactive: 'Inactive',
      edit: 'Edit',
      delete: 'Delete',
      view: 'View',
      save: 'Save',
      cancel: 'Cancel',
      close: 'Close',
      addNewClient: 'Add New Client',
      editClient: 'Edit Client',
      clientDetails: 'Client Details',
      enterName: 'Enter Client Name',
      enterEmail: 'Enter Email Address',
      enterPhone: 'Enter Phone Number',
      enterAddress: 'Enter Physical Address or Location',
      enterCompany: 'Enter Company Name',
      enterWebsite: 'Enter Website URL',
      enterNotes: 'Enter Client Notes',
      confirmDelete: 'Are you sure you want to delete this client?',
      deleteClient: 'Delete Client',
      clientAdded: 'Client added successfully',
      clientUpdated: 'Client updated successfully',
      clientDeleted: 'Client deleted successfully',
      fillRequired: 'Please fill all required fields',
      invalidEmail: 'Please enter a valid email address',
      emailExists: 'Email address already exists',
      noClients: 'No clients found',
      noClientsDesc: 'Start by adding your first client',
      totalClients: 'Total Clients',
      activeClients: 'Active Clients',
      newThisMonth: 'New This Month',
      export: 'Export',
      print: 'Print',
      refresh: 'Refresh',
      required: 'Required',
      optional: 'Optional',
      contactInfo: 'Contact Information',
      businessInfo: 'Business Information',
      additionalInfo: 'Additional Information',
      addSocialMedia: 'Add Social Media',
      platform: 'Platform',
      url: 'URL',
      removeSocialMedia: 'Remove',
      loadingClients: 'Loading clients...',
      errorLoading: 'Error loading clients'
    },
    ar: {
      title: 'العملاء',
      subtitle: 'إدارة علاقاتك مع العملاء',
      addClient: 'إضافة عميل',
      searchPlaceholder: 'البحث في العملاء...',
      filterAll: 'جميع العملاء',
      filterActive: 'نشط',
      filterInactive: 'غير نشط',
      sortByName: 'الاسم',
      sortByEmail: 'البريد الإلكتروني',
      sortByDate: 'تاريخ الإضافة',
      name: 'اسم العميل',
      email: 'البريد الإلكتروني',
      phone: 'رقم الهاتف',
      address: 'العنوان الفعلي',
      company: 'اسم الشركة',
      website: 'رابط الموقع الإلكتروني',
      socialMedia: 'وسائل التواصل الاجتماعي',
      notes: 'ملاحظات العميل',
      dateAdded: 'تاريخ الإضافة',
      status: 'الحالة',
      actions: 'الإجراءات',
      active: 'نشط',
      inactive: 'غير نشط',
      edit: 'تعديل',
      delete: 'حذف',
      view: 'عرض',
      save: 'حفظ',
      cancel: 'إلغاء',
      close: 'إغلاق',
      addNewClient: 'إضافة عميل جديد',
      editClient: 'تعديل العميل',
      clientDetails: 'تفاصيل العميل',
      enterName: 'أدخل اسم العميل',
      enterEmail: 'أدخل عنوان البريد الإلكتروني',
      enterPhone: 'أدخل رقم الهاتف',
      enterAddress: 'أدخل العنوان الفعلي أو الموقع',
      enterCompany: 'أدخل اسم الشركة',
      enterWebsite: 'أدخل رابط الموقع الإلكتروني',
      enterNotes: 'أدخل ملاحظات العميل',
      confirmDelete: 'هل أنت متأكد من حذف هذا العميل؟',
      deleteClient: 'حذف العميل',
      clientAdded: 'تم إضافة العميل بنجاح',
      clientUpdated: 'تم تحديث العميل بنجاح',
      clientDeleted: 'تم حذف العميل بنجاح',
      fillRequired: 'يرجى ملء جميع الحقول المطلوبة',
      invalidEmail: 'يرجى إدخال عنوان بريد إلكتروني صحيح',
      emailExists: 'عنوان البريد الإلكتروني موجود بالفعل',
      noClients: 'لا يوجد عملاء',
      noClientsDesc: 'ابدأ بإضافة عميلك الأول',
      totalClients: 'إجمالي العملاء',
      activeClients: 'العملاء النشطين',
      newThisMonth: 'جديد هذا الشهر',
      export: 'تصدير',
      print: 'طباعة',
      refresh: 'تحديث',
      required: 'مطلوب',
      optional: 'اختياري',
      contactInfo: 'معلومات الاتصال',
      businessInfo: 'معلومات العمل',
      additionalInfo: 'معلومات إضافية',
      addSocialMedia: 'إضافة وسائل التواصل',
      platform: 'المنصة',
      url: 'الرابط',
      removeSocialMedia: 'إزالة',
      loadingClients: 'جاري تحميل العملاء...',
      errorLoading: 'خطأ في تحميل العملاء'
    }
  };

  const t = translations[language];

  // Default permissions for boss or if not provided
  const permissions = userPermissions || { view: true, add: true, edit: true, delete: true };

  // Load clients from Supabase
  useEffect(() => {
    const loadClients = async () => {
      setIsLoading(true);
      const currentUser = getCurrentUser();
      
      if (!currentUser) {
        setIsLoading(false);
        return;
      }

      // Use bossId if provided (for employees), otherwise use current user id (for boss)
      const targetBossId = bossId || currentUser.id;

      try {
        const result = await clientService.getClients(targetBossId);
        
        if (result.success) {
          setClients(result.data);
          setFilteredClients(result.data);
        } else {
          setError(result.error || t.errorLoading);
        }
      } catch (error) {
        console.error('Error loading clients:', error);
        setError(t.errorLoading);
      }
      
      setIsLoading(false);
    };

    loadClients();
  }, [bossId]);

  // Filter and sort clients
  useEffect(() => {
    let filtered = [...clients];

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(client =>
        client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        client.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        client.phone.includes(searchTerm) ||
        client.company?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(client => 
        filterStatus === 'active' ? client.is_active : !client.is_active
      );
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'name':
          comparison = a.name.localeCompare(b.name);
          break;
        case 'email':
          comparison = a.email.localeCompare(b.email);
          break;
        case 'created_at':
          comparison = new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
          break;
      }

      return sortOrder === 'asc' ? comparison : -comparison;
    });

    setFilteredClients(filtered);
  }, [clients, searchTerm, filterStatus, sortBy, sortOrder]);

  // Validate email format
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!clientForm.name || !clientForm.email || !clientForm.phone) {
      setError(t.fillRequired);
      return;
    }

    if (!validateEmail(clientForm.email)) {
      setError(t.invalidEmail);
      return;
    }

    const currentUser = getCurrentUser();
    if (!currentUser) {
      setError('User not found');
      return;
    }

    const targetBossId = bossId || currentUser.id;

    // Check if email exists
    const emailExists = await clientService.checkClientEmailExists(
      targetBossId, 
      clientForm.email, 
      editingClient?.id
    );
    
    if (emailExists) {
      setError(t.emailExists);
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      if (editingClient) {
        // Update existing client
        const result = await clientService.updateClient(editingClient.id, {
          name: clientForm.name,
          email: clientForm.email,
          phone: clientForm.phone,
          address: clientForm.address || undefined,
          company: clientForm.company || undefined,
          website: clientForm.website || undefined,
          social_media: clientForm.socialMedia,
          notes: clientForm.notes || undefined
        });

        if (result.success) {
          // Update local state
          const updatedClients = clients.map(client => 
            client.id === editingClient.id ? result.data : client
          );
          setClients(updatedClients);
          setSuccess(t.clientUpdated);
          setEditingClient(null);
        } else {
          setError(result.error || 'Failed to update client');
        }
      } else {
        // Add new client
        const result = await clientService.addClient(targetBossId, {
          name: clientForm.name,
          email: clientForm.email,
          phone: clientForm.phone,
          address: clientForm.address || undefined,
          company: clientForm.company || undefined,
          website: clientForm.website || undefined,
          social_media: clientForm.socialMedia,
          notes: clientForm.notes || undefined,
          is_active: true
        });

        if (result.success) {
          // Update local state
          setClients(prev => [...prev, result.data]);
          setSuccess(t.clientAdded);
        } else {
          setError(result.error || 'Failed to add client');
        }
      }

      setIsLoading(false);
      setShowAddModal(false);
      resetForm();

      setTimeout(() => setSuccess(''), 3000);
    } catch (error) {
      console.error('Error saving client:', error);
      setError('Failed to save client. Please try again.');
      setIsLoading(false);
    }
  };

  // Reset form
  const resetForm = () => {
    setClientForm({
      name: '',
      email: '',
      phone: '',
      address: '',
      company: '',
      website: '',
      socialMedia: [],
      notes: ''
    });
    setError('');
  };

  // Handle edit
  const handleEdit = (client: Client) => {
    setEditingClient(client);
    setClientForm({
      name: client.name,
      email: client.email,
      phone: client.phone,
      address: client.address || '',
      company: client.company || '',
      website: client.website || '',
      socialMedia: client.social_media || [],
      notes: client.notes || ''
    });
    setShowAddModal(true);
  };

  // Handle delete
  const handleDelete = async (clientId: string) => {
    if (window.confirm(t.confirmDelete)) {
      setIsLoading(true);
      
      try {
        const result = await clientService.deleteClient(clientId);
        
        if (result.success) {
          const updatedClients = clients.filter(client => client.id !== clientId);
          setClients(updatedClients);
          setSuccess(t.clientDeleted);
        } else {
          setError(result.error || 'Failed to delete client');
        }
      } catch (error) {
        console.error('Error deleting client:', error);
        setError('Failed to delete client. Please try again.');
      }
      
      setIsLoading(false);
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  // Toggle client status
  const toggleClientStatus = async (clientId: string) => {
    try {
      const result = await clientService.toggleClientStatus(clientId);
      
      if (result.success) {
        const updatedClients = clients.map(client => 
          client.id === clientId ? result.data : client
        );
        setClients(updatedClients);
      } else {
        setError(result.error || 'Failed to update client status');
        setTimeout(() => setError(''), 3000);
      }
    } catch (error) {
      console.error('Error updating client status:', error);
      setError('Failed to update client status');
      setTimeout(() => setError(''), 3000);
    }
  };

  // Add social media entry
  const addSocialMedia = () => {
    setClientForm(prev => ({
      ...prev,
      socialMedia: [...prev.socialMedia, { platform: '', url: '' }]
    }));
  };

  // Remove social media entry
  const removeSocialMedia = (index: number) => {
    setClientForm(prev => ({
      ...prev,
      socialMedia: prev.socialMedia.filter((_, i) => i !== index)
    }));
  };

  // Update social media entry
  const updateSocialMedia = (index: number, field: 'platform' | 'url', value: string) => {
    setClientForm(prev => ({
      ...prev,
      socialMedia: prev.socialMedia.map((item, i) => 
        i === index ? { ...item, [field]: value } : item
      )
    }));
  };

  // Calculate summary statistics
  const totalClients = clients.length;
  const activeClients = clients.filter(c => c.is_active).length;
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const newThisMonth = clients.filter(client => {
    const clientDate = new Date(client.created_at);
    return clientDate.getMonth() === currentMonth && clientDate.getFullYear() === currentYear;
  }).length;

  if (isLoading && clients.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">{t.loadingClients}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{t.title}</h1>
          <p className="text-gray-600">{t.subtitle}</p>
        </div>

        {permissions.add && (
          <button
            onClick={() => {
              resetForm();
              setEditingClient(null);
              setShowAddModal(true);
            }}
            className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            <Plus className="w-5 h-5" />
            {t.addClient}
          </button>
        )}
      </div>

      {/* Success/Error Messages */}
      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-indigo-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Users className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-blue-100 text-sm">{t.totalClients}</div>
              <div className="text-2xl font-bold">{totalClients}</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CheckCircle className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-green-100 text-sm">{t.activeClients}</div>
              <div className="text-2xl font-bold">{activeClients}</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Calendar className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-purple-100 text-sm">{t.newThisMonth}</div>
              <div className="text-2xl font-bold">{newThisMonth}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-lg">
        <div className={`flex flex-col md:flex-row gap-4 ${isRTL ? 'md:flex-row-reverse' : ''}`}>
          {/* Search */}
          <div className="flex-1 relative">
            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5`} />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t.searchPlaceholder}
              className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200`}
            />
          </div>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as 'all' | 'active' | 'inactive')}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            <option value="all">{t.filterAll}</option>
            <option value="active">{t.filterActive}</option>
            <option value="inactive">{t.filterInactive}</option>
          </select>

          {/* Sort By */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'name' | 'email' | 'created_at')}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            <option value="name">{t.sortByName}</option>
            <option value="email">{t.sortByEmail}</option>
            <option value="created_at">{t.sortByDate}</option>
          </select>

          {/* Sort Order */}
          <button
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            className="px-4 py-3 bg-gray-100 hover:bg-gray-200 rounded-2xl transition-all duration-200 flex items-center gap-2"
          >
            {sortOrder === 'asc' ? '↑' : '↓'}
          </button>
        </div>
      </div>

      {/* Clients Table */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-lg overflow-hidden">
        {filteredClients.length === 0 ? (
          <div className="text-center py-16">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">{t.noClients}</h3>
            <p className="text-gray-500 mb-6">{t.noClientsDesc}</p>
            {permissions.add && (
              <button
                onClick={() => {
                  resetForm();
                  setEditingClient(null);
                  setShowAddModal(true);
                }}
                className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl mx-auto"
              >
                <Plus className="w-5 h-5" />
                {t.addClient}
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.name}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.email}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.phone}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.company}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.status}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.actions}
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredClients.map((client, index) => (
                  <tr
                    key={client.id}
                    className={`border-b border-gray-100 hover:bg-gray-50 transition-colors animate-fadeIn`}
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <td className={`py-4 px-6 font-medium text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-semibold">
                          {client.name.charAt(0).toUpperCase()}
                        </div>
                        {client.name}
                      </div>
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-gray-400" />
                        {client.email}
                      </div>
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-gray-400" />
                        {client.phone}
                      </div>
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {client.company ? (
                        <div className="flex items-center gap-2">
                          <Building className="w-4 h-4 text-gray-400" />
                          {client.company}
                        </div>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className="py-4 px-6">
                      <button
                        onClick={() => toggleClientStatus(client.id)}
                        className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                          client.is_active
                            ? 'bg-green-100 text-green-800 hover:bg-green-200'
                            : 'bg-red-100 text-red-800 hover:bg-red-200'
                        }`}
                      >
                        <div className={`w-2 h-2 rounded-full ${client.is_active ? 'bg-green-500' : 'bg-red-500'}`}></div>
                        {client.is_active ? t.active : t.inactive}
                      </button>
                    </td>
                    <td className="py-4 px-6">
                      <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <button
                          onClick={() => setViewingClient(client)}
                          className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                          title={t.view}
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        {permissions.edit && (
                          <button
                            onClick={() => handleEdit(client)}
                            className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors duration-200"
                            title={t.edit}
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                        )}
                        {permissions.delete && (
                          <button
                            onClick={() => handleDelete(client.id)}
                            className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors duration-200"
                            title={t.delete}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add/Edit Client Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-fadeIn">
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-2xl font-bold text-gray-800">
                {editingClient ? t.editClient : t.addNewClient}
              </h2>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setEditingClient(null);
                  resetForm();
                }}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl mb-4 animate-fadeIn">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-5 h-5" />
                  {error}
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Contact Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.contactInfo}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Client Name - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.name} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={clientForm.name}
                      onChange={(e) => setClientForm(prev => ({ ...prev, name: e.target.value }))}
                      placeholder={t.enterName}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Email - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.email} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      value={clientForm.email}
                      onChange={(e) => setClientForm(prev => ({ ...prev, email: e.target.value }))}
                      placeholder={t.enterEmail}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Phone - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.phone} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      value={clientForm.phone}
                      onChange={(e) => setClientForm(prev => ({ ...prev, phone: e.target.value }))}
                      placeholder={t.enterPhone}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Address - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.address} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="text"
                      value={clientForm.address}
                      onChange={(e) => setClientForm(prev => ({ ...prev, address: e.target.value }))}
                      placeholder={t.enterAddress}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>
              </div>

              {/* Business Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.businessInfo}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Company - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.company} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="text"
                      value={clientForm.company}
                      onChange={(e) => setClientForm(prev => ({ ...prev, company: e.target.value }))}
                      placeholder={t.enterCompany}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Website - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.website} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="url"
                      value={clientForm.website}
                      onChange={(e) => setClientForm(prev => ({ ...prev, website: e.target.value }))}
                      placeholder={t.enterWebsite}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>
              </div>

              {/* Social Media */}
              <div>
                <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.socialMedia} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </h3>
                  <button
                    type="button"
                    onClick={addSocialMedia}
                    className="flex items-center gap-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-xl font-medium hover:bg-blue-200 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    {t.addSocialMedia}
                  </button>
                </div>

                {clientForm.socialMedia.length > 0 && (
                  <div className="space-y-3">
                    {clientForm.socialMedia.map((social, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <input
                          type="text"
                          value={social.platform}
                          onChange={(e) => updateSocialMedia(index, 'platform', e.target.value)}
                          placeholder={t.platform}
                          className="flex-1 px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                        />
                        <input
                          type="url"
                          value={social.url}
                          onChange={(e) => updateSocialMedia(index, 'url', e.target.value)}
                          placeholder={t.url}
                          className="flex-2 px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                        />
                        <button
                          type="button"
                          onClick={() => removeSocialMedia(index)}
                          className="p-3 text-red-600 hover:bg-red-100 rounded-xl transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Notes */}
              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.notes} <span className="text-gray-400 text-xs">({t.optional})</span>
                </label>
                <textarea
                  value={clientForm.notes}
                  onChange={(e) => setClientForm(prev => ({ ...prev, notes: e.target.value }))}
                  placeholder={t.enterNotes}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-none"
                />
              </div>

              {/* Action Buttons */}
              <div className={`flex gap-4 pt-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      {language === 'en' ? 'Saving...' : 'جاري الحفظ...'}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <Save className="w-5 h-5" />
                      {t.save}
                    </div>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingClient(null);
                    resetForm();
                  }}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Client Modal */}
      {viewingClient && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-fadeIn">
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-2xl font-bold text-gray-800">{t.clientDetails}</h2>
              <button
                onClick={() => setViewingClient(null)}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-6">
              {/* Client Header */}
              <div className={`flex items-center gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                  {viewingClient.name.charAt(0).toUpperCase()}
                </div>
                <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                  <h3 className="text-xl font-bold text-gray-800">{viewingClient.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <div className={`w-2 h-2 rounded-full ${viewingClient.is_active ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span className={`text-sm ${viewingClient.is_active ? 'text-green-600' : 'text-red-600'}`}>
                      {viewingClient.is_active ? t.active : t.inactive}
                    </span>
                  </div>
                </div>
              </div>

              {/* Contact Information */}
              <div className="bg-gray-50 rounded-2xl p-6">
                <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.contactInfo}
                </h4>
                <div className="space-y-3">
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Mail className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-700">{viewingClient.email}</span>
                  </div>
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Phone className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-700">{viewingClient.phone}</span>
                  </div>
                  {viewingClient.address && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <MapPin className="w-5 h-5 text-gray-400" />
                      <span className="text-gray-700">{viewingClient.address}</span>
                    </div>
                  )}
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Calendar className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-700">
                      {new Date(viewingClient.created_at).toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </span>
                  </div>
                </div>
              </div>

              {/* Business Information */}
              {(viewingClient.company || viewingClient.website) && (
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.businessInfo}
                  </h4>
                  <div className="space-y-3">
                    {viewingClient.company && (
                      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <Building className="w-5 h-5 text-gray-400" />
                        <span className="text-gray-700">{viewingClient.company}</span>
                      </div>
                    )}
                    {viewingClient.website && (
                      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <Globe className="w-5 h-5 text-gray-400" />
                        <a 
                          href={viewingClient.website} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800 transition-colors flex items-center gap-1"
                        >
                          {viewingClient.website}
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Social Media */}
              {viewingClient.social_media && viewingClient.social_media.length > 0 && (
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.socialMedia}
                  </h4>
                  <div className="space-y-2">
                    {viewingClient.social_media.map((social, index) => (
                      <div key={index} className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <MessageSquare className="w-4 h-4 text-gray-400" />
                        <span className="text-gray-600 font-medium">{social.platform}:</span>
                        <a 
                          href={social.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800 transition-colors flex items-center gap-1"
                        >
                          {social.url}
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Notes */}
              {viewingClient.notes && (
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.notes}
                  </h4>
                  <p className="text-gray-700 whitespace-pre-wrap">{viewingClient.notes}</p>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className={`flex gap-4 mt-8 ${isRTL ? 'flex-row-reverse' : ''}`}>
              {permissions.edit && (
                <button
                  onClick={() => {
                    setViewingClient(null);
                    handleEdit(viewingClient);
                  }}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl"
                >
                  <div className="flex items-center justify-center gap-2">
                    <Edit3 className="w-5 h-5" />
                    {t.edit}
                  </div>
                </button>
              )}
              <button
                onClick={() => setViewingClient(null)}
                className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
              >
                {t.close}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ClientsPage;