import React, { useState, useEffect } from 'react';
import { Plus, FileText, Users, BarChart3, CreditCard, Send, Calculator, Settings } from 'lucide-react';

interface QuickActionsProps {
  language: 'en' | 'ar';
  onPageChange: (page: string) => void;
}

const QuickActions: React.FC<QuickActionsProps> = ({ language, onPageChange }) => {
  const [themeSettings, setThemeSettings] = useState({
    backgroundColor: '#f8fafc',
    iconStyle: 'light'
  });
  const isRTL = language === 'ar';

  // Load theme settings
  useEffect(() => {
    const getCurrentUser = () => {
      const savedUser = localStorage.getItem('currentUser');
      return savedUser ? JSON.parse(savedUser) : null;
    };

    const getBossDataKey = (dataType: string) => {
      const currentUser = getCurrentUser();
      if (!currentUser) return null;
      return `spaceZone_boss_${currentUser.id}_${dataType}`;
    };

    const loadThemeSettings = () => {
      const themeKey = getBossDataKey('theme');
      if (!themeKey) return;
      
      const savedTheme = localStorage.getItem(themeKey);
      if (savedTheme) {
        try {
          const theme = JSON.parse(savedTheme);
          setThemeSettings(theme);
        } catch (error) {
          console.error('Error parsing theme:', error);
        }
      }
    };

    loadThemeSettings();

    // Listen for theme changes
    const handleThemeChange = (event: CustomEvent) => {
      setThemeSettings(event.detail);
    };

    window.addEventListener('themeChanged', handleThemeChange as EventListener);

    return () => {
      window.removeEventListener('themeChanged', handleThemeChange as EventListener);
    };
  }, []);

  const translations = {
    en: {
      title: 'Quick Actions',
      subtitle: 'Frequently used actions',
      addTransaction: 'Add Transaction',
      createInvoice: 'Create Invoice',
      addClient: 'Add Client',
      generateReport: 'Generate Report',
      viewReports: 'View Reports',
      sendInvoice: 'Send Invoice',
      calculator: 'Calculator',
      settings: 'Settings'
    },
    ar: {
      title: 'الإجراءات السريعة',
      subtitle: 'الإجراءات المستخدمة بكثرة',
      addTransaction: 'إضافة معاملة',
      createInvoice: 'إنشاء فاتورة',
      addClient: 'إضافة عميل',
      generateReport: 'إنشاء تقرير',
      viewReports: 'عرض التقارير',
      sendInvoice: 'إرسال فاتورة',
      calculator: 'آلة حاسبة',
      settings: 'الإعدادات'
    }
  };

  const t = translations[language];

  // Get action colors based on theme
  const getActionColors = () => {
    switch (themeSettings.iconStyle) {
      case 'dark':
        return [
          { color: 'from-gray-700 to-gray-900', hoverColor: 'hover:from-gray-800 hover:to-black' },
          { color: 'from-slate-600 to-slate-800', hoverColor: 'hover:from-slate-700 hover:to-slate-900' },
          { color: 'from-zinc-700 to-zinc-900', hoverColor: 'hover:from-zinc-800 hover:to-black' },
          { color: 'from-stone-600 to-stone-800', hoverColor: 'hover:from-stone-700 hover:to-stone-900' },
          { color: 'from-neutral-700 to-neutral-900', hoverColor: 'hover:from-neutral-800 hover:to-black' },
          { color: 'from-gray-600 to-gray-800', hoverColor: 'hover:from-gray-700 hover:to-gray-900' }
        ];
      case 'soft':
        return [
          { color: 'from-blue-300 to-blue-400', hoverColor: 'hover:from-blue-400 hover:to-blue-500' },
          { color: 'from-green-300 to-green-400', hoverColor: 'hover:from-green-400 hover:to-green-500' },
          { color: 'from-purple-300 to-purple-400', hoverColor: 'hover:from-purple-400 hover:to-purple-500' },
          { color: 'from-pink-300 to-pink-400', hoverColor: 'hover:from-pink-400 hover:to-pink-500' },
          { color: 'from-teal-300 to-teal-400', hoverColor: 'hover:from-teal-400 hover:to-teal-500' },
          { color: 'from-indigo-300 to-indigo-400', hoverColor: 'hover:from-indigo-400 hover:to-indigo-500' }
        ];
      default: // light
        return [
          { color: 'from-blue-500 to-blue-600', hoverColor: 'hover:from-blue-600 hover:to-blue-700' },
          { color: 'from-green-500 to-green-600', hoverColor: 'hover:from-green-600 hover:to-green-700' },
          { color: 'from-purple-500 to-purple-600', hoverColor: 'hover:from-purple-600 hover:to-purple-700' },
          { color: 'from-orange-500 to-orange-600', hoverColor: 'hover:from-orange-600 hover:to-orange-700' },
          { color: 'from-teal-500 to-teal-600', hoverColor: 'hover:from-teal-600 hover:to-teal-700' },
          { color: 'from-indigo-500 to-indigo-600', hoverColor: 'hover:from-indigo-600 hover:to-indigo-700' }
        ];
    }
  };

  const actionColors = getActionColors();

  const actions = [
    {
      id: 'add-transaction',
      title: t.addTransaction,
      icon: Plus,
      color: actionColors[0].color,
      hoverColor: actionColors[0].hoverColor,
      page: 'transactions'
    },
    {
      id: 'create-invoice',
      title: t.createInvoice,
      icon: FileText,
      color: actionColors[1].color,
      hoverColor: actionColors[1].hoverColor,
      page: 'transactions'
    },
    {
      id: 'add-client',
      title: t.addClient,
      icon: Users,
      color: actionColors[2].color,
      hoverColor: actionColors[2].hoverColor,
      page: 'clients'
    },
    {
      id: 'generate-report',
      title: t.generateReport,
      icon: BarChart3,
      color: actionColors[3].color,
      hoverColor: actionColors[3].hoverColor,
      page: 'reports'
    },
    {
      id: 'send-invoice',
      title: t.sendInvoice,
      icon: Send,
      color: actionColors[4].color,
      hoverColor: actionColors[4].hoverColor,
      page: 'transactions'
    },
    {
      id: 'calculator',
      title: t.calculator,
      icon: Calculator,
      color: actionColors[5].color,
      hoverColor: actionColors[5].hoverColor,
      page: 'home' // يمكن إضافة صفحة آلة حاسبة منفصلة لاحقاً
    }
  ];

  const handleActionClick = (actionId: string) => {
    const action = actions.find(a => a.id === actionId);
    if (action && action.page) {
      onPageChange(action.page);
    }
  };

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/50">
      <div className={`${isRTL ? 'text-right' : 'text-left'} mb-6`}>
        <h3 className="text-xl font-bold text-gray-800 mb-1">{t.title}</h3>
        <p className="text-gray-600 text-sm">{t.subtitle}</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {actions.map((action, index) => {
          const Icon = action.icon;
          return (
            <button
              key={action.id}
              onClick={() => handleActionClick(action.id)}
              className={`group relative overflow-hidden bg-gradient-to-r ${action.color} ${action.hoverColor} text-white p-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 animate-fadeIn`}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              {/* Background animation */}
              <div className="absolute inset-0 bg-white/10 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>
              
              <div className={`relative z-10 flex flex-col items-center gap-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                <Icon className="w-6 h-6 group-hover:scale-110 transition-transform duration-200" />
                <span className="text-sm font-medium text-center leading-tight">
                  {action.title}
                </span>
              </div>

              {/* Hover effect overlay */}
              <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/10 to-white/0 transform -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
            </button>
          );
        })}
      </div>

      {/* Additional quick access */}
      <div className="mt-6 pt-4 border-t border-gray-200">
        <button
          onClick={() => handleActionClick('settings')}
          className={`w-full flex items-center gap-3 p-3 rounded-xl text-gray-600 hover:text-gray-800 hover:bg-gray-100 transition-all duration-200 ${isRTL ? 'flex-row-reverse text-right' : 'text-left'}`}
        >
          <Settings className="w-5 h-5" />
          <span className="text-sm font-medium">{t.settings}</span>
        </button>
      </div>
    </div>
  );
};

export default QuickActions;