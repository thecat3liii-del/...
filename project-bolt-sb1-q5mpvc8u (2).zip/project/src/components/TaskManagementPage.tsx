import React, { useState, useEffect } from 'react';
import { 
  Calendar,
  Plus,
  Search,
  Filter,
  Eye,
  Edit3,
  Trash2,
  Clock,
  User,
  Flag,
  CheckCircle,
  AlertCircle,
  Play,
  Pause,
  Square,
  RotateCcw,
  Target,
  Briefcase,
  MessageSquare,
  Save,
  X,
  ChevronLeft,
  ChevronRight,
  Users,
  FolderOpen,
  Activity,
  TrendingUp,
  Award,
  Zap
} from 'lucide-react';
import { projectService, taskService, taskCommentService } from '../lib/taskService';
import { authService } from '../lib/supabase';
import type { Project, Task, TaskComment } from '../lib/taskService';
import type { Employee } from '../lib/supabase';

interface TaskManagementPageProps {
  language: 'en' | 'ar';
  bossId?: string;
}

const TaskManagementPage: React.FC<TaskManagementPageProps> = ({ language, bossId }) => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [filteredTasks, setFilteredTasks] = useState<Task[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [filterProject, setFilterProject] = useState<string>('all');
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [calendarView, setCalendarView] = useState<'month' | 'week' | 'day'>('month');
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [showProjectModal, setShowProjectModal] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [viewingTask, setViewingTask] = useState<Task | null>(null);
  const [taskComments, setTaskComments] = useState<TaskComment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const isRTL = language === 'ar';

  // Get current user from localStorage
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Task form state
  const [taskForm, setTaskForm] = useState({
    title: '',
    description: '',
    projectId: '',
    startDate: new Date().toISOString().split('T')[0],
    endDate: '',
    startTime: '',
    endTime: '',
    status: 'pending' as Task['status'],
    priority: 'medium' as Task['priority'],
    assignedTo: '',
    category: '',
    tags: [] as string[],
    reminderDate: '',
    isRecurring: false,
    recurrencePattern: undefined as Task['recurrence_pattern'],
    completionPercentage: 0,
    estimatedHours: 0,
    actualHours: 0
  });

  // Project form state
  const [projectForm, setProjectForm] = useState({
    name: '',
    description: '',
    startDate: new Date().toISOString().split('T')[0],
    endDate: '',
    status: 'planning' as Project['status'],
    priority: 'medium' as Project['priority'],
    budget: 0,
    progress: 0,
    color: '#3b82f6'
  });

  const translations = {
    en: {
      title: 'Tasks & Projects',
      subtitle: 'Manage your tasks and projects efficiently',
      addTask: 'Add Task',
      addProject: 'Add Project',
      searchPlaceholder: 'Search tasks and projects...',
      filterAll: 'All',
      filterActive: 'Active',
      filterCompleted: 'Completed',
      filterPending: 'Pending',
      filterInProgress: 'In Progress',
      filterOnHold: 'On Hold',
      filterCancelled: 'Cancelled',
      priorityLow: 'Low',
      priorityMedium: 'Medium',
      priorityHigh: 'High',
      priorityUrgent: 'Urgent',
      statusPending: 'Pending',
      statusInProgress: 'In Progress',
      statusCompleted: 'Completed',
      statusCancelled: 'Cancelled',
      statusOnHold: 'On Hold',
      projectStatusPlanning: 'Planning',
      projectStatusActive: 'Active',
      projectStatusCompleted: 'Completed',
      monthView: 'Month',
      weekView: 'Week',
      dayView: 'Day',
      today: 'Today',
      taskTitle: 'Task Title',
      taskDescription: 'Task Description',
      project: 'Project',
      startDate: 'Start Date',
      endDate: 'End Date',
      startTime: 'Start Time',
      endTime: 'End Time',
      status: 'Status',
      priority: 'Priority',
      assignedTo: 'Assigned To',
      category: 'Category',
      tags: 'Tags',
      reminderDate: 'Reminder Date',
      isRecurring: 'Recurring Task',
      recurrencePattern: 'Recurrence Pattern',
      completionPercentage: 'Completion %',
      estimatedHours: 'Estimated Hours',
      actualHours: 'Actual Hours',
      projectName: 'Project Name',
      projectDescription: 'Project Description',
      budget: 'Budget',
      progress: 'Progress',
      color: 'Color',
      save: 'Save',
      cancel: 'Cancel',
      close: 'Close',
      edit: 'Edit',
      delete: 'Delete',
      view: 'View',
      addComment: 'Add Comment',
      comments: 'Comments',
      noTasks: 'No tasks found',
      noProjects: 'No projects found',
      noComments: 'No comments yet',
      taskAdded: 'Task added successfully',
      taskUpdated: 'Task updated successfully',
      taskDeleted: 'Task deleted successfully',
      projectAdded: 'Project added successfully',
      projectUpdated: 'Project updated successfully',
      projectDeleted: 'Project deleted successfully',
      commentAdded: 'Comment added successfully',
      fillRequired: 'Please fill all required fields',
      confirmDelete: 'Are you sure you want to delete this item?',
      totalTasks: 'Total Tasks',
      completedTasks: 'Completed Tasks',
      activeTasks: 'Active Tasks',
      overdueTasks: 'Overdue Tasks',
      totalProjects: 'Total Projects',
      activeProjects: 'Active Projects',
      completedProjects: 'Completed Projects',
      projectProgress: 'Project Progress',
      taskDetails: 'Task Details',
      projectDetails: 'Project Details',
      addNewTask: 'Add New Task',
      addNewProject: 'Add New Project',
      editTask: 'Edit Task',
      editProject: 'Edit Project',
      selectProject: 'Select Project',
      selectEmployee: 'Select Employee',
      enterTitle: 'Enter task title',
      enterDescription: 'Enter task description',
      enterProjectName: 'Enter project name',
      enterProjectDescription: 'Enter project description',
      enterCategory: 'Enter category',
      enterTags: 'Enter tags (comma separated)',
      enterComment: 'Enter your comment',
      daily: 'Daily',
      weekly: 'Weekly',
      monthly: 'Monthly',
      yearly: 'Yearly',
      required: 'Required',
      optional: 'Optional',
      bhd: 'BHD',
      hours: 'hours',
      days: 'days',
      dueIn: 'Due in',
      overdue: 'Overdue',
      createdBy: 'Created by',
      assignedBy: 'Assigned by',
      lastUpdated: 'Last updated',
      taskOverview: 'Task Overview',
      projectOverview: 'Project Overview',
      calendarView: 'Calendar View',
      listView: 'List View',
      kanbanView: 'Kanban View',
      timeline: 'Timeline',
      statistics: 'Statistics',
      performance: 'Performance',
      productivity: 'Productivity Score',
      efficiency: 'Efficiency Rate',
      onTime: 'On Time Completion',
      teamPerformance: 'Team Performance'
    },
    ar: {
      title: 'المهام والمشاريع',
      subtitle: 'إدارة المهام والمشاريع بكفاءة',
      addTask: 'إضافة مهمة',
      addProject: 'إضافة مشروع',
      searchPlaceholder: 'البحث في المهام والمشاريع...',
      filterAll: 'الكل',
      filterActive: 'نشط',
      filterCompleted: 'مكتمل',
      filterPending: 'معلق',
      filterInProgress: 'قيد التنفيذ',
      filterOnHold: 'متوقف',
      filterCancelled: 'ملغي',
      priorityLow: 'منخفض',
      priorityMedium: 'متوسط',
      priorityHigh: 'عالي',
      priorityUrgent: 'عاجل',
      statusPending: 'معلق',
      statusInProgress: 'قيد التنفيذ',
      statusCompleted: 'مكتمل',
      statusCancelled: 'ملغي',
      statusOnHold: 'متوقف',
      projectStatusPlanning: 'تخطيط',
      projectStatusActive: 'نشط',
      projectStatusCompleted: 'مكتمل',
      monthView: 'عرض شهري',
      weekView: 'عرض أسبوعي',
      dayView: 'عرض يومي',
      today: 'اليوم',
      taskTitle: 'عنوان المهمة',
      taskDescription: 'وصف المهمة',
      project: 'المشروع',
      startDate: 'تاريخ البداية',
      endDate: 'تاريخ النهاية',
      startTime: 'وقت البداية',
      endTime: 'وقت النهاية',
      status: 'الحالة',
      priority: 'الأولوية',
      assignedTo: 'مُعيَّن إلى',
      category: 'الفئة',
      tags: 'العلامات',
      reminderDate: 'تاريخ التذكير',
      isRecurring: 'مهمة متكررة',
      recurrencePattern: 'نمط التكرار',
      completionPercentage: 'نسبة الإنجاز %',
      estimatedHours: 'الساعات المقدرة',
      actualHours: 'الساعات الفعلية',
      projectName: 'اسم المشروع',
      projectDescription: 'وصف المشروع',
      budget: 'الميزانية',
      progress: 'التقدم',
      color: 'اللون',
      save: 'حفظ',
      cancel: 'إلغاء',
      close: 'إغلاق',
      edit: 'تعديل',
      delete: 'حذف',
      view: 'عرض',
      addComment: 'إضافة تعليق',
      comments: 'التعليقات',
      noTasks: 'لا توجد مهام',
      noProjects: 'لا توجد مشاريع',
      noComments: 'لا توجد تعليقات بعد',
      taskAdded: 'تم إضافة المهمة بنجاح',
      taskUpdated: 'تم تحديث المهمة بنجاح',
      taskDeleted: 'تم حذف المهمة بنجاح',
      projectAdded: 'تم إضافة المشروع بنجاح',
      projectUpdated: 'تم تحديث المشروع بنجاح',
      projectDeleted: 'تم حذف المشروع بنجاح',
      commentAdded: 'تم إضافة التعليق بنجاح',
      fillRequired: 'يرجى ملء جميع الحقول المطلوبة',
      confirmDelete: 'هل أنت متأكد من حذف هذا العنصر؟',
      totalTasks: 'إجمالي المهام',
      completedTasks: 'المهام المكتملة',
      activeTasks: 'المهام النشطة',
      overdueTasks: 'المهام المتأخرة',
      totalProjects: 'إجمالي المشاريع',
      activeProjects: 'المشاريع النشطة',
      completedProjects: 'المشاريع المكتملة',
      projectProgress: 'تقدم المشروع',
      taskDetails: 'تفاصيل المهمة',
      projectDetails: 'تفاصيل المشروع',
      addNewTask: 'إضافة مهمة جديدة',
      addNewProject: 'إضافة مشروع جديد',
      editTask: 'تعديل المهمة',
      editProject: 'تعديل المشروع',
      selectProject: 'اختر المشروع',
      selectEmployee: 'اختر الموظف',
      enterTitle: 'أدخل عنوان المهمة',
      enterDescription: 'أدخل وصف المهمة',
      enterProjectName: 'أدخل اسم المشروع',
      enterProjectDescription: 'أدخل وصف المشروع',
      enterCategory: 'أدخل الفئة',
      enterTags: 'أدخل العلامات (مفصولة بفواصل)',
      enterComment: 'أدخل تعليقك',
      daily: 'يومي',
      weekly: 'أسبوعي',
      monthly: 'شهري',
      yearly: 'سنوي',
      required: 'مطلوب',
      optional: 'اختياري',
      bhd: 'د.ب',
      hours: 'ساعات',
      days: 'أيام',
      dueIn: 'مستحق خلال',
      overdue: 'متأخر',
      createdBy: 'أنشأ بواسطة',
      assignedBy: 'عُيِّن بواسطة',
      lastUpdated: 'آخر تحديث',
      taskOverview: 'نظرة عامة على المهام',
      projectOverview: 'نظرة عامة على المشاريع',
      calendarView: 'عرض التقويم',
      listView: 'عرض القائمة',
      kanbanView: 'عرض كانبان',
      timeline: 'الجدول الزمني',
      statistics: 'الإحصائيات',
      performance: 'الأداء',
      productivity: 'نقاط الإنتاجية',
      efficiency: 'معدل الكفاءة',
      onTime: 'الإنجاز في الوقت المحدد',
      teamPerformance: 'أداء الفريق'
    }
  };

  const t = translations[language];

  // Load data
  useEffect(() => {
    loadData();
  }, [bossId]);

  const loadData = async () => {
    setIsLoading(true);
    const currentUser = getCurrentUser();
    
    if (!currentUser) {
      setIsLoading(false);
      return;
    }

    const targetBossId = bossId || currentUser.id;

    try {
      // Load projects
      const projectsResult = await projectService.getProjects(targetBossId);
      if (projectsResult.success) {
        setProjects(projectsResult.data);
      }

      // Load tasks
      const tasksResult = await taskService.getTasks(targetBossId);
      if (tasksResult.success) {
        setTasks(tasksResult.data);
      }

      // Load employees
      const employeesResult = await authService.getEmployees(targetBossId);
      if (employeesResult.success) {
        setEmployees(employeesResult.data);
      }
    } catch (error) {
      console.error('Error loading data:', error);
      setError('Failed to load data');
    }
    
    setIsLoading(false);
  };

  // Filter tasks
  useEffect(() => {
    let filtered = [...tasks];

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(task =>
        task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.category?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(task => task.status === filterStatus);
    }

    // Priority filter
    if (filterPriority !== 'all') {
      filtered = filtered.filter(task => task.priority === filterPriority);
    }

    // Project filter
    if (filterProject !== 'all') {
      filtered = filtered.filter(task => task.project_id === filterProject);
    }

    setFilteredTasks(filtered);
  }, [tasks, searchTerm, filterStatus, filterPriority, filterProject]);

  // Calendar functions
  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentMonth(prev => {
      const newMonth = new Date(prev);
      if (direction === 'prev') {
        newMonth.setMonth(newMonth.getMonth() - 1);
      } else {
        newMonth.setMonth(newMonth.getMonth() + 1);
      }
      return newMonth;
    });
  };

  const getTasksForDate = (date: Date) => {
    return filteredTasks.filter(task => {
      const taskDate = new Date(task.start_date);
      return taskDate.toDateString() === date.toDateString();
    });
  };

  // Form handlers
  const handleTaskSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!taskForm.title) {
      setError(t.fillRequired);
      return;
    }

    const currentUser = getCurrentUser();
    if (!currentUser) return;

    const targetBossId = bossId || currentUser.id;
    setIsLoading(true);
    setError('');

    try {
      const taskData = {
        title: taskForm.title,
        description: taskForm.description || undefined,
        project_id: taskForm.projectId || undefined,
        start_date: taskForm.startDate,
        end_date: taskForm.endDate || undefined,
        start_time: taskForm.startTime || undefined,
        end_time: taskForm.endTime || undefined,
        status: taskForm.status,
        priority: taskForm.priority,
        assigned_to: taskForm.assignedTo || undefined,
        category: taskForm.category || undefined,
        tags: taskForm.tags,
        reminder_date: taskForm.reminderDate || undefined,
        is_recurring: taskForm.isRecurring,
        recurrence_pattern: taskForm.recurrencePattern,
        completion_percentage: taskForm.completionPercentage,
        estimated_hours: taskForm.estimatedHours || undefined,
        actual_hours: taskForm.actualHours || undefined,
        is_active: true
      };

      if (editingTask) {
        const result = await taskService.updateTask(editingTask.id, taskData);
        if (result.success) {
          setSuccess(t.taskUpdated);
          loadData();
        } else {
          setError(result.error || 'Failed to update task');
        }
      } else {
        const result = await taskService.addTask(targetBossId, taskData);
        if (result.success) {
          setSuccess(t.taskAdded);
          loadData();
        } else {
          setError(result.error || 'Failed to add task');
        }
      }

      setShowTaskModal(false);
      resetTaskForm();
    } catch (error) {
      console.error('Error saving task:', error);
      setError('Failed to save task');
    }
    
    setIsLoading(false);
    setTimeout(() => setSuccess(''), 3000);
  };

  const handleProjectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!projectForm.name) {
      setError(t.fillRequired);
      return;
    }

    const currentUser = getCurrentUser();
    if (!currentUser) return;

    const targetBossId = bossId || currentUser.id;
    setIsLoading(true);
    setError('');

    try {
      const projectData = {
        name: projectForm.name,
        description: projectForm.description || undefined,
        start_date: projectForm.startDate,
        end_date: projectForm.endDate || undefined,
        status: projectForm.status,
        priority: projectForm.priority,
        budget: projectForm.budget || undefined,
        progress: projectForm.progress,
        color: projectForm.color,
        is_active: true
      };

      if (editingProject) {
        const result = await projectService.updateProject(editingProject.id, projectData);
        if (result.success) {
          setSuccess(t.projectUpdated);
          loadData();
        } else {
          setError(result.error || 'Failed to update project');
        }
      } else {
        const result = await projectService.addProject(targetBossId, projectData);
        if (result.success) {
          setSuccess(t.projectAdded);
          loadData();
        } else {
          setError(result.error || 'Failed to add project');
        }
      }

      setShowProjectModal(false);
      resetProjectForm();
    } catch (error) {
      console.error('Error saving project:', error);
      setError('Failed to save project');
    }
    
    setIsLoading(false);
    setTimeout(() => setSuccess(''), 3000);
  };

  const resetTaskForm = () => {
    setTaskForm({
      title: '',
      description: '',
      projectId: '',
      startDate: new Date().toISOString().split('T')[0],
      endDate: '',
      startTime: '',
      endTime: '',
      status: 'pending',
      priority: 'medium',
      assignedTo: '',
      category: '',
      tags: [],
      reminderDate: '',
      isRecurring: false,
      recurrencePattern: undefined,
      completionPercentage: 0,
      estimatedHours: 0,
      actualHours: 0
    });
    setEditingTask(null);
  };

  const resetProjectForm = () => {
    setProjectForm({
      name: '',
      description: '',
      startDate: new Date().toISOString().split('T')[0],
      endDate: '',
      status: 'planning',
      priority: 'medium',
      budget: 0,
      progress: 0,
      color: '#3b82f6'
    });
    setEditingProject(null);
  };

  // Handle edit
  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setTaskForm({
      title: task.title,
      description: task.description || '',
      projectId: task.project_id || '',
      startDate: task.start_date,
      endDate: task.end_date || '',
      startTime: task.start_time || '',
      endTime: task.end_time || '',
      status: task.status,
      priority: task.priority,
      assignedTo: task.assigned_to || '',
      category: task.category || '',
      tags: task.tags || [],
      reminderDate: task.reminder_date || '',
      isRecurring: task.is_recurring,
      recurrencePattern: task.recurrence_pattern,
      completionPercentage: task.completion_percentage,
      estimatedHours: task.estimated_hours || 0,
      actualHours: task.actual_hours || 0
    });
    setShowTaskModal(true);
  };

  const handleEditProject = (project: Project) => {
    setEditingProject(project);
    setProjectForm({
      name: project.name,
      description: project.description || '',
      startDate: project.start_date,
      endDate: project.end_date || '',
      status: project.status,
      priority: project.priority,
      budget: project.budget || 0,
      progress: project.progress,
      color: project.color || '#3b82f6'
    });
    setShowProjectModal(true);
  };

  // Handle delete
  const handleDeleteTask = async (taskId: string) => {
    if (window.confirm(t.confirmDelete)) {
      try {
        const result = await taskService.deleteTask(taskId);
        if (result.success) {
          setSuccess(t.taskDeleted);
          loadData();
        } else {
          setError(result.error || 'Failed to delete task');
        }
      } catch (error) {
        console.error('Error deleting task:', error);
        setError('Failed to delete task');
      }
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  const handleDeleteProject = async (projectId: string) => {
    if (window.confirm(t.confirmDelete)) {
      try {
        const result = await projectService.deleteProject(projectId);
        if (result.success) {
          setSuccess(t.projectDeleted);
          loadData();
        } else {
          setError(result.error || 'Failed to delete project');
        }
      } catch (error) {
        console.error('Error deleting project:', error);
        setError('Failed to delete project');
      }
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  // Handle view task
  const handleViewTask = async (task: Task) => {
    setViewingTask(task);
    
    // Load comments for this task
    try {
      const result = await taskCommentService.getTaskComments(task.id);
      if (result.success) {
        setTaskComments(result.data);
      }
    } catch (error) {
      console.error('Error loading comments:', error);
    }
  };

  // Handle add comment
  const handleAddComment = async () => {
    if (!newComment.trim() || !viewingTask) return;

    const currentUser = getCurrentUser();
    if (!currentUser) return;

    try {
      const result = await taskCommentService.addComment(
        viewingTask.id,
        currentUser.id,
        currentUser.fullName,
        newComment.trim()
      );

      if (result.success) {
        setTaskComments(prev => [...prev, result.data]);
        setNewComment('');
        setSuccess(t.commentAdded);
      } else {
        setError(result.error || 'Failed to add comment');
      }
    } catch (error) {
      console.error('Error adding comment:', error);
      setError('Failed to add comment');
    }
    
    setTimeout(() => setSuccess(''), 3000);
  };

  // Calculate statistics
  const calculateStats = () => {
    const totalTasks = tasks.length;
    const completedTasks = tasks.filter(t => t.status === 'completed').length;
    const activeTasks = tasks.filter(t => t.status === 'in_progress').length;
    const overdueTasks = tasks.filter(t => {
      if (!t.end_date) return false;
      const endDate = new Date(t.end_date);
      const today = new Date();
      return endDate < today && t.status !== 'completed';
    }).length;

    const totalProjects = projects.length;
    const activeProjects = projects.filter(p => p.status === 'active').length;
    const completedProjects = projects.filter(p => p.status === 'completed').length;
    const avgProjectProgress = projects.length > 0 
      ? projects.reduce((sum, p) => sum + p.progress, 0) / projects.length 
      : 0;

    return {
      totalTasks,
      completedTasks,
      activeTasks,
      overdueTasks,
      totalProjects,
      activeProjects,
      completedProjects,
      avgProjectProgress
    };
  };

  const stats = calculateStats();

  // Get priority color
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'urgent': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-gray-100 text-gray-800';
      case 'in_progress': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      case 'on_hold': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // Render calendar
  const renderCalendar = () => {
    const daysInMonth = getDaysInMonth(currentMonth);
    const firstDay = getFirstDayOfMonth(currentMonth);
    const days = [];

    // Empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-24 border border-gray-100"></div>);
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
      const dayTasks = getTasksForDate(date);
      const isToday = date.toDateString() === new Date().toDateString();
      const isSelected = date.toDateString() === selectedDate.toDateString();

      days.push(
        <div
          key={day}
          className={`h-24 border border-gray-100 p-2 cursor-pointer hover:bg-gray-50 transition-colors ${
            isToday ? 'bg-blue-50 border-blue-200' : ''
          } ${isSelected ? 'bg-blue-100 border-blue-300' : ''}`}
          onClick={() => setSelectedDate(date)}
        >
          <div className={`text-sm font-medium mb-1 ${isToday ? 'text-blue-600' : 'text-gray-700'}`}>
            {day}
          </div>
          <div className="space-y-1">
            {dayTasks.slice(0, 2).map(task => (
              <div
                key={task.id}
                className={`text-xs px-2 py-1 rounded truncate ${getPriorityColor(task.priority)}`}
                title={task.title}
              >
                {task.title}
              </div>
            ))}
            {dayTasks.length > 2 && (
              <div className="text-xs text-gray-500">+{dayTasks.length - 2} more</div>
            )}
          </div>
        </div>
      );
    }

    return days;
  };

  // Generate year options from 2020 to 2050
  const generateYearOptions = () => {
    const years = [];
    for (let year = 2020; year <= 2050; year++) {
      years.push(year);
    }
    return years;
  };

  const yearOptions = generateYearOptions();

  if (isLoading && tasks.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">Loading tasks and projects...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{t.title}</h1>
          <p className="text-gray-600">{t.subtitle}</p>
        </div>

        <div className={`flex items-center gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <button
            onClick={() => {
              resetTaskForm();
              setShowTaskModal(true);
            }}
            className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            <Plus className="w-5 h-5" />
            {t.addTask}
          </button>
          <button
            onClick={() => {
              resetProjectForm();
              setShowProjectModal(true);
            }}
            className="flex items-center gap-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            <Plus className="w-5 h-5" />
            {t.addProject}
          </button>
        </div>
      </div>

      {/* Success/Error Messages */}
      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-indigo-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CheckCircle className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-blue-100 text-sm">{t.totalTasks}</div>
              <div className="text-2xl font-bold">{stats.totalTasks}</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Target className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-green-100 text-sm">{t.completedTasks}</div>
              <div className="text-2xl font-bold">{stats.completedTasks}</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <FolderOpen className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-purple-100 text-sm">{t.activeProjects}</div>
              <div className="text-2xl font-bold">{stats.activeProjects}</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-red-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <AlertCircle className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-orange-100 text-sm">{t.overdueTasks}</div>
              <div className="text-2xl font-bold">{stats.overdueTasks}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-lg">
        <div className={`flex flex-col lg:flex-row gap-4 ${isRTL ? 'lg:flex-row-reverse' : ''}`}>
          {/* Search */}
          <div className="flex-1 relative">
            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5`} />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t.searchPlaceholder}
              className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200`}
            />
          </div>

          {/* Filters */}
          <div className={`flex gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">{t.filterAll}</option>
              <option value="pending">{t.statusPending}</option>
              <option value="in_progress">{t.statusInProgress}</option>
              <option value="completed">{t.statusCompleted}</option>
              <option value="on_hold">{t.statusOnHold}</option>
              <option value="cancelled">{t.statusCancelled}</option>
            </select>

            <select
              value={filterPriority}
              onChange={(e) => setFilterPriority(e.target.value)}
              className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">{t.filterAll}</option>
              <option value="low">{t.priorityLow}</option>
              <option value="medium">{t.priorityMedium}</option>
              <option value="high">{t.priorityHigh}</option>
              <option value="urgent">{t.priorityUrgent}</option>
            </select>

            <select
              value={filterProject}
              onChange={(e) => setFilterProject(e.target.value)}
              className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">{t.filterAll}</option>
              {projects.map(project => (
                <option key={project.id} value={project.id}>{project.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Calendar */}
        <div className="lg:col-span-2">
          <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 shadow-xl">
            {/* Calendar Header */}
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <div className={`flex items-center gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <button
                  onClick={() => navigateMonth('prev')}
                  className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
                >
                  <ChevronLeft className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
                </button>
                
                <div className={`flex items-center gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <select
                    value={currentMonth.getMonth()}
                    onChange={(e) => setCurrentMonth(new Date(currentMonth.getFullYear(), parseInt(e.target.value), 1))}
                    className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {Array.from({ length: 12 }, (_, i) => (
                      <option key={i} value={i}>
                        {new Date(2024, i, 1).toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA', { month: 'long' })}
                      </option>
                    ))}
                  </select>
                  
                  <select
                    value={currentMonth.getFullYear()}
                    onChange={(e) => setCurrentMonth(new Date(parseInt(e.target.value), currentMonth.getMonth(), 1))}
                    className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {yearOptions.map(year => (
                      <option key={year} value={year}>{year}</option>
                    ))}
                  </select>
                </div>

                <button
                  onClick={() => navigateMonth('next')}
                  className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
                >
                  <ChevronRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
                </button>
              </div>

              <button
                onClick={() => setCurrentMonth(new Date())}
                className="px-4 py-2 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-colors"
              >
                {t.today}
              </button>
            </div>

            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-0 border border-gray-200 rounded-2xl overflow-hidden">
              {/* Day headers */}
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                <div key={day} className="bg-gray-50 p-3 text-center text-sm font-medium text-gray-700 border-b border-gray-200">
                  {day}
                </div>
              ))}
              
              {/* Calendar days */}
              {renderCalendar()}
            </div>
          </div>
        </div>

        {/* Tasks List */}
        <div className="space-y-6">
          {/* Tasks for Selected Date */}
          <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-lg">
            <h3 className={`text-lg font-bold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
              {selectedDate.toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA', {
                weekday: 'long',
                month: 'long',
                day: 'numeric'
              })}
            </h3>
            
            <div className="space-y-3">
              {getTasksForDate(selectedDate).length === 0 ? (
                <div className="text-center py-8">
                  <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500 text-sm">{t.noTasks}</p>
                </div>
              ) : (
                getTasksForDate(selectedDate).map(task => (
                  <div
                    key={task.id}
                    className="bg-gray-50 rounded-2xl p-4 border border-gray-200 hover:shadow-md transition-all duration-200 cursor-pointer"
                    onClick={() => handleViewTask(task)}
                  >
                    <div className={`flex items-center justify-between mb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <h4 className="font-medium text-gray-800">{task.title}</h4>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(task.priority)}`}>
                        {t[`priority${task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}` as keyof typeof t]}
                      </span>
                    </div>
                    
                    <div className={`flex items-center gap-4 text-sm text-gray-600 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      {task.start_time && (
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {task.start_time}
                        </div>
                      )}
                      
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(task.status)}`}>
                        {t[`status${task.status.charAt(0).toUpperCase() + task.status.slice(1).replace('_', '')}` as keyof typeof t]}
                      </span>
                    </div>

                    {/* Progress bar */}
                    <div className="mt-3">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${task.completion_percentage}%` }}
                        ></div>
                      </div>
                      <div className={`text-xs text-gray-500 mt-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {task.completion_percentage}% {language === 'en' ? 'complete' : 'مكتمل'}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Recent Projects */}
          <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-lg">
            <h3 className={`text-lg font-bold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
              {t.activeProjects}
            </h3>
            
            <div className="space-y-3">
              {projects.filter(p => p.status === 'active').slice(0, 3).map(project => (
                <div
                  key={project.id}
                  className="bg-gray-50 rounded-2xl p-4 border border-gray-200 hover:shadow-md transition-all duration-200"
                >
                  <div className={`flex items-center justify-between mb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <h4 className="font-medium text-gray-800">{project.name}</h4>
                    <div
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: project.color }}
                    ></div>
                  </div>
                  
                  <div className="mt-3">
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="h-2 rounded-full transition-all duration-300"
                        style={{ 
                          width: `${project.progress}%`,
                          backgroundColor: project.color 
                        }}
                      ></div>
                    </div>
                    <div className={`text-xs text-gray-500 mt-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {project.progress}% {language === 'en' ? 'complete' : 'مكتمل'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Tasks Table */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-lg overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h3 className={`text-xl font-bold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
            {t.taskOverview}
          </h3>
        </div>
        
        {filteredTasks.length === 0 ? (
          <div className="text-center py-16">
            <CheckCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">{t.noTasks}</h3>
            <button
              onClick={() => {
                resetTaskForm();
                setShowTaskModal(true);
              }}
              className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl mx-auto"
            >
              <Plus className="w-5 h-5" />
              {t.addTask}
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.taskTitle}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.project}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.assignedTo}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.priority}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.status}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.progress}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {language === 'en' ? 'Actions' : 'الإجراءات'}
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredTasks.map((task, index) => (
                  <tr
                    key={task.id}
                    className={`border-b border-gray-100 hover:bg-gray-50 transition-colors animate-fadeIn`}
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <td className={`py-4 px-6 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div>
                        <div className="font-medium text-gray-800">{task.title}</div>
                        {task.description && (
                          <div className="text-sm text-gray-600 mt-1 truncate">
                            {task.description}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {task.project ? (
                        <div className="flex items-center gap-2">
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: task.project.color }}
                          ></div>
                          {task.project.name}
                        </div>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {task.assigned_employee ? (
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-gray-400" />
                          {task.assigned_employee.full_name}
                        </div>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className="py-4 px-6">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getPriorityColor(task.priority)}`}>
                        {t[`priority${task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}` as keyof typeof t]}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(task.status)}`}>
                        {t[`status${task.status.charAt(0).toUpperCase() + task.status.slice(1).replace('_', '')}` as keyof typeof t]}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-500 h-2 rounded-full"
                          style={{ width: `${task.completion_percentage}%` }}
                        ></div>
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        {task.completion_percentage}%
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <button
                          onClick={() => handleViewTask(task)}
                          className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                          title={t.view}
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleEditTask(task)}
                          className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors"
                          title={t.edit}
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteTask(task.id)}
                          className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                          title={t.delete}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Task Modal */}
      {showTaskModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-2xl font-bold text-gray-800">
                {editingTask ? t.editTask : t.addNewTask}
              </h2>
              <button
                onClick={() => {
                  setShowTaskModal(false);
                  resetTaskForm();
                }}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleTaskSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Task Title */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.taskTitle} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={taskForm.title}
                    onChange={(e) => setTaskForm(prev => ({ ...prev, title: e.target.value }))}
                    placeholder={t.enterTitle}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Project */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.project} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <select
                    value={taskForm.projectId}
                    onChange={(e) => setTaskForm(prev => ({ ...prev, projectId: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">{t.selectProject}</option>
                    {projects.filter(p => p.is_active).map(project => (
                      <option key={project.id} value={project.id}>{project.name}</option>
                    ))}
                  </select>
                </div>

                {/* Start Date */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.startDate} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={taskForm.startDate}
                    min="2020-01-01"
                    max="2050-12-31"
                    onChange={(e) => setTaskForm(prev => ({ ...prev, startDate: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* End Date */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.endDate} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <input
                    type="date"
                    value={taskForm.endDate}
                    min="2020-01-01"
                    max="2050-12-31"
                    onChange={(e) => setTaskForm(prev => ({ ...prev, endDate: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Start Time */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.startTime} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <input
                    type="time"
                    value={taskForm.startTime}
                    onChange={(e) => setTaskForm(prev => ({ ...prev, startTime: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* End Time */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.endTime} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <input
                    type="time"
                    value={taskForm.endTime}
                    onChange={(e) => setTaskForm(prev => ({ ...prev, endTime: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Status */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.status}
                  </label>
                  <select
                    value={taskForm.status}
                    onChange={(e) => setTaskForm(prev => ({ ...prev, status: e.target.value as Task['status'] }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="pending">{t.statusPending}</option>
                    <option value="in_progress">{t.statusInProgress}</option>
                    <option value="completed">{t.statusCompleted}</option>
                    <option value="on_hold">{t.statusOnHold}</option>
                    <option value="cancelled">{t.statusCancelled}</option>
                  </select>
                </div>

                {/* Priority */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.priority}
                  </label>
                  <select
                    value={taskForm.priority}
                    onChange={(e) => setTaskForm(prev => ({ ...prev, priority: e.target.value as Task['priority'] }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="low">{t.priorityLow}</option>
                    <option value="medium">{t.priorityMedium}</option>
                    <option value="high">{t.priorityHigh}</option>
                    <option value="urgent">{t.priorityUrgent}</option>
                  </select>
                </div>

                {/* Assigned To */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.assignedTo} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <select
                    value={taskForm.assignedTo}
                    onChange={(e) => setTaskForm(prev => ({ ...prev, assignedTo: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">{t.selectEmployee}</option>
                    {employees.filter(emp => emp.is_active).map(employee => (
                      <option key={employee.id} value={employee.id}>{employee.full_name}</option>
                    ))}
                  </select>
                </div>

                {/* Category */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.category} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <input
                    type="text"
                    value={taskForm.category}
                    onChange={(e) => setTaskForm(prev => ({ ...prev, category: e.target.value }))}
                    placeholder={t.enterCategory}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Completion Percentage */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.completionPercentage}
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={taskForm.completionPercentage}
                    onChange={(e) => setTaskForm(prev => ({ ...prev, completionPercentage: parseInt(e.target.value) }))}
                    className="w-full"
                  />
                  <div className={`text-sm text-gray-600 mt-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {taskForm.completionPercentage}%
                  </div>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.taskDescription} <span className="text-gray-400 text-xs">({t.optional})</span>
                </label>
                <textarea
                  value={taskForm.description}
                  onChange={(e) => setTaskForm(prev => ({ ...prev, description: e.target.value }))}
                  placeholder={t.enterDescription}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                />
              </div>

              {/* Action Buttons */}
              <div className={`flex gap-4 pt-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      {language === 'en' ? 'Saving...' : 'جاري الحفظ...'}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <Save className="w-5 h-5" />
                      {t.save}
                    </div>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowTaskModal(false);
                    resetTaskForm();
                  }}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Project Modal */}
      {showProjectModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-2xl font-bold text-gray-800">
                {editingProject ? t.editProject : t.addNewProject}
              </h2>
              <button
                onClick={() => {
                  setShowProjectModal(false);
                  resetProjectForm();
                }}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleProjectSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Project Name */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.projectName} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={projectForm.name}
                    onChange={(e) => setProjectForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder={t.enterProjectName}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Color */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.color}
                  </label>
                  <input
                    type="color"
                    value={projectForm.color}
                    onChange={(e) => setProjectForm(prev => ({ ...prev, color: e.target.value }))}
                    className="w-full h-12 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Start Date */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.startDate} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={projectForm.startDate}
                    min="2020-01-01"
                    max="2050-12-31"
                    onChange={(e) => setProjectForm(prev => ({ ...prev, startDate: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* End Date */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.endDate} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <input
                    type="date"
                    value={projectForm.endDate}
                    min="2020-01-01"
                    max="2050-12-31"
                    onChange={(e) => setProjectForm(prev => ({ ...prev, endDate: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Status */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.status}
                  </label>
                  <select
                    value={projectForm.status}
                    onChange={(e) => setProjectForm(prev => ({ ...prev, status: e.target.value as Project['status'] }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="planning">{t.projectStatusPlanning}</option>
                    <option value="active">{t.projectStatusActive}</option>
                    <option value="on_hold">{t.statusOnHold}</option>
                    <option value="completed">{t.projectStatusCompleted}</option>
                    <option value="cancelled">{t.statusCancelled}</option>
                  </select>
                </div>

                {/* Priority */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.priority}
                  </label>
                  <select
                    value={projectForm.priority}
                    onChange={(e) => setProjectForm(prev => ({ ...prev, priority: e.target.value as Project['priority'] }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="low">{t.priorityLow}</option>
                    <option value="medium">{t.priorityMedium}</option>
                    <option value="high">{t.priorityHigh}</option>
                    <option value="urgent">{t.priorityUrgent}</option>
                  </select>
                </div>

                {/* Budget */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.budget} ({t.bhd}) <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={projectForm.budget}
                    onChange={(e) => setProjectForm(prev => ({ ...prev, budget: parseFloat(e.target.value) || 0 }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Progress */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.progress}
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={projectForm.progress}
                    onChange={(e) => setProjectForm(prev => ({ ...prev, progress: parseInt(e.target.value) }))}
                    className="w-full"
                  />
                  <div className={`text-sm text-gray-600 mt-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {projectForm.progress}%
                  </div>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.projectDescription} <span className="text-gray-400 text-xs">({t.optional})</span>
                </label>
                <textarea
                  value={projectForm.description}
                  onChange={(e) => setProjectForm(prev => ({ ...prev, description: e.target.value }))}
                  placeholder={t.enterProjectDescription}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                />
              </div>

              {/* Action Buttons */}
              <div className={`flex gap-4 pt-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-green-600 hover:to-emerald-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      {language === 'en' ? 'Saving...' : 'جاري الحفظ...'}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <Save className="w-5 h-5" />
                      {t.save}
                    </div>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowProjectModal(false);
                    resetProjectForm();
                  }}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Task View Modal */}
      {viewingTask && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-2xl font-bold text-gray-800">{t.taskDetails}</h2>
              <button
                onClick={() => setViewingTask(null)}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Task Information */}
              <div className="space-y-6">
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.taskDetails}
                  </h3>
                  
                  <div className="space-y-4">
                    <div>
                      <div className="text-sm text-gray-600 mb-1">{t.taskTitle}</div>
                      <div className="font-medium text-gray-800">{viewingTask.title}</div>
                    </div>
                    
                    {viewingTask.description && (
                      <div>
                        <div className="text-sm text-gray-600 mb-1">{t.taskDescription}</div>
                        <div className="text-gray-800">{viewingTask.description}</div>
                      </div>
                    )}
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-gray-600 mb-1">{t.status}</div>
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(viewingTask.status)}`}>
                          {t[`status${viewingTask.status.charAt(0).toUpperCase() + viewingTask.status.slice(1).replace('_', '')}` as keyof typeof t]}
                        </span>
                      </div>
                      
                      <div>
                        <div className="text-sm text-gray-600 mb-1">{t.priority}</div>
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getPriorityColor(viewingTask.priority)}`}>
                          {t[`priority${viewingTask.priority.charAt(0).toUpperCase() + viewingTask.priority.slice(1)}` as keyof typeof t]}
                        </span>
                      </div>
                    </div>

                    <div>
                      <div className="text-sm text-gray-600 mb-2">{t.completionPercentage}</div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div
                          className="bg-blue-500 h-3 rounded-full transition-all duration-300"
                          style={{ width: `${viewingTask.completion_percentage}%` }}
                        ></div>
                      </div>
                      <div className="text-sm text-gray-600 mt-1">{viewingTask.completion_percentage}%</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Comments Section */}
              <div className="space-y-6">
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.comments}
                  </h3>
                  
                  {/* Add Comment */}
                  <div className="mb-4">
                    <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <input
                        type="text"
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder={t.enterComment}
                        className="flex-1 px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        onKeyPress={(e) => e.key === 'Enter' && handleAddComment()}
                      />
                      <button
                        onClick={handleAddComment}
                        disabled={!newComment.trim()}
                        className="px-4 py-2 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Comments List */}
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {taskComments.length === 0 ? (
                      <div className="text-center py-8">
                        <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                        <p className="text-gray-500 text-sm">{t.noComments}</p>
                      </div>
                    ) : (
                      taskComments.map(comment => (
                        <div key={comment.id} className="bg-white rounded-xl p-4 border border-gray-200">
                          <div className={`flex items-center justify-between mb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                            <div className="font-medium text-gray-800">{comment.user_name}</div>
                            <div className="text-xs text-gray-500">
                              {new Date(comment.created_at).toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA')}
                            </div>
                          </div>
                          <div className="text-gray-700">{comment.comment}</div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className={`flex gap-4 mt-8 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <button
                onClick={() => {
                  setViewingTask(null);
                  handleEditTask(viewingTask);
                }}
                className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                <div className="flex items-center justify-center gap-2">
                  <Edit3 className="w-5 h-5" />
                  {t.edit}
                </div>
              </button>
              <button
                onClick={() => setViewingTask(null)}
                className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
              >
                {t.close}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TaskManagementPage;