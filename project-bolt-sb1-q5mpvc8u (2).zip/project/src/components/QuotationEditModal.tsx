import React, { useState, useEffect } from 'react';
import { 
  X, 
  Save, 
  Plus, 
  Trash2, 
  AlertCircle, 
  CheckCircle,
  FileText,
  User,
  Calendar,
  DollarSign,
  Package
} from 'lucide-react';
import { clientService, serviceService } from '../lib/supabase';
import { quotationService } from '../lib/quotationService';
import type { Quotation, QuotationItem } from '../lib/quotationService';
import type { Client, Service } from '../lib/supabase';

interface QuotationEditModalProps {
  quotation: Quotation;
  language: 'en' | 'ar';
  onClose: () => void;
  onSuccess: () => void;
}

const QuotationEditModal: React.FC<QuotationEditModalProps> = ({ 
  quotation, 
  language, 
  onClose, 
  onSuccess 
}) => {
  const [clients, setClients] = useState<Client[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const isRTL = language === 'ar';

  // Form state
  const [quotationData, setQuotationData] = useState({
    quotationNumber: quotation.quotation_number,
    clientId: quotation.client_id || '',
    clientName: quotation.client_name || '',
    clientEmail: quotation.client_email || '',
    clientPhone: quotation.client_phone || '',
    clientAddress: quotation.client_address || '',
    issueDate: quotation.issue_date,
    validUntil: quotation.valid_until,
    taxRate: quotation.tax_rate,
    discountRate: quotation.discount_rate,
    notes: quotation.notes || '',
    status: quotation.status
  });

  const [items, setItems] = useState<QuotationItem[]>(quotation.items || []);

  // Get current user from localStorage
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  const translations = {
    en: {
      title: 'Edit Quotation',
      quotationNumber: 'Quotation Number',
      selectClient: 'Select Client',
      clientName: 'Client Name',
      clientEmail: 'Client Email',
      clientPhone: 'Client Phone',
      clientAddress: 'Client Address',
      issueDate: 'Issue Date',
      validUntil: 'Valid Until',
      taxRate: 'Tax Rate (%)',
      discountRate: 'Discount Rate (%)',
      notes: 'Notes',
      status: 'Status',
      items: 'Items',
      addItem: 'Add Item',
      removeItem: 'Remove Item',
      itemName: 'Item Name',
      selectService: 'Select Service',
      customItem: 'Custom Item',
      category: 'Category',
      subcategory: 'Subcategory',
      price: 'Unit Price',
      quantity: 'Quantity',
      total: 'Total',
      subtotal: 'Subtotal',
      tax: 'Tax',
      discount: 'Discount',
      grandTotal: 'Grand Total',
      save: 'Save Changes',
      cancel: 'Cancel',
      close: 'Close',
      required: 'Required',
      optional: 'Optional',
      enterQuotationNumber: 'Enter quotation number',
      enterClientName: 'Enter client name',
      enterClientEmail: 'Enter client email',
      enterClientPhone: 'Enter client phone',
      enterClientAddress: 'Enter client address',
      enterNotes: 'Enter notes',
      enterItemName: 'Enter item name',
      enterCategory: 'Enter category',
      enterSubcategory: 'Enter subcategory',
      enterDescription: 'Enter description',
      quotationUpdated: 'Quotation updated successfully',
      fillRequired: 'Please fill all required fields',
      invalidEmail: 'Please enter a valid email address',
      quotationNumberExists: 'Quotation number already exists',
      noItems: 'Please add at least one item',
      bhd: 'BHD',
      draft: 'Draft',
      sent: 'Sent',
      accepted: 'Accepted',
      rejected: 'Rejected',
      expired: 'Expired',
      quotationDetails: 'Quotation Details',
      clientDetails: 'Client Details',
      itemDetails: 'Item Details',
      pricingDetails: 'Pricing Details',
      description: 'Description'
    },
    ar: {
      title: 'تعديل عرض السعر',
      quotationNumber: 'رقم عرض السعر',
      selectClient: 'اختر العميل',
      clientName: 'اسم العميل',
      clientEmail: 'بريد العميل الإلكتروني',
      clientPhone: 'هاتف العميل',
      clientAddress: 'عنوان العميل',
      issueDate: 'تاريخ الإصدار',
      validUntil: 'صالح حتى',
      taxRate: 'معدل الضريبة (%)',
      discountRate: 'معدل الخصم (%)',
      notes: 'ملاحظات',
      status: 'الحالة',
      items: 'العناصر',
      addItem: 'إضافة عنصر',
      removeItem: 'إزالة العنصر',
      itemName: 'اسم العنصر',
      selectService: 'اختر الخدمة',
      customItem: 'عنصر مخصص',
      category: 'الفئة',
      subcategory: 'الفئة الفرعية',
      price: 'سعر الوحدة',
      quantity: 'الكمية',
      total: 'الإجمالي',
      subtotal: 'المجموع الفرعي',
      tax: 'الضريبة',
      discount: 'الخصم',
      grandTotal: 'الإجمالي النهائي',
      save: 'حفظ التغييرات',
      cancel: 'إلغاء',
      close: 'إغلاق',
      required: 'مطلوب',
      optional: 'اختياري',
      enterQuotationNumber: 'أدخل رقم عرض السعر',
      enterClientName: 'أدخل اسم العميل',
      enterClientEmail: 'أدخل بريد العميل الإلكتروني',
      enterClientPhone: 'أدخل هاتف العميل',
      enterClientAddress: 'أدخل عنوان العميل',
      enterNotes: 'أدخل الملاحظات',
      enterItemName: 'أدخل اسم العنصر',
      enterCategory: 'أدخل الفئة',
      enterSubcategory: 'أدخل الفئة الفرعية',
      enterDescription: 'أدخل الوصف',
      quotationUpdated: 'تم تحديث عرض السعر بنجاح',
      fillRequired: 'يرجى ملء جميع الحقول المطلوبة',
      invalidEmail: 'يرجى إدخال عنوان بريد إلكتروني صحيح',
      quotationNumberExists: 'رقم عرض السعر موجود بالفعل',
      noItems: 'يرجى إضافة عنصر واحد على الأقل',
      bhd: 'د.ب',
      draft: 'مسودة',
      sent: 'مرسل',
      accepted: 'مقبول',
      rejected: 'مرفوض',
      expired: 'منتهي الصلاحية',
      quotationDetails: 'تفاصيل عرض السعر',
      clientDetails: 'تفاصيل العميل',
      itemDetails: 'تفاصيل العناصر',
      pricingDetails: 'تفاصيل التسعير',
      description: 'الوصف'
    }
  };

  const t = translations[language];

  // Load clients and services
  useEffect(() => {
    const loadData = async () => {
      const currentUser = getCurrentUser();
      if (!currentUser) return;

      try {
        // Load clients
        const clientsResult = await clientService.getClients(currentUser.id);
        if (clientsResult.success) {
          setClients(clientsResult.data);
        }

        // Load services
        const servicesResult = await serviceService.getServices(currentUser.id);
        if (servicesResult.success) {
          setServices(servicesResult.data);
        }
      } catch (error) {
        console.error('Error loading data:', error);
      }
    };

    loadData();
  }, []);

  // Validate email format
  const validateEmail = (email: string): boolean => {
    if (!email) return true; // Email is optional
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Handle client selection
  const handleClientSelect = (clientId: string) => {
    const selectedClient = clients.find(c => c.id === clientId);
    if (selectedClient) {
      setQuotationData(prev => ({
        ...prev,
        clientId: selectedClient.id,
        clientName: selectedClient.name,
        clientEmail: selectedClient.email,
        clientPhone: selectedClient.phone,
        clientAddress: selectedClient.address || ''
      }));
    } else {
      // Clear client data if "Custom Client" is selected
      setQuotationData(prev => ({
        ...prev,
        clientId: '',
        clientName: '',
        clientEmail: '',
        clientPhone: '',
        clientAddress: ''
      }));
    }
  };

  // Add new item
  const addItem = () => {
    const newItem: QuotationItem = {
      id: `item-${Date.now()}`,
      name: '',
      category: '',
      subcategory: '',
      price: 0,
      quantity: 1,
      total: 0,
      description: ''
    };
    setItems(prev => [...prev, newItem]);
  };

  // Remove item
  const removeItem = (itemId: string) => {
    setItems(prev => prev.filter(item => item.id !== itemId));
  };

  // Update item
  const updateItem = (itemId: string, field: keyof QuotationItem, value: string | number) => {
    setItems(prev => prev.map(item => {
      if (item.id === itemId) {
        return { ...item, [field]: value };
      }
      return item;
    }));
  };

  // Handle service selection for item
  const handleServiceSelect = (itemId: string, serviceId: string) => {
    const selectedService = services.find(s => s.id === serviceId);
    if (selectedService) {
      updateItem(itemId, 'name', selectedService.name);
      updateItem(itemId, 'category', selectedService.category || '');
      updateItem(itemId, 'subcategory', selectedService.subcategory || '');
      updateItem(itemId, 'price', selectedService.price);
      updateItem(itemId, 'description', selectedService.description || '');
      // Total will be recalculated automatically
    }
  };

  // Calculate totals
  const subtotal = items.reduce((sum, item) => sum + item.total, 0);
  const taxAmount = (subtotal * quotationData.taxRate) / 100;
  const discountAmount = (subtotal * quotationData.discountRate) / 100;
  const grandTotal = subtotal + taxAmount - discountAmount;

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!quotationData.quotationNumber || !quotationData.clientName) {
      setError(t.fillRequired);
      return;
    }

    // Validate email if provided
    if (quotationData.clientEmail && !validateEmail(quotationData.clientEmail)) {
      setError(t.invalidEmail);
      return;
    }

    // Validate items
    if (items.length === 0) {
      setError(t.noItems);
      return;
    }

    // Check if all items have names
    const hasEmptyItems = items.some(item => !item.name.trim());
    if (hasEmptyItems) {
      setError(t.fillRequired);
      return;
    }

    const currentUser = getCurrentUser();
    if (!currentUser) {
      setError('User not found');
      return;
    }

    // Check if quotation number exists (excluding current quotation)
    const quotationNumberExists = await quotationService.checkQuotationNumberExists(
      currentUser.id, 
      quotationData.quotationNumber,
      quotation.id
    );
    
    if (quotationNumberExists) {
      setError(t.quotationNumberExists);
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // Prepare updated quotation data
      const updatedQuotationData = {
        quotation_number: quotationData.quotationNumber,
        client_id: quotationData.clientId || null,
        client_name: quotationData.clientName,
        client_email: quotationData.clientEmail || null,
        client_phone: quotationData.clientPhone || null,
        client_address: quotationData.clientAddress || null,
        issue_date: quotationData.issueDate,
        valid_until: quotationData.validUntil,
        items: items,
        subtotal: subtotal,
        tax_rate: quotationData.taxRate,
        tax_amount: taxAmount,
        discount_rate: quotationData.discountRate,
        discount_amount: discountAmount,
        total_amount: grandTotal,
        notes: quotationData.notes || null,
        status: quotationData.status
      };

      // Update quotation in database
      const result = await quotationService.updateQuotation(quotation.id, updatedQuotationData);

      if (result.success) {
        setSuccess(t.quotationUpdated);
        setTimeout(() => {
          onSuccess();
          onClose();
        }, 1500);
      } else {
        setError(result.error || 'Failed to update quotation');
      }
    } catch (error) {
      console.error('Error updating quotation:', error);
      setError('Failed to update quotation. Please try again.');
    }
    
    setIsLoading(false);
  };

  const handleInputChange = (field: string, value: string | number) => {
    setQuotationData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-6xl w-full max-h-[95vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className={`flex items-center justify-between p-6 border-b border-gray-200 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <div className="p-2 bg-blue-100 rounded-xl">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
            <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
              <h2 className="text-2xl font-bold text-gray-800">{t.title}</h2>
              <p className="text-gray-600 text-sm">#{quotationData.quotationNumber}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6">
          {/* Success/Error Messages */}
          {success && (
            <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-2xl mb-6 animate-fadeIn flex items-center gap-2">
              <CheckCircle className="w-5 h-5" />
              {success}
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl mb-6 animate-fadeIn flex items-center gap-2">
              <AlertCircle className="w-5 h-5" />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Quotation Details */}
            <div>
              <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.quotationDetails}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Quotation Number */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.quotationNumber} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={quotationData.quotationNumber}
                    readOnly
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 text-gray-700 cursor-not-allowed"
                  />
                </div>

                {/* Issue Date */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.issueDate} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={quotationData.issueDate}
                    onChange={(e) => handleInputChange('issueDate', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Valid Until */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.validUntil} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={quotationData.validUntil}
                    onChange={(e) => handleInputChange('validUntil', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Status */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.status}
                  </label>
                  <select
                    value={quotationData.status}
                    onChange={(e) => handleInputChange('status', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="draft">{t.draft}</option>
                    <option value="sent">{t.sent}</option>
                    <option value="accepted">{t.accepted}</option>
                    <option value="rejected">{t.rejected}</option>
                    <option value="expired">{t.expired}</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Client Details */}
            <div>
              <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.clientDetails}
              </h3>
              
              {/* Client Selection */}
              <div className="mb-4">
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.selectClient}
                </label>
                <select
                  value={quotationData.clientId}
                  onChange={(e) => handleClientSelect(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">{language === 'en' ? 'Custom Client' : 'عميل مخصص'}</option>
                  {clients.map(client => (
                    <option key={client.id} value={client.id}>
                      {client.name} ({client.email})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Client Name */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.clientName} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={quotationData.clientName}
                    onChange={(e) => handleInputChange('clientName', e.target.value)}
                    placeholder={t.enterClientName}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Client Email */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.clientEmail} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <input
                    type="email"
                    value={quotationData.clientEmail}
                    onChange={(e) => handleInputChange('clientEmail', e.target.value)}
                    placeholder={t.enterClientEmail}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Client Phone */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.clientPhone} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <input
                    type="tel"
                    value={quotationData.clientPhone}
                    onChange={(e) => handleInputChange('clientPhone', e.target.value)}
                    placeholder={t.enterClientPhone}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Client Address */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.clientAddress} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <input
                    type="text"
                    value={quotationData.clientAddress}
                    onChange={(e) => handleInputChange('clientAddress', e.target.value)}
                    placeholder={t.enterClientAddress}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            {/* Items Section */}
            <div>
              <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.itemDetails}
                </h3>
                <button
                  type="button"
                  onClick={addItem}
                  className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <Plus className="w-4 h-4" />
                  {t.addItem}
                </button>
              </div>

              <div className="space-y-4">
                {items.map((item, index) => (
                  <div key={item.id} className="bg-gray-50 rounded-2xl p-6 border border-gray-200">
                    <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <h4 className={`font-medium text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {language === 'en' ? `Item ${index + 1}` : `العنصر ${index + 1}`}
                      </h4>
                      {items.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeItem(item.id)}
                          className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                          title={t.removeItem}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    {/* Service Selection */}
                    <div className="mb-4">
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {t.selectService}
                      </label>
                      
                      {/* Structured Dropdown Flow */}
                      <div className="space-y-4">
                        {/* Step 1: Product/Service Selection */}
                        <div>
                          <label className={`block text-xs font-medium text-gray-600 mb-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                            {language === 'en' ? 'Step 1: Select Product/Service' : 'الخطوة 1: اختر المنتج/الخدمة'}
                          </label>
                          <select
                            value={item.serviceId || ''}
                            onChange={(e) => {
                              const serviceId = e.target.value;
                              updateItem(item.id, 'serviceId', serviceId);
                              
                              if (serviceId) {
                                const selectedService = services.find(s => s.id === serviceId);
                                if (selectedService) {
                                  updateItem(item.id, 'name', selectedService.name);
                                  updateItem(item.id, 'price', selectedService.price);
                                  updateItem(item.id, 'description', selectedService.description || '');
                                  // Clear category selections to force user to choose
                                  updateItem(item.id, 'selectedCategory', '');
                                  updateItem(item.id, 'category', '');
                                  updateItem(item.id, 'selectedSubcategory', '');
                                  updateItem(item.id, 'subcategory', '');
                                }
                              } else {
                                // Clear service-related data when custom is selected
                                updateItem(item.id, 'name', '');
                                updateItem(item.id, 'price', 0);
                                updateItem(item.id, 'description', '');
                                updateItem(item.id, 'selectedCategory', '');
                                updateItem(item.id, 'category', '');
                                updateItem(item.id, 'selectedSubcategory', '');
                                updateItem(item.id, 'subcategory', '');
                              }
                            }}
                            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                          >
                            <option value="">{t.customItem}</option>
                            {/* عرض الأسماء الفريدة فقط */}
                            {Array.from(new Set(
                              services
                                .filter(s => s.is_active && s.availability_active !== false)
                                .map(s => s.name)
                            )).map(uniqueName => {
                              // العثور على أول خدمة بهذا الاسم لعرض السعر
                              const firstService = services.find(s => 
                                s.name === uniqueName && 
                                s.is_active && 
                                s.availability_active !== false
                              );
                              return (
                                <option key={uniqueName} value={firstService?.id || ''}>
                                  {uniqueName} - {firstService?.price || 0} {t.bhd}
                                </option>
                              );
                            })}
                          </select>
                        </div>

                        {/* Step 2: Category Selection */}
                        <div>
                          <label className={`block text-xs font-medium text-gray-600 mb-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                            {language === 'en' ? 'Step 2: Select Category' : 'الخطوة 2: اختر الفئة'}
                          </label>
                          <select
                            value={item.selectedCategory || ''}
                            onChange={(e) => {
                              const selectedCategory = e.target.value;
                              updateItem(item.id, 'selectedCategory', selectedCategory);
                              updateItem(item.id, 'category', selectedCategory);
                              // Clear subcategory when category changes
                              updateItem(item.id, 'selectedSubcategory', '');
                              updateItem(item.id, 'subcategory', '');
                            }}
                            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                          >
                            <option value="">{language === 'en' ? 'Select Category' : 'اختر الفئة'}</option>
                            {/* عرض الفئات المرتبطة بالخدمة المختارة فقط */}
                            {item.serviceId ? (
                              // إذا تم اختيار خدمة محددة، عرض فئاتها فقط
                              Array.from(new Set(
                                services
                                  .filter(s => 
                                    s.is_active && 
                                    s.name === item.name && 
                                    s.category
                                  )
                                  .map(s => s.category)
                              )).map(category => (
                                <option key={category} value={category}>
                                  {category}
                                </option>
                              ))
                            ) : (
                              // إذا لم يتم اختيار خدمة، عرض جميع الفئات
                              Array.from(new Set(
                                services
                                  .filter(s => s.is_active && s.category)
                                  .map(s => s.category)
                              )).map(category => (
                                <option key={category} value={category}>
                                  {category}
                                </option>
                              ))
                            )}
                            <option value="custom">{language === 'en' ? 'Custom Category' : 'فئة مخصصة'}</option>
                          </select>
                        </div>

                        {/* Step 3: Subcategory Selection (only if category is selected) */}
                        {item.selectedCategory && (
                          <div>
                            <label className={`block text-xs font-medium text-gray-600 mb-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                              {language === 'en' ? 'Step 3: Select Subcategory' : 'الخطوة 3: اختر الفئة الفرعية'}
                            </label>
                            <select
                              value={item.selectedSubcategory || ''}
                              onChange={(e) => {
                                const selectedSubcategory = e.target.value;
                                updateItem(item.id, 'selectedSubcategory', selectedSubcategory);
                                updateItem(item.id, 'subcategory', selectedSubcategory);
                              }}
                              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                            >
                              <option value="">{language === 'en' ? 'Select Subcategory' : 'اختر الفئة الفرعية'}</option>
                              {/* عرض الفئات الفرعية المرتبطة بالخدمة والفئة المختارة */}
                              {item.serviceId ? (
                                // إذا تم اختيار خدمة محددة، عرض فئاتها الفرعية المرتبطة بالفئة المختارة
                                Array.from(new Set(
                                  services
                                    .filter(s => 
                                      s.is_active && 
                                      s.name === item.name && 
                                      s.category === item.selectedCategory && 
                                      s.subcategory
                                    )
                                    .map(s => s.subcategory)
                                )).map(subcategory => (
                                  <option key={subcategory} value={subcategory}>
                                    {subcategory}
                                  </option>
                                ))
                              ) : (
                                // إذا لم يتم اختيار خدمة، عرض جميع الفئات الفرعية للفئة المختارة
                                Array.from(new Set(
                                  services
                                    .filter(s => s.is_active && s.category === item.selectedCategory && s.subcategory)
                                    .map(s => s.subcategory)
                                )).map(subcategory => (
                                  <option key={subcategory} value={subcategory}>
                                    {subcategory}
                                  </option>
                                ))
                              )}
                              <option value="custom">{language === 'en' ? 'Custom Subcategory' : 'فئة فرعية مخصصة'}</option>
                            </select>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
                      {/* Item Name */}
                      <div className="lg:col-span-2">
                        <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                          {t.itemName} <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          value={item.name}
                          onChange={(e) => updateItem(item.id, 'name', e.target.value)}
                          placeholder={t.enterItemName}
                          className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        />
                      </div>

                      {/* Quantity */}
                      <div>
                        <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                          {t.quantity}
                        </label>
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => updateItem(item.id, 'quantity', parseInt(e.target.value) || 1)}
                          className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        />
                      </div>

                      {/* Total Amount */}
                      <div className="lg:col-span-3">
                        <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                          {t.total} <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          value={item.total}
                          onChange={(e) => updateItem(item.id, 'total', parseFloat(e.target.value) || 0)}
                          className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        />
                      </div>
                    </div>

                    {/* Category - Changed to textarea */}
                    <div className="mt-4">
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {t.category} {item.selectedCategory === 'custom' ? `(${language === 'en' ? 'Custom' : 'مخصص'})` : ''}
                      </label>
                      <textarea
                        value={item.category}
                        onChange={(e) => updateItem(item.id, 'category', e.target.value)}
                        placeholder={t.enterCategory}
                        rows={3}
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm resize-none"
                      />
                    </div>

                    {/* Subcategory - Full width below category */}
                    <div className="mt-4">
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {t.subcategory} {item.selectedSubcategory === 'custom' ? `(${language === 'en' ? 'Custom' : 'مخصص'})` : ''}
                      </label>
                      <textarea
                        value={item.subcategory || ''}
                        onChange={(e) => updateItem(item.id, 'subcategory', e.target.value)}
                        placeholder={t.enterSubcategory}
                        rows={6}
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm resize-none"
                      />
                    </div>

                    {/* Description */}
                    <div className="mt-4">
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {t.description} <span className="text-gray-400 text-xs">({t.optional})</span>
                      </label>
                      <textarea
                        value={item.description || ''}
                        onChange={(e) => updateItem(item.id, 'description', e.target.value)}
                        placeholder={t.enterDescription}
                        rows={2}
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm resize-none"
                      />
                    </div>

                    {/* Item Total */}
                    <div className={`mt-4 pt-4 border-t border-gray-200 ${isRTL ? 'text-left' : 'text-right'}`}>
                      <div className="text-sm text-gray-600">{t.total}:</div>
                      <div className="text-lg font-bold text-blue-600">
                        {item.total.toLocaleString()} {t.bhd}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pricing Details */}
            <div>
              <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.pricingDetails}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Tax Rate */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.taxRate}
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={quotationData.taxRate}
                    onChange={(e) => handleInputChange('taxRate', parseFloat(e.target.value) || 0)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                {/* Discount Rate */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.discountRate}
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={quotationData.discountRate}
                    onChange={(e) => handleInputChange('discountRate', parseFloat(e.target.value) || 0)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              {/* Totals Summary */}
              <div className="mt-6 bg-white rounded-2xl p-6 border border-gray-200">
                <div className="space-y-3">
                  <div className={`flex justify-between items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <span className="text-gray-600">{t.subtotal}:</span>
                    <span className="font-semibold text-gray-800">{subtotal.toLocaleString()} {t.bhd}</span>
                  </div>
                  
                  {quotationData.taxRate > 0 && (
                    <div className={`flex justify-between items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <span className="text-gray-600">{t.tax} ({quotationData.taxRate}%):</span>
                      <span className="font-semibold text-gray-800">{taxAmount.toLocaleString()} {t.bhd}</span>
                    </div>
                  )}
                  
                  {quotationData.discountRate > 0 && (
                    <div className={`flex justify-between items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <span className="text-red-600">{t.discount} ({quotationData.discountRate}%):</span>
                      <span className="font-semibold text-red-600">-{discountAmount.toLocaleString()} {t.bhd}</span>
                    </div>
                  )}
                  
                  <div className={`flex justify-between items-center pt-3 border-t border-gray-200 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <span className="text-lg font-bold text-gray-800">{t.grandTotal}:</span>
                    <span className="text-xl font-bold text-blue-600">{grandTotal.toLocaleString()} {t.bhd}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.notes} <span className="text-gray-400 text-xs">({t.optional})</span>
              </label>
              <textarea
                value={quotationData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                placeholder={t.enterNotes}
                rows={4}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              />
            </div>

            {/* Action Buttons */}
            <div className={`flex gap-4 pt-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
              >
                {isLoading ? (
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    {language === 'en' ? 'Saving...' : 'جاري الحفظ...'}
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-2">
                    <Save className="w-5 h-5" />
                    {t.save}
                  </div>
                )}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
              >
                {t.cancel}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default QuotationEditModal;