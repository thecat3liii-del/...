import React, { useState, useEffect } from 'react';
import { User, Shield, Check, X, Save, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Employee {
  id: string;
  full_name: string;
  email: string;
  position: string;
  is_active: boolean;
}

interface PagePermission {
  id: string;
  employee_id: string;
  page_name: string;
  is_allowed: boolean;
}

interface DetailedPermission {
  id: string;
  employee_id: string;
  page_name: string;
  can_view: boolean;
  can_add: boolean;
  can_edit: boolean;
  can_delete: boolean;
}

const PAGES = [
  'home',
  'transactions',
  'quotations-invoices',
  'reports',
  'clients',
  'suppliers',
  'services',
  'settings'
];

export default function EmployeePermissions() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [pagePermissions, setPagePermissions] = useState<PagePermission[]>([]);
  const [detailedPermissions, setDetailedPermissions] = useState<DetailedPermission[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<string>('');

  useEffect(() => {
    fetchEmployees();
  }, []);

  useEffect(() => {
    if (selectedEmployee) {
      fetchPermissions(selectedEmployee);
    }
  }, [selectedEmployee]);

  const fetchEmployees = async () => {
    try {
      const { data, error } = await supabase
        .from('employees')
        .select('id, full_name, email, position, is_active')
        .eq('is_active', true)
        .order('full_name');

      if (error) throw error;
      setEmployees(data || []);
      if (data && data.length > 0) {
        setSelectedEmployee(data[0].id);
      }
    } catch (error) {
      console.error('Error fetching employees:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchPermissions = async (employeeId: string) => {
    try {
      const [pagePermsResponse, detailedPermsResponse] = await Promise.all([
        supabase
          .from('employee_page_permissions')
          .select('*')
          .eq('employee_id', employeeId),
        supabase
          .from('employee_detailed_permissions')
          .select('*')
          .eq('employee_id', employeeId)
      ]);

      if (pagePermsResponse.error) throw pagePermsResponse.error;
      if (detailedPermsResponse.error) throw detailedPermsResponse.error;

      setPagePermissions(pagePermsResponse.data || []);
      setDetailedPermissions(detailedPermsResponse.data || []);
    } catch (error) {
      console.error('Error fetching permissions:', error);
    }
  };

  const updatePagePermission = async (employeeId: string, pageName: string, isAllowed: boolean) => {
    try {
      const existingPermission = pagePermissions.find(
        p => p.employee_id === employeeId && p.page_name === pageName
      );

      if (existingPermission) {
        const { error } = await supabase
          .from('employee_page_permissions')
          .update({ is_allowed: isAllowed })
          .eq('id', existingPermission.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('employee_page_permissions')
          .insert({
            employee_id: employeeId,
            page_name: pageName,
            is_allowed: isAllowed
          });

        if (error) throw error;
      }

      await fetchPermissions(employeeId);
    } catch (error) {
      console.error('Error updating page permission:', error);
    }
  };

  const updateDetailedPermission = async (
    employeeId: string,
    pageName: string,
    permissionType: 'can_view' | 'can_add' | 'can_edit' | 'can_delete',
    value: boolean
  ) => {
    try {
      const existingPermission = detailedPermissions.find(
        p => p.employee_id === employeeId && p.page_name === pageName
      );

      if (existingPermission) {
        const { error } = await supabase
          .from('employee_detailed_permissions')
          .update({ [permissionType]: value })
          .eq('id', existingPermission.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('employee_detailed_permissions')
          .insert({
            employee_id: employeeId,
            page_name: pageName,
            [permissionType]: value
          });

        if (error) throw error;
      }

      await fetchPermissions(employeeId);
    } catch (error) {
      console.error('Error updating detailed permission:', error);
    }
  };

  const getPagePermission = (employeeId: string, pageName: string): boolean => {
    const permission = pagePermissions.find(
      p => p.employee_id === employeeId && p.page_name === pageName
    );
    return permission?.is_allowed || false;
  };

  const getDetailedPermission = (
    employeeId: string,
    pageName: string,
    permissionType: 'can_view' | 'can_add' | 'can_edit' | 'can_delete'
  ): boolean => {
    const permission = detailedPermissions.find(
      p => p.employee_id === employeeId && p.page_name === pageName
    );
    return permission?.[permissionType] || false;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (employees.length === 0) {
    return (
      <div className="text-center py-12">
        <User className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">No employees</h3>
        <p className="mt-1 text-sm text-gray-500">
          Add employees to manage their permissions.
        </p>
      </div>
    );
  }

  const selectedEmployeeData = employees.find(emp => emp.id === selectedEmployee);

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <Shield className="h-6 w-6 text-blue-600" />
              <h3 className="text-lg font-medium text-gray-900">Employee Permissions</h3>
            </div>
          </div>

          {/* Employee Selection */}
          <div className="mb-6">
            <label htmlFor="employee-select" className="block text-sm font-medium text-gray-700 mb-2">
              Select Employee
            </label>
            <select
              id="employee-select"
              value={selectedEmployee}
              onChange={(e) => setSelectedEmployee(e.target.value)}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              {employees.map((employee) => (
                <option key={employee.id} value={employee.id}>
                  {employee.full_name} ({employee.email})
                </option>
              ))}
            </select>
          </div>

          {selectedEmployeeData && (
            <div className="space-y-6">
              {/* Employee Info */}
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center space-x-3">
                  <User className="h-8 w-8 text-gray-400" />
                  <div>
                    <h4 className="text-lg font-medium text-gray-900">
                      {selectedEmployeeData.full_name}
                    </h4>
                    <p className="text-sm text-gray-500">
                      {selectedEmployeeData.position} • {selectedEmployeeData.email}
                    </p>
                  </div>
                </div>
              </div>

              {/* Page Access Permissions */}
              <div>
                <h4 className="text-md font-medium text-gray-900 mb-4">Page Access</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {PAGES.map((page) => {
                    const hasAccess = getPagePermission(selectedEmployee, page);
                    return (
                      <div
                        key={page}
                        className="flex items-center justify-between p-3 border rounded-lg"
                      >
                        <span className="text-sm font-medium text-gray-700 capitalize">
                          {page.replace('-', ' ')}
                        </span>
                        <button
                          onClick={() => updatePagePermission(selectedEmployee, page, !hasAccess)}
                          className={`p-1 rounded-full ${
                            hasAccess
                              ? 'bg-green-100 text-green-600 hover:bg-green-200'
                              : 'bg-red-100 text-red-600 hover:bg-red-200'
                          }`}
                        >
                          {hasAccess ? <Check className="h-4 w-4" /> : <X className="h-4 w-4" />}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Detailed Permissions */}
              <div>
                <h4 className="text-md font-medium text-gray-900 mb-4">Detailed Permissions</h4>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Page
                        </th>
                        <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                          View
                        </th>
                        <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Add
                        </th>
                        <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Edit
                        </th>
                        <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Delete
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {PAGES.map((page) => {
                        const hasPageAccess = getPagePermission(selectedEmployee, page);
                        return (
                          <tr key={page} className={!hasPageAccess ? 'opacity-50' : ''}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 capitalize">
                              {page.replace('-', ' ')}
                            </td>
                            {(['can_view', 'can_add', 'can_edit', 'can_delete'] as const).map((permType) => (
                              <td key={permType} className="px-6 py-4 whitespace-nowrap text-center">
                                <button
                                  onClick={() => updateDetailedPermission(selectedEmployee, page, permType, !getDetailedPermission(selectedEmployee, page, permType))}
                                  disabled={!hasPageAccess}
                                  className={`p-1 rounded-full ${
                                    getDetailedPermission(selectedEmployee, page, permType)
                                      ? 'bg-green-100 text-green-600 hover:bg-green-200'
                                      : 'bg-red-100 text-red-600 hover:bg-red-200'
                                  } ${!hasPageAccess ? 'cursor-not-allowed opacity-50' : ''}`}
                                >
                                  {getDetailedPermission(selectedEmployee, page, permType) ? (
                                    <Check className="h-4 w-4" />
                                  ) : (
                                    <X className="h-4 w-4" />
                                  )}
                                </button>
                              </td>
                            ))}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Info Note */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div className="text-sm text-blue-700">
                    <p className="font-medium">Permission Hierarchy</p>
                    <p className="mt-1">
                      Employees must have page access enabled before detailed permissions can be granted.
                      Detailed permissions are automatically disabled when page access is revoked.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}