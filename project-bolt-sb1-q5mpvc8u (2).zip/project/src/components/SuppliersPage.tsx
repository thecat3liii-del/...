import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  Download, 
  Edit3, 
  Trash2, 
  Truck,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Eye,
  X,
  Save,
  AlertCircle,
  Building,
  Globe,
  Star,
  Package,
  CheckCircle,
  ExternalLink,
  UserPlus,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { supplierService, serviceService } from '../lib/supabase';
import type { Supplier, Service } from '../lib/supabase';

interface SuppliersPageProps {
  language: 'en' | 'ar';
  bossId?: string;
  userPermissions?: {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
  };
}

const SuppliersPage: React.FC<SuppliersPageProps> = ({ language, bossId, userPermissions }) => {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [filteredSuppliers, setFilteredSuppliers] = useState<Supplier[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [sortBy, setSortBy] = useState<'name' | 'email' | 'created_at'>('created_at');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [viewingSupplier, setViewingSupplier] = useState<Supplier | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Services dropdown state
  const [serviceSearchTerm, setServiceSearchTerm] = useState('');
  const [showServiceDropdown, setShowServiceDropdown] = useState(false);
  const [selectedServices, setSelectedServices] = useState<Service[]>([]);

  const isRTL = language === 'ar';

  // Get current user from localStorage to access boss ID
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Form state for adding/editing suppliers
  const [supplierForm, setSupplierForm] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    website: '',
    address: '',
    contactPerson: '',
    paymentMethod: '',
    rating: 5,
    notes: ''
  });

  const translations = {
    en: {
      title: 'Suppliers',
      subtitle: 'Manage your supplier relationships',
      addSupplier: 'Add Supplier',
      searchPlaceholder: 'Search suppliers...',
      filterAll: 'All Suppliers',
      filterActive: 'Active',
      filterInactive: 'Inactive',
      sortByName: 'Name',
      sortByEmail: 'Email',
      sortByDate: 'Date Added',
      name: 'Supplier Name',
      company: 'Company Name',
      email: 'Email',
      phone: 'Phone Number',
      website: 'Website',
      address: 'Address',
      contactPerson: 'Contact Person',
      paymentMethod: 'Payment Method',
      rating: 'Rating',
      supplierProvides: 'Services & Products',
      notes: 'Notes',
      dateAdded: 'Date Added',
      status: 'Status',
      actions: 'Actions',
      active: 'Active',
      inactive: 'Inactive',
      edit: 'Edit',
      delete: 'Delete',
      view: 'View',
      save: 'Save',
      cancel: 'Cancel',
      close: 'Close',
      addNewSupplier: 'Add New Supplier',
      editSupplier: 'Edit Supplier',
      supplierDetails: 'Supplier Details',
      enterName: 'Enter Supplier Name',
      enterCompany: 'Enter Company Name',
      enterEmail: 'Enter Email Address',
      enterPhone: 'Enter Phone Number',
      enterWebsite: 'Enter Website URL',
      enterAddress: 'Enter Address',
      enterContactPerson: 'Enter Contact Person Name',
      enterPaymentMethod: 'Enter Payment Method',
      enterNotes: 'Enter Notes',
      confirmDelete: 'Are you sure you want to delete this supplier?',
      deleteSupplier: 'Delete Supplier',
      supplierAdded: 'Supplier added successfully',
      supplierUpdated: 'Supplier updated successfully',
      supplierDeleted: 'Supplier deleted successfully',
      fillRequired: 'Please fill all required fields',
      invalidEmail: 'Please enter a valid email address',
      emailExists: 'Email address already exists',
      noSuppliers: 'No suppliers found',
      noSuppliersDesc: 'Start by adding your first supplier',
      totalSuppliers: 'Total Suppliers',
      activeSuppliers: 'Active Suppliers',
      newThisMonth: 'New This Month',
      export: 'Export',
      print: 'Print',
      refresh: 'Refresh',
      required: 'Required',
      optional: 'Optional',
      contactInfo: 'Contact Information',
      businessInfo: 'Business Information',
      additionalInfo: 'Additional Information',
      loadingSuppliers: 'Loading suppliers...',
      errorLoading: 'Error loading suppliers',
      searchServices: 'Search services & products...',
      selectServices: 'Select Services & Products',
      noServicesFound: 'No services found',
      selectedServices: 'Selected Services',
      removeService: 'Remove service'
    },
    ar: {
      title: 'الموردين',
      subtitle: 'إدارة علاقاتك مع الموردين',
      addSupplier: 'إضافة مورد',
      searchPlaceholder: 'البحث في الموردين...',
      filterAll: 'جميع الموردين',
      filterActive: 'نشط',
      filterInactive: 'غير نشط',
      sortByName: 'الاسم',
      sortByEmail: 'البريد الإلكتروني',
      sortByDate: 'تاريخ الإضافة',
      name: 'اسم المورد',
      company: 'اسم الشركة',
      email: 'البريد الإلكتروني',
      phone: 'رقم الهاتف',
      website: 'الموقع الإلكتروني',
      address: 'العنوان',
      contactPerson: 'الشخص المسؤول',
      paymentMethod: 'طريقة الدفع',
      rating: 'التقييم',
      supplierProvides: 'الخدمات والمنتجات',
      notes: 'ملاحظات',
      dateAdded: 'تاريخ الإضافة',
      status: 'الحالة',
      actions: 'الإجراءات',
      active: 'نشط',
      inactive: 'غير نشط',
      edit: 'تعديل',
      delete: 'حذف',
      view: 'عرض',
      save: 'حفظ',
      cancel: 'إلغاء',
      close: 'إغلاق',
      addNewSupplier: 'إضافة مورد جديد',
      editSupplier: 'تعديل المورد',
      supplierDetails: 'تفاصيل المورد',
      enterName: 'أدخل اسم المورد',
      enterCompany: 'أدخل اسم الشركة',
      enterEmail: 'أدخل عنوان البريد الإلكتروني',
      enterPhone: 'أدخل رقم الهاتف',
      enterWebsite: 'أدخل رابط الموقع الإلكتروني',
      enterAddress: 'أدخل العنوان',
      enterContactPerson: 'أدخل اسم الشخص المسؤول',
      enterPaymentMethod: 'أدخل طريقة الدفع',
      enterNotes: 'أدخل الملاحظات',
      confirmDelete: 'هل أنت متأكد من حذف هذا المورد؟',
      deleteSupplier: 'حذف المورد',
      supplierAdded: 'تم إضافة المورد بنجاح',
      supplierUpdated: 'تم تحديث المورد بنجاح',
      supplierDeleted: 'تم حذف المورد بنجاح',
      fillRequired: 'يرجى ملء جميع الحقول المطلوبة',
      invalidEmail: 'يرجى إدخال عنوان بريد إلكتروني صحيح',
      emailExists: 'عنوان البريد الإلكتروني موجود بالفعل',
      noSuppliers: 'لا يوجد موردين',
      noSuppliersDesc: 'ابدأ بإضافة موردك الأول',
      totalSuppliers: 'إجمالي الموردين',
      activeSuppliers: 'الموردين النشطين',
      newThisMonth: 'جديد هذا الشهر',
      export: 'تصدير',
      print: 'طباعة',
      refresh: 'تحديث',
      required: 'مطلوب',
      optional: 'اختياري',
      contactInfo: 'معلومات الاتصال',
      businessInfo: 'معلومات العمل',
      additionalInfo: 'معلومات إضافية',
      loadingSuppliers: 'جاري تحميل الموردين...',
      errorLoading: 'خطأ في تحميل الموردين',
      searchServices: 'البحث في الخدمات والمنتجات...',
      selectServices: 'اختر الخدمات والمنتجات',
      noServicesFound: 'لا توجد خدمات',
      selectedServices: 'الخدمات المختارة',
      removeService: 'إزالة الخدمة'
    }
  };

  const t = translations[language];

  // Default permissions for boss or if not provided
  const permissions = userPermissions || { view: true, add: true, edit: true, delete: true };

  // Load suppliers and services from Supabase
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      const currentUser = getCurrentUser();
      
      if (!currentUser) {
        setIsLoading(false);
        return;
      }

      // Use bossId if provided (for employees), otherwise use current user id (for boss)
      const targetBossId = bossId || currentUser.id;

      try {
        // Load suppliers
        const suppliersResult = await supplierService.getSuppliers(targetBossId);
        
        if (suppliersResult.success) {
          setSuppliers(suppliersResult.data);
          setFilteredSuppliers(suppliersResult.data);
        } else {
          setError(suppliersResult.error || t.errorLoading);
        }

        // Load services
        const servicesResult = await serviceService.getServices(targetBossId);
        
        if (servicesResult.success) {
          setServices(servicesResult.data);
        } else {
          console.error('Error loading services:', servicesResult.error);
        }
      } catch (error) {
        console.error('Error loading data:', error);
        setError(t.errorLoading);
      }
      
      setIsLoading(false);
    };

    loadData();
  }, [bossId]);

  // Filter and sort suppliers
  useEffect(() => {
    let filtered = [...suppliers];

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(supplier =>
        supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        supplier.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
        supplier.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        supplier.phone.includes(searchTerm) ||
        supplier.contact_person?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(supplier => 
        filterStatus === 'active' ? supplier.is_active : !supplier.is_active
      );
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'name':
          comparison = a.name.localeCompare(b.name);
          break;
        case 'email':
          comparison = a.email.localeCompare(b.email);
          break;
        case 'created_at':
          comparison = new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
          break;
      }

      return sortOrder === 'asc' ? comparison : -comparison;
    });

    setFilteredSuppliers(filtered);
  }, [suppliers, searchTerm, filterStatus, sortBy, sortOrder]);

  // Filter services based on search term
  const filteredServices = services.filter(service =>
    service.name.toLowerCase().includes(serviceSearchTerm.toLowerCase()) ||
    service.category?.toLowerCase().includes(serviceSearchTerm.toLowerCase()) ||
    service.subcategory?.toLowerCase().includes(serviceSearchTerm.toLowerCase())
  );

  // Validate email format
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Handle service selection
  const handleServiceSelect = (service: Service) => {
    if (!selectedServices.find(s => s.id === service.id)) {
      setSelectedServices(prev => [...prev, service]);
    }
    setServiceSearchTerm('');
    setShowServiceDropdown(false);
  };

  // Remove selected service
  const removeSelectedService = (serviceId: string) => {
    setSelectedServices(prev => prev.filter(s => s.id !== serviceId));
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!supplierForm.name || !supplierForm.company || !supplierForm.email || !supplierForm.phone) {
      setError(t.fillRequired);
      return;
    }

    if (!validateEmail(supplierForm.email)) {
      setError(t.invalidEmail);
      return;
    }

    const currentUser = getCurrentUser();
    if (!currentUser) {
      setError('User not found');
      return;
    }

    const targetBossId = bossId || currentUser.id;

    // Check if email exists
    const emailExists = await supplierService.checkSupplierEmailExists(
      targetBossId, 
      supplierForm.email, 
      editingSupplier?.id
    );
    
    if (emailExists) {
      setError(t.emailExists);
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const supplierData = {
        name: supplierForm.name,
        company: supplierForm.company,
        email: supplierForm.email,
        phone: supplierForm.phone,
        website: supplierForm.website || undefined,
        address: supplierForm.address || undefined,
        contact_person: supplierForm.contactPerson || undefined,
        payment_method: supplierForm.paymentMethod || undefined,
        rating: supplierForm.rating,
        selected_service_ids: selectedServices.map(s => s.id),
        notes: supplierForm.notes || undefined,
        is_active: true
      };

      if (editingSupplier) {
        // Update existing supplier
        const result = await supplierService.updateSupplier(editingSupplier.id, supplierData);

        if (result.success) {
          // Update local state
          const updatedSuppliers = suppliers.map(supplier => 
            supplier.id === editingSupplier.id ? result.data : supplier
          );
          setSuppliers(updatedSuppliers);
          setSuccess(t.supplierUpdated);
          setEditingSupplier(null);
        } else {
          setError(result.error || 'Failed to update supplier');
        }
      } else {
        // Add new supplier
        const result = await supplierService.addSupplier(targetBossId, supplierData);

        if (result.success) {
          // Update local state
          setSuppliers(prev => [...prev, result.data]);
          setSuccess(t.supplierAdded);
        } else {
          setError(result.error || 'Failed to add supplier');
        }
      }

      setIsLoading(false);
      setShowAddModal(false);
      resetForm();

      setTimeout(() => setSuccess(''), 3000);
    } catch (error) {
      console.error('Error saving supplier:', error);
      setError('Failed to save supplier. Please try again.');
      setIsLoading(false);
    }
  };

  // Reset form
  const resetForm = () => {
    setSupplierForm({
      name: '',
      company: '',
      email: '',
      phone: '',
      website: '',
      address: '',
      contactPerson: '',
      paymentMethod: '',
      rating: 5,
      notes: ''
    });
    setSelectedServices([]);
    setError('');
  };

  // Handle edit
  const handleEdit = (supplier: Supplier) => {
    setEditingSupplier(supplier);
    setSupplierForm({
      name: supplier.name,
      company: supplier.company,
      email: supplier.email,
      phone: supplier.phone,
      website: supplier.website || '',
      address: supplier.address || '',
      contactPerson: supplier.contact_person || '',
      paymentMethod: supplier.payment_method || '',
      rating: supplier.rating || 5,
      notes: supplier.notes || ''
    });

    // Load selected services for this supplier
    if (supplier.selected_service_ids && supplier.selected_service_ids.length > 0) {
      const supplierServices = services.filter(service => 
        supplier.selected_service_ids.includes(service.id)
      );
      setSelectedServices(supplierServices);
    } else {
      setSelectedServices([]);
    }

    setShowAddModal(true);
  };

  // Handle delete
  const handleDelete = async (supplierId: string) => {
    if (window.confirm(t.confirmDelete)) {
      setIsLoading(true);
      
      try {
        const result = await supplierService.deleteSupplier(supplierId);
        
        if (result.success) {
          const updatedSuppliers = suppliers.filter(supplier => supplier.id !== supplierId);
          setSuppliers(updatedSuppliers);
          setSuccess(t.supplierDeleted);
        } else {
          setError(result.error || 'Failed to delete supplier');
        }
      } catch (error) {
        console.error('Error deleting supplier:', error);
        setError('Failed to delete supplier. Please try again.');
      }
      
      setIsLoading(false);
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  // Toggle supplier status
  const toggleSupplierStatus = async (supplierId: string) => {
    try {
      const result = await supplierService.toggleSupplierStatus(supplierId);
      
      if (result.success) {
        const updatedSuppliers = suppliers.map(supplier => 
          supplier.id === supplierId ? result.data : supplier
        );
        setSuppliers(updatedSuppliers);
      } else {
        setError(result.error || 'Failed to update supplier status');
        setTimeout(() => setError(''), 3000);
      }
    } catch (error) {
      console.error('Error updating supplier status:', error);
      setError('Failed to update supplier status');
      setTimeout(() => setError(''), 3000);
    }
  };

  // Calculate summary statistics
  const totalSuppliers = suppliers.length;
  const activeSuppliers = suppliers.filter(s => s.is_active).length;
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const newThisMonth = suppliers.filter(supplier => {
    const supplierDate = new Date(supplier.created_at);
    return supplierDate.getMonth() === currentMonth && supplierDate.getFullYear() === currentYear;
  }).length;

  if (isLoading && suppliers.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">{t.loadingSuppliers}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{t.title}</h1>
          <p className="text-gray-600">{t.subtitle}</p>
        </div>

        {permissions.add && (
          <button
            onClick={() => {
              resetForm();
              setEditingSupplier(null);
              setShowAddModal(true);
            }}
            className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            <Plus className="w-5 h-5" />
            {t.addSupplier}
          </button>
        )}
      </div>

      {/* Success/Error Messages */}
      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-indigo-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Truck className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-blue-100 text-sm">{t.totalSuppliers}</div>
              <div className="text-2xl font-bold">{totalSuppliers}</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CheckCircle className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-green-100 text-sm">{t.activeSuppliers}</div>
              <div className="text-2xl font-bold">{activeSuppliers}</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Calendar className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-purple-100 text-sm">{t.newThisMonth}</div>
              <div className="text-2xl font-bold">{newThisMonth}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-lg">
        <div className={`flex flex-col md:flex-row gap-4 ${isRTL ? 'md:flex-row-reverse' : ''}`}>
          {/* Search */}
          <div className="flex-1 relative">
            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5`} />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t.searchPlaceholder}
              className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200`}
            />
          </div>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as 'all' | 'active' | 'inactive')}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            <option value="all">{t.filterAll}</option>
            <option value="active">{t.filterActive}</option>
            <option value="inactive">{t.filterInactive}</option>
          </select>

          {/* Sort By */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'name' | 'email' | 'created_at')}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            <option value="name">{t.sortByName}</option>
            <option value="email">{t.sortByEmail}</option>
            <option value="created_at">{t.sortByDate}</option>
          </select>

          {/* Sort Order */}
          <button
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            className="px-4 py-3 bg-gray-100 hover:bg-gray-200 rounded-2xl transition-all duration-200 flex items-center gap-2"
          >
            {sortOrder === 'asc' ? '↑' : '↓'}
          </button>
        </div>
      </div>

      {/* Suppliers Table */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-lg overflow-hidden">
        {filteredSuppliers.length === 0 ? (
          <div className="text-center py-16">
            <Truck className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">{t.noSuppliers}</h3>
            <p className="text-gray-500 mb-6">{t.noSuppliersDesc}</p>
            {permissions.add && (
              <button
                onClick={() => {
                  resetForm();
                  setEditingSupplier(null);
                  setShowAddModal(true);
                }}
                className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl mx-auto"
              >
                <Plus className="w-5 h-5" />
                {t.addSupplier}
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.name}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.company}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.email}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.phone}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.rating}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.status}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.actions}
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredSuppliers.map((supplier, index) => (
                  <tr
                    key={supplier.id}
                    className={`border-b border-gray-100 hover:bg-gray-50 transition-colors animate-fadeIn`}
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <td className={`py-4 px-6 font-medium text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-semibold">
                          {supplier.name.charAt(0).toUpperCase()}
                        </div>
                        {supplier.name}
                      </div>
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-2">
                        <Building className="w-4 h-4 text-gray-400" />
                        {supplier.company}
                      </div>
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-gray-400" />
                        {supplier.email}
                      </div>
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-gray-400" />
                        {supplier.phone}
                      </div>
                    </td>
                    <td className={`py-4 px-6 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < (supplier.rating || 5) ? 'text-yellow-400 fill-current' : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <button
                        onClick={() => toggleSupplierStatus(supplier.id)}
                        className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                          supplier.is_active
                            ? 'bg-green-100 text-green-800 hover:bg-green-200'
                            : 'bg-red-100 text-red-800 hover:bg-red-200'
                        }`}
                      >
                        <div className={`w-2 h-2 rounded-full ${supplier.is_active ? 'bg-green-500' : 'bg-red-500'}`}></div>
                        {supplier.is_active ? t.active : t.inactive}
                      </button>
                    </td>
                    <td className="py-4 px-6">
                      <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <button
                          onClick={() => setViewingSupplier(supplier)}
                          className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                          title={t.view}
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        {permissions.edit && (
                          <button
                            onClick={() => handleEdit(supplier)}
                            className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors duration-200"
                            title={t.edit}
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                        )}
                        {permissions.delete && (
                          <button
                            onClick={() => handleDelete(supplier.id)}
                            className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors duration-200"
                            title={t.delete}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add/Edit Supplier Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-fadeIn">
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-2xl font-bold text-gray-800">
                {editingSupplier ? t.editSupplier : t.addNewSupplier}
              </h2>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setEditingSupplier(null);
                  resetForm();
                }}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl mb-4 animate-fadeIn">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-5 h-5" />
                  {error}
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Contact Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.contactInfo}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Supplier Name - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.name} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={supplierForm.name}
                      onChange={(e) => setSupplierForm(prev => ({ ...prev, name: e.target.value }))}
                      placeholder={t.enterName}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Company - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.company} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={supplierForm.company}
                      onChange={(e) => setSupplierForm(prev => ({ ...prev, company: e.target.value }))}
                      placeholder={t.enterCompany}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Email - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.email} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      value={supplierForm.email}
                      onChange={(e) => setSupplierForm(prev => ({ ...prev, email: e.target.value }))}
                      placeholder={t.enterEmail}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Phone - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.phone} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      value={supplierForm.phone}
                      onChange={(e) => setSupplierForm(prev => ({ ...prev, phone: e.target.value }))}
                      placeholder={t.enterPhone}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>
              </div>

              {/* Business Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.businessInfo}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Website - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.website} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="url"
                      value={supplierForm.website}
                      onChange={(e) => setSupplierForm(prev => ({ ...prev, website: e.target.value }))}
                      placeholder={t.enterWebsite}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Contact Person - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.contactPerson} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="text"
                      value={supplierForm.contactPerson}
                      onChange={(e) => setSupplierForm(prev => ({ ...prev, contactPerson: e.target.value }))}
                      placeholder={t.enterContactPerson}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Payment Method - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.paymentMethod} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="text"
                      value={supplierForm.paymentMethod}
                      onChange={(e) => setSupplierForm(prev => ({ ...prev, paymentMethod: e.target.value }))}
                      placeholder={t.enterPaymentMethod}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Rating */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.rating}
                    </label>
                    <select
                      value={supplierForm.rating}
                      onChange={(e) => setSupplierForm(prev => ({ ...prev, rating: Number(e.target.value) }))}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    >
                      {[1, 2, 3, 4, 5].map(rating => (
                        <option key={rating} value={rating}>
                          {rating} {rating === 1 ? 'Star' : 'Stars'}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Address - Full Width */}
                <div className="mt-6">
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.address} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <textarea
                    value={supplierForm.address}
                    onChange={(e) => setSupplierForm(prev => ({ ...prev, address: e.target.value }))}
                    placeholder={t.enterAddress}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-none"
                  />
                </div>
              </div>

              {/* Services & Products Selection */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.supplierProvides}
                </h3>
                
                {/* Services Dropdown */}
                <div className="relative">
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.selectServices} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  
                  <div className="relative">
                    <div className="relative">
                      <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5`} />
                      <input
                        type="text"
                        value={serviceSearchTerm}
                        onChange={(e) => setServiceSearchTerm(e.target.value)}
                        onFocus={() => setShowServiceDropdown(true)}
                        placeholder={t.searchServices}
                        className={`w-full ${isRTL ? 'pr-12 pl-10' : 'pl-12 pr-10'} py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowServiceDropdown(!showServiceDropdown)}
                        className={`absolute ${isRTL ? 'left-3' : 'right-3'} top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors`}
                      >
                        {showServiceDropdown ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                      </button>
                    </div>

                    {/* Services Dropdown */}
                    {showServiceDropdown && (
                      <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-2xl shadow-xl z-50 max-h-60 overflow-y-auto">
                        {filteredServices.length === 0 ? (
                          <div className="p-4 text-center text-gray-500">
                            <Package className="w-8 h-8 mx-auto mb-2 opacity-50" />
                            <p>{t.noServicesFound}</p>
                          </div>
                        ) : (
                          <div className="p-2">
                            {filteredServices.map((service) => (
                              <button
                                key={service.id}
                                type="button"
                                onClick={() => handleServiceSelect(service)}
                                className={`w-full text-left p-3 rounded-xl hover:bg-gray-50 transition-colors duration-200 ${
                                  selectedServices.find(s => s.id === service.id) ? 'bg-blue-50 border border-blue-200' : ''
                                }`}
                                disabled={!!selectedServices.find(s => s.id === service.id)}
                              >
                                <div className="flex items-center justify-between">
                                  <div>
                                    <div className="font-medium text-gray-800">{service.name}</div>
                                    <div className="text-sm text-gray-600">
                                      {service.category}
                                      {service.subcategory && ` > ${service.subcategory}`}
                                    </div>
                                    <div className="text-xs text-blue-600 font-medium">
                                      {service.price} BHD
                                    </div>
                                  </div>
                                  {selectedServices.find(s => s.id === service.id) && (
                                    <CheckCircle className="w-5 h-5 text-green-500" />
                                  )}
                                </div>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Selected Services Tags */}
                  {selectedServices.length > 0 && (
                    <div className="mt-4">
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {t.selectedServices}
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {selectedServices.map((service) => (
                          <div
                            key={service.id}
                            className="inline-flex items-center gap-2 bg-blue-100 text-blue-800 px-3 py-2 rounded-xl text-sm font-medium"
                          >
                            <Package className="w-4 h-4" />
                            <span>
                              {service.name}
                              {service.category && ` • ${service.category}`}
                              {service.subcategory && ` • ${service.subcategory}`}
                            </span>
                            <button
                              type="button"
                              onClick={() => removeSelectedService(service.id)}
                              className="text-blue-600 hover:text-blue-800 transition-colors"
                              title={t.removeService}
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.notes} <span className="text-gray-400 text-xs">({t.optional})</span>
                </label>
                <textarea
                  value={supplierForm.notes}
                  onChange={(e) => setSupplierForm(prev => ({ ...prev, notes: e.target.value }))}
                  placeholder={t.enterNotes}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-none"
                />
              </div>

              {/* Action Buttons */}
              <div className={`flex gap-4 pt-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      {language === 'en' ? 'Saving...' : 'جاري الحفظ...'}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <Save className="w-5 h-5" />
                      {t.save}
                    </div>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingSupplier(null);
                    resetForm();
                  }}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Supplier Modal */}
      {viewingSupplier && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-fadeIn">
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-2xl font-bold text-gray-800">{t.supplierDetails}</h2>
              <button
                onClick={() => setViewingSupplier(null)}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-6">
              {/* Supplier Header */}
              <div className={`flex items-center gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                  {viewingSupplier.name.charAt(0).toUpperCase()}
                </div>
                <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                  <h3 className="text-xl font-bold text-gray-800">{viewingSupplier.name}</h3>
                  <p className="text-gray-600">{viewingSupplier.company}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <div className={`w-2 h-2 rounded-full ${viewingSupplier.is_active ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span className={`text-sm ${viewingSupplier.is_active ? 'text-green-600' : 'text-red-600'}`}>
                      {viewingSupplier.is_active ? t.active : t.inactive}
                    </span>
                  </div>
                </div>
              </div>

              {/* Contact Information */}
              <div className="bg-gray-50 rounded-2xl p-6">
                <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.contactInfo}
                </h4>
                <div className="space-y-3">
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Mail className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-700">{viewingSupplier.email}</span>
                  </div>
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Phone className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-700">{viewingSupplier.phone}</span>
                  </div>
                  {viewingSupplier.address && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <MapPin className="w-5 h-5 text-gray-400" />
                      <span className="text-gray-700">{viewingSupplier.address}</span>
                    </div>
                  )}
                  {viewingSupplier.contact_person && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <UserPlus className="w-5 h-5 text-gray-400" />
                      <span className="text-gray-700">{viewingSupplier.contact_person}</span>
                    </div>
                  )}
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Calendar className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-700">
                      {new Date(viewingSupplier.created_at).toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </span>
                  </div>
                </div>
              </div>

              {/* Business Information */}
              <div className="bg-gray-50 rounded-2xl p-6">
                <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.businessInfo}
                </h4>
                <div className="space-y-3">
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Building className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-700">{viewingSupplier.company}</span>
                  </div>
                  {viewingSupplier.website && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <Globe className="w-5 h-5 text-gray-400" />
                      <a 
                        href={viewingSupplier.website} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-800 transition-colors flex items-center gap-1"
                      >
                        {viewingSupplier.website}
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  )}
                  {viewingSupplier.payment_method && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <Package className="w-5 h-5 text-gray-400" />
                      <span className="text-gray-700">{viewingSupplier.payment_method}</span>
                    </div>
                  )}
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Star className="w-5 h-5 text-yellow-400" />
                    <div className="flex items-center gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < (viewingSupplier.rating || 5) ? 'text-yellow-400 fill-current' : 'text-gray-300'
                          }`}
                        />
                      ))}
                      <span className="text-gray-700 ml-2">({viewingSupplier.rating || 5}/5)</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Services & Products */}
              {viewingSupplier.selected_service_ids && viewingSupplier.selected_service_ids.length > 0 && (
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.supplierProvides}
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {viewingSupplier.selected_service_ids.map((serviceId) => {
                      const service = services.find(s => s.id === serviceId);
                      if (!service) return null;
                      
                      return (
                        <div
                          key={serviceId}
                          className="inline-flex items-center gap-2 bg-blue-100 text-blue-800 px-3 py-2 rounded-xl text-sm font-medium"
                        >
                          <Package className="w-4 h-4" />
                          <span>
                            {service.name}
                            {service.category && ` • ${service.category}`}
                            {service.subcategory && ` • ${service.subcategory}`}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Notes */}
              {viewingSupplier.notes && (
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.notes}
                  </h4>
                  <p className="text-gray-700 whitespace-pre-wrap">{viewingSupplier.notes}</p>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className={`flex gap-4 mt-8 ${isRTL ? 'flex-row-reverse' : ''}`}>
              {permissions.edit && (
                <button
                  onClick={() => {
                    setViewingSupplier(null);
                    handleEdit(viewingSupplier);
                  }}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl"
                >
                  <div className="flex items-center justify-center gap-2">
                    <Edit3 className="w-5 h-5" />
                    {t.edit}
                  </div>
                </button>
              )}
              <button
                onClick={() => setViewingSupplier(null)}
                className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
              >
                {t.close}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Click outside to close dropdown */}
      {showServiceDropdown && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowServiceDropdown(false)}
        />
      )}
    </div>
  );
};

export default SuppliersPage;