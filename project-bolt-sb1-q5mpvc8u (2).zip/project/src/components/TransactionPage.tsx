import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  Download, 
  Edit3, 
  Trash2, 
  DollarSign,
  Calendar,
  User,
  Package,
  TrendingUp,
  TrendingDown,
  Eye,
  X,
  Save,
  AlertCircle,
  CheckCircle,
  Building,
  CreditCard,
  FileText,
  Target,
  Zap,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { transactionService, clientService, supplierService, serviceService } from '../lib/supabase';
import type { Transaction, Client, Supplier, Service } from '../lib/supabase';

interface TransactionPageProps {
  language: 'en' | 'ar';
  bossId?: string;
  userPermissions?: {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
  };
}

const TransactionPage: React.FC<TransactionPageProps> = ({ language, bossId, userPermissions }) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMonth, setFilterMonth] = useState<number>(0);
  const [filterYear, setFilterYear] = useState<number>(new Date().getFullYear());
  const [filterType, setFilterType] = useState<'all' | 'revenue' | 'expense'>('all');
  const [sortBy, setSortBy] = useState<'date' | 'amount' | 'profit'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [viewingTransaction, setViewingTransaction] = useState<Transaction | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Service selection states
  const [serviceSearchTerm, setServiceSearchTerm] = useState('');
  const [showServiceDropdown, setShowServiceDropdown] = useState(false);
  const [selectedServices, setSelectedServices] = useState<Service[]>([]);

  const isRTL = language === 'ar';

  // Get current user from localStorage to access boss ID
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Form state for adding/editing transactions
  const [transactionForm, setTransactionForm] = useState({
    amount: 0,
    cost: 0,
    vat: 0,
    profit: 0,
    clientId: '',
    clientName: '',
    supplierId: '',
    supplierName: '',
    serviceIds: [] as string[],
    serviceNames: [] as string[],
    transactionDate: new Date().toISOString().split('T')[0],
    paymentMethod: '',
    status: '',
    description: '',
    priority: '',
    category: '',
    vatPercentage: 0,
    totalWithVat: 0
  });

  const translations = {
    en: {
      title: 'Transactions',
      subtitle: 'Manage your business transactions',
      addTransaction: 'Add Transaction',
      searchPlaceholder: 'Search transactions...',
      filterAll: 'All Months',
      filterRevenue: 'Revenue Only',
      filterExpense: 'Expense Only',
      sortByDate: 'Date',
      sortByAmount: 'Amount',
      sortByProfit: 'Profit',
      amount: 'Amount',
      cost: 'Cost',
      vat: 'VAT',
      profit: 'Profit',
      client: 'Client',
      supplier: 'Supplier',
      services: 'Services/Products',
      date: 'Date',
      paymentMethod: 'Payment Method',
      status: 'Status',
      description: 'Description',
      priority: 'Priority',
      category: 'Category',
      vatPercentage: 'VAT %',
      totalWithVat: 'Total with VAT',
      actions: 'Actions',
      edit: 'Edit',
      delete: 'Delete',
      view: 'View',
      save: 'Save',
      cancel: 'Cancel',
      close: 'Close',
      addNewTransaction: 'Add New Transaction',
      editTransaction: 'Edit Transaction',
      transactionDetails: 'Transaction Details',
      enterAmount: 'Enter Amount',
      enterCost: 'Enter Cost',
      enterVAT: 'Enter VAT Amount',
      enterDescription: 'Enter Description',
      selectClient: 'Select Client',
      selectSupplier: 'Select Supplier',
      selectServices: 'Select Services/Products',
      searchServices: 'Search services...',
      noServicesSelected: 'No services selected',
      confirmDelete: 'Are you sure you want to delete this transaction?',
      deleteTransaction: 'Delete Transaction',
      transactionAdded: 'Transaction added successfully',
      transactionUpdated: 'Transaction updated successfully',
      transactionDeleted: 'Transaction deleted successfully',
      fillRequired: 'Please fill all required fields',
      noTransactions: 'No transactions found',
      noTransactionsDesc: 'Start by adding your first transaction',
      totalTransactions: 'Total Transactions',
      totalRevenue: 'Total Revenue',
      totalExpenses: 'Total Expenses',
      netProfit: 'Net Profit',
      thisMonth: 'This Month',
      export: 'Export',
      print: 'Print',
      refresh: 'Refresh',
      required: 'Required',
      optional: 'Optional',
      financialInfo: 'Financial Information',
      clientInfo: 'Client Information',
      supplierInfo: 'Supplier Information',
      serviceInfo: 'Services Information',
      additionalInfo: 'Additional Information',
      loadingTransactions: 'Loading transactions...',
      errorLoading: 'Error loading transactions',
      bhd: 'BHD',
      cash: 'Cash',
      card: 'Card',
      transfer: 'Transfer',
      check: 'Check',
      pending: 'Pending',
      completed: 'Completed',
      cancelled: 'Cancelled',
      high: 'High',
      medium: 'Medium',
      low: 'Low',
      urgent: 'Urgent',
      removeService: 'Remove service'
    },
    ar: {
      title: 'المعاملات',
      subtitle: 'إدارة معاملات عملك',
      addTransaction: 'إضافة معاملة',
      searchPlaceholder: 'البحث في المعاملات...',
      filterAll: 'جميع الشهور',
      filterRevenue: 'الإيرادات فقط',
      filterExpense: 'المصروفات فقط',
      sortByDate: 'التاريخ',
      sortByAmount: 'المبلغ',
      sortByProfit: 'الربح',
      amount: 'المبلغ',
      cost: 'التكلفة',
      vat: 'ضريبة القيمة المضافة',
      profit: 'الربح',
      client: 'العميل',
      supplier: 'المورد',
      services: 'الخدمات/المنتجات',
      date: 'التاريخ',
      paymentMethod: 'طريقة الدفع',
      status: 'الحالة',
      description: 'الوصف',
      priority: 'الأولوية',
      category: 'الفئة',
      vatPercentage: 'نسبة الضريبة',
      totalWithVat: 'الإجمالي مع الضريبة',
      actions: 'الإجراءات',
      edit: 'تعديل',
      delete: 'حذف',
      view: 'عرض',
      save: 'حفظ',
      cancel: 'إلغاء',
      close: 'إغلاق',
      addNewTransaction: 'إضافة معاملة جديدة',
      editTransaction: 'تعديل المعاملة',
      transactionDetails: 'تفاصيل المعاملة',
      enterAmount: 'أدخل المبلغ',
      enterCost: 'أدخل التكلفة',
      enterVAT: 'أدخل مبلغ الضريبة',
      enterDescription: 'أدخل الوصف',
      selectClient: 'اختر العميل',
      selectSupplier: 'اختر المورد',
      selectServices: 'اختر الخدمات/المنتجات',
      searchServices: 'البحث في الخدمات...',
      noServicesSelected: 'لم يتم اختيار خدمات',
      confirmDelete: 'هل أنت متأكد من حذف هذه المعاملة؟',
      deleteTransaction: 'حذف المعاملة',
      transactionAdded: 'تم إضافة المعاملة بنجاح',
      transactionUpdated: 'تم تحديث المعاملة بنجاح',
      transactionDeleted: 'تم حذف المعاملة بنجاح',
      fillRequired: 'يرجى ملء جميع الحقول المطلوبة',
      noTransactions: 'لا توجد معاملات',
      noTransactionsDesc: 'ابدأ بإضافة معاملتك الأولى',
      totalTransactions: 'إجمالي المعاملات',
      totalRevenue: 'إجمالي الإيرادات',
      totalExpenses: 'إجمالي المصروفات',
      netProfit: 'صافي الربح',
      thisMonth: 'هذا الشهر',
      export: 'تصدير',
      print: 'طباعة',
      refresh: 'تحديث',
      required: 'مطلوب',
      optional: 'اختياري',
      financialInfo: 'المعلومات المالية',
      clientInfo: 'معلومات العميل',
      supplierInfo: 'معلومات المورد',
      serviceInfo: 'معلومات الخدمات',
      additionalInfo: 'معلومات إضافية',
      loadingTransactions: 'جاري تحميل المعاملات...',
      errorLoading: 'خطأ في تحميل المعاملات',
      bhd: 'د.ب',
      cash: 'نقداً',
      card: 'بطاقة',
      transfer: 'تحويل',
      check: 'شيك',
      pending: 'معلق',
      completed: 'مكتمل',
      cancelled: 'ملغي',
      high: 'عالي',
      medium: 'متوسط',
      low: 'منخفض',
      urgent: 'عاجل',
      removeService: 'إزالة الخدمة'
    }
  };

  const t = translations[language];

  // Default permissions for boss or if not provided
  const permissions = userPermissions || { view: true, add: true, edit: true, delete: true };

  // Load data from Supabase
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      const currentUser = getCurrentUser();
      
      if (!currentUser) {
        setIsLoading(false);
        return;
      }

      const targetBossId = bossId || currentUser.id;

      try {
        // Load transactions
        const transactionsResult = await transactionService.getTransactions(targetBossId);
        if (transactionsResult.success) {
          setTransactions(transactionsResult.data);
          setFilteredTransactions(transactionsResult.data);
        } else {
          setError(transactionsResult.error || t.errorLoading);
        }

        // Load clients
        const clientsResult = await clientService.getClients(targetBossId);
        if (clientsResult.success) {
          setClients(clientsResult.data);
        }

        // Load suppliers
        const suppliersResult = await supplierService.getSuppliers(targetBossId);
        if (suppliersResult.success) {
          setSuppliers(suppliersResult.data);
        }

        // Load services
        const servicesResult = await serviceService.getServices(targetBossId);
        if (servicesResult.success) {
          setServices(servicesResult.data);
        }
      } catch (error) {
        console.error('Error loading data:', error);
        setError(t.errorLoading);
      }
      
      setIsLoading(false);
    };

    loadData();
  }, [bossId]);

  // Filter and sort transactions
  useEffect(() => {
    let filtered = [...transactions];

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(transaction =>
        transaction.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.client_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.supplier_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.service_names?.some(service => 
          service.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    }

    // Apply month filter
    if (filterMonth > 0) {
      filtered = filtered.filter(transaction => transaction.month === filterMonth);
    }

    // Apply year filter
    filtered = filtered.filter(transaction => transaction.year === filterYear);

    // Apply type filter
    if (filterType === 'revenue') {
      filtered = filtered.filter(transaction => transaction.profit > 0);
    } else if (filterType === 'expense') {
      filtered = filtered.filter(transaction => transaction.profit <= 0);
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'date':
          comparison = new Date(a.transaction_date).getTime() - new Date(b.transaction_date).getTime();
          break;
        case 'amount':
          comparison = a.amount - b.amount;
          break;
        case 'profit':
          comparison = a.profit - b.profit;
          break;
      }

      return sortOrder === 'asc' ? comparison : -comparison;
    });

    setFilteredTransactions(filtered);
  }, [transactions, searchTerm, filterMonth, filterYear, filterType, sortBy, sortOrder]);

  // Calculate profit automatically
  useEffect(() => {
    const profit = transactionForm.amount - transactionForm.cost;
    setTransactionForm(prev => ({ ...prev, profit }));
  }, [transactionForm.amount, transactionForm.cost, transactionForm.vat]);

  // Calculate total with VAT
  useEffect(() => {
    const totalWithVat = transactionForm.amount + transactionForm.vat;
    setTransactionForm(prev => ({ ...prev, totalWithVat }));
  }, [transactionForm.amount, transactionForm.vat]);

  // Calculate VAT from percentage
  useEffect(() => {
    if (transactionForm.vatPercentage > 0) {
      const vatAmount = (transactionForm.amount * transactionForm.vatPercentage) / 100;
      setTransactionForm(prev => ({ ...prev, vat: vatAmount }));
    }
  }, [transactionForm.amount, transactionForm.vatPercentage]);

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!transactionForm.amount || !transactionForm.cost) {
      setError(t.fillRequired);
      return;
    }

    const currentUser = getCurrentUser();
    if (!currentUser) {
      setError('User not found');
      return;
    }

    const targetBossId = bossId || currentUser.id;

    setIsLoading(true);
    setError('');

    try {
      const transactionData = {
        amount: transactionForm.amount,
        cost: transactionForm.cost,
        vat: transactionForm.vat,
        profit: transactionForm.profit,
        client_id: transactionForm.clientId || null,
        client_name: transactionForm.clientName || null,
        supplier_id: transactionForm.supplierId || null,
        supplier_name: transactionForm.supplierName || null,
        service_ids: selectedServices.map(s => s.id),
        service_names: selectedServices.map(s => s.name),
        transaction_date: transactionForm.transactionDate,
        payment_method: transactionForm.paymentMethod || null,
        status: transactionForm.status || null,
        description: transactionForm.description || null,
        priority: transactionForm.priority || null,
        category: transactionForm.category || null,
        vat_percentage: transactionForm.vatPercentage,
        total_with_vat: transactionForm.totalWithVat
      };

      if (editingTransaction) {
        // Update existing transaction
        const result = await transactionService.updateTransaction(editingTransaction.id, transactionData);

        if (result.success) {
          const updatedTransactions = transactions.map(transaction => 
            transaction.id === editingTransaction.id ? result.data : transaction
          );
          setTransactions(updatedTransactions);
          setSuccess(t.transactionUpdated);
          setEditingTransaction(null);
        } else {
          setError(result.error || 'Failed to update transaction');
        }
      } else {
        // Add new transaction
        const result = await transactionService.addTransaction(targetBossId, transactionData);

        if (result.success) {
          setTransactions(prev => [...prev, result.data]);
          setSuccess(t.transactionAdded);
        } else {
          setError(result.error || 'Failed to add transaction');
        }
      }

      setIsLoading(false);
      setShowAddModal(false);
      resetForm();

      setTimeout(() => setSuccess(''), 3000);
    } catch (error) {
      console.error('Error saving transaction:', error);
      setError('Failed to save transaction. Please try again.');
      setIsLoading(false);
    }
  };

  // Reset form
  const resetForm = () => {
    setTransactionForm({
      amount: 0,
      cost: 0,
      vat: 0,
      profit: 0,
      clientId: '',
      clientName: '',
      supplierId: '',
      supplierName: '',
      serviceIds: [],
      serviceNames: [],
      transactionDate: new Date().toISOString().split('T')[0],
      paymentMethod: '',
      status: '',
      description: '',
      priority: '',
      category: '',
      vatPercentage: 0,
      totalWithVat: 0
    });
    setSelectedServices([]);
    setServiceSearchTerm('');
    setError('');
  };

  // Handle edit
  const handleEdit = (transaction: Transaction) => {
    setEditingTransaction(transaction);
    setTransactionForm({
      amount: transaction.amount,
      cost: transaction.cost,
      vat: transaction.vat || 0,
      profit: transaction.profit,
      clientId: transaction.client_id || '',
      clientName: transaction.client_name || '',
      supplierId: transaction.supplier_id || '',
      supplierName: transaction.supplier_name || '',
      serviceIds: transaction.service_ids || [],
      serviceNames: transaction.service_names || [],
      transactionDate: transaction.transaction_date,
      paymentMethod: transaction.payment_method || '',
      status: transaction.status || '',
      description: transaction.description || '',
      priority: transaction.priority || '',
      category: transaction.category || '',
      vatPercentage: transaction.vat_percentage || 0,
      totalWithVat: transaction.total_with_vat || 0
    });

    // Set selected services based on transaction data
    if (transaction.service_ids && transaction.service_ids.length > 0) {
      const transactionServices = services.filter(service => 
        transaction.service_ids?.includes(service.id)
      );
      setSelectedServices(transactionServices);
    }

    setShowAddModal(true);
  };

  // Handle delete
  const handleDelete = async (transactionId: string) => {
    if (window.confirm(t.confirmDelete)) {
      setIsLoading(true);
      
      try {
        const result = await transactionService.deleteTransaction(transactionId);
        
        if (result.success) {
          const updatedTransactions = transactions.filter(transaction => transaction.id !== transactionId);
          setTransactions(updatedTransactions);
          setSuccess(t.transactionDeleted);
        } else {
          setError(result.error || 'Failed to delete transaction');
        }
      } catch (error) {
        console.error('Error deleting transaction:', error);
        setError('Failed to delete transaction. Please try again.');
      }
      
      setIsLoading(false);
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  // Handle client selection
  const handleClientSelect = (clientId: string) => {
    const selectedClient = clients.find(c => c.id === clientId);
    if (selectedClient) {
      setTransactionForm(prev => ({
        ...prev,
        clientId: selectedClient.id,
        clientName: selectedClient.name
      }));
    } else {
      setTransactionForm(prev => ({
        ...prev,
        clientId: '',
        clientName: ''
      }));
    }
  };

  // Handle supplier selection
  const handleSupplierSelect = (supplierId: string) => {
    const selectedSupplier = suppliers.find(s => s.id === supplierId);
    if (selectedSupplier) {
      setTransactionForm(prev => ({
        ...prev,
        supplierId: selectedSupplier.id,
        supplierName: selectedSupplier.name
      }));
    } else {
      setTransactionForm(prev => ({
        ...prev,
        supplierId: '',
        supplierName: ''
      }));
    }
  };

  // Filter services based on search term
  const filteredServices = services.filter(service =>
    service.is_active &&
    !selectedServices.some(selected => selected.id === service.id) &&
    (service.name.toLowerCase().includes(serviceSearchTerm.toLowerCase()) ||
     service.category?.toLowerCase().includes(serviceSearchTerm.toLowerCase()) ||
     service.subcategory?.toLowerCase().includes(serviceSearchTerm.toLowerCase()))
  );

  // Handle service selection
  const handleServiceSelect = (service: Service) => {
    setSelectedServices(prev => [...prev, service]);
    setServiceSearchTerm('');
    setShowServiceDropdown(false);
  };

  // Handle service removal
  const handleServiceRemove = (serviceId: string) => {
    setSelectedServices(prev => prev.filter(service => service.id !== serviceId));
  };

  // Calculate summary statistics
  const totalTransactions = transactions.length;
  const totalRevenue = transactions.reduce((sum, t) => sum + (t.amount + (t.vat || 0)), 0);
  const totalExpenses = transactions.reduce((sum, t) => sum + t.cost, 0);
  const netProfit = totalRevenue - totalExpenses;

  const currentMonth = new Date().getMonth() + 1;
  const currentYear = new Date().getFullYear();
  
  const thisMonthTransactions = transactions.filter(t => 
    t.month === currentMonth && t.year === currentYear
  );
  const thisMonthRevenue = thisMonthTransactions.reduce((sum, t) => sum + (t.amount + (t.vat || 0)), 0);

  const monthNames = [
    t.january, t.february, t.march, t.april, t.may, t.june,
    t.july, t.august, t.september, t.october, t.november, t.december
  ];

  if (isLoading && transactions.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">{t.loadingTransactions}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{t.title}</h1>
          <p className="text-gray-600">{t.subtitle}</p>
        </div>

        {permissions.add && (
          <button
            onClick={() => {
              resetForm();
              setEditingTransaction(null);
              setShowAddModal(true);
            }}
            className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            <Plus className="w-5 h-5" />
            {t.addTransaction}
          </button>
        )}
      </div>

      {/* Success/Error Messages */}
      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-indigo-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <FileText className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-blue-100 text-sm">{t.totalTransactions}</div>
              <div className="text-2xl font-bold">{totalTransactions}</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <TrendingUp className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-green-100 text-sm">{t.totalRevenue}</div>
              <div className="text-2xl font-bold">{totalRevenue.toLocaleString()} {t.bhd}</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-red-500 to-rose-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <TrendingDown className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-red-100 text-sm">{t.totalExpenses}</div>
              <div className="text-2xl font-bold">{totalExpenses.toLocaleString()} {t.bhd}</div>
            </div>
          </div>
        </div>

        <div className={`bg-gradient-to-br ${netProfit >= 0 ? 'from-purple-500 to-pink-500' : 'from-orange-500 to-red-500'} rounded-3xl p-6 text-white shadow-lg`}>
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <DollarSign className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-white/80 text-sm">{t.netProfit}</div>
              <div className="text-2xl font-bold">{netProfit.toLocaleString()} {t.bhd}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-lg">
        <div className={`flex flex-col md:flex-row gap-4 ${isRTL ? 'md:flex-row-reverse' : ''}`}>
          {/* Search */}
          <div className="flex-1 relative">
            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5`} />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t.searchPlaceholder}
              className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200`}
            />
          </div>

          {/* Type Filter */}
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value as 'all' | 'revenue' | 'expense')}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            <option value="all">{language === 'en' ? 'All Types' : 'جميع الأنواع'}</option>
            <option value="revenue">{t.filterRevenue}</option>
            <option value="expense">{t.filterExpense}</option>
          </select>

          {/* Month Filter */}
          <select
            value={filterMonth}
            onChange={(e) => setFilterMonth(Number(e.target.value))}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            <option value={0}>{t.filterAll}</option>
            <option value={1}>{language === 'en' ? 'January' : 'يناير'}</option>
            <option value={2}>{language === 'en' ? 'February' : 'فبراير'}</option>
            <option value={3}>{language === 'en' ? 'March' : 'مارس'}</option>
            <option value={4}>{language === 'en' ? 'April' : 'أبريل'}</option>
            <option value={5}>{language === 'en' ? 'May' : 'مايو'}</option>
            <option value={6}>{language === 'en' ? 'June' : 'يونيو'}</option>
            <option value={7}>{language === 'en' ? 'July' : 'يوليو'}</option>
            <option value={8}>{language === 'en' ? 'August' : 'أغسطس'}</option>
            <option value={9}>{language === 'en' ? 'September' : 'سبتمبر'}</option>
            <option value={10}>{language === 'en' ? 'October' : 'أكتوبر'}</option>
            <option value={11}>{language === 'en' ? 'November' : 'نوفمبر'}</option>
            <option value={12}>{language === 'en' ? 'December' : 'ديسمبر'}</option>
          </select>

          {/* Year Filter */}
          <select
            value={filterYear}
            onChange={(e) => setFilterYear(Number(e.target.value))}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            {Array.from({ length: 21 }, (_, i) => 2025 + i).map(year => (
              <option key={year} value={year}>{year}</option>
            ))}
          </select>

          {/* Sort By */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'date' | 'amount' | 'profit')}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            <option value="date">{t.sortByDate}</option>
            <option value="amount">{t.sortByAmount}</option>
            <option value="profit">{t.sortByProfit}</option>
          </select>

          {/* Sort Order */}
          <button
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            className="px-4 py-3 bg-gray-100 hover:bg-gray-200 rounded-2xl transition-all duration-200 flex items-center gap-2"
          >
            {sortOrder === 'asc' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-lg overflow-hidden">
        {filteredTransactions.length === 0 ? (
          <div className="text-center py-16">
            <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">{t.noTransactions}</h3>
            <p className="text-gray-500 mb-6">{t.noTransactionsDesc}</p>
            {permissions.add && (
              <button
                onClick={() => {
                  resetForm();
                  setEditingTransaction(null);
                  setShowAddModal(true);
                }}
                className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl mx-auto"
              >
                <Plus className="w-5 h-5" />
                {t.addTransaction}
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.date}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.description}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.client}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.amount}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.profit}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.services}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.actions}
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredTransactions.map((transaction, index) => (
                  <tr
                    key={transaction.id}
                    className={`border-b border-gray-100 hover:bg-gray-50 transition-colors animate-fadeIn`}
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        {new Date(transaction.transaction_date).toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA')}
                      </div>
                    </td>
                    <td className={`py-4 px-6 font-medium text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {transaction.description || '-'}
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-gray-400" />
                        {transaction.client_name || '-'}
                      </div>
                    </td>
                    <td className={`py-4 px-6 font-semibold text-green-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {(transaction.amount + (transaction.vat || 0)).toLocaleString()} {t.bhd}
                    </td>
                    <td className={`py-4 px-6 font-semibold ${transaction.profit >= 0 ? 'text-green-600' : 'text-red-600'} ${isRTL ? 'text-right' : 'text-left'}`}>
                      {transaction.profit >= 0 ? '+' : ''}{transaction.profit.toLocaleString()} {t.bhd}
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {transaction.service_names && transaction.service_names.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {transaction.service_names.slice(0, 2).map((service, idx) => (
                            <span key={idx} className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              {service}
                            </span>
                          ))}
                          {transaction.service_names.length > 2 && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
                              +{transaction.service_names.length - 2}
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className="py-4 px-6">
                      <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <button
                          onClick={() => setViewingTransaction(transaction)}
                          className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                          title={t.view}
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        {permissions.edit && (
                          <button
                            onClick={() => handleEdit(transaction)}
                            className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors duration-200"
                            title={t.edit}
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                        )}
                        {permissions.delete && (
                          <button
                            onClick={() => handleDelete(transaction.id)}
                            className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors duration-200"
                            title={t.delete}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add/Edit Transaction Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-fadeIn">
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-2xl font-bold text-gray-800">
                {editingTransaction ? t.editTransaction : t.addNewTransaction}
              </h2>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setEditingTransaction(null);
                  resetForm();
                }}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl mb-4 animate-fadeIn">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-5 h-5" />
                  {error}
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Financial Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.financialInfo}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {/* Amount - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.amount} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={transactionForm.amount}
                      onChange={(e) => setTransactionForm(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
                      placeholder={t.enterAmount}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Cost - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.cost} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={transactionForm.cost}
                      onChange={(e) => setTransactionForm(prev => ({ ...prev, cost: parseFloat(e.target.value) || 0 }))}
                      placeholder={t.enterCost}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* VAT Percentage */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.vatPercentage} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      max="100"
                      value={transactionForm.vatPercentage}
                      onChange={(e) => setTransactionForm(prev => ({ ...prev, vatPercentage: parseFloat(e.target.value) || 0 }))}
                      placeholder="0"
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* VAT Amount (calculated) */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.vat} <span className="text-gray-400 text-xs">({language === 'en' ? 'Calculated' : 'محسوب'})</span>
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={transactionForm.vat}
                      onChange={(e) => setTransactionForm(prev => ({ ...prev, vat: parseFloat(e.target.value) || 0 }))}
                      placeholder={t.enterVAT}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50"
                    />
                  </div>

                  {/* Profit (calculated) */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.profit} <span className="text-gray-400 text-xs">({language === 'en' ? 'Calculated' : 'محسوب'})</span>
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={transactionForm.profit}
                      readOnly
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl bg-gray-50 text-gray-700 cursor-not-allowed"
                    />
                  </div>

                  {/* Total with VAT (calculated) */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.totalWithVat} <span className="text-gray-400 text-xs">({language === 'en' ? 'Calculated' : 'محسوب'})</span>
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={transactionForm.totalWithVat}
                      readOnly
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl bg-gray-50 text-gray-700 cursor-not-allowed"
                    />
                  </div>

                  {/* Transaction Date */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.date} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={transactionForm.transactionDate}
                      onChange={(e) => setTransactionForm(prev => ({ ...prev, transactionDate: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>
              </div>

              {/* Client and Supplier Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {language === 'en' ? 'Client & Supplier Information' : 'معلومات العميل والمورد'}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Client Selection */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.client} <span className="text-gray-400 text-xs">{t.cat}</span>
                    </label>
                    <select
                      value={transactionForm.clientId}
                      onChange={(e) => handleClientSelect(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    >
                      <option value="">{t.selectClient}</option>
                      {clients.filter(c => c.is_active).map(client => (
                        <option key={client.id} value={client.id}>
                          {client.name} ({client.email})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Supplier Selection */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.supplier} <span className="text-gray-400 text-xs">{t.cat}</span>
                    </label>
                    <select
                      value={transactionForm.supplierId}
                      onChange={(e) => handleSupplierSelect(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    >
                      <option value="">{t.selectSupplier}</option>
                      {suppliers.filter(s => s.is_active).map(supplier => (
                        <option key={supplier.id} value={supplier.id}>
                          {supplier.name} ({supplier.company})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Services/Products Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.serviceInfo}
                </h3>
                
                {/* Multi-Select Services Dropdown */}
                <div className="relative">
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.services} <span className="text-gray-400 text-xs">({t.cat})</span>
                  </label>
                  
                  {/* Selected Services Tags */}
                  {selectedServices.length > 0 && (
                    <div className="mb-3 flex flex-wrap gap-2">
                      {selectedServices.map((service) => (
                        <div
                          key={service.id}
                          className="inline-flex items-center gap-2 bg-blue-100 text-blue-800 px-3 py-2 rounded-xl text-sm font-medium border border-blue-200"
                        >
                          <div className="flex flex-col">
                            <span className="font-semibold">{service.name}</span>
                            <span className="text-xs text-blue-600">
                              {service.category}{service.subcategory ? ` > ${service.subcategory}` : ''} • {service.price} {t.bhd}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleServiceRemove(service.id)}
                            className="text-blue-600 hover:text-blue-800 transition-colors"
                            title={t.removeService}
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Search Input */}
                  <div className="relative">
                    <div className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5`}>
                      🔍
                    </div>
                    <input
                      type="text"
                      value={serviceSearchTerm}
                      onChange={(e) => {
                        setServiceSearchTerm(e.target.value);
                        setShowServiceDropdown(true);
                      }}
                      onFocus={() => setShowServiceDropdown(true)}
                      placeholder={t.searchServices}
                      className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200`}
                    />
                  </div>

                  {/* Dropdown */}
                  {showServiceDropdown && (
                    <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-2xl shadow-lg max-h-60 overflow-y-auto">
                      {filteredServices.length === 0 ? (
                        <div className="p-4 text-center text-gray-500">
                          {serviceSearchTerm ? 
                            (language === 'en' ? 'No services found' : 'لا توجد خدمات') :
                            (language === 'en' ? 'No available services' : 'لا توجد خدمات متاحة')
                          }
                        </div>
                      ) : (
                        filteredServices.map((service) => (
                          <button
                            key={service.id}
                            type="button"
                            onClick={() => handleServiceSelect(service)}
                            className={`w-full p-4 text-left hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-b-0 ${isRTL ? 'text-right' : 'text-left'}`}
                          >
                            <div className="flex items-center justify-between">
                              <div>
                                <div className="font-medium text-gray-800">{service.name}</div>
                                <div className="text-sm text-gray-600">
                                  {service.category}{service.subcategory ? ` > ${service.subcategory}` : ''}
                                </div>
                                {service.description && (
                                  <div className="text-xs text-gray-500 mt-1">{service.description}</div>
                                )}
                              </div>
                              <div className="text-right">
                                <div className="font-semibold text-blue-600">{service.price} {t.bhd}</div>
                              </div>
                            </div>
                          </button>
                        ))
                      )}
                    </div>
                  )}

                  {/* Click outside to close dropdown */}
                  {showServiceDropdown && (
                    <div
                      className="fixed inset-0 z-5"
                      onClick={() => setShowServiceDropdown(false)}
                    />
                  )}
                </div>

                {/* No Services Selected Message */}
                {selectedServices.length === 0 && (
                  <p className={`text-gray-500 text-sm mt-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.noServicesSelected}
                  </p>
                )}
              </div>

              {/* Additional Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.additionalInfo}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Payment Method */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.paymentMethod} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <select
                      value={transactionForm.paymentMethod}
                      onChange={(e) => setTransactionForm(prev => ({ ...prev, paymentMethod: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    >
                      <option value="">{language === 'en' ? 'Select Payment Method' : 'اختر طريقة الدفع'}</option>
                      <option value="cash">{t.cash}</option>
                      <option value="card">{t.card}</option>
                      <option value="transfer">{t.transfer}</option>
                      <option value="check">{t.check}</option>
                    </select>
                  </div>

                  {/* Status */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.status} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <select
                      value={transactionForm.status}
                      onChange={(e) => setTransactionForm(prev => ({ ...prev, status: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    >
                      <option value="">{language === 'en' ? 'Select Status' : 'اختر الحالة'}</option>
                      <option value="pending">{t.pending}</option>
                      <option value="completed">{t.completed}</option>
                      <option value="cancelled">{t.cancelled}</option>
                    </select>
                  </div>

                  {/* Priority */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.priority} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <select
                      value={transactionForm.priority}
                      onChange={(e) => setTransactionForm(prev => ({ ...prev, priority: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    >
                      <option value="">{language === 'en' ? 'Select Priority' : 'اختر الأولوية'}</option>
                      <option value="low">{t.low}</option>
                      <option value="medium">{t.medium}</option>
                      <option value="high">{t.high}</option>
                      <option value="urgent">{t.urgent}</option>
                    </select>
                  </div>

                  {/* Category */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.category} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="text"
                      value={transactionForm.category}
                      onChange={(e) => setTransactionForm(prev => ({ ...prev, category: e.target.value }))}
                      placeholder={language === 'en' ? 'Enter Category' : 'أدخل الفئة'}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>

                {/* Description */}
                <div className="mt-6">
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.description} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <textarea
                    value={transactionForm.description}
                    onChange={(e) => setTransactionForm(prev => ({ ...prev, description: e.target.value }))}
                    placeholder={t.enterDescription}
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-none"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className={`flex gap-4 pt-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      {language === 'en' ? 'Saving...' : 'جاري الحفظ...'}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <Save className="w-5 h-5" />
                      {t.save}
                    </div>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingTransaction(null);
                    resetForm();
                  }}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Transaction Modal */}
      {viewingTransaction && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-fadeIn">
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-2xl font-bold text-gray-800">{t.transactionDetails}</h2>
              <button
                onClick={() => setViewingTransaction(null)}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-6">
              {/* Financial Details */}
              <div className="bg-gray-50 rounded-2xl p-6">
                <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.financialInfo}
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="text-sm text-gray-600">{t.amount}:</span>
                    <p className="font-semibold text-gray-800">{viewingTransaction.amount.toLocaleString()} {t.bhd}</p>
                  </div>
                  <div>
                    <span className="text-sm text-gray-600">{t.cost}:</span>
                    <p className="font-semibold text-gray-800">{viewingTransaction.cost.toLocaleString()} {t.bhd}</p>
                  </div>
                  {viewingTransaction.vat && viewingTransaction.vat > 0 && (
                    <div>
                      <span className="text-sm text-gray-600">{t.vat}:</span>
                      <p className="font-semibold text-gray-800">{viewingTransaction.vat.toLocaleString()} {t.bhd}</p>
                    </div>
                  )}
                  <div>
                    <span className="text-sm text-gray-600">{t.profit}:</span>
                    <p className={`font-semibold ${viewingTransaction.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {viewingTransaction.profit >= 0 ? '+' : ''}{viewingTransaction.profit.toLocaleString()} {t.bhd}
                    </p>
                  </div>
                </div>
              </div>

              {/* Client and Supplier Info */}
              {(viewingTransaction.client_name || viewingTransaction.supplier_name) && (
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {language === 'en' ? 'Client & Supplier' : 'العميل والمورد'}
                  </h4>
                  <div className="space-y-3">
                    {viewingTransaction.client_name && (
                      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <User className="w-5 h-5 text-gray-400" />
                        <div>
                          <span className="text-sm text-gray-600">{t.client}:</span>
                          <p className="font-medium text-gray-800">{viewingTransaction.client_name}</p>
                        </div>
                      </div>
                    )}
                    {viewingTransaction.supplier_name && (
                      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <Building className="w-5 h-5 text-gray-400" />
                        <div>
                          <span className="text-sm text-gray-600">{t.supplier}:</span>
                          <p className="font-medium text-gray-800">{viewingTransaction.supplier_name}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Services */}
              {viewingTransaction.service_names && viewingTransaction.service_names.length > 0 && (
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.services}
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {viewingTransaction.service_names.map((serviceName, index) => (
                      <span key={index} className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                        <Package className="w-4 h-4 mr-1" />
                        {serviceName}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Additional Details */}
              <div className="bg-gray-50 rounded-2xl p-6">
                <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {language === 'en' ? 'Additional Details' : 'تفاصيل إضافية'}
                </h4>
                <div className="space-y-3">
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Calendar className="w-5 h-5 text-gray-400" />
                    <div>
                      <span className="text-sm text-gray-600">{t.date}:</span>
                      <p className="font-medium text-gray-800">
                        {new Date(viewingTransaction.transaction_date).toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </p>
                    </div>
                  </div>

                  {viewingTransaction.payment_method && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <CreditCard className="w-5 h-5 text-gray-400" />
                      <div>
                        <span className="text-sm text-gray-600">{t.paymentMethod}:</span>
                        <p className="font-medium text-gray-800">{viewingTransaction.payment_method}</p>
                      </div>
                    </div>
                  )}

                  {viewingTransaction.status && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <CheckCircle className="w-5 h-5 text-gray-400" />
                      <div>
                        <span className="text-sm text-gray-600">{t.status}:</span>
                        <p className="font-medium text-gray-800">{viewingTransaction.status}</p>
                      </div>
                    </div>
                  )}

                  {viewingTransaction.priority && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <Target className="w-5 h-5 text-gray-400" />
                      <div>
                        <span className="text-sm text-gray-600">{t.priority}:</span>
                        <p className="font-medium text-gray-800">{viewingTransaction.priority}</p>
                      </div>
                    </div>
                  )}

                  {viewingTransaction.category && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <Package className="w-5 h-5 text-gray-400" />
                      <div>
                        <span className="text-sm text-gray-600">{t.category}:</span>
                        <p className="font-medium text-gray-800">{viewingTransaction.category}</p>
                      </div>
                    </div>
                  )}

                  {viewingTransaction.description && (
                    <div className={`flex items-start gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <FileText className="w-5 h-5 text-gray-400 mt-1" />
                      <div>
                        <span className="text-sm text-gray-600">{t.description}:</span>
                        <p className="font-medium text-gray-800 whitespace-pre-wrap">{viewingTransaction.description}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className={`flex gap-4 mt-8 ${isRTL ? 'flex-row-reverse' : ''}`}>
              {permissions.edit && (
                <button
                  onClick={() => {
                    setViewingTransaction(null);
                    handleEdit(viewingTransaction);
                  }}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl"
                >
                  <div className="flex items-center justify-center gap-2">
                    <Edit3 className="w-5 h-5" />
                    {t.edit}
                  </div>
                </button>
              )}
              <button
                onClick={() => setViewingTransaction(null)}
                className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
              >
                {t.close}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TransactionPage;