import React from 'react';
import { useEffect } from 'react';
import { useState } from 'react';
import { 
  Home, 
  CreditCard, 
  FileText, 
  Users, 
  UserCheck, 
  Truck, 
  Package, 
  Settings,
  Shield,
  Menu,
  ChevronLeft,
  ChevronRight,
  Receipt,
  Calendar
} from 'lucide-react';
import { employeeDetailedPermissionService } from '../lib/supabase';

interface SidebarProps {
  language: 'en' | 'ar';
  currentPage: string;
  onPageChange: (page: string) => void;
  userRole: 'boss' | 'employee';
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ language, currentPage, onPageChange, userRole, isCollapsed, onToggleCollapse }) => {
  const [allowedPages, setAllowedPages] = useState<string[]>([]);
  const isRTL = language === 'ar';

  // Get current user from localStorage
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Load employee page permissions
  useEffect(() => {
    const loadPagePermissions = async () => {
      if (userRole === 'boss') {
        // Boss has access to all pages
        setAllowedPages(['home', 'transactions', 'quotations-invoices', 'reports', 'clients', 'employees', 'permissions', 'suppliers', 'services', 'settings']);
        return;
      }

      // For employees, check their page permissions
      const currentUser = getCurrentUser();
      if (!currentUser || !currentUser.id) {
        setAllowedPages(['home', 'settings']); // Default minimal access
        return;
      }

      try {
        const result = await employeeDetailedPermissionService.getEmployeeDetailedPermissions(currentUser.id);
        if (result.success) {
          const allowed = result.data
            .filter(permission => permission.can_view)
            .map(permission => permission.page_name);
          setAllowedPages(allowed);
        } else {
          console.error('Error loading page permissions:', result.error);
          setAllowedPages(['home', 'settings']); // Default minimal access
        }
      } catch (error) {
        console.error('Error loading page permissions:', error);
        setAllowedPages(['home', 'settings']); // Default minimal access
      }
    };

    loadPagePermissions();
  }, [userRole]);

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      // Toggle sidebar with Ctrl/Cmd + B
      if ((event.ctrlKey || event.metaKey) && event.key === 'b') {
        event.preventDefault();
        onToggleCollapse();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onToggleCollapse]);

  const menuItems = [
    { id: 'home', icon: Home, label: { en: 'Home', ar: 'الرئيسية' } },
    { id: 'transactions', icon: CreditCard, label: { en: 'Transactions', ar: 'المعاملات' } },
    { id: 'quotations-invoices', icon: Receipt, label: { en: 'Quotations & Invoices', ar: 'عروض الأسعار والفواتير' } },
    { id: 'tasks-projects', icon: Calendar, label: { en: 'Tasks & Projects', ar: 'المهام والمشاريع' } },
    { id: 'reports', icon: FileText, label: { en: 'Financial Reports', ar: 'التقارير المالية' } },
    { id: 'clients', icon: Users, label: { en: 'Clients', ar: 'العملاء' } },
    ...(userRole === 'boss' ? [{ id: 'employees', icon: UserCheck, label: { en: 'Employees', ar: 'الموظفين' } }] : []),
    ...(userRole === 'boss' ? [{ id: 'permissions', icon: Shield, label: { en: 'Permissions', ar: 'الصلاحيات' } }] : []),
    { id: 'suppliers', icon: Truck, label: { en: 'Suppliers', ar: 'الموردين' } },
    { id: 'services', icon: Package, label: { en: 'Services', ar: 'الخدمات' } },
    { id: 'settings', icon: Settings, label: { en: 'Settings', ar: 'الإعدادات' } },
  ].filter(item => {
    // For boss, show all items
    if (userRole === 'boss') return true;
    
    // For employees, only show pages they have permission to access
    return allowedPages.includes(item.id);
  });

  return (
    <div className={`fixed ${isRTL ? 'right-0' : 'left-0'} top-0 h-full ${isCollapsed ? 'w-16' : 'w-64'} bg-white/90 backdrop-blur-sm shadow-xl z-40 border-${isRTL ? 'l' : 'r'} border-gray-200 transition-all duration-300 ease-in-out`}>
      {/* Header */}
      <div className="p-6 border-b border-gray-200 relative">
        {/* Toggle Button */}
        <button
          onClick={onToggleCollapse}
          className={`absolute ${isRTL ? 'left-2' : 'right-2'} top-1/2 transform -translate-y-1/2 p-2 rounded-lg bg-white hover:bg-gray-50 border border-gray-200 hover:border-gray-300 transition-all duration-200 z-10 group shadow-sm hover:shadow-md`}
          title={`${isCollapsed ? (language === 'en' ? 'Expand Sidebar' : 'توسيع الشريط الجانبي') : (language === 'en' ? 'Collapse Sidebar' : 'طي الشريط الجانبي')} (Ctrl+B)`}
        >
          {isCollapsed ? (
            isRTL ? <ChevronLeft className="w-4 h-4 text-gray-600 group-hover:text-blue-600 transition-colors" /> : <ChevronRight className="w-4 h-4 text-gray-600 group-hover:text-blue-600 transition-colors" />
          ) : (
            isRTL ? <ChevronRight className="w-4 h-4 text-gray-600 group-hover:text-blue-600 transition-colors" /> : <ChevronLeft className="w-4 h-4 text-gray-600 group-hover:text-blue-600 transition-colors" />
          )}
        </button>
        
        {/* Logo */}
        <div className={`transition-all duration-300 ease-in-out ${isCollapsed ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
          {!isCollapsed && (
            <div className="flex items-center justify-center">
              <img 
                src="/logo space zone123.png" 
                alt="Space Zone Logo" 
                className="h-20 w-auto max-w-full object-contain filter drop-shadow-lg hover:drop-shadow-xl transition-all duration-300 hover:scale-105"
                style={{ 
                  imageRendering: 'crisp-edges' as any,
                  WebkitImageRendering: '-webkit-optimize-contrast' as any
                }}
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  // Show fallback text
                  const fallback = document.createElement('div');
                  fallback.className = 'text-2xl font-bold text-blue-600';
                  fallback.textContent = language === 'en' ? 'Space Zone' : 'سبيس زون';
                  target.parentNode?.appendChild(fallback);
                }}
              />
            </div>
          )}
        </div>
        
        {/* Collapsed Logo */}
        {isCollapsed && (
          <div className="flex items-center justify-center">
            <img 
              src="/logo space zone123.png" 
              alt="Space Zone Logo" 
              className="h-12 w-12 object-contain rounded-lg filter drop-shadow-md hover:drop-shadow-lg transition-all duration-300 hover:scale-110"
              style={{ 
                imageRendering: 'crisp-edges' as any,
                WebkitImageRendering: '-webkit-optimize-contrast' as any
              }}
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
                // Show fallback text
                const fallback = document.createElement('div');
                fallback.className = 'w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-xl';
                fallback.textContent = 'SZ';
                target.parentNode?.appendChild(fallback);
              }}
            />
          </div>
        )}
      </div>

      {/* Menu Items */}
      <nav className="mt-6 px-4">
        <ul className={`space-y-2 ${isCollapsed ? 'px-0' : ''}`}>
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            
            return (
              <li key={item.id}>
                <button
                  onClick={() => onPageChange(item.id)}
                  className={`w-full flex items-center ${isCollapsed ? 'justify-center px-2 py-3' : 'gap-3 px-4 py-3'} rounded-xl transition-all duration-200 group relative ${
                    isActive
                      ? 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white shadow-lg'
                      : 'text-gray-600 hover:bg-gray-100 hover:text-gray-800'
                  } ${isRTL && !isCollapsed ? 'flex-row-reverse text-right' : 'text-left'}`}
                  title={isCollapsed ? item.label[language] : ''}
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-gray-500 group-hover:text-gray-700'} transition-colors duration-200 flex-shrink-0`} />
                  
                  {/* Label with smooth transition */}
                  <span className={`font-medium transition-all duration-300 ease-in-out ${
                    isCollapsed 
                      ? 'opacity-0 scale-95 w-0 overflow-hidden' 
                      : 'opacity-100 scale-100 w-auto'
                  }`}>
                    {!isCollapsed && item.label[language]}
                  </span>
                  
                  {/* Tooltip for collapsed state */}
                  {isCollapsed && (
                    <div className={`absolute ${isRTL ? 'right-full mr-3' : 'left-full ml-3'} top-1/2 transform -translate-y-1/2 bg-gray-900 text-white px-3 py-2 rounded-lg text-sm font-medium opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none whitespace-nowrap z-50 shadow-lg scale-95 group-hover:scale-100`}>
                      {item.label[language]}
                      {/* Tooltip Arrow */}
                      <div className={`absolute top-1/2 transform -translate-y-1/2 ${isRTL ? 'left-full border-l-4 border-l-gray-900' : 'right-full border-r-4 border-r-gray-900'} w-0 h-0 border-t-4 border-b-4 border-transparent`}></div>
                    </div>
                  )}
                </button>
              </li>
            );
          })}
        </ul>
        
        {/* Collapsed state indicator */}
        {isCollapsed && (
          <div className="mt-8 flex justify-center">
            <div className="w-8 h-0.5 bg-gradient-to-r from-transparent via-gray-300 to-transparent"></div>
          </div>
        )}
      </nav>

      {/* Mobile Overlay */}
      <div className="md:hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-30 opacity-0 pointer-events-none transition-opacity duration-300" />
    </div>
  );
};

export default Sidebar;