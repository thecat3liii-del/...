import React, { useEffect, useState } from 'react';
import { XIcon as Icon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: number;
  icon: Icon;
  color: string;
  currency?: boolean;
  language: 'en' | 'ar';
}

const StatCard: React.FC<StatCardProps> = ({ 
  title, 
  value, 
  icon: IconComponent, 
  color, 
  currency = false, 
  language 
}) => {
  const [displayValue, setDisplayValue] = useState(0);
  const isRTL = language === 'ar';

  useEffect(() => {
    const duration = 1500;
    const steps = 60;
    const increment = value / steps;
    let current = 0;
    
    const timer = setInterval(() => {
      current += increment;
      if (current >= value) {
        setDisplayValue(value);
        clearInterval(timer);
      } else {
        setDisplayValue(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [value]);

  const formatValue = (val: number) => {
    if (currency) {
      return `${val.toLocaleString()} ${language === 'en' ? 'BHD' : 'د.ب'}`;
    }
    return val.toLocaleString();
  };

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-white/50">
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
          <p className="text-gray-600 text-sm font-medium mb-2">{title}</p>
          <p className="text-2xl font-bold text-gray-800">
            {formatValue(displayValue)}
          </p>
        </div>
        <div className={`p-3 rounded-xl ${color}`}>
          <IconComponent className="w-6 h-6 text-white" />
        </div>
      </div>
    </div>
  );
};

export default StatCard;