import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Download, 
  Printer, 
  FileText, 
  Calendar,
  User,
  Mail,
  Phone,
  MapPin,
  Hash,
  DollarSign,
  Save,
  Plus,
  Trash2,
  Edit3,
  Package
} from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { serviceService } from '../lib/supabase';
import { numberingService } from '../lib/numberingService';
import { invoiceService } from '../lib/supabase';

interface Transaction {
  id: string;
  amount: number;
  cost: number;
  vat?: number;
  profit: number;
  clientId?: string;
  clientName?: string;
  supplierId?: string;
  supplierName?: string;
  serviceIds?: string[];
  serviceNames?: string[];
  date: string;
  paymentMethod?: string;
  status?: string;
  description?: string;
  priority?: string;
  month: number;
  year: number;
  category?: string;
  vatPercentage?: number;
  totalWithVat?: number;
}

interface Service {
  id: string;
  name: string;
  description?: string;
  price: number;
  category?: string;
  subcategory?: string;
  isActive: boolean;
}

interface InvoiceItem {
  id: string;
  name: string;
  category: string;
  subcategory?: string;
  price: number;
  quantity: number;
  total: number;
}

interface InvoiceModalProps {
  transaction: Transaction;
  language: 'en' | 'ar';
  onClose: () => void;
  onInvoiceCreated?: () => void;
}

const InvoiceModal: React.FC<InvoiceModalProps> = ({ transaction, language, onClose, onInvoiceCreated }) => {
  const [services, setServices] = useState<Service[]>([]);
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>([]);
  const [customLogo, setCustomLogo] = useState<string | null>(null);
  const [isLoadingNumber, setIsLoadingNumber] = useState(true);
  const [invoiceData, setInvoiceData] = useState({
    invoiceNumber: '',
    issueDate: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    clientName: transaction.clientName || '',
    clientEmail: '',
    clientPhone: '',
    clientAddress: '',
    notes: '',
    taxRate: transaction.vatPercentage || 0,
    discountRate: 0
  });

  const [isSaved, setIsSaved] = useState(false);
  const invoiceRef = useRef<HTMLDivElement>(null);
  const isRTL = language === 'ar';

  // Get current user from localStorage to access boss ID
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Generate unique database key for current boss
  const getBossDataKey = (dataType: string) => {
    const currentUser = getCurrentUser();
    if (!currentUser) return null;
    return `spaceZone_boss_${currentUser.id}_${dataType}`;
  };

  // Load services and initialize invoice items
  useEffect(() => {
    const loadInvoiceNumber = async () => {
      const currentUser = getCurrentUser();
      if (!currentUser) {
        setIsLoadingNumber(false);
        return;
      }

      try {
        // Use transaction-specific invoice number to ensure consistency
        const nextNumber = await numberingService.getTransactionInvoiceNumber(currentUser.id, transaction.id);
        setInvoiceData(prev => ({ ...prev, invoiceNumber: nextNumber }));
      } catch (error) {
        console.error('Error loading invoice number:', error);
        setInvoiceData(prev => ({ ...prev, invoiceNumber: 'INV-1000' }));
      }
      
      setIsLoadingNumber(false);
    };

    const saveInvoiceToDatabase = async () => {
      if (isSaved) return; // تجنب الحفظ المتكرر
      
      const currentUser = getCurrentUser();
      if (!currentUser) return;

      try {
        const invoiceDataToSave = {
          invoiceNumber: invoiceData.invoiceNumber,
          clientId: null,
          clientName: invoiceData.clientName,
          clientEmail: invoiceData.clientEmail,
          clientPhone: invoiceData.clientPhone,
          clientAddress: invoiceData.clientAddress,
          issueDate: invoiceData.issueDate,
          dueDate: invoiceData.dueDate,
          items: invoiceItems,
          subtotal: subtotal,
          taxRate: invoiceData.taxRate,
          taxAmount: taxAmount,
          discountRate: invoiceData.discountRate,
          discountAmount: discountAmount,
          totalAmount: grandTotal,
          notes: invoiceData.notes,
          status: 'draft'
        };
        
        const saveResult = await numberingService.saveInvoice(currentUser.id, invoiceDataToSave);
        if (saveResult.success) {
          setIsSaved(true);
        }
      } catch (error) {
        console.error('Error saving invoice to database:', error);
      }
    };

    const loadServices = () => {
      const loadData = async () => {
        const currentUser = getCurrentUser();
        if (!currentUser) return;
        
        const targetBossId = currentUser.id;
        try {
          const result = await serviceService.getServices(targetBossId);
          if (result.success) {
            // Convert Supabase data to local format
            const convertedServices = result.data.map((s: any) => ({
              id: s.id,
              name: s.name,
              description: s.description,
              price: s.price,
              category: s.category,
              subcategory: s.subcategory,
              isActive: s.is_active
            }));
            setServices(convertedServices);
          } else {
            console.error('Error loading services:', result.error);
            setServices([]);
          }
        } catch (error) {
          console.error('Error loading services:', error);
          setServices([]);
        }
      };
      
      loadData();
    };

    // Load custom logo
    const loadCustomLogo = () => {
      const logoKey = getBossDataKey('customLogo');
      if (!logoKey) return;
      
      const savedLogo = localStorage.getItem(logoKey);
      if (savedLogo) {
        try {
          const logoData = JSON.parse(savedLogo);
          setCustomLogo(logoData?.logoImage || null);
        } catch (error) {
          console.error('Error parsing logo:', error);
          setCustomLogo(null);
        }
      }
    };

    loadInvoiceNumber();
    loadServices();
    loadCustomLogo();
    
    // حفظ الفاتورة في قاعدة البيانات فور تحميل الرقم
    if (!isLoadingNumber && invoiceData.invoiceNumber && !isSaved) {
      saveInvoiceToDatabase();
    }


    // Listen for logo updates
    const handleLogoUpdate = (event: CustomEvent) => {
      setCustomLogo(event.detail);
    };

    window.addEventListener('logoUpdated', handleLogoUpdate as EventListener);

    return () => {
      window.removeEventListener('logoUpdated', handleLogoUpdate as EventListener);
    };
  }, [transaction]);

  // Initialize invoice items from transaction details - separate useEffect to ensure services are loaded
  useEffect(() => {
    if (services.length === 0) return; // Wait for services to load

    // Initialize invoice items from transaction services with complete details
    if (transaction.serviceIds && transaction.serviceIds.length > 0) {
      const initialItems = transaction.serviceIds.map((serviceId, index) => {
        const service = services.find((s: Service) => s.id === serviceId);
        const serviceName = service?.name || transaction.serviceNames?.[index] || '';
        const servicePrice = service?.price || 0;
        
        return {
          id: `item-${index}`,
          name: serviceName,
          category: service?.category || transaction.category || '',
          subcategory: service?.subcategory || '',
          price: servicePrice,
          quantity: 1,
          total: servicePrice,
          description: service?.description || transaction.description || ''
        };
      });
      setInvoiceItems(initialItems);
    } else {
      // Create item from transaction details
      const transactionItem = {
        id: 'item-0',
        name: transaction.description || 'Service/Product',
        category: transaction.category || '',
        subcategory: '',
        price: transaction.amount || 0,
        quantity: 1,
        total: transaction.amount || 0,
        description: transaction.description || ''
      };
      setInvoiceItems([transactionItem]);
    }
  }, [transaction, services]);
  // حفظ الفاتورة عند تغيير الرقم
  useEffect(() => {
    if (!isLoadingNumber && invoiceData.invoiceNumber && !isSaved) {
      const saveInvoiceToDatabase = async () => {
        const currentUser = getCurrentUser();
        if (!currentUser) return;

        try {
          const invoiceDataToSave = {
            invoiceNumber: invoiceData.invoiceNumber,
            clientId: null,
            clientName: invoiceData.clientName,
            clientEmail: invoiceData.clientEmail,
            clientPhone: invoiceData.clientPhone,
            clientAddress: invoiceData.clientAddress,
            issueDate: invoiceData.issueDate,
            dueDate: invoiceData.dueDate,
            items: invoiceItems,
            subtotal: subtotal,
            taxRate: invoiceData.taxRate,
            taxAmount: taxAmount,
            discountRate: invoiceData.discountRate,
            discountAmount: discountAmount,
            totalAmount: grandTotal,
            notes: invoiceData.notes,
            status: 'draft'
          };
          
          const saveResult = await numberingService.saveInvoice(currentUser.id, invoiceDataToSave);
          if (saveResult.success) {
            setIsSaved(true);
          }
        } catch (error) {
          console.error('Error saving invoice to database:', error);
        }
      };
      
      saveInvoiceToDatabase();
    }
  }, [invoiceData.invoiceNumber, isLoadingNumber, isSaved]);

  const translations = {
    en: {
      invoice: 'Invoice',
      invoiceNumber: 'Invoice Number',
      issueDate: 'Issue Date',
      dueDate: 'Due Date',
      billTo: 'Bill To',
      clientName: 'Client Name',
      clientEmail: 'Client Email',
      clientPhone: 'Client Phone',
      clientAddress: 'Client Address',
      description: 'Description',
      itemName: 'Item Name',
      category: 'Category',
      subcategory: 'Subcategory',
      price: 'Unit Price',
      quantity: 'Qty',
      total: 'Total',
      subtotal: 'Subtotal',
      tax: 'Tax',
      discount: 'Discount',
      grandTotal: 'Grand Total',
      notes: 'Notes',
      taxRate: 'Tax Rate (%)',
      discountRate: 'Discount Rate (%)',
      downloadPDF: 'Download PDF',
      print: 'Print',
      save: 'Save Invoice',
      close: 'Close',
      bhd: 'BHD',
      companyInfo: 'Space Zone Accounting',
      companyAddress: 'Business Management System',
      invoiceTerms: 'Payment is due within 30 days from the invoice date.',
      thankYou: 'Thank you for your business!',
      enterClientName: 'Enter client name',
      enterClientEmail: 'Enter client email',
      enterClientPhone: 'Enter client phone',
      enterClientAddress: 'Enter client address',
      enterNotes: 'Enter additional notes',
      invoiceGenerated: 'Invoice generated successfully',
      required: 'Required',
      addItem: 'Add Item',
      removeItem: 'Remove Item',
      editItem: 'Edit Item',
      enterItemName: 'Enter item name',
      enterCategory: 'Enter category',
      enterSubcategory: 'Enter subcategory',
      enterPrice: 'Enter unit price',
      items: 'Items',
      noItems: 'No items added',
      itemDetails: 'Item Details'
    },
    ar: {
      invoice: 'فاتورة',
      invoiceNumber: 'رقم الفاتورة',
      issueDate: 'تاريخ الإصدار',
      dueDate: 'تاريخ الاستحقاق',
      billTo: 'فاتورة إلى',
      clientName: 'اسم العميل',
      clientEmail: 'بريد العميل الإلكتروني',
      clientPhone: 'هاتف العميل',
      clientAddress: 'عنوان العميل',
      description: 'الوصف',
      itemName: 'اسم العنصر',
      category: 'الفئة',
      subcategory: 'الفئة الفرعية',
      price: 'سعر الوحدة',
      quantity: 'الكمية',
      total: 'الإجمالي',
      subtotal: 'المجموع الفرعي',
      tax: 'الضريبة',
      discount: 'الخصم',
      grandTotal: 'الإجمالي النهائي',
      notes: 'ملاحظات',
      taxRate: 'معدل الضريبة (%)',
      discountRate: 'معدل الخصم (%)',
      downloadPDF: 'تحميل PDF',
      print: 'طباعة',
      save: 'حفظ الفاتورة',
      close: 'إغلاق',
      bhd: 'د.ب',
      companyInfo: 'سبيس زون للمحاسبة',
      companyAddress: 'نظام إدارة الأعمال',
      invoiceTerms: 'الدفع مستحق خلال 30 يوماً من تاريخ الفاتورة.',
      thankYou: 'شكراً لك على تعاملك معنا!',
      enterClientName: 'أدخل اسم العميل',
      enterClientEmail: 'أدخل بريد العميل الإلكتروني',
      enterClientPhone: 'أدخل هاتف العميل',
      enterClientAddress: 'أدخل عنوان العميل',
      enterNotes: 'أدخل ملاحظات إضافية',
      invoiceGenerated: 'تم إنشاء الفاتورة بنجاح',
      required: 'مطلوب',
      addItem: 'إضافة عنصر',
      removeItem: 'إزالة العنصر',
      editItem: 'تعديل العنصر',
      enterItemName: 'أدخل اسم العنصر',
      enterCategory: 'أدخل الفئة',
      enterSubcategory: 'أدخل الفئة الفرعية',
      enterPrice: 'أدخل سعر الوحدة',
      items: 'العناصر',
      noItems: 'لم يتم إضافة عناصر',
      itemDetails: 'تفاصيل العنصر'
    }
  };

  const t = translations[language];

  // Calculate totals
  const subtotal = invoiceItems.reduce((sum, item) => sum + item.total, 0);
  const taxAmount = (subtotal * invoiceData.taxRate) / 100;
  const discountAmount = (subtotal * invoiceData.discountRate) / 100;
  const grandTotal = subtotal + taxAmount - discountAmount;

  const handleInputChange = (field: string, value: string | number) => {
    setInvoiceData(prev => ({ ...prev, [field]: value }));
  };

  // Add new item
  const addItem = () => {
    const newItem: InvoiceItem = {
      id: `item-${Date.now()}`,
      name: '',
      category: '',
      subcategory: '',
      price: 0,
      quantity: 1,
      total: 0
    };
    setInvoiceItems(prev => [...prev, newItem]);
  };

  // Remove item
  const removeItem = (itemId: string) => {
    setInvoiceItems(prev => prev.filter(item => item.id !== itemId));
  };

  // Update item
  const updateItem = (itemId: string, field: keyof InvoiceItem, value: string | number) => {
    setInvoiceItems(prev => prev.map(item => {
      if (item.id === itemId) {
        const updatedItem = { ...item, [field]: value };
        
        // Recalculate total when price or quantity changes
        if (field === 'price' || field === 'quantity') {
          updatedItem.total = updatedItem.price * updatedItem.quantity;
        }
        
        return updatedItem;
      }
      return item;
    }));
  };

  const handleDownloadPDF = async () => {
    if (!invoiceRef.current) return;

    try {
      const canvas = await html2canvas(invoiceRef.current, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#f5f1eb'
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
      const imgX = (pdfWidth - imgWidth * ratio) / 2;
      const imgY = 0;

      pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
      pdf.save(`${invoiceData.invoiceNumber}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
    }
  };

  const handlePrint = () => {
    if (!invoiceRef.current) return;
    
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>${t.invoice} - ${invoiceData.invoiceNumber}</title>
          <style>
            body { 
              font-family: 'Arial', sans-serif; 
              margin: 0; 
              padding: 20px; 
              background-color: #ffdba6;
            }
            .invoice-container { max-width: 800px; margin: 0 auto; }
            .no-print { display: none !important; }
            @media print {
              body { margin: 0; background-color: #ffdba6; }
              .invoice-container { max-width: none; }
            }
          </style>
        </head>
        <body>
          ${invoiceRef.current.innerHTML}
        </body>
      </html>
    `);
    
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
      
      // Notify parent component that invoice was created
      if (onInvoiceCreated) {
        onInvoiceCreated();
      }
    }, 250);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-6xl w-full max-h-[95vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className={`flex items-center justify-between p-6 border-b border-gray-200 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <div className="p-2 bg-blue-100 rounded-xl">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
            <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
              <h2 className="text-2xl font-bold text-gray-800">{t.invoice}</h2>
              <p className="text-gray-600 text-sm">#{invoiceData.invoiceNumber}</p>
            </div>
          </div>

          <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <button
              onClick={handleDownloadPDF}
              className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Download className="w-4 h-4" />
              {t.downloadPDF}
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Printer className="w-4 h-4" />
              {t.print}
            </button>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6">
          {/* Invoice Form */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Invoice Details */}
            <div className="space-y-4">
              <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                {language === 'en' ? 'Invoice Details' : 'تفاصيل الفاتورة'}
              </h3>
              
              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.invoiceNumber}
                </label>
                {isLoadingNumber ? (
                  <div className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-gray-500">Loading number...</span>
                  </div>
                ) : (
                  <input
                    type="text"
                    value={invoiceData.invoiceNumber}
                    readOnly
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 text-gray-700 cursor-not-allowed"
                  />
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.issueDate}
                  </label>
                  <input
                    type="date"
                    value={invoiceData.issueDate}
                    onChange={(e) => handleInputChange('issueDate', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.dueDate}
                  </label>
                  <input
                    type="date"
                    value={invoiceData.dueDate}
                    onChange={(e) => handleInputChange('dueDate', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.taxRate}
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={invoiceData.taxRate}
                    onChange={(e) => handleInputChange('taxRate', parseFloat(e.target.value) || 0)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.discountRate}
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={invoiceData.discountRate}
                    onChange={(e) => handleInputChange('discountRate', parseFloat(e.target.value) || 0)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            {/* Client Details */}
            <div className="space-y-4">
              <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.billTo}
              </h3>
              
              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.clientName} <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={invoiceData.clientName}
                  onChange={(e) => handleInputChange('clientName', e.target.value)}
                  placeholder={t.enterClientName}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.clientEmail}
                </label>
                <input
                  type="email"
                  value={invoiceData.clientEmail}
                  onChange={(e) => handleInputChange('clientEmail', e.target.value)}
                  placeholder={t.enterClientEmail}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.clientPhone}
                </label>
                <input
                  type="tel"
                  value={invoiceData.clientPhone}
                  onChange={(e) => handleInputChange('clientPhone', e.target.value)}
                  placeholder={t.enterClientPhone}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.clientAddress}
                </label>
                <textarea
                  value={invoiceData.clientAddress}
                  onChange={(e) => handleInputChange('clientAddress', e.target.value)}
                  placeholder={t.enterClientAddress}
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                />
              </div>
            </div>
          </div>

          {/* Items Section */}
          <div className="mb-8">
            <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.items}
              </h3>
              <button
                onClick={addItem}
                className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                <Plus className="w-4 h-4" />
                {t.addItem}
              </button>
            </div>

            <div className="space-y-4">
              {invoiceItems.map((item, index) => (
                <div key={item.id} className="bg-gray-50 rounded-2xl p-6 border border-gray-200">
                  <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <h4 className={`font-medium text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {language === 'en' ? `Item ${index + 1}` : `العنصر ${index + 1}`}
                    </h4>
                    {invoiceItems.length > 1 && (
                      <button
                        onClick={() => removeItem(item.id)}
                        className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                        title={t.removeItem}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                    {/* Service Selection */}
                    <div className="lg:col-span-5 mb-4">
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {language === 'en' ? 'Select Service/Product' : 'اختر الخدمة/المنتج'}
                      </label>
                      
                      {/* Structured Dropdown Flow */}
                      <div className="space-y-4">
                        {/* Step 1: Product/Service Selection */}
                        <div>
                          <label className={`block text-xs font-medium text-gray-600 mb-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                            {language === 'en' ? 'Step 1: Select Product/Service' : 'الخطوة 1: اختر المنتج/الخدمة'}
                          </label>
                          <select
                            value={item.serviceId || ''}
                            onChange={(e) => {
                              const serviceId = e.target.value;
                              updateItem(item.id, 'serviceId', serviceId);
                              
                              if (serviceId) {
                                const selectedService = services.find(s => s.id === serviceId);
                                if (selectedService) {
                                  updateItem(item.id, 'name', selectedService.name);
                                  updateItem(item.id, 'price', selectedService.price);
                                  updateItem(item.id, 'description', selectedService.description || '');
                                  // Don't auto-fill category and subcategory - let user choose
                                }
                              } else {
                                // Clear service-related data when custom is selected
                                updateItem(item.id, 'name', '');
                                updateItem(item.id, 'price', 0);
                                updateItem(item.id, 'description', '');
                              }
                            }}
                            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                          >
                            <option value="">{language === 'en' ? 'Custom Item' : 'عنصر مخصص'}</option>
                            {services.filter(s => s.isActive && s.availability_active !== false).map(service => (
                              <option key={service.id} value={service.id}>
                                {service.name} - {service.price} {t.bhd}
                              </option>
                            ))}
                          </select>
                        </div>

                        {/* Step 2: Category Selection */}
                        <div>
                          <label className={`block text-xs font-medium text-gray-600 mb-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                            {language === 'en' ? 'Step 2: Select Category' : 'الخطوة 2: اختر الفئة'}
                          </label>
                          <select
                            value={item.selectedCategory || ''}
                            onChange={(e) => {
                              const selectedCategory = e.target.value;
                              updateItem(item.id, 'selectedCategory', selectedCategory);
                              updateItem(item.id, 'category', selectedCategory);
                              // Clear subcategory when category changes
                              updateItem(item.id, 'selectedSubcategory', '');
                              updateItem(item.id, 'subcategory', '');
                            }}
                            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                          >
                            <option value="">{language === 'en' ? 'Select Category' : 'اختر الفئة'}</option>
                            {/* Get unique categories from services */}
                            {Array.from(new Set(
                              services
                                .filter(s => s.isActive && s.category)
                                .map(s => s.category)
                            )).map(category => (
                              <option key={category} value={category}>
                                {category}
                              </option>
                            ))}
                            <option value="custom">{language === 'en' ? 'Custom Category' : 'فئة مخصصة'}</option>
                          </select>
                        </div>

                        {/* Step 3: Subcategory Selection (only if category is selected) */}
                        {item.selectedCategory && (
                          <div>
                            <label className={`block text-xs font-medium text-gray-600 mb-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                              {language === 'en' ? 'Step 3: Select Subcategory' : 'الخطوة 3: اختر الفئة الفرعية'}
                            </label>
                            <select
                              value={item.selectedSubcategory || ''}
                              onChange={(e) => {
                                const selectedSubcategory = e.target.value;
                                updateItem(item.id, 'selectedSubcategory', selectedSubcategory);
                                updateItem(item.id, 'subcategory', selectedSubcategory);
                              }}
                              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                            >
                              <option value="">{language === 'en' ? 'Select Subcategory' : 'اختر الفئة الفرعية'}</option>
                              {/* Get unique subcategories for selected category */}
                              {Array.from(new Set(
                                services
                                  .filter(s => s.isActive && s.category === item.selectedCategory && s.subcategory)
                                  .map(s => s.subcategory)
                              )).map(subcategory => (
                                <option key={subcategory} value={subcategory}>
                                  {subcategory}
                                </option>
                              ))}
                              <option value="custom">{language === 'en' ? 'Custom Subcategory' : 'فئة فرعية مخصصة'}</option>
                            </select>
                          </div>
                        )}
                      </div>
                    </div>

                      {/* Item Name */}
                      <div className="lg:col-span-2">
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {t.itemName}
                      </label>
                      <input
                        type="text"
                        value={item.name}
                        onChange={(e) => updateItem(item.id, 'name', e.target.value)}
                        placeholder={t.enterItemName}
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                      />
                    </div>
                    
                    {/* Price */}
                    <div>
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {t.price}
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        value={item.price}
                        onChange={(e) => updateItem(item.id, 'price', parseFloat(e.target.value) || 0)}
                        placeholder={t.enterPrice}
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                      />
                    </div>

                    {/* Quantity */}
                    <div>
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {t.quantity}
                      </label>
                      <input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) => updateItem(item.id, 'quantity', parseInt(e.target.value) || 1)}
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                      />
                    </div>
                  </div>

                    {/* Subcategory - Full width below other inputs */}
                    <div className="mt-4">
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {t.subcategory} {item.selectedSubcategory === 'custom' ? `(${language === 'en' ? 'Custom' : 'مخصص'})` : ''}
                      </label>
                      <textarea
                        value={item.subcategory || ''}
                        onChange={(e) => updateItem(item.id, 'subcategory', e.target.value)}
                        placeholder={t.enterSubcategory}
                        disabled={item.selectedSubcategory && item.selectedSubcategory !== 'custom'}
                        rows={6}
                        className={`w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm resize-none ${
                          item.selectedSubcategory && item.selectedSubcategory !== 'custom' ? 'bg-gray-50 cursor-not-allowed' : ''
                        }`}
                      />
                    </div>

                    {/* Category - Changed to textarea */}
                    <div className="mt-4">
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {t.category} {item.selectedCategory === 'custom' ? `(${language === 'en' ? 'Custom' : 'مخصص'})` : ''}
                      </label>
                      <textarea
                        value={item.category}
                        onChange={(e) => updateItem(item.id, 'category', e.target.value)}
                        placeholder={t.enterCategory}
                        disabled={item.selectedCategory && item.selectedCategory !== 'custom'}
                        rows={3}
                        className={`w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm resize-none ${
                          item.selectedCategory && item.selectedCategory !== 'custom' ? 'bg-gray-50 cursor-not-allowed' : ''
                        }`}
                      />
                    </div>

                  {/* Transaction Details Display */}
                  <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <div className="text-xs text-blue-800 font-medium mb-2">
                      {language === 'en' ? 'Transaction Details:' : 'تفاصيل المعاملة:'}
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs text-blue-700">
                      {transaction.amount && (
                        <div>
                          <span className="font-medium">{language === 'en' ? 'Base Amount:' : 'المبلغ الأساسي:'}</span> {transaction.amount.toLocaleString()} BHD
                        </div>
                      )}
                      {transaction.vat && transaction.vat > 0 && (
                        <div>
                          <span className="font-medium">{language === 'en' ? 'VAT:' : 'ضريبة القيمة المضافة:'}</span> {transaction.vat.toLocaleString()} BHD ({transaction.vatPercentage || 0}%)
                        </div>
                      )}
                      {transaction.cost && (
                        <div>
                          <span className="font-medium">{language === 'en' ? 'Cost:' : 'التكلفة:'}</span> {transaction.cost.toLocaleString()} BHD
                        </div>
                      )}
                      {transaction.profit && (
                        <div>
                          <span className="font-medium">{language === 'en' ? 'Profit:' : 'الربح:'}</span> {transaction.profit.toLocaleString()} BHD
                        </div>
                      )}
                      {transaction.paymentMethod && (
                        <div>
                          <span className="font-medium">{language === 'en' ? 'Payment:' : 'طريقة الدفع:'}</span> {transaction.paymentMethod}
                        </div>
                      )}
                      {transaction.status && (
                        <div>
                          <span className="font-medium">{language === 'en' ? 'Status:' : 'الحالة:'}</span> {transaction.status}
                        </div>
                      )}
                    </div>
                  </div>
                  {/* Item Total */}
                  <div className={`mt-4 pt-4 border-t border-gray-200 ${isRTL ? 'text-left' : 'text-right'}`}>
                    <div className="text-sm text-gray-600">{t.total}:</div>
                    <div className="text-lg font-bold text-blue-600">
                      {item.total.toLocaleString()} {t.bhd}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div className="mb-8">
            <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
              {t.notes}
            </label>
            <textarea
              value={invoiceData.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              placeholder={t.enterNotes}
              rows={3}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            />
          </div>

          {/* Invoice Preview - نفس تصميم الكوتيشن بالضبط */}
          <div 
            ref={invoiceRef}
            className="relative w-full max-w-[210mm] mx-auto bg-[#f5f1eb] shadow-2xl"
            style={{ 
              fontFamily: 'Arial, sans-serif',
              aspectRatio: '210/297',
              minHeight: '297mm',
              width: '210mm',
              padding: '12mm',
              boxSizing: 'border-box'
            }}
          >
            {/* Background Decorative Elements - نفس التصميم */}
            <div className="absolute top-0 right-0 w-24 h-24 opacity-30">
              <svg viewBox="0 0 200 200" className="w-full h-full">
                <path
                  d="M20,20 Q50,10 80,20 T140,30 Q170,40 180,70 T170,130 Q160,160 130,170 T70,160 Q40,150 30,120 T40,60 Q50,30 80,20"
                  fill="none"
                  stroke="#ffe8cf"
                  strokeWidth="1.5"
                  opacity="0.6"
                />
                <path
                  d="M30,30 Q60,20 90,30 T150,40 Q180,50 190,80 T180,140 Q170,170 140,180 T80,170 Q50,160 40,130 T50,70 Q60,40 90,30"
                  fill="none"
                  stroke="#ffe8cf"
                  strokeWidth="1"
                  opacity="0.4"
                />
              </svg>
            </div>

            <div className="absolute bottom-0 left-0 w-20 h-20 opacity-25">
              <svg viewBox="0 0 150 150" className="w-full h-full">
                <path
                  d="M10,10 Q25,5 40,10 T70,15 Q85,20 90,35 T85,65 Q80,80 65,85 T35,80 Q20,75 15,60 T20,30 Q25,15 40,10"
                  fill="none"
                  stroke="#d97706"
                  strokeWidth="1.2"
                  opacity="0.5"
                />
              </svg>
            </div>

            {/* Logo - نفس التصميم */}
            <div className="absolute top-4 left-4">
              {customLogo ? (
                <div className="w-16 h-16 rounded-xl overflow-hidden border-2 border-gray-200 bg-white flex items-center justify-center shadow-lg">
                  <img
                    src={customLogo}
                    alt="Custom Logo"
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
              ) : (
                <div className="w-16 h-16 bg-black rounded-full flex items-center justify-center relative">
                  <div className="absolute inset-0 border-2 border-yellow-400 rounded-full animate-pulse opacity-60"></div>
                  <div className="absolute inset-1 border border-yellow-300 rounded-full opacity-40"></div>
                  <div className="text-center">
                    <div className="text-yellow-400 font-bold text-[10px] leading-tight">SPACE</div>
                    <div className="text-white font-bold text-[10px] leading-tight">ZONE</div>
                  </div>
                </div>
              )}
            </div>

            {/* Title - تغيير من QUOTATION إلى INVOICE */}
            <div className="text-center mt-6 mb-8">
              <h1 
                className="text-3xl font-light tracking-[0.3em] text-gray-700"
                style={{ 
                  fontFamily: 'Arial, sans-serif',
                  letterSpacing: '0.3em',
                  fontWeight: '300'
                }}
              >
                INVOICE
              </h1>
            </div>

            {/* Bill To and Details Section - نفس التصميم */}
            <div className="flex justify-between items-start mb-8">
              <div>
                <div 
                  className="text-gray-500 text-xs font-light tracking-wider mb-3"
                  style={{ letterSpacing: '0.1em' }}
                >
                  BILL TO:
                </div>
                <div className="text-gray-800 space-y-1">
                  <div className="font-medium text-base">{invoiceData.clientName || 'Client Name'}</div>
                  {invoiceData.clientEmail && <div className="text-xs">{invoiceData.clientEmail}</div>}
                  {invoiceData.clientPhone && <div className="text-xs">{invoiceData.clientPhone}</div>}
                  {invoiceData.clientAddress && <div className="text-xs">{invoiceData.clientAddress}</div>}
                </div>
              </div>

              <div className="text-center space-y-1">
                <div>
                  <div className="text-gray-500 text-xs font-light tracking-wider">NO.</div>
                  <div className="text-gray-800 font-medium text-sm">{invoiceData.invoiceNumber}</div>
                </div>
                <div>
                  <div className="text-gray-500 text-xs font-light tracking-wider">DATE.</div>
                  <div className="text-gray-800 font-medium text-sm">
                    {new Date(invoiceData.issueDate).toLocaleDateString('en-US')}
                  </div>
                </div>
              </div>
            </div>

            {/* Table - نفس التصميم بالضبط */}
            <div className="mb-8">
              {/* Table Header */}
              <div className="grid grid-cols-12 gap-1 border-b border-gray-300 pb-2 mb-4">
                <div 
                  className="col-span-1 text-gray-600 text-xs font-light tracking-wider text-center"
                  style={{ letterSpacing: '0.1em' }}
                >
                  S.N
                </div>
                <div 
                  className="col-span-5 text-gray-600 text-xs font-light tracking-wider text-center"
                  style={{ letterSpacing: '0.1em' }}
                >
                  DESCRIPTION
                </div>
                <div 
                  className="col-span-2 text-gray-600 text-xs font-light tracking-wider text-center"
                  style={{ letterSpacing: '0.1em' }}
                >
                  QTY
                </div>
                <div 
                  className="col-span-4 text-gray-600 text-xs font-light tracking-wider text-center"
                  style={{ letterSpacing: '0.1em' }}
                >
                  TOTAL
                </div>
              </div>

              {/* Table Content */}
              <div className="space-y-2 min-h-[200px]">
                {invoiceItems.map((item, index) => (
                  <div key={item.id} className="grid grid-cols-12 gap-1 py-2 border-b border-gray-100">
                    <div className="col-span-1 text-gray-800 text-xs text-center">{index + 1}</div>
                    <div className="col-span-5 text-gray-800 text-xs text-left pl-20">
                      <div className="font-medium">{item.name || 'Item Name'}</div>
                      {item.category && (
                        <div className="text-xs text-gray-600 mt-1 whitespace-pre-wrap text-left">
                          {item.category}
                          {item.subcategory && (
                            <div className="mt-1">
                              <div className="whitespace-pre-wrap">{item.subcategory}</div>
                            </div>
                          )}
                        </div>
                      )}
                      {item.description && (
                        <div className="text-xs text-gray-600 mt-1 italic text-left">
                          {item.description}
                        </div>
                      )}
                    </div>
                    <div className="col-span-2 text-gray-800 text-xs text-center">{item.quantity}</div>
                    <div className="col-span-4 text-gray-800 text-xs text-center font-medium">
                      {item.total.toLocaleString()} BHD
                      {/* Show total with VAT if applicable */}
                      {transaction.total && transaction.total !== item.total && (
                        <div className="text-[9px] text-green-600 mt-1">
                          (With VAT: {transaction.totalWithVat.toLocaleString()} BHD)
                        </div>
                      )}
                    </div>
                  </div>
                ))}

                {/* Tax Row if applicable */}
                {invoiceData.taxRate > 0 && (
                  <div className="grid grid-cols-12 gap-1 py-1">
                    <div className="col-span-8"></div>
                    <div className="col-span-4 text-gray-600 text-xs text-center">
                      <div className="font-light tracking-wider text-[10px]" style={{ letterSpacing: '0.1em' }}>
                        TAX ({invoiceData.taxRate}%)
                      </div>
                      <div className="font-medium text-gray-800 text-xs">{taxAmount.toLocaleString()} BHD</div>
                    </div>
                  </div>
                )}

                {/* Discount Row if applicable */}
                {invoiceData.discountRate > 0 && (
                  <div className="grid grid-cols-12 gap-1 py-1">
                    <div className="col-span-8"></div>
                    <div className="col-span-4 text-red-600 text-xs text-center">
                      <div className="font-light tracking-wider text-[10px]" style={{ letterSpacing: '0.1em' }}>
                        DISCOUNT ({invoiceData.discountRate}%)
                      </div>
                      <div className="font-medium text-xs">-{discountAmount.toLocaleString()} BHD</div>
                    </div>
                  </div>
                )}

                {/* Grand Total Row */}
                <div className="grid grid-cols-12 gap-1 py-3 border-t-2 border-gray-400">
                  <div className="col-span-8"></div>
                  <div className="col-span-4 text-gray-800 text-base text-center">
                    <div className="font-light tracking-wider text-xs mb-1" style={{ letterSpacing: '0.1em' }}>
                      TOTAL
                    </div>
                    <div className="font-bold text-lg">{((transaction.amount || 0) + (transaction.vat || 0)).toLocaleString()} BHD</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Notes Section */}
            {invoiceData.notes && (
              <div className="mb-8">
                <div className="text-gray-600 text-xs font-light tracking-wider mb-2">NOTES:</div>
                <div className="text-gray-800 text-xs whitespace-pre-wrap">{invoiceData.notes}</div>
              </div>
            )}

            {/* Footer Section - نفس التصميم بالضبط */}
            <div className="absolute bottom-4 left-4 right-4">
              {/* Contact Section */}
              <div className="text-center mb-4">
                <div 
                  className="text-gray-700 text-xs font-light tracking-wider mb-1"
                  style={{ letterSpacing: '0.15em' }}
                >
                  CONTACT US FOR MORE DETAIL
                </div>
                <div className="text-gray-600 text-xs">
                  Contact NO: 00973-37155515<br />
                  Call and WhatsApp
                </div>
              </div>

              {/* Thank You Section */}
              <div className="text-center">
                <div className="text-sm">
                  <span className="text-black font-medium">Thank You For </span>
                  <span className="text-yellow-600 font-medium">Your Business </span>
                  <span className="text-black font-bold">SPACE ZONE</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoiceModal;