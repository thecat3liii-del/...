import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  Download, 
  Edit3, 
  Trash2, 
  Package,
  Tag,
  DollarSign,
  Calendar,
  Eye,
  X,
  Save,
  AlertCircle,
  CheckCircle,
  Hash,
  Layers,
  Grid,
  List,
  Star,
  Clock,
  TrendingUp,
  Archive
} from 'lucide-react';
import { serviceService, serviceCategoryService } from '../lib/supabase';
import type { Service, ServiceCategory } from '../lib/supabase';

interface ServicesPageProps {
  language: 'en' | 'ar';
  bossId?: string;
  userPermissions?: {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
  };
}

const ServicesPage: React.FC<ServicesPageProps> = ({ language, bossId, userPermissions }) => {
  const [services, setServices] = useState<Service[]>([]);
  const [categories, setCategories] = useState<ServiceCategory[]>([]);
  const [filteredServices, setFilteredServices] = useState<Service[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [sortBy, setSortBy] = useState<'name' | 'price' | 'category' | 'created_at'>('created_at');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [viewingService, setViewingService] = useState<Service | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const isRTL = language === 'ar';

  // Get current user from localStorage to access boss ID
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Form state for adding/editing services
  const [serviceForm, setServiceForm] = useState({
    name: '',
    categories: [] as string[],
    subcategories: [] as string[],
    price: 0,
    vat: 0,
    description: '',
    storageDuration: '',
    imageMedia: '',
    expirationValidity: ''
  });

  // Available categories and subcategories for dropdowns
  const [availableCategories, setAvailableCategories] = useState<string[]>([]);
  const [availableSubcategories, setAvailableSubcategories] = useState<string[]>([]);
  const [newCategoryInput, setNewCategoryInput] = useState('');
  const [newSubcategoryInput, setNewSubcategoryInput] = useState('');

  const translations = {
    en: {
      title: 'Services & Products',
      subtitle: 'Manage your services and products catalog',
      addService: 'Add Service/Product',
      searchPlaceholder: 'Search services and products...',
      filterAll: 'All Services',
      filterActive: 'Active',
      filterInactive: 'Inactive',
      sortByName: 'Name',
      sortByPrice: 'Price',
      sortByCategory: 'Category',
      sortByDate: 'Date Added',
      name: 'Service/Product Name',
      categories: 'Categories',
      subcategories: 'Subcategories',
      price: 'Price',
      vat: 'VAT/Tax',
      description: 'Description',
      storageDuration: 'Storage Duration',
      imageMedia: 'Image/Media URL',
      expirationValidity: 'Expiration Date',
      dateAdded: 'Date Added',
      status: 'Status',
      actions: 'Actions',
      active: 'Active',
      inactive: 'Inactive',
      edit: 'Edit',
      delete: 'Delete',
      view: 'View',
      save: 'Save',
      cancel: 'Cancel',
      close: 'Close',
      addNewService: 'Add New Service/Product',
      editService: 'Edit Service/Product',
      serviceDetails: 'Service/Product Details',
      enterName: 'Enter service/product name',
      enterPrice: 'Enter price',
      enterVat: 'Enter VAT/tax percentage',
      enterDescription: 'Enter description',
      enterStorageDuration: 'Enter storage duration',
      enterImageUrl: 'Enter image/media URL',
      selectExpirationDate: 'Select expiration date',
      confirmDelete: 'Are you sure you want to delete this service/product?',
      deleteService: 'Delete Service/Product',
      serviceAdded: 'Service/product added successfully',
      serviceUpdated: 'Service/product updated successfully',
      serviceDeleted: 'Service/product deleted successfully',
      fillRequired: 'Please fill all required fields',
      serviceExists: 'Service/product with this name already exists',
      noServices: 'No services/products found',
      noServicesDesc: 'Start by adding your first service or product',
      totalServices: 'Total Services',
      activeServices: 'Active Services',
      newThisMonth: 'New This Month',
      export: 'Export',
      print: 'Print',
      refresh: 'Refresh',
      required: 'Required',
      optional: 'Optional',
      basicInfo: 'Basic Information',
      categoryInfo: 'Category Information',
      pricingInfo: 'Pricing Information',
      additionalInfo: 'Additional Information',
      addCategory: 'Add Category',
      addSubcategory: 'Add Subcategory',
      removeCategory: 'Remove Category',
      removeSubcategory: 'Remove Subcategory',
      newCategory: 'New Category',
      newSubcategory: 'New Subcategory',
      enterNewCategory: 'Enter new category',
      enterNewSubcategory: 'Enter new subcategory',
      loadingServices: 'Loading services...',
      errorLoading: 'Error loading services',
      bhd: 'BHD',
      variations: 'Variations',
      variationsGenerated: 'variations will be generated automatically',
      autoGenerate: 'Auto-generate variations',
      generatingVariations: 'Generating service variations...',
      variationsCreated: 'Service variations created successfully'
    },
    ar: {
      title: 'الخدمات والمنتجات',
      subtitle: 'إدارة كتالوج الخدمات والمنتجات',
      addService: 'إضافة خدمة/منتج',
      searchPlaceholder: 'البحث في الخدمات والمنتجات...',
      filterAll: 'جميع الخدمات',
      filterActive: 'نشط',
      filterInactive: 'غير نشط',
      sortByName: 'الاسم',
      sortByPrice: 'السعر',
      sortByCategory: 'الفئة',
      sortByDate: 'تاريخ الإضافة',
      name: 'اسم الخدمة/المنتج',
      categories: 'الفئات',
      subcategories: 'الفئات الفرعية',
      price: 'السعر',
      vat: 'ضريبة القيمة المضافة',
      description: 'الوصف',
      storageDuration: 'مدة التخزين',
      imageMedia: 'رابط الصورة/الوسائط',
      expirationValidity: 'تاريخ انتهاء الصلاحية',
      dateAdded: 'تاريخ الإضافة',
      status: 'الحالة',
      actions: 'الإجراءات',
      active: 'نشط',
      inactive: 'غير نشط',
      edit: 'تعديل',
      delete: 'حذف',
      view: 'عرض',
      save: 'حفظ',
      cancel: 'إلغاء',
      close: 'إغلاق',
      addNewService: 'إضافة خدمة/منتج جديد',
      editService: 'تعديل الخدمة/المنتج',
      serviceDetails: 'تفاصيل الخدمة/المنتج',
      enterName: 'أدخل اسم الخدمة/المنتج',
      enterPrice: 'أدخل السعر',
      enterVat: 'أدخل نسبة ضريبة القيمة المضافة',
      enterDescription: 'أدخل الوصف',
      enterStorageDuration: 'أدخل مدة التخزين',
      enterImageUrl: 'أدخل رابط الصورة/الوسائط',
      selectExpirationDate: 'اختر تاريخ انتهاء الصلاحية',
      confirmDelete: 'هل أنت متأكد من حذف هذه الخدمة/المنتج؟',
      deleteService: 'حذف الخدمة/المنتج',
      serviceAdded: 'تم إضافة الخدمة/المنتج بنجاح',
      serviceUpdated: 'تم تحديث الخدمة/المنتج بنجاح',
      serviceDeleted: 'تم حذف الخدمة/المنتج بنجاح',
      fillRequired: 'يرجى ملء جميع الحقول المطلوبة',
      serviceExists: 'خدمة/منتج بهذا الاسم موجود بالفعل',
      noServices: 'لا توجد خدمات/منتجات',
      noServicesDesc: 'ابدأ بإضافة خدمتك أو منتجك الأول',
      totalServices: 'إجمالي الخدمات',
      activeServices: 'الخدمات النشطة',
      newThisMonth: 'جديد هذا الشهر',
      export: 'تصدير',
      print: 'طباعة',
      refresh: 'تحديث',
      required: 'مطلوب',
      optional: 'اختياري',
      basicInfo: 'المعلومات الأساسية',
      categoryInfo: 'معلومات الفئة',
      pricingInfo: 'معلومات التسعير',
      additionalInfo: 'معلومات إضافية',
      addCategory: 'إضافة فئة',
      addSubcategory: 'إضافة فئة فرعية',
      removeCategory: 'إزالة الفئة',
      removeSubcategory: 'إزالة الفئة الفرعية',
      newCategory: 'فئة جديدة',
      newSubcategory: 'فئة فرعية جديدة',
      enterNewCategory: 'أدخل فئة جديدة',
      enterNewSubcategory: 'أدخل فئة فرعية جديدة',
      loadingServices: 'جاري تحميل الخدمات...',
      errorLoading: 'خطأ في تحميل الخدمات',
      bhd: 'د.ب',
      variations: 'التنويعات',
      variationsGenerated: 'سيتم إنشاء التنويعات تلقائياً',
      autoGenerate: 'إنشاء التنويعات تلقائياً',
      generatingVariations: 'جاري إنشاء تنويعات الخدمة...',
      variationsCreated: 'تم إنشاء تنويعات الخدمة بنجاح'
    }
  };

  const t = translations[language];

  // Default permissions for boss or if not provided
  const permissions = userPermissions || { view: true, add: true, edit: true, delete: true };

  // Load services and categories from Supabase
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      const currentUser = getCurrentUser();
      
      if (!currentUser) {
        setIsLoading(false);
        return;
      }

      const targetBossId = bossId || currentUser.id;

      try {
        // Load services
        const servicesResult = await serviceService.getServices(targetBossId);
        if (servicesResult.success) {
          setServices(servicesResult.data);
          setFilteredServices(servicesResult.data);
        } else {
          setError(servicesResult.error || t.errorLoading);
        }

        // Load categories
        const categoriesResult = await serviceCategoryService.getServiceCategories(targetBossId);
        if (categoriesResult.success) {
          setCategories(categoriesResult.data);
          
          // Extract unique categories and subcategories for dropdowns
          const allCategories = new Set<string>();
          const allSubcategories = new Set<string>();
          
          categoriesResult.data.forEach(cat => {
            allCategories.add(cat.name);
            cat.subcategories.forEach(sub => allSubcategories.add(sub));
          });
          
          setAvailableCategories(Array.from(allCategories));
          setAvailableSubcategories(Array.from(allSubcategories));
        }
      } catch (error) {
        console.error('Error loading data:', error);
        setError(t.errorLoading);
      }
      
      setIsLoading(false);
    };

    loadData();
  }, [bossId]);

  // Filter and sort services
  useEffect(() => {
    let filtered = [...services];

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(service =>
        service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        service.category?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        service.subcategory?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        service.description?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply category filter
    if (filterCategory !== 'all') {
      filtered = filtered.filter(service => service.category === filterCategory);
    }

    // Apply status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(service => 
        filterStatus === 'active' ? service.is_active : !service.is_active
      );
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'name':
          comparison = a.name.localeCompare(b.name);
          break;
        case 'price':
          comparison = (a.price || 0) - (b.price || 0);
          break;
        case 'category':
          comparison = (a.category || '').localeCompare(b.category || '');
          break;
        case 'created_at':
          comparison = new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
          break;
      }

      return sortOrder === 'asc' ? comparison : -comparison;
    });

    setFilteredServices(filtered);
  }, [services, searchTerm, filterCategory, filterStatus, sortBy, sortOrder]);

  // Add new category to available list
  const addNewCategory = () => {
    if (newCategoryInput.trim() && !availableCategories.includes(newCategoryInput.trim())) {
      setAvailableCategories(prev => [...prev, newCategoryInput.trim()]);
      setNewCategoryInput('');
    }
  };

  // Add new subcategory to available list
  const addNewSubcategory = () => {
    if (newSubcategoryInput.trim() && !availableSubcategories.includes(newSubcategoryInput.trim())) {
      setAvailableSubcategories(prev => [...prev, newSubcategoryInput.trim()]);
      setNewSubcategoryInput('');
    }
  };

  // Add category to service form
  const addCategoryToForm = (category: string) => {
    if (!serviceForm.categories.includes(category)) {
      setServiceForm(prev => ({
        ...prev,
        categories: [...prev.categories, category]
      }));
    }
  };

  // Remove category from service form
  const removeCategoryFromForm = (category: string) => {
    setServiceForm(prev => ({
      ...prev,
      categories: prev.categories.filter(c => c !== category)
    }));
  };

  // Add subcategory to service form
  const addSubcategoryToForm = (subcategory: string) => {
    if (!serviceForm.subcategories.includes(subcategory)) {
      setServiceForm(prev => ({
        ...prev,
        subcategories: [...prev.subcategories, subcategory]
      }));
    }
  };

  // Remove subcategory from service form
  const removeSubcategoryFromForm = (subcategory: string) => {
    setServiceForm(prev => ({
      ...prev,
      subcategories: prev.subcategories.filter(s => s !== subcategory)
    }));
  };

  // Generate all possible service variations
  const generateServiceVariations = (baseService: any) => {
    const variations = [];
    const { name, categories, subcategories, price, vat, description, storageDuration, imageMedia, expirationValidity } = baseService;

    if (categories.length === 0) {
      // If no categories, create one service with empty category
      variations.push({
        name,
        category: '',
        subcategory: '',
        price: price || 0,
        vat: vat || 0,
        description: description || '',
        storage_duration: storageDuration || '',
        image_media: imageMedia || '',
        expiration_validity: expirationValidity || null,
        is_active: true
      });
    } else {
      // Generate variations for each category
      categories.forEach(category => {
        if (subcategories.length === 0) {
          // Category without subcategories
          variations.push({
            name,
            category,
            subcategory: '',
            price: price || 0,
            vat: vat || 0,
            description: description || '',
            storage_duration: storageDuration || '',
            image_media: imageMedia || '',
            expiration_validity: expirationValidity || null,
            is_active: true
          });
        } else {
          // Category with subcategories
          subcategories.forEach(subcategory => {
            variations.push({
              name,
              category,
              subcategory,
              price: price || 0,
              vat: vat || 0,
              description: description || '',
              storage_duration: storageDuration || '',
              image_media: imageMedia || '',
              expiration_validity: expirationValidity || null,
              is_active: true
            });
          });
        }
      });
    }

    return variations;
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!serviceForm.name.trim() || serviceForm.categories.length === 0) {
      setError(t.fillRequired);
      return;
    }

    const currentUser = getCurrentUser();
    if (!currentUser) {
      setError('User not found');
      return;
    }

    const targetBossId = bossId || currentUser.id;

    setIsLoading(true);
    setError('');

    try {
      if (editingService) {
        // Update existing service
        const updateData = {
          name: serviceForm.name,
          category: serviceForm.categories.join(', '),
          subcategory: serviceForm.subcategories.join(', '),
          price: serviceForm.price || 0,
          vat: serviceForm.vat || 0,
          description: serviceForm.description || '',
          storage_duration: serviceForm.storageDuration || '',
          image_media: serviceForm.imageMedia || '',
          expiration_validity: serviceForm.expirationValidity || null
        };

        const result = await serviceService.updateService(editingService.id, updateData);

        if (result.success) {
          // Update local state
          const updatedServices = services.map(service => 
            service.id === editingService.id ? result.data : service
          );
          setServices(updatedServices);
          setSuccess(t.serviceUpdated);
          setEditingService(null);
        } else {
          setError(result.error || 'Failed to update service');
        }
      } else {
        // Generate and create all service variations
        const variations = generateServiceVariations(serviceForm);
        
        setSuccess(`${t.generatingVariations} (${variations.length} ${t.variations})`);
        
        let successCount = 0;
        let errorCount = 0;

        // Create each variation
        for (const variation of variations) {
          try {
            const result = await serviceService.addService(targetBossId, variation);
            if (result.success) {
              successCount++;
              // Add to local state
              setServices(prev => [...prev, result.data]);
            } else {
              errorCount++;
              console.error('Error creating variation:', result.error);
            }
          } catch (error) {
            errorCount++;
            console.error('Error creating variation:', error);
          }
        }

        if (successCount > 0) {
          setSuccess(`${t.variationsCreated} (${successCount}/${variations.length})`);
          
          // Update categories in database
          for (const category of serviceForm.categories) {
            if (!availableCategories.includes(category)) {
              await serviceCategoryService.addServiceCategory(targetBossId, {
                name: category,
                subcategories: serviceForm.subcategories
              });
            }
          }
          
          // Refresh available categories and subcategories
          setAvailableCategories(prev => [...new Set([...prev, ...serviceForm.categories])]);
          setAvailableSubcategories(prev => [...new Set([...prev, ...serviceForm.subcategories])]);
        }

        if (errorCount > 0) {
          setError(`${errorCount} variations failed to create`);
        }
      }

      setIsLoading(false);
      setShowAddModal(false);
      resetForm();

      setTimeout(() => {
        setSuccess('');
        setError('');
      }, 3000);
    } catch (error) {
      console.error('Error saving service:', error);
      setError('Failed to save service. Please try again.');
      setIsLoading(false);
    }
  };

  // Reset form
  const resetForm = () => {
    setServiceForm({
      name: '',
      categories: [],
      subcategories: [],
      price: 0,
      vat: 0,
      description: '',
      storageDuration: '',
      imageMedia: '',
      expirationValidity: ''
    });
    setError('');
  };

  // Handle edit
  const handleEdit = (service: Service) => {
    setEditingService(service);
    setServiceForm({
      name: service.name,
      categories: service.category ? service.category.split(', ') : [],
      subcategories: service.subcategory ? service.subcategory.split(', ') : [],
      price: service.price || 0,
      vat: service.vat || 0,
      description: service.description || '',
      storageDuration: service.storage_duration || '',
      imageMedia: service.image_media || '',
      expirationValidity: service.expiration_validity || ''
    });
    setShowAddModal(true);
  };

  // Handle delete
  const handleDelete = async (serviceId: string) => {
    if (window.confirm(t.confirmDelete)) {
      setIsLoading(true);
      
      try {
        const result = await serviceService.deleteService(serviceId);
        
        if (result.success) {
          const updatedServices = services.filter(service => service.id !== serviceId);
          setServices(updatedServices);
          setSuccess(t.serviceDeleted);
        } else {
          setError(result.error || 'Failed to delete service');
        }
      } catch (error) {
        console.error('Error deleting service:', error);
        setError('Failed to delete service. Please try again.');
      }
      
      setIsLoading(false);
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  // Toggle service status
  const toggleServiceStatus = async (serviceId: string) => {
    try {
      const result = await serviceService.toggleServiceStatus(serviceId);
      
      if (result.success) {
        const updatedServices = services.map(service => 
          service.id === serviceId ? result.data : service
        );
        setServices(updatedServices);
      } else {
        setError(result.error || 'Failed to update service status');
        setTimeout(() => setError(''), 3000);
      }
    } catch (error) {
      console.error('Error updating service status:', error);
      setError('Failed to update service status');
      setTimeout(() => setError(''), 3000);
    }
  };

  // Calculate summary statistics
  const totalServices = services.length;
  const activeServices = services.filter(s => s.is_active).length;
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const newThisMonth = services.filter(service => {
    const serviceDate = new Date(service.created_at);
    return serviceDate.getMonth() === currentMonth && serviceDate.getFullYear() === currentYear;
  }).length;

  if (isLoading && services.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">{t.loadingServices}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{t.title}</h1>
          <p className="text-gray-600">{t.subtitle}</p>
        </div>

        {permissions.add && (
          <button
            onClick={() => {
              resetForm();
              setEditingService(null);
              setShowAddModal(true);
            }}
            className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            <Plus className="w-5 h-5" />
            {t.addService}
          </button>
        )}
      </div>

      {/* Success/Error Messages */}
      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-indigo-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Package className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-blue-100 text-sm">{t.totalServices}</div>
              <div className="text-2xl font-bold">{totalServices}</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CheckCircle className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-green-100 text-sm">{t.activeServices}</div>
              <div className="text-2xl font-bold">{activeServices}</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Calendar className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-purple-100 text-sm">{t.newThisMonth}</div>
              <div className="text-2xl font-bold">{newThisMonth}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-lg">
        <div className={`flex flex-col md:flex-row gap-4 ${isRTL ? 'md:flex-row-reverse' : ''}`}>
          {/* Search */}
          <div className="flex-1 relative">
            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5`} />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t.searchPlaceholder}
              className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200`}
            />
          </div>

          {/* Category Filter */}
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            <option value="all">{t.filterAll}</option>
            {availableCategories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as 'all' | 'active' | 'inactive')}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            <option value="all">{t.filterAll}</option>
            <option value="active">{t.filterActive}</option>
            <option value="inactive">{t.filterInactive}</option>
          </select>

          {/* Sort By */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'name' | 'price' | 'category' | 'created_at')}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            <option value="name">{t.sortByName}</option>
            <option value="price">{t.sortByPrice}</option>
            <option value="category">{t.sortByCategory}</option>
            <option value="created_at">{t.sortByDate}</option>
          </select>

          {/* Sort Order */}
          <button
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            className="px-4 py-3 bg-gray-100 hover:bg-gray-200 rounded-2xl transition-all duration-200 flex items-center gap-2"
          >
            {sortOrder === 'asc' ? '↑' : '↓'}
          </button>
        </div>
      </div>

      {/* Services Table */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-lg overflow-hidden">
        {filteredServices.length === 0 ? (
          <div className="text-center py-16">
            <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">{t.noServices}</h3>
            <p className="text-gray-500 mb-6">{t.noServicesDesc}</p>
            {permissions.add && (
              <button
                onClick={() => {
                  resetForm();
                  setEditingService(null);
                  setShowAddModal(true);
                }}
                className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl mx-auto"
              >
                <Plus className="w-5 h-5" />
                {t.addService}
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.name}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.categories}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.subcategories}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.price}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.status}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.actions}
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredServices.map((service, index) => (
                  <tr
                    key={service.id}
                    className={`border-b border-gray-100 hover:bg-gray-50 transition-colors animate-fadeIn`}
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <td className={`py-4 px-6 font-medium text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-semibold">
                          {service.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-medium">{service.name}</div>
                          {service.description && (
                            <div className="text-sm text-gray-500 truncate max-w-xs">
                              {service.description}
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {service.category ? (
                        <div className="flex flex-wrap gap-1">
                          {service.category.split(', ').map((cat, idx) => (
                            <span key={idx} className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              <Tag className="w-3 h-3 mr-1" />
                              {cat}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {service.subcategory ? (
                        <div className="flex flex-wrap gap-1">
                          {service.subcategory.split(', ').map((subcat, idx) => (
                            <span key={idx} className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              <Layers className="w-3 h-3 mr-1" />
                              {subcat}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {service.price ? (
                        <div className="flex items-center gap-2">
                          <DollarSign className="w-4 h-4 text-gray-400" />
                          <span className="font-semibold">{service.price.toLocaleString()} {t.bhd}</span>
                          {service.vat && service.vat > 0 && (
                            <span className="text-xs text-gray-500">+{service.vat}% VAT</span>
                          )}
                        </div>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className="py-4 px-6">
                      <button
                        onClick={() => toggleServiceStatus(service.id)}
                        className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                          service.is_active
                            ? 'bg-green-100 text-green-800 hover:bg-green-200'
                            : 'bg-red-100 text-red-800 hover:bg-red-200'
                        }`}
                      >
                        <div className={`w-2 h-2 rounded-full ${service.is_active ? 'bg-green-500' : 'bg-red-500'}`}></div>
                        {service.is_active ? t.active : t.inactive}
                      </button>
                    </td>
                    <td className="py-4 px-6">
                      <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <button
                          onClick={() => setViewingService(service)}
                          className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                          title={t.view}
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        {permissions.edit && (
                          <button
                            onClick={() => handleEdit(service)}
                            className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors duration-200"
                            title={t.edit}
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                        )}
                        {permissions.delete && (
                          <button
                            onClick={() => handleDelete(service.id)}
                            className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors duration-200"
                            title={t.delete}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add/Edit Service Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-fadeIn">
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-2xl font-bold text-gray-800">
                {editingService ? t.editService : t.addNewService}
              </h2>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setEditingService(null);
                  resetForm();
                }}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl mb-4 animate-fadeIn">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-5 h-5" />
                  {error}
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Basic Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.basicInfo}
                </h3>
                <div className="grid grid-cols-1 gap-6">
                  {/* Service Name - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.name} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={serviceForm.name}
                      onChange={(e) => setServiceForm(prev => ({ ...prev, name: e.target.value }))}
                      placeholder={t.enterName}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Description - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.description} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <textarea
                      value={serviceForm.description}
                      onChange={(e) => setServiceForm(prev => ({ ...prev, description: e.target.value }))}
                      placeholder={t.enterDescription}
                      rows={3}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-none"
                    />
                  </div>
                </div>
              </div>

              {/* Category Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.categoryInfo}
                </h3>
                
                {/* Categories - Required */}
                <div className="mb-6">
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.categories} <span className="text-red-500">*</span>
                  </label>
                  
                  {/* Selected Categories */}
                  <div className="flex flex-wrap gap-2 mb-3">
                    {serviceForm.categories.map((category, index) => (
                      <span key={index} className="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                        <Tag className="w-3 h-3" />
                        {category}
                        <button
                          type="button"
                          onClick={() => removeCategoryFromForm(category)}
                          className="ml-1 text-blue-600 hover:text-blue-800"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>

                  {/* Add Category */}
                  <div className="flex gap-2 mb-3">
                    <select
                      onChange={(e) => {
                        if (e.target.value) {
                          addCategoryToForm(e.target.value);
                          e.target.value = '';
                        }
                      }}
                      className="flex-1 px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">{language === 'en' ? 'Select existing category' : 'اختر فئة موجودة'}</option>
                      {availableCategories.filter(cat => !serviceForm.categories.includes(cat)).map(category => (
                        <option key={category} value={category}>{category}</option>
                      ))}
                    </select>
                  </div>

                  {/* New Category Input */}
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newCategoryInput}
                      onChange={(e) => setNewCategoryInput(e.target.value)}
                      placeholder={t.enterNewCategory}
                      className="flex-1 px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                      onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          addNewCategory();
                          addCategoryToForm(newCategoryInput.trim());
                        }
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => {
                        addNewCategory();
                        if (newCategoryInput.trim()) {
                          addCategoryToForm(newCategoryInput.trim());
                        }
                      }}
                      className="px-4 py-2 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-colors"
                    >
                      {t.addCategory}
                    </button>
                  </div>
                </div>

                {/* Subcategories - Optional */}
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.subcategories} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  
                  {/* Selected Subcategories */}
                  <div className="flex flex-wrap gap-2 mb-3">
                    {serviceForm.subcategories.map((subcategory, index) => (
                      <span key={index} className="inline-flex items-center gap-1 px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                        <Layers className="w-3 h-3" />
                        {subcategory}
                        <button
                          type="button"
                          onClick={() => removeSubcategoryFromForm(subcategory)}
                          className="ml-1 text-green-600 hover:text-green-800"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>

                  {/* Add Subcategory */}
                  <div className="flex gap-2 mb-3">
                    <select
                      onChange={(e) => {
                        if (e.target.value) {
                          addSubcategoryToForm(e.target.value);
                          e.target.value = '';
                        }
                      }}
                      className="flex-1 px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">{language === 'en' ? 'Select existing subcategory' : 'اختر فئة فرعية موجودة'}</option>
                      {availableSubcategories.filter(subcat => !serviceForm.subcategories.includes(subcat)).map(subcategory => (
                        <option key={subcategory} value={subcategory}>{subcategory}</option>
                      ))}
                    </select>
                  </div>

                  {/* New Subcategory Input */}
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newSubcategoryInput}
                      onChange={(e) => setNewSubcategoryInput(e.target.value)}
                      placeholder={t.enterNewSubcategory}
                      className="flex-1 px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                      onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          addNewSubcategory();
                          addSubcategoryToForm(newSubcategoryInput.trim());
                        }
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => {
                        addNewSubcategory();
                        if (newSubcategoryInput.trim()) {
                          addSubcategoryToForm(newSubcategoryInput.trim());
                        }
                      }}
                      className="px-4 py-2 bg-green-500 text-white rounded-xl hover:bg-green-600 transition-colors"
                    >
                      {t.addSubcategory}
                    </button>
                  </div>
                </div>

                {/* Variations Preview */}
                {!editingService && serviceForm.categories.length > 0 && (
                  <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-2xl">
                    <div className="flex items-center gap-2 mb-2">
                      <Grid className="w-5 h-5 text-blue-600" />
                      <span className="text-blue-800 font-medium">{t.autoGenerate}</span>
                    </div>
                    <p className="text-blue-700 text-sm">
                      {serviceForm.subcategories.length > 0 
                        ? `${serviceForm.categories.length} × ${serviceForm.subcategories.length} = ${serviceForm.categories.length * serviceForm.subcategories.length} ${t.variationsGenerated}`
                        : `${serviceForm.categories.length} ${t.variationsGenerated}`
                      }
                    </p>
                  </div>
                )}
              </div>

              {/* Pricing Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.pricingInfo}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Price - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.price} ({t.bhd}) <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={serviceForm.price}
                      onChange={(e) => setServiceForm(prev => ({ ...prev, price: parseFloat(e.target.value) || 0 }))}
                      placeholder={t.enterPrice}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* VAT - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.vat} (%) <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      max="100"
                      value={serviceForm.vat}
                      onChange={(e) => setServiceForm(prev => ({ ...prev, vat: parseFloat(e.target.value) || 0 }))}
                      placeholder={t.enterVat}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>
              </div>

              {/* Additional Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.additionalInfo}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Storage Duration - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.storageDuration} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="text"
                      value={serviceForm.storageDuration}
                      onChange={(e) => setServiceForm(prev => ({ ...prev, storageDuration: e.target.value }))}
                      placeholder={t.enterStorageDuration}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Expiration Date - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.expirationValidity} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="date"
                      value={serviceForm.expirationValidity}
                      onChange={(e) => setServiceForm(prev => ({ ...prev, expirationValidity: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Image/Media URL - Optional */}
                  <div className="md:col-span-2">
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.imageMedia} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="url"
                      value={serviceForm.imageMedia}
                      onChange={(e) => setServiceForm(prev => ({ ...prev, imageMedia: e.target.value }))}
                      placeholder={t.enterImageUrl}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className={`flex gap-4 pt-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      {editingService ? (language === 'en' ? 'Updating...' : 'جاري التحديث...') : (language === 'en' ? 'Creating...' : 'جاري الإنشاء...')}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <Save className="w-5 h-5" />
                      {t.save}
                    </div>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingService(null);
                    resetForm();
                  }}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Service Modal */}
      {viewingService && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-fadeIn">
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-2xl font-bold text-gray-800">{t.serviceDetails}</h2>
              <button
                onClick={() => setViewingService(null)}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-6">
              {/* Service Header */}
              <div className={`flex items-center gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                  {viewingService.name.charAt(0).toUpperCase()}
                </div>
                <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                  <h3 className="text-xl font-bold text-gray-800">{viewingService.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <div className={`w-2 h-2 rounded-full ${viewingService.is_active ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span className={`text-sm ${viewingService.is_active ? 'text-green-600' : 'text-red-600'}`}>
                      {viewingService.is_active ? t.active : t.inactive}
                    </span>
                  </div>
                </div>
              </div>

              {/* Service Information */}
              <div className="bg-gray-50 rounded-2xl p-6">
                <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.basicInfo}
                </h4>
                <div className="space-y-3">
                  {viewingService.description && (
                    <div>
                      <span className="text-gray-600 font-medium">{t.description}:</span>
                      <p className="text-gray-700 mt-1">{viewingService.description}</p>
                    </div>
                  )}
                  
                  {viewingService.category && (
                    <div>
                      <span className="text-gray-600 font-medium">{t.categories}:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {viewingService.category.split(', ').map((cat, idx) => (
                          <span key={idx} className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            <Tag className="w-3 h-3 mr-1" />
                            {cat}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {viewingService.subcategory && (
                    <div>
                      <span className="text-gray-600 font-medium">{t.subcategories}:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {viewingService.subcategory.split(', ').map((subcat, idx) => (
                          <span key={idx} className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            <Layers className="w-3 h-3 mr-1" />
                            {subcat}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Calendar className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-700">
                      {new Date(viewingService.created_at).toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </span>
                  </div>
                </div>
              </div>

              {/* Pricing Information */}
              {(viewingService.price || viewingService.vat) && (
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.pricingInfo}
                  </h4>
                  <div className="space-y-3">
                    {viewingService.price && (
                      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <DollarSign className="w-5 h-5 text-gray-400" />
                        <span className="text-gray-700 font-semibold">
                          {viewingService.price.toLocaleString()} {t.bhd}
                        </span>
                      </div>
                    )}
                    {viewingService.vat && viewingService.vat > 0 && (
                      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <Hash className="w-5 h-5 text-gray-400" />
                        <span className="text-gray-700">
                          {t.vat}: {viewingService.vat}%
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Additional Information */}
              {(viewingService.storage_duration || viewingService.image_media || viewingService.expiration_validity) && (
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.additionalInfo}
                  </h4>
                  <div className="space-y-3">
                    {viewingService.storage_duration && (
                      <div>
                        <span className="text-gray-600 font-medium">{t.storageDuration}:</span>
                        <p className="text-gray-700 mt-1">{viewingService.storage_duration}</p>
                      </div>
                    )}
                    
                    {viewingService.expiration_validity && (
                      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <Clock className="w-5 h-5 text-gray-400" />
                        <span className="text-gray-700">
                          {t.expirationValidity}: {new Date(viewingService.expiration_validity).toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA')}
                        </span>
                      </div>
                    )}

                    {viewingService.image_media && (
                      <div>
                        <span className="text-gray-600 font-medium">{t.imageMedia}:</span>
                        <div className="mt-2">
                          <img 
                            src={viewingService.image_media} 
                            alt={viewingService.name}
                            className="w-32 h-32 object-cover rounded-lg border border-gray-200"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.style.display = 'none';
                            }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className={`flex gap-4 mt-8 ${isRTL ? 'flex-row-reverse' : ''}`}>
              {permissions.edit && (
                <button
                  onClick={() => {
                    setViewingService(null);
                    handleEdit(viewingService);
                  }}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl"
                >
                  <div className="flex items-center justify-center gap-2">
                    <Edit3 className="w-5 h-5" />
                    {t.edit}
                  </div>
                </button>
              )}
              <button
                onClick={() => setViewingService(null)}
                className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
              >
                {t.close}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ServicesPage;