import React, { useRef } from 'react';
import { 
  X, 
  Download, 
  Printer, 
  FileText, 
  Calendar,
  User,
  Mail,
  Phone,
  MapPin,
  Hash
} from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import type { Quotation } from '../lib/quotationService';

interface QuotationModalProps {
  quotation: Quotation;
  language: 'en' | 'ar';
  onClose: () => void;
}

const QuotationModal: React.FC<QuotationModalProps> = ({ quotation, language, onClose }) => {
  const quotationRef = useRef<HTMLDivElement>(null);
  const isRTL = language === 'ar';

  // Get current user from localStorage to access boss ID
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Generate unique database key for current boss
  const getBossDataKey = (dataType: string) => {
    const currentUser = getCurrentUser();
    if (!currentUser) return null;
    return `spaceZone_boss_${currentUser.id}_${dataType}`;
  };

  // Get custom logo
  const getCustomLogo = () => {
    const logoKey = getBossDataKey('customLogo');
    if (!logoKey) return null;
    
    const savedLogo = localStorage.getItem(logoKey);
    if (savedLogo) {
      try {
        const logoData = JSON.parse(savedLogo);
        return logoData?.logoImage || null;
      } catch (error) {
        console.error('Error parsing logo:', error);
        return null;
      }
    }
    return null;
  };

  const customLogo = getCustomLogo();

  const translations = {
    en: {
      quotation: 'Quotation',
      quotationNumber: 'Quotation Number',
      issueDate: 'Issue Date',
      validUntil: 'Valid Until',
      quoteTo: 'Quote To',
      clientName: 'Client Name',
      clientEmail: 'Client Email',
      clientPhone: 'Client Phone',
      clientAddress: 'Client Address',
      description: 'Description',
      itemName: 'Item Name',
      category: 'Category',
      subcategory: 'Subcategory',
      price: 'Unit Price',
      quantity: 'Qty',
      total: 'Total',
      subtotal: 'Subtotal',
      tax: 'Tax',
      discount: 'Discount',
      grandTotal: 'Grand Total',
      notes: 'Notes',
      downloadPDF: 'Download PDF',
      print: 'Print',
      close: 'Close',
      bhd: 'BHD',
      companyInfo: 'Space Zone Accounting',
      companyAddress: 'Business Management System',
      quotationTerms: 'This quotation is valid for 30 days from the issue date.',
      thankYou: 'Thank you for considering our services!'
    },
    ar: {
      quotation: 'عرض سعر',
      quotationNumber: 'رقم عرض السعر',
      issueDate: 'تاريخ الإصدار',
      validUntil: 'صالح حتى',
      quoteTo: 'عرض سعر إلى',
      clientName: 'اسم العميل',
      clientEmail: 'بريد العميل الإلكتروني',
      clientPhone: 'هاتف العميل',
      clientAddress: 'عنوان العميل',
      description: 'الوصف',
      itemName: 'اسم العنصر',
      category: 'الفئة',
      subcategory: 'الفئة الفرعية',
      price: 'سعر الوحدة',
      quantity: 'الكمية',
      total: 'الإجمالي',
      subtotal: 'المجموع الفرعي',
      tax: 'الضريبة',
      discount: 'الخصم',
      grandTotal: 'الإجمالي النهائي',
      notes: 'ملاحظات',
      downloadPDF: 'تحميل PDF',
      print: 'طباعة',
      close: 'إغلاق',
      bhd: 'د.ب',
      companyInfo: 'سبيس زون للمحاسبة',
      companyAddress: 'نظام إدارة الأعمال',
      quotationTerms: 'عرض السعر هذا صالح لمدة 30 يوماً من تاريخ الإصدار.',
      thankYou: 'شكراً لك على النظر في خدماتنا!'
    }
  };

  const t = translations[language];

  const handleDownloadPDF = async () => {
    if (!quotationRef.current) return;

    try {
      const canvas = await html2canvas(quotationRef.current, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#f5f1eb'
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
      const imgX = (pdfWidth - imgWidth * ratio) / 2;
      const imgY = 0;

      pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
      pdf.save(`${quotation.quotation_number}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
    }
  };

  const handlePrint = () => {
    if (!quotationRef.current) return;
    
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>${t.quotation} - ${quotation.quotation_number}</title>
          <style>
            body { 
              font-family: 'Arial', sans-serif; 
              margin: 0; 
              padding: 20px; 
              background-color: #f5f1eb;
            }
            .quotation-container { max-width: 800px; margin: 0 auto; }
            .no-print { display: none !important; }
            @media print {
              body { margin: 0; background-color: #f5f1eb; }
              .quotation-container { max-width: none; }
            }
          </style>
        </head>
        <body>
          ${quotationRef.current.innerHTML}
        </body>
      </html>
    `);
    
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 250);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-5xl w-full max-h-[95vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className={`flex items-center justify-between p-6 border-b border-gray-200 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <div className="p-2 bg-green-100 rounded-xl">
              <FileText className="w-6 h-6 text-green-600" />
            </div>
            <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
              <h2 className="text-2xl font-bold text-gray-800">{t.quotation}</h2>
              <p className="text-gray-600 text-sm">#{quotation.quotation_number}</p>
            </div>
          </div>

          <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <button
              onClick={handleDownloadPDF}
              className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Download className="w-4 h-4" />
              {t.downloadPDF}
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Printer className="w-4 h-4" />
              {t.print}
            </button>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6">
          {/* Quotation Preview */}
          <div 
            ref={quotationRef}
            className="relative w-full max-w-[210mm] mx-auto bg-[#f5f1eb] shadow-2xl"
            style={{ 
              fontFamily: 'Arial, sans-serif',
              aspectRatio: '210/297',
              minHeight: '297mm',
              width: '210mm',
              padding: '12mm',
              boxSizing: 'border-box'
            }}
          >
            {/* Background Decorative Elements */}
            <div className="absolute top-0 right-0 w-24 h-24 opacity-30">
              <svg viewBox="0 0 200 200" className="w-full h-full">
                <path
                  d="M20,20 Q50,10 80,20 T140,30 Q170,40 180,70 T170,130 Q160,160 130,170 T70,160 Q40,150 30,120 T40,60 Q50,30 80,20"
                  fill="none"
                  stroke="#d97706"
                  strokeWidth="1.5"
                  opacity="0.6"
                />
                <path
                  d="M30,30 Q60,20 90,30 T150,40 Q180,50 190,80 T180,140 Q170,170 140,180 T80,170 Q50,160 40,130 T50,70 Q60,40 90,30"
                  fill="none"
                  stroke="#d97706"
                  strokeWidth="1"
                  opacity="0.4"
                />
              </svg>
            </div>

            <div className="absolute bottom-0 left-0 w-20 h-20 opacity-25">
              <svg viewBox="0 0 150 150" className="w-full h-full">
                <path
                  d="M10,10 Q25,5 40,10 T70,15 Q85,20 90,35 T85,65 Q80,80 65,85 T35,80 Q20,75 15,60 T20,30 Q25,15 40,10"
                  fill="none"
                  stroke="#d97706"
                  strokeWidth="1.2"
                  opacity="0.5"
                />
              </svg>
            </div>

            {/* Logo */}
            <div className="absolute top-4 left-4">
              {customLogo ? (
                <div className="w-16 h-16 rounded-xl overflow-hidden border-2 border-gray-200 bg-white flex items-center justify-center shadow-lg">
                  <img
                    src={customLogo}
                    alt="Custom Logo"
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
              ) : (
                <div className="w-16 h-16 bg-black rounded-full flex items-center justify-center relative">
                  <div className="absolute inset-0 border-2 border-yellow-400 rounded-full animate-pulse opacity-60"></div>
                  <div className="absolute inset-1 border border-yellow-300 rounded-full opacity-40"></div>
                  <div className="text-center">
                    <div className="text-yellow-400 font-bold text-[10px] leading-tight">SPACE</div>
                    <div className="text-white font-bold text-[10px] leading-tight">ZONE</div>
                  </div>
                </div>
              )}
            </div>

            {/* Title */}
            <div className="text-center mt-6 mb-8">
              <h1 
                className="text-3xl font-light tracking-[0.3em] text-gray-700"
                style={{ 
                  fontFamily: 'Arial, sans-serif',
                  letterSpacing: '0.3em',
                  fontWeight: '300'
                }}
              >
                QUOTATION
              </h1>
            </div>

            {/* Quote To and Details Section */}
            <div className="flex justify-between items-start mb-8">
              <div>
                <div 
                  className="text-gray-500 text-xs font-light tracking-wider mb-3"
                  style={{ letterSpacing: '0.1em' }}
                >
                  QUOTE TO:
                </div>
                <div className="text-gray-800 space-y-1">
                  <div className="font-medium text-base">{quotation.client_name || 'Client Name'}</div>
                  {quotation.client_email && <div className="text-xs">{quotation.client_email}</div>}
                  {quotation.client_phone && <div className="text-xs">{quotation.client_phone}</div>}
                  {quotation.client_address && <div className="text-xs">{quotation.client_address}</div>}
                </div>
              </div>

              <div className="text-center space-y-1">
                <div className="text-center">
                  <div className="text-gray-500 text-xs font-light tracking-wider">NO.</div>
                  <div className="text-gray-800 font-medium text-sm text-center">{quotation.quotation_number}</div>
                </div>
                <div className="text-center">
                  <div className="text-gray-500 text-xs font-light tracking-wider">DATE.</div>
                  <div className="text-gray-800 font-medium text-sm text-center">
                    {new Date(quotation.issue_date).toLocaleDateString('en-US')}
                  </div>
                </div>
              </div>
            </div>

            {/* Table */}
            <div className="mb-8">
              {/* Table Header */}
              <div className="grid grid-cols-4 gap-4 border-b border-gray-300 pb-2 mb-4">
                <div 
                  className="text-gray-600 text-xs font-light tracking-wider text-center"
                  style={{ letterSpacing: '0.1em' }}
                >
                  S.N
                </div>
                <div 
                  className="text-gray-600 text-xs font-light tracking-wider text-center"
                  style={{ letterSpacing: '0.1em' }}
                >
                  DESCRIPTION
                </div>
                <div 
                  className="text-gray-600 text-xs font-light tracking-wider text-center"
                  style={{ letterSpacing: '0.1em' }}
                >
                  QTY
                </div>
                <div 
                  className="text-gray-600 text-xs font-light tracking-wider text-center"
                  style={{ letterSpacing: '0.1em' }}
                >
                  TOTAL
                </div>
              </div>

              {/* Table Content */}
              <div className="space-y-2 min-h-[200px]">
                {quotation.items.map((item, index) => (
                  <div key={item.id} className="grid grid-cols-4 gap-4 py-2 border-b border-gray-100">
                    <div className="text-gray-800 text-xs text-center">{index + 1}</div>
                    <div className="text-gray-800 text-xs text-lift pl-2">
                      <div className="font-bold text-sm">{item.name}</div>
                      {item.category && (
                        <div className="text-sm text-gray-700 mt-1 whitespace-pre-wrap text-left font-bold">
                          {item.category}
                          {item.subcategory && (
                            <div className="mt-1">
                              <div className="whitespace-pre-wrap text-sm font-bold">{item.subcategory}</div>
                            </div>
                          )}
                        </div>
                      )}
                      {item.description && (
                        <div className="text-sm text-gray-600 mt-1 text-left font-bold">{item.description}</div>
                      )}
                    </div>
                    <div className="text-gray-800 text-xs text-center font-bold">{item.quantity}</div>
                    <div className="text-gray-800 text-xs text-center font-bold">
                      {item.total.toLocaleString()} BHD
                    </div>
                  </div>
                ))}

                {/* Tax Row if applicable */}
                {quotation.tax_rate > 0 && (
                  <div className="grid grid-cols-4 gap-4 py-1">
                    <div className="col-span-3"></div>
                    <div className="text-gray-600 text-xs text-center">
                      <div className="font-light tracking-wider text-[10px]" style={{ letterSpacing: '0.1em' }}>
                        TAX ({quotation.tax_rate}%)
                      </div>
                      <div className="font-medium text-gray-800 text-xs">{quotation.tax_amount.toLocaleString()} BHD</div>
                    </div>
                  </div>
                )}

                {/* Discount Row if applicable */}
                {quotation.discount_rate > 0 && (
                  <div className="grid grid-cols-4 gap-4 py-1">
                    <div className="col-span-3"></div>
                    <div className="text-red-600 text-xs text-center">
                      <div className="font-light tracking-wider text-[10px]" style={{ letterSpacing: '0.1em' }}>
                        DISCOUNT ({quotation.discount_rate}%)
                      </div>
                      <div className="font-medium text-xs">-{quotation.discount_amount.toLocaleString()} BHD</div>
                    </div>
                  </div>
                )}

                {/* Grand Total Row */}
                <div className="grid grid-cols-4 gap-4 py-3 border-t-2 border-gray-400">
                  <div className="col-span-3"></div>
                  <div className="text-gray-800 text-base text-center">
                    <div className="font-light tracking-wider text-xs mb-1" style={{ letterSpacing: '0.1em' }}>
                      TOTAL
                    </div>
                    <div className="font-bold text-lg">{quotation.total_amount.toLocaleString()} BHD</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Notes Section */}
            {quotation.notes && (
              <div className="mb-8">
                <div className="text-gray-600 text-xs font-light tracking-wider mb-2">NOTES:</div>
                <div className="text-gray-800 text-xs whitespace-pre-wrap">{quotation.notes}</div>
              </div>
            )}

            {/* Footer Section */}
            <div className="absolute bottom-4 left-4 right-4">
              {/* Contact Section */}
              <div className="text-center mb-4">
                <div 
                  className="text-gray-700 text-xs font-light tracking-wider mb-1"
                  style={{ letterSpacing: '0.15em' }}
                >
                  CONTACT US FOR MORE DETAIL
                </div>
                <div className="text-gray-600 text-xs">
                  Contact NO: 00973-37155515<br />
                  Call and WhatsApp
                </div>
              </div>

              {/* Thank You Section */}
              <div className="text-center">
                <div className="text-sm">
                  <span className="text-black font-medium">Thank You For </span>
                  <span className="text-yellow-600 font-medium">Contacting Us </span>
                  <span className="text-black font-bold">SPACE ZONE</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuotationModal;