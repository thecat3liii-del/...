@@ .. @@
                 <th className="px-4 py-3 text-right font-semibold text-gray-700 border-b border-gray-300">S.N</th>
-                <th className="px-4 py-3 text-right font-semibold text-gray-700 border-b border-gray-300">Description</th>
+                <th className="px-4 py-3 text-center font-semibold text-gray-700 border-b border-gray-300">Description</th>
                 <th className="px-4 py-3 text-right font-semibold text-gray-700 border-b border-gray-300">QTY</th>
@@ .. @@
               {items.map((item, index) => (
                 <tr key={index} className="hover:bg-gray-50">
-                  <td className="px-4 py-3 text-right border-b border-gray-200">{index + 1}</td>
+                  <td className="px-4 py-3 text-center border-b border-gray-200">{index + 1}</td>
-                  <td className="px-4 py-3 text-right border-b border-gray-200">{item.description}</td>
+                  <td className="px-4 py-3 text-center border-b border-gray-200">{item.description}</td>
                   <td className="px-4 py-3 text-right border-b border-gray-200">{item.quantity}</td>
@@ .. @@
           <div className="flex justify-between items-center mb-4">
             <div>
-              <p className="text-gray-600"><span className="font-semibold">التاريخ:</span> {invoiceData.date}</p>
+              <p className="text-gray-600 text-center"><span className="font-semibold">التاريخ:</span> {invoiceData.date}</p>
             </div>
@@ .. @@
             <div className="text-right">
-              <p className="text-gray-600"><span className="font-semibold">رقم الفاتورة:</span> {invoiceData.invoiceNumber}</p>
+              <p className="text-gray-600 text-center"><span className="font-semibold">رقم الفاتورة:</span> {invoiceData.invoiceNumber}</p>
             </div>
               )
               )
               }