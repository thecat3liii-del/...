import React, { useState, useEffect, useRef } from 'react';
import { 
  FileText, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Calendar,
  Download,
  Filter,
  Eye,
  BarChart3,
  PieChart,
  LineChart,
  Activity,
  Target,
  Award,
  AlertCircle,
  CheckCircle,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Printer,
  Share2,
  RefreshCw
} from 'lucide-react';
import { transactionService } from '../lib/supabase';
import type { Transaction as SupabaseTransaction } from '../lib/supabase';

interface Transaction {
  id: string;
  type: 'revenue' | 'expense';
  amount: number;
  description: string;
  date: string;
  month: number;
  year: number;
}

interface FinancialReportsProps {
  language: 'en' | 'ar';
  bossId?: string;
}

const FinancialReports: React.FC<FinancialReportsProps> = ({ language, bossId }) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [selectedPeriod, setSelectedPeriod] = useState<'month' | 'quarter' | 'year'>('month');
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedChart, setSelectedChart] = useState<'line' | 'bar' | 'pie'>('line');
  const [isLoading, setIsLoading] = useState(false);
  const chartCanvasRef = useRef<HTMLCanvasElement>(null);
  const pieChartCanvasRef = useRef<HTMLCanvasElement>(null);
  const isRTL = language === 'ar';

  // Get current user from localStorage to access boss ID
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Generate unique database key for current boss
  const getBossDataKey = (dataType: string) => {
    const currentUser = getCurrentUser();
    if (!currentUser) return null;
    const targetBossId = bossId || currentUser.id;
    return `spaceZone_boss_${targetBossId}_${dataType}`;
  };
  const translations = {
    en: {
      title: 'Financial Reports',
      subtitle: 'Comprehensive financial analysis and insights',
      overview: 'Financial Overview',
      monthlyTrends: 'Monthly Trends',
      categoryBreakdown: 'Category Breakdown',
      profitLoss: 'Profit & Loss Statement',
      cashFlow: 'Cash Flow Analysis',
      performance: 'Performance Metrics',
      exportReport: 'Export Report',
      printReport: 'Print Report',
      shareReport: 'Share Report',
      refreshData: 'Refresh Data',
      filterBy: 'Filter By',
      thisMonth: 'This Month',
      thisQuarter: 'This Quarter',
      thisYear: 'This Year',
      totalRevenue: 'Total Revenue',
      totalExpenses: 'Total Expenses',
      netProfit: 'Net Profit',
      netLoss: 'Net Loss',
      profitMargin: 'Profit Margin',
      expenseRatio: 'Expense Ratio',
      growthRate: 'Growth Rate',
      avgTransaction: 'Avg Transaction',
      transactionCount: 'Total Transactions',
      highestRevenue: 'Highest Revenue',
      highestExpense: 'Highest Expense',
      revenueTransactions: 'Revenue Transactions',
      expenseTransactions: 'Expense Transactions',
      monthlyComparison: 'Monthly Comparison',
      yearOverYear: 'Year over Year',
      quarterlyAnalysis: 'Quarterly Analysis',
      trendAnalysis: 'Trend Analysis',
      financialHealth: 'Financial Health',
      recommendations: 'Recommendations',
      keyInsights: 'Key Insights',
      noData: 'No financial data available',
      noDataDesc: 'Start adding transactions to generate comprehensive reports',
      excellent: 'Excellent',
      good: 'Good',
      average: 'Average',
      poor: 'Poor',
      bhd: 'BHD',
      revenue: 'Revenue',
      expenses: 'Expenses',
      profit: 'Profit',
      loss: 'Loss',
      january: 'January',
      february: 'February',
      march: 'March',
      april: 'April',
      may: 'May',
      june: 'June',
      july: 'July',
      august: 'August',
      september: 'September',
      october: 'October',
      november: 'November',
      december: 'December',
      q1: 'Q1',
      q2: 'Q2',
      q3: 'Q3',
      q4: 'Q4',
      increaseFrom: 'increase from',
      decreaseFrom: 'decrease from',
      lastMonth: 'last month',
      lastYear: 'last year',
      vs: 'vs',
      reportGenerated: 'Report generated successfully',
      dataUpdated: 'Data updated',
      healthScore: 'Health Score'
    },
    ar: {
      title: 'التقارير المالية',
      subtitle: 'تحليل مالي شامل ورؤى تفصيلية',
      overview: 'نظرة عامة مالية',
      monthlyTrends: 'الاتجاهات الشهرية',
      categoryBreakdown: 'تفصيل الفئات',
      profitLoss: 'بيان الأرباح والخسائر',
      cashFlow: 'تحليل التدفق النقدي',
      performance: 'مقاييس الأداء',
      exportReport: 'تصدير التقرير',
      printReport: 'طباعة التقرير',
      shareReport: 'مشاركة التقرير',
      refreshData: 'تحديث البيانات',
      filterBy: 'تصفية حسب',
      thisMonth: 'هذا الشهر',
      thisQuarter: 'هذا الربع',
      thisYear: 'هذا العام',
      totalRevenue: 'إجمالي الإيرادات',
      totalExpenses: 'إجمالي المصروفات',
      netProfit: 'صافي الربح',
      netLoss: 'صافي الخسارة',
      profitMargin: 'هامش الربح',
      expenseRatio: 'نسبة المصروفات',
      growthRate: 'معدل النمو',
      avgTransaction: 'متوسط المعاملة',
      transactionCount: 'إجمالي المعاملات',
      highestRevenue: 'أعلى إيراد',
      highestExpense: 'أعلى مصروف',
      revenueTransactions: 'معاملات الإيرادات',
      expenseTransactions: 'معاملات المصروفات',
      monthlyComparison: 'المقارنة الشهرية',
      yearOverYear: 'سنة بعد سنة',
      quarterlyAnalysis: 'التحليل الربعي',
      trendAnalysis: 'تحليل الاتجاهات',
      financialHealth: 'الصحة المالية',
      recommendations: 'التوصيات',
      keyInsights: 'الرؤى الرئيسية',
      noData: 'لا توجد بيانات مالية متاحة',
      noDataDesc: 'ابدأ بإضافة المعاملات لإنشاء تقارير شاملة',
      excellent: 'ممتاز',
      good: 'جيد',
      average: 'متوسط',
      poor: 'ضعيف',
      bhd: 'د.ب',
      revenue: 'الإيرادات',
      expenses: 'المصروفات',
      profit: 'الربح',
      loss: 'الخسارة',
      january: 'يناير',
      february: 'فبراير',
      march: 'مارس',
      april: 'أبريل',
      may: 'مايو',
      june: 'يونيو',
      july: 'يوليو',
      august: 'أغسطس',
      september: 'سبتمبر',
      october: 'أكتوبر',
      november: 'نوفمبر',
      december: 'ديسمبر',
      q1: 'الربع الأول',
      q2: 'الربع الثاني',
      q3: 'الربع الثالث',
      q4: 'الربع الرابع',
      increaseFrom: 'زيادة من',
      decreaseFrom: 'انخفاض من',
      lastMonth: 'الشهر الماضي',
      lastYear: 'العام الماضي',
      vs: 'مقابل',
      reportGenerated: 'تم إنشاء التقرير بنجاح',
      dataUpdated: 'تم تحديث البيانات',
      healthScore: 'نقاط الصحة'
    }
  };

  const t = translations[language];

  const monthNames = [
    t.january, t.february, t.march, t.april, t.may, t.june,
    t.july, t.august, t.september, t.october, t.november, t.december
  ];

  // Load transactions from localStorage
  useEffect(() => {
    const loadTransactions = () => {
      const loadData = async () => {
        const currentUser = getCurrentUser();
        if (!currentUser) return;
        
        const targetBossId = bossId || currentUser.id;
        try {
          const result = await transactionService.getTransactions(targetBossId);
          if (result.success) {
            // Convert Supabase data to local format for reports
            const convertedTransactions = result.data.map((t: SupabaseTransaction) => ({
              id: t.id,
              type: 'revenue' as const,
              amount: t.amount,
              description: t.description || '',
              date: t.transaction_date,
              month: t.month,
              year: t.year,
              cost: t.cost,
              vat: t.vat
            }));
            setTransactions(convertedTransactions);
          } else {
            console.error('Error loading transactions:', result.error);
            setTransactions([]);
          }
        } catch (error) {
          console.error('Error loading transactions:', error);
          setTransactions([]);
        }
      };
      
      loadData();
    };

    loadTransactions();

  }, []);

  // Calculate financial metrics
  const calculateMetrics = () => {
    const currentYear = selectedYear;
    const currentMonth = new Date().getMonth() + 1;
    
    // Filter transactions by selected period
    let filteredTransactions = transactions.filter(t => t.year === currentYear);
    
    if (selectedPeriod === 'month') {
      filteredTransactions = filteredTransactions.filter(t => t.month === currentMonth);
    } else if (selectedPeriod === 'quarter') {
      const currentQuarter = Math.ceil(currentMonth / 3);
      const quarterMonths = {
        1: [1, 2, 3],
        2: [4, 5, 6],
        3: [7, 8, 9],
        4: [10, 11, 12]
      };
      filteredTransactions = filteredTransactions.filter(t => 
        quarterMonths[currentQuarter as keyof typeof quarterMonths].includes(t.month)
      );
    }

    // Calculate revenue from amount + vat
    const totalRevenue = filteredTransactions
      .reduce((sum, t) => sum + (t.amount || 0) + (t.vat || 0), 0);

    // Calculate expenses from cost
    const totalExpenses = filteredTransactions
      .reduce((sum, t) => sum + (t.cost || 0), 0);

    const netProfit = totalRevenue - totalExpenses;
    const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;
    const expenseRatio = totalRevenue > 0 ? (totalExpenses / totalRevenue) * 100 : 0;

    // All transactions are both revenue and expense
    const revenueTransactions = filteredTransactions;
    const expenseTransactions = filteredTransactions;

    const avgRevenueTransaction = filteredTransactions.length > 0 
      ? totalRevenue / filteredTransactions.length : 0;
    const avgExpenseTransaction = filteredTransactions.length > 0 
      ? totalExpenses / filteredTransactions.length : 0;

    const highestRevenue = filteredTransactions.length > 0 
      ? Math.max(...filteredTransactions.map(t => (t.amount || 0) + (t.vat || 0))) : 0;
    const highestExpense = filteredTransactions.length > 0 
      ? Math.max(...filteredTransactions.map(t => t.cost || 0)) : 0;

    // Calculate growth rate
    let growthRate = 0;
    if (selectedPeriod === 'month' && currentMonth > 1) {
      const lastMonthRevenue = transactions
        .filter(t => t.month === currentMonth - 1 && t.year === currentYear)
        .reduce((sum, t) => sum + (t.amount || 0) + (t.vat || 0), 0);
      
      if (lastMonthRevenue > 0) {
        growthRate = ((totalRevenue - lastMonthRevenue) / lastMonthRevenue) * 100;
      }
    } else if (selectedPeriod === 'year') {
      const lastYearRevenue = transactions
        .filter(t => t.year === currentYear - 1)
        .reduce((sum, t) => sum + (t.amount || 0) + (t.vat || 0), 0);
      
      if (lastYearRevenue > 0) {
        growthRate = ((totalRevenue - lastYearRevenue) / lastYearRevenue) * 100;
      }
    }

    // Financial health score
    let healthScore = 0;
    if (totalRevenue > 0) {
      healthScore += netProfit > 0 ? 40 : 0; // Profitability
      healthScore += profitMargin > 20 ? 30 : profitMargin > 10 ? 20 : profitMargin > 0 ? 10 : 0; // Margin
      healthScore += growthRate > 10 ? 20 : growthRate > 0 ? 10 : 0; // Growth
      healthScore += filteredTransactions.length > 10 ? 10 : filteredTransactions.length > 5 ? 5 : 0; // Activity
    }

    return {
      totalRevenue,
      totalExpenses,
      netProfit,
      profitMargin,
      expenseRatio,
      growthRate,
      avgRevenueTransaction,
      avgExpenseTransaction,
      highestRevenue,
      highestExpense,
      revenueCount: filteredTransactions.length,
      expenseCount: filteredTransactions.length,
      totalTransactions: filteredTransactions.length,
      healthScore: Math.min(100, healthScore)
    };
  };

  const metrics = calculateMetrics();

  // Generate monthly data for charts
  const generateMonthlyData = () => {
    return Array.from({ length: 12 }, (_, index) => {
      const month = index + 1;
      const monthTransactions = transactions
        .filter(t => t.month === month && t.year === selectedYear);
      
      // Calculate revenue from amount + vat
      const monthRevenue = monthTransactions
        .reduce((sum, t) => sum + (t.amount || 0) + (t.vat || 0), 0);
      
      // Calculate expenses from cost
      const monthExpenses = monthTransactions
        .reduce((sum, t) => sum + (t.cost || 0), 0);

      return {
        month: monthNames[index],
        revenue: monthRevenue,
        expenses: monthExpenses,
        profit: monthRevenue - monthExpenses
      };
    });
  };

  const monthlyData = generateMonthlyData();

  // Draw charts
  useEffect(() => {
    drawLineChart();
    drawPieChart();
  }, [transactions, selectedYear, selectedChart, language]);

  const drawLineChart = () => {
    const canvas = chartCanvasRef.current;
    if (!canvas || monthlyData.every(d => d.revenue === 0 && d.expenses === 0)) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;
    const padding = 60;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;

    ctx.clearRect(0, 0, width, height);

    // Find max value
    const maxValue = Math.max(
      ...monthlyData.map(d => Math.max(d.revenue, d.expenses)),
      1000
    );

    // Draw background
    const bgGradient = ctx.createLinearGradient(0, 0, 0, height);
    bgGradient.addColorStop(0, 'rgba(59, 130, 246, 0.02)');
    bgGradient.addColorStop(1, 'rgba(147, 51, 234, 0.02)');
    ctx.fillStyle = bgGradient;
    ctx.fillRect(0, 0, width, height);

    // Draw grid
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.2)';
    ctx.lineWidth = 1;
    
    for (let i = 0; i <= 6; i++) {
      const y = padding + (chartHeight / 6) * i;
      ctx.beginPath();
      ctx.moveTo(padding, y);
      ctx.lineTo(width - padding, y);
      ctx.stroke();
    }

    for (let i = 0; i <= 11; i++) {
      const x = padding + (chartWidth / 11) * i;
      ctx.beginPath();
      ctx.moveTo(x, padding);
      ctx.lineTo(x, height - padding);
      ctx.stroke();
    }

    if (selectedChart === 'line') {
      // Draw area fills
      const revenueGradient = ctx.createLinearGradient(0, padding, 0, height - padding);
      revenueGradient.addColorStop(0, 'rgba(34, 197, 94, 0.2)');
      revenueGradient.addColorStop(1, 'rgba(34, 197, 94, 0.02)');
      
      ctx.fillStyle = revenueGradient;
      ctx.beginPath();
      ctx.moveTo(padding, height - padding);
      
      monthlyData.forEach((point, index) => {
        const x = padding + (chartWidth / 11) * index;
        const y = height - padding - (point.revenue / maxValue) * chartHeight;
        if (index === 0) ctx.lineTo(x, y);
        else ctx.lineTo(x, y);
      });
      
      ctx.lineTo(width - padding, height - padding);
      ctx.closePath();
      ctx.fill();

      // Draw lines
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 3;
      ctx.beginPath();
      
      monthlyData.forEach((point, index) => {
        const x = padding + (chartWidth / 11) * index;
        const y = height - padding - (point.revenue / maxValue) * chartHeight;
        if (index === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();

      ctx.strokeStyle = '#ef4444';
      ctx.beginPath();
      
      monthlyData.forEach((point, index) => {
        const x = padding + (chartWidth / 11) * index;
        const y = height - padding - (point.expenses / maxValue) * chartHeight;
        if (index === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();

      // Draw points
      monthlyData.forEach((point, index) => {
        const x = padding + (chartWidth / 11) * index;
        
        // Revenue point
        const revenueY = height - padding - (point.revenue / maxValue) * chartHeight;
        ctx.fillStyle = '#22c55e';
        ctx.beginPath();
        ctx.arc(x, revenueY, 4, 0, Math.PI * 2);
        ctx.fill();
        
        // Expenses point
        const expensesY = height - padding - (point.expenses / maxValue) * chartHeight;
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(x, expensesY, 4, 0, Math.PI * 2);
        ctx.fill();
      });
    } else if (selectedChart === 'bar') {
      const barWidth = chartWidth / 24;
      
      monthlyData.forEach((point, index) => {
        const x = padding + (chartWidth / 11) * index;
        
        // Revenue bar
        const revenueHeight = (point.revenue / maxValue) * chartHeight;
        const revenueGradient = ctx.createLinearGradient(0, height - padding - revenueHeight, 0, height - padding);
        revenueGradient.addColorStop(0, '#22c55e');
        revenueGradient.addColorStop(1, '#16a34a');
        
        ctx.fillStyle = revenueGradient;
        ctx.fillRect(x - barWidth, height - padding - revenueHeight, barWidth - 2, revenueHeight);
        
        // Expenses bar
        const expensesHeight = (point.expenses / maxValue) * chartHeight;
        const expensesGradient = ctx.createLinearGradient(0, height - padding - expensesHeight, 0, height - padding);
        expensesGradient.addColorStop(0, '#ef4444');
        expensesGradient.addColorStop(1, '#dc2626');
        
        ctx.fillStyle = expensesGradient;
        ctx.fillRect(x + 2, height - padding - expensesHeight, barWidth - 2, expensesHeight);
      });
    }

    // Draw labels
    ctx.fillStyle = '#475569';
    ctx.font = '12px Inter, system-ui, sans-serif';
    ctx.textAlign = 'center';
    
    monthlyData.forEach((point, index) => {
      const x = padding + (chartWidth / 11) * index;
      const shortMonth = point.month.substring(0, 3);
      ctx.fillText(shortMonth, x, height - padding + 20);
    });

    // Y-axis labels
    ctx.textAlign = isRTL ? 'right' : 'left';
    for (let i = 0; i <= 6; i++) {
      const value = (maxValue / 6) * (6 - i);
      const y = padding + (chartHeight / 6) * i;
      const formattedValue = value >= 1000 ? `${(value / 1000).toFixed(1)}K` : value.toFixed(0);
      ctx.fillText(formattedValue, padding - 15, y + 4);
    }
  };

  const drawPieChart = () => {
    const canvas = pieChartCanvasRef.current;
    if (!canvas || (metrics.totalRevenue === 0 && metrics.totalExpenses === 0)) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) / 2 - 40;

    ctx.clearRect(0, 0, width, height);

    const total = metrics.totalRevenue + metrics.totalExpenses;
    if (total === 0) return;

    const revenueAngle = (metrics.totalRevenue / total) * 2 * Math.PI;
    const expenseAngle = (metrics.totalExpenses / total) * 2 * Math.PI;

    // Draw revenue slice
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.arc(centerX, centerY, radius, 0, revenueAngle);
    ctx.closePath();
    
    const revenueGradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius);
    revenueGradient.addColorStop(0, '#34d399');
    revenueGradient.addColorStop(1, '#10b981');
    ctx.fillStyle = revenueGradient;
    ctx.fill();

    // Draw expense slice
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.arc(centerX, centerY, radius, revenueAngle, revenueAngle + expenseAngle);
    ctx.closePath();
    
    const expenseGradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius);
    expenseGradient.addColorStop(0, '#f87171');
    expenseGradient.addColorStop(1, '#ef4444');
    ctx.fillStyle = expenseGradient;
    ctx.fill();

    // Draw labels
    ctx.fillStyle = 'white';
    ctx.font = 'bold 14px Inter, system-ui, sans-serif';
    ctx.textAlign = 'center';

    // Revenue label
    const revenueAngleMiddle = revenueAngle / 2;
    const revenueLabelX = centerX + Math.cos(revenueAngleMiddle) * (radius * 0.7);
    const revenueLabelY = centerY + Math.sin(revenueAngleMiddle) * (radius * 0.7);
    ctx.fillText(`${((metrics.totalRevenue / total) * 100).toFixed(1)}%`, revenueLabelX, revenueLabelY);

    // Expense label
    const expenseAngleMiddle = revenueAngle + (expenseAngle / 2);
    const expenseLabelX = centerX + Math.cos(expenseAngleMiddle) * (radius * 0.7);
    const expenseLabelY = centerY + Math.sin(expenseAngleMiddle) * (radius * 0.7);
    ctx.fillText(`${((metrics.totalExpenses / total) * 100).toFixed(1)}%`, expenseLabelX, expenseLabelY);
  };

  const handleRefreshData = () => {
    setIsLoading(true);
    
    const loadData = async () => {
      const currentUser = getCurrentUser();
      if (!currentUser) {
        setIsLoading(false);
        return;
      }
      
      const targetBossId = bossId || currentUser.id;
      try {
        const result = await transactionService.getTransactions(targetBossId);
        if (result.success) {
          // Convert Supabase data to local format for reports
          const convertedTransactions = result.data.map((t: any) => ({
            id: t.id,
            type: 'revenue' as const,
            amount: t.amount,
            description: t.description || '',
            date: t.transaction_date,
            month: t.month,
            year: t.year
          }));
          setTransactions(convertedTransactions);
        } else {
          console.error('Error loading transactions:', result.error);
        }
      } catch (error) {
        console.error('Error loading transactions:', error);
      }
      
      setIsLoading(false);
    };
    
    loadData();
  };

  const getHealthStatus = (score: number) => {
    if (score >= 80) return { text: t.excellent, color: 'text-green-600', bg: 'bg-green-100' };
    if (score >= 60) return { text: t.good, color: 'text-blue-600', bg: 'bg-blue-100' };
    if (score >= 40) return { text: t.average, color: 'text-yellow-600', bg: 'bg-yellow-100' };
    return { text: t.poor, color: 'text-red-600', bg: 'bg-red-100' };
  };

  const healthStatus = getHealthStatus(metrics.healthScore);

  if (transactions.length === 0) {
    return (
      <div className="space-y-8">
        {/* Header */}
        <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">{t.title}</h1>
            <p className="text-gray-600">{t.subtitle}</p>
          </div>
        </div>

        {/* Empty State */}
        <div className="text-center py-16">
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-12 shadow-lg max-w-2xl mx-auto">
            <div className="mb-8">
              <div className="w-24 h-24 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <FileText className="w-12 h-12 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-gray-800 mb-4">{t.noData}</h2>
              <p className="text-gray-600 text-lg">{t.noDataDesc}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header with Controls */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{t.title}</h1>
          <p className="text-gray-600">{t.subtitle}</p>
        </div>

        <div className={`flex items-center gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
          {/* Year Selector */}
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            className="bg-white/80 backdrop-blur-sm border border-gray-200 rounded-xl px-4 py-2 text-sm font-medium text-gray-700 shadow-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {Array.from({ length: 21 }, (_, i) => 2025 + i).map(year => (
              <option key={year} value={year}>{year}</option>
            ))}
          </select>

          {/* Action Buttons */}
          <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <button
              onClick={handleRefreshData}
              disabled={isLoading}
              className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              {t.refreshData}
            </button>

            <button className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl">
              <Download className="w-4 h-4" />
              {t.exportReport}
            </button>
          </div>
        </div>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl p-6 text-white shadow-xl">
          <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <TrendingUp className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-green-100 text-sm">{t.totalRevenue}</div>
              <div className="text-2xl font-bold">{metrics.totalRevenue.toLocaleString()} {t.bhd}</div>
            </div>
          </div>
          <div className="flex items-center gap-2 text-green-100 text-sm">
            <ArrowUpRight className="w-4 h-4" />
            <span>{metrics.revenueCount} {t.revenueTransactions}</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-red-500 to-rose-600 rounded-2xl p-6 text-white shadow-xl">
          <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <TrendingDown className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-red-100 text-sm">{t.totalExpenses}</div>
              <div className="text-2xl font-bold">{metrics.totalExpenses.toLocaleString()} {t.bhd}</div>
            </div>
          </div>
          <div className="flex items-center gap-2 text-red-100 text-sm">
            <ArrowDownRight className="w-4 h-4" />
            <span>{metrics.expenseCount} {t.expenseTransactions}</span>
          </div>
        </div>

        <div className={`bg-gradient-to-br ${metrics.netProfit >= 0 ? 'from-blue-500 to-indigo-600' : 'from-orange-500 to-red-600'} rounded-2xl p-6 text-white shadow-xl`}>
          <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <DollarSign className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-white/80 text-sm">{metrics.netProfit >= 0 ? t.netProfit : t.netLoss}</div>
              <div className="text-2xl font-bold">{Math.abs(metrics.netProfit).toLocaleString()} {t.bhd}</div>
            </div>
          </div>
          <div className="flex items-center gap-2 text-white/80 text-sm">
            <Target className="w-4 h-4" />
            <span>{metrics.profitMargin.toFixed(1)}% {t.profitMargin}</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl p-6 text-white shadow-xl">
          <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Activity className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-purple-100 text-sm">{t.healthScore}</div>
              <div className="text-2xl font-bold">{metrics.healthScore}%</div>
            </div>
          </div>
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium ${healthStatus.bg} ${healthStatus.color}`}>
            <CheckCircle className="w-3 h-3" />
            {healthStatus.text}
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Chart */}
        <div className="lg:col-span-2 bg-white/90 backdrop-blur-sm rounded-3xl p-8 shadow-xl">
          <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
              <h3 className="text-xl font-bold text-gray-800 mb-1">{t.monthlyTrends}</h3>
              <p className="text-gray-600 text-sm">{selectedYear} {t.yearOverYear}</p>
            </div>

            <div className="flex items-center gap-2 bg-gray-100 rounded-xl p-1">
              <button
                onClick={() => setSelectedChart('line')}
                className={`p-2 rounded-lg transition-all duration-200 ${
                  selectedChart === 'line' ? 'bg-white shadow-sm text-blue-600' : 'text-gray-500'
                }`}
              >
                <LineChart className="w-4 h-4" />
              </button>
              <button
                onClick={() => setSelectedChart('bar')}
                className={`p-2 rounded-lg transition-all duration-200 ${
                  selectedChart === 'bar' ? 'bg-white shadow-sm text-blue-600' : 'text-gray-500'
                }`}
              >
                <BarChart3 className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="relative">
            <canvas
              ref={chartCanvasRef}
              className="w-full h-80"
              style={{ width: '100%', height: '320px' }}
            />
          </div>

          <div className={`flex items-center justify-center gap-8 mt-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-green-500 rounded-full"></div>
              <span className="text-sm font-medium text-gray-700">{t.revenue}</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-red-500 rounded-full"></div>
              <span className="text-sm font-medium text-gray-700">{t.expenses}</span>
            </div>
          </div>
        </div>

        {/* Pie Chart and Summary */}
        <div className="space-y-6">
          {/* Pie Chart */}
          <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-xl">
            <h3 className={`text-lg font-bold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
              {t.categoryBreakdown}
            </h3>
            
            <div className="relative">
              <canvas
                ref={pieChartCanvasRef}
                className="w-full h-48"
                style={{ width: '100%', height: '192px' }}
              />
            </div>

            <div className="space-y-3 mt-4">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-sm font-medium text-gray-700">{t.revenue}</span>
                </div>
                <span className="text-sm font-bold text-gray-800">
                  {metrics.totalRevenue.toLocaleString()} {t.bhd}
                </span>
              </div>
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span className="text-sm font-medium text-gray-700">{t.expenses}</span>
                </div>
                <span className="text-sm font-bold text-gray-800">
                  {metrics.totalExpenses.toLocaleString()} {t.bhd}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-xl">
            <h3 className={`text-lg font-bold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
              {t.keyInsights}
            </h3>

            <div className="space-y-4">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="text-sm text-gray-600">{t.avgTransaction}</span>
                <span className="text-sm font-semibold text-gray-800">
                  {metrics.avgRevenueTransaction.toLocaleString()} {t.bhd}
                </span>
              </div>

              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="text-sm text-gray-600">{t.highestRevenue}</span>
                <span className="text-sm font-semibold text-green-600">
                  {metrics.highestRevenue.toLocaleString()} {t.bhd}
                </span>
              </div>

              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="text-sm text-gray-600">{t.highestExpense}</span>
                <span className="text-sm font-semibold text-red-600">
                  {metrics.highestExpense.toLocaleString()} {t.bhd}
                </span>
              </div>

              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="text-sm text-gray-600">{t.growthRate}</span>
                <span className={`text-sm font-semibold ${metrics.growthRate >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {metrics.growthRate >= 0 ? '+' : ''}{metrics.growthRate.toFixed(1)}%
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Analysis Table */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 shadow-xl">
        <h3 className={`text-xl font-bold text-gray-800 mb-6 ${isRTL ? 'text-right' : 'text-left'}`}>
          {t.monthlyComparison}
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className={`py-3 px-4 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {language === 'en' ? 'Month' : 'الشهر'}
                </th>
                <th className={`py-3 px-4 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.revenue}
                </th>
                <th className={`py-3 px-4 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.expenses}
                </th>
                <th className={`py-3 px-4 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {metrics.netProfit >= 0 ? t.profit : t.loss}
                </th>
                <th className={`py-3 px-4 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.profitMargin}
                </th>
              </tr>
            </thead>
            <tbody>
              {monthlyData.map((month, index) => (
                <tr key={index} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className={`py-3 px-4 font-medium text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {month.month}
                  </td>
                  <td className={`py-3 px-4 text-green-600 font-semibold ${isRTL ? 'text-right' : 'text-left'}`}>
                    {month.revenue.toLocaleString()} {t.bhd}
                  </td>
                  <td className={`py-3 px-4 text-red-600 font-semibold ${isRTL ? 'text-right' : 'text-left'}`}>
                    {month.expenses.toLocaleString()} {t.bhd}
                  </td>
                  <td className={`py-3 px-4 font-semibold ${month.profit >= 0 ? 'text-green-600' : 'text-red-600'} ${isRTL ? 'text-right' : 'text-left'}`}>
                    {month.profit >= 0 ? '+' : ''}{month.profit.toLocaleString()} {t.bhd}
                  </td>
                  <td className={`py-3 px-4 font-semibold ${isRTL ? 'text-right' : 'text-left'}`}>
                    {month.revenue > 0 ? ((month.profit / month.revenue) * 100).toFixed(1) : '0.0'}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default FinancialReports;