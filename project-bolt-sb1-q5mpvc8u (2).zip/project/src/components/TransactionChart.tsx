import React, { useEffect, useRef, useState } from 'react';
import { TrendingUp, TrendingDown, BarChart3 } from 'lucide-react';

interface ChartData {
  month: string;
  revenue: number;
  expenses: number;
}

interface TransactionChartProps {
  data: ChartData[];
  language: 'en' | 'ar';
  selectedYear?: number;
  onYearChange?: (year: number) => void;
}

const TransactionChart: React.FC<TransactionChartProps> = ({ data, language, selectedYear = new Date().getFullYear(), onYearChange }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [hoveredPoint, setHoveredPoint] = useState<{ x: number; y: number; data: any } | null>(null);
  const [chartType, setChartType] = useState<'line' | 'bar'>('line');
  const [animationProgress, setAnimationProgress] = useState(0);
  const isRTL = language === 'ar';

  const months = {
    en: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    ar: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']
  };

  const translations = {
    en: {
      title: 'Monthly Transactions Overview',
      revenue: 'Revenue',
      expenses: 'Expenses',
      profit: 'Net Profit',
      loss: 'Net Loss',
      total: 'Total',
      average: 'Average',
      highest: 'Highest',
      lowest: 'Lowest',
      noData: 'No transaction data available',
      bhd: 'BHD'
    },
    ar: {
      title: 'نظرة عامة على المعاملات الشهرية',
      revenue: 'الإيرادات',
      expenses: 'المصروفات',
      profit: 'صافي الربح',
      loss: 'صافي الخسارة',
      total: 'الإجمالي',
      average: 'المتوسط',
      highest: 'الأعلى',
      lowest: 'الأقل',
      noData: 'لا توجد بيانات معاملات متاحة',
      bhd: 'د.ب'
    }
  };

  const t = translations[language];

  // Calculate statistics
  const totalRevenue = data.reduce((sum, item) => sum + (item.revenue || 0), 0);
  const totalExpenses = data.reduce((sum, item) => sum + (item.expenses || 0), 0);
  const netProfit = totalRevenue - totalExpenses;
  const avgRevenue = totalRevenue / 12;
  const avgExpenses = totalExpenses / 12;

  const maxRevenue = Math.max(...data.map(d => d.revenue || 0));
  const maxExpenses = Math.max(...data.map(d => d.expenses || 0));
  const minRevenue = Math.min(...data.map(d => d.revenue || 0));
  const minExpenses = Math.min(...data.map(d => d.expenses || 0));

  // Animation effect
  useEffect(() => {
    const duration = 2000;
    const startTime = Date.now();
    
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Easing function for smooth animation
      const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);
      setAnimationProgress(easeOutCubic(progress));
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    
    requestAnimationFrame(animate);
  }, [data]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size with high DPI support
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;
    const padding = 100; // زيادة المساحة للأرقام
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // تحديد القيم الثابتة للمحور Y من 0 إلى 5000
    const minValue = 0;
    const maxValue = 10000;
    const yAxisSteps = 10; // 10 خطوط (0, 500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000)
    const stepValue = maxValue / yAxisSteps;

    // Draw background gradient
    const bgGradient = ctx.createLinearGradient(0, 0, 0, height);
    bgGradient.addColorStop(0, 'rgba(59, 130, 246, 0.02)');
    bgGradient.addColorStop(1, 'rgba(147, 51, 234, 0.02)');
    ctx.fillStyle = bgGradient;
    ctx.fillRect(0, 0, width, height);

    // Draw grid lines with improved styling
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.3)';
    ctx.lineWidth = 1;
    
    // Horizontal grid lines (Y-axis)
    for (let i = 0; i <= yAxisSteps; i++) {
      const y = padding + (chartHeight / yAxisSteps) * i;
      ctx.beginPath();
      ctx.moveTo(padding, y);
      ctx.lineTo(width - padding, y);
      ctx.stroke();
      
      // Add subtle glow effect for major grid lines
      if (i % 2 === 0) {
        ctx.strokeStyle = 'rgba(148, 163, 184, 0.4)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.strokeStyle = 'rgba(148, 163, 184, 0.3)';
        ctx.lineWidth = 1;
      }
    }

    // Vertical grid lines (X-axis)
    for (let i = 0; i <= 11; i++) {
      const x = padding + (chartWidth / 11) * i;
      ctx.beginPath();
      ctx.moveTo(x, padding);
      ctx.lineTo(x, height - padding);
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.2)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    // Draw main axes with improved styling
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 2;
    ctx.beginPath();
    // Y-axis
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, height - padding);
    // X-axis
    ctx.moveTo(padding, height - padding);
    ctx.lineTo(width - padding, height - padding);
    ctx.stroke();

    if (chartType === 'line') {
      // Draw area fills first (behind lines)
      // Revenue area
      const revenueGradient = ctx.createLinearGradient(0, padding, 0, height - padding);
      revenueGradient.addColorStop(0, 'rgba(59, 130, 246, 0.2)');
      revenueGradient.addColorStop(1, 'rgba(59, 130, 246, 0.02)');
      
      ctx.fillStyle = revenueGradient;
      ctx.beginPath();
      ctx.moveTo(padding, height - padding);
      
      data.forEach((point, index) => {
        const x = padding + (chartWidth / 11) * index;
        const y = height - padding - ((point.revenue - minValue) / (maxValue - minValue)) * chartHeight * animationProgress;
        if (index === 0) {
          ctx.lineTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
      
      ctx.lineTo(width - padding, height - padding);
      ctx.closePath();
      ctx.fill();

      // Expenses area
      const expensesGradient = ctx.createLinearGradient(0, padding, 0, height - padding);
      expensesGradient.addColorStop(0, 'rgba(239, 68, 68, 0.2)');
      expensesGradient.addColorStop(1, 'rgba(239, 68, 68, 0.02)');
      
      ctx.fillStyle = expensesGradient;
      ctx.beginPath();
      ctx.moveTo(padding, height - padding);
      
      data.forEach((point, index) => {
        const x = padding + (chartWidth / 11) * index;
        const y = height - padding - ((point.expenses - minValue) / (maxValue - minValue)) * chartHeight * animationProgress;
        if (index === 0) {
          ctx.lineTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
      
      ctx.lineTo(width - padding, height - padding);
      ctx.closePath();
      ctx.fill();

      // Draw revenue line with glow effect
      ctx.shadowColor = 'rgba(59, 130, 246, 0.4)';
      ctx.shadowBlur = 8;
      ctx.strokeStyle = '#3b82f6';
      ctx.lineWidth = 3;
      ctx.beginPath();
      
      data.forEach((point, index) => {
        const x = padding + (chartWidth / 11) * index;
        const y = height - padding - ((point.revenue - minValue) / (maxValue - minValue)) * chartHeight * animationProgress;
        
        if (index === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
      ctx.stroke();

      // Draw expenses line with glow effect
      ctx.shadowColor = 'rgba(239, 68, 68, 0.4)';
      ctx.shadowBlur = 8;
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 3;
      ctx.beginPath();
      
      data.forEach((point, index) => {
        const x = padding + (chartWidth / 11) * index;
        const y = height - padding - ((point.expenses - minValue) / (maxValue - minValue)) * chartHeight * animationProgress;
        
        if (index === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
      ctx.stroke();

      // Reset shadow
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;

      // Draw data points with enhanced styling
      data.forEach((point, index) => {
        const x = padding + (chartWidth / 11) * index;
        
        // Revenue point
        const revenueY = height - padding - ((point.revenue - minValue) / (maxValue - minValue)) * chartHeight * animationProgress;
        
        // Outer glow
        ctx.fillStyle = 'rgba(59, 130, 246, 0.3)';
        ctx.beginPath();
        ctx.arc(x, revenueY, 8, 0, Math.PI * 2);
        ctx.fill();
        
        // Inner circle
        ctx.fillStyle = '#3b82f6';
        ctx.beginPath();
        ctx.arc(x, revenueY, 5, 0, Math.PI * 2);
        ctx.fill();
        
        // White center
        ctx.fillStyle = 'white';
        ctx.beginPath();
        ctx.arc(x, revenueY, 2, 0, Math.PI * 2);
        ctx.fill();
        
        // Expenses point
        const expensesY = height - padding - ((point.expenses - minValue) / (maxValue - minValue)) * chartHeight * animationProgress;
        
        // Outer glow
        ctx.fillStyle = 'rgba(239, 68, 68, 0.3)';
        ctx.beginPath();
        ctx.arc(x, expensesY, 8, 0, Math.PI * 2);
        ctx.fill();
        
        // Inner circle
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(x, expensesY, 5, 0, Math.PI * 2);
        ctx.fill();
        
        // White center
        ctx.fillStyle = 'white';
        ctx.beginPath();
        ctx.arc(x, expensesY, 2, 0, Math.PI * 2);
        ctx.fill();
      });
    } else {
      // Bar chart implementation
      const barWidth = chartWidth / 24; // 2 bars per month
      
      data.forEach((point, index) => {
        const x = padding + (chartWidth / 11) * index;
        
        // Revenue bar
        const revenueHeight = ((point.revenue - minValue) / (maxValue - minValue)) * chartHeight * animationProgress;
        const revenueGradient = ctx.createLinearGradient(0, height - padding - revenueHeight, 0, height - padding);
        revenueGradient.addColorStop(0, '#3b82f6');
        revenueGradient.addColorStop(1, '#1d4ed8');
        
        ctx.fillStyle = revenueGradient;
        ctx.fillRect(x - barWidth, height - padding - revenueHeight, barWidth - 2, revenueHeight);
        
        // Expenses bar
        const expensesHeight = ((point.expenses - minValue) / (maxValue - minValue)) * chartHeight * animationProgress;
        const expensesGradient = ctx.createLinearGradient(0, height - padding - expensesHeight, 0, height - padding);
        expensesGradient.addColorStop(0, '#ef4444');
        expensesGradient.addColorStop(1, '#dc2626');
        
        ctx.fillStyle = expensesGradient;
        ctx.fillRect(x + 2, height - padding - expensesHeight, barWidth - 2, expensesHeight);
      });
    }

    // Draw labels with improved typography and spacing
    ctx.fillStyle = '#475569';
    ctx.font = 'bold 12px Inter, system-ui, sans-serif';
    ctx.textAlign = 'center';
    
    // Month labels (X-axis)
    months[language].forEach((month, index) => {
      const x = padding + (chartWidth / 11) * index;
      ctx.fillText(month, x, height - padding + 30);
    });

    // Y-axis labels with better spacing
    ctx.textAlign = isRTL ? 'right' : 'left';
    ctx.font = 'bold 11px Inter, system-ui, sans-serif';
    ctx.fillStyle = '#374151';
    
    for (let i = 0; i <= yAxisSteps; i++) {
      const value = maxValue - (stepValue * i); // من الأعلى للأسفل
      const y = padding + (chartHeight / yAxisSteps) * i;
      
      // تنسيق الأرقام
      let formattedValue: string;
      if (value >= 1000) {
        formattedValue = `${(value / 1000).toFixed(value % 1000 === 0 ? 0 : 1)}K`;
      } else {
        formattedValue = value.toString();
      }
      
      // رسم الأرقام مع مسافة أكبر من الخطوط
      const labelX = isRTL ? padding + 35 : padding - 35;
      ctx.fillText(formattedValue, labelX, y + 4);
      
      // إضافة خط صغير عند كل قيمة
      ctx.strokeStyle = '#6b7280';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(padding - 8, y);
      ctx.lineTo(padding - 3, y);
      ctx.stroke();
    }

    // إضافة تسمية للمحور Y
    ctx.save();
    ctx.translate(20, height / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillStyle = '#374151';
    ctx.font = 'bold 12px Inter, system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(language === 'en' ? 'Amount (BHD)' : 'المبلغ (د.ب)', 0, 0);
    ctx.restore();

  }, [data, language, isRTL, chartType, animationProgress]);

  // Handle mouse events for interactivity
  const handleMouseMove = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    if (!rect) return;
    
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    // Check if mouse is over a data point
    const padding = 100;
    const chartWidth = rect.width - padding * 2;
    
    data.forEach((point, index) => {
      const pointX = padding + (chartWidth / 11) * index;
      const distance = Math.abs(x - pointX);
      
      if (distance < 25) {
        setHoveredPoint({
          x: pointX,
          y: y,
          data: { ...point, month: months[language][index] }
        });
      }
    });
  };

  const handleMouseLeave = () => {
    setHoveredPoint(null);
  };

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/20">
      {/* Header */}
      <div className={`mb-8 ${isRTL ? 'text-right' : 'text-left'}`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">
              {t.title}
            </h3>
            <p className="text-gray-600 text-sm">
              {language === 'en' ? 'Track your financial performance over time (0 - 10,000 BHD)' : 'تتبع أداءك المالي عبر الزمن (0 - 10,000 د.ب)'}
            </p>
          </div>
          
          {/* Chart Type Toggle */}
          <div className="flex items-center gap-2 bg-gray-100 rounded-xl p-1">
            <button
              onClick={() => setChartType('line')}
              className={`p-2 rounded-lg transition-all duration-200 ${
                chartType === 'line' 
                  ? 'bg-white shadow-sm text-blue-600' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
            </button>
            <button
              onClick={() => setChartType('bar')}
              className={`p-2 rounded-lg transition-all duration-200 ${
                chartType === 'bar' 
                  ? 'bg-white shadow-sm text-blue-600' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
            </button>
          </div>
          
          {/* Year Filter */}
          {onYearChange && (
            <select
              value={selectedYear}
              onChange={(e) => onYearChange(Number(e.target.value))}
              className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm font-medium text-gray-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {Array.from({ length: 21 }, (_, i) => 2025 + i).map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          )}
        </div>

        {/* Legend and Statistics */}
        <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div className={`flex items-center gap-8 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full shadow-sm"></div>
              <span className="text-sm font-medium text-gray-700">{t.revenue}</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-gradient-to-r from-red-500 to-red-600 rounded-full shadow-sm"></div>
              <span className="text-sm font-medium text-gray-700">{t.expenses}</span>
            </div>
          </div>
          
          {/* Quick Stats */}
          <div className={`flex items-center gap-6 text-xs ${isRTL ? 'flex-row-reverse' : ''}`}>
            <div className={`text-center ${isRTL ? 'text-right' : 'text-left'}`}>
              <div className="text-gray-500">{t.total}</div>
              <div className={`font-semibold ${netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {netProfit >= 0 ? '+' : ''}{netProfit.toLocaleString()} {t.bhd}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Chart Container */}
      <div className="relative">
        {totalRevenue === 0 && totalExpenses === 0 ? (
          <div className="flex flex-col items-center justify-center h-80 text-gray-500">
            <BarChart3 className="w-16 h-16 mb-4 opacity-30" />
            <p className="text-lg font-medium">{t.noData}</p>
            <p className="text-sm mt-2">
              {language === 'en' 
                ? 'Start adding transactions to see your financial overview' 
                : 'ابدأ بإضافة المعاملات لرؤية نظرتك المالية العامة'
              }
            </p>
          </div>
        ) : (
          <>
            <canvas
              ref={canvasRef}
              className="w-full h-96 cursor-crosshair"
              style={{ width: '100%', height: '384px' }}
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
            />
            
            {/* Tooltip */}
            {hoveredPoint && (
              <div 
                className="absolute bg-gray-900 text-white px-4 py-3 rounded-lg shadow-xl pointer-events-none z-10 text-sm border border-gray-700"
                style={{
                  left: hoveredPoint.x - 80,
                  top: hoveredPoint.y - 100,
                  transform: 'translateX(-50%)'
                }}
              >
                <div className="font-semibold mb-2 text-center">{hoveredPoint.data.month}</div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <span className="text-blue-300">{t.revenue}: {hoveredPoint.data.revenue.toLocaleString()} {t.bhd}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span className="text-red-300">{t.expenses}: {hoveredPoint.data.expenses.toLocaleString()} {t.bhd}</span>
                  </div>
                  <div className="border-t border-gray-600 pt-1 mt-2">
                    <div className={`font-medium text-center ${(hoveredPoint.data.revenue - hoveredPoint.data.expenses) >= 0 ? 'text-green-300' : 'text-red-300'}`}>
                      {(hoveredPoint.data.revenue - hoveredPoint.data.expenses) >= 0 ? t.profit : t.loss}: {Math.abs(hoveredPoint.data.revenue - hoveredPoint.data.expenses).toLocaleString()} {t.bhd}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Summary Statistics */}
      {(totalRevenue > 0 || totalExpenses > 0) && (
        <div className="mt-8 pt-6 border-t border-gray-200">
          <div className={`grid grid-cols-2 md:grid-cols-4 gap-4 ${isRTL ? 'text-right' : 'text-left'}`}>
            <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">
              <div className="text-blue-600 text-sm font-medium">{t.average} {t.revenue}</div>
              <div className="text-blue-800 font-bold text-lg">{avgRevenue.toLocaleString()} {t.bhd}</div>
            </div>
            <div className="bg-red-50 rounded-xl p-4 border border-red-100">
              <div className="text-red-600 text-sm font-medium">{t.average} {t.expenses}</div>
              <div className="text-red-800 font-bold text-lg">{avgExpenses.toLocaleString()} {t.bhd}</div>
            </div>
            <div className="bg-green-50 rounded-xl p-4 border border-green-100">
              <div className="text-green-600 text-sm font-medium">{t.highest} {t.revenue}</div>
              <div className="text-green-800 font-bold text-lg">{maxRevenue.toLocaleString()} {t.bhd}</div>
            </div>
            <div className="bg-purple-50 rounded-xl p-4 border border-purple-100">
              <div className="text-purple-600 text-sm font-medium">{netProfit >= 0 ? t.profit : t.loss}</div>
              <div className={`font-bold text-lg ${netProfit >= 0 ? 'text-green-800' : 'text-red-800'}`}>
                {Math.abs(netProfit).toLocaleString()} {t.bhd}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TransactionChart;