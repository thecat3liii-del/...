import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Download, 
  Printer, 
  FileText, 
  Calendar,
  User,
  Mail,
  Phone,
  MapPin,
  Hash,
  DollarSign,
  Save,
  Plus,
  Trash2,
  Edit3,
  Package
} from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { serviceService, invoiceService } from '../lib/supabase';

interface InvoiceItem {
  id: string;
  name: string;
  category: string;
  subcategory?: string;
  price: number;
  quantity: number;
  total: number;
  description?: string;
}

interface Invoice {
  id: string;
  boss_id: string;
  invoice_number: string;
  client_id?: string;
  client_name?: string;
  client_email?: string;
  client_phone?: string;
  client_address?: string;
  issue_date: string;
  due_date: string;
  items: InvoiceItem[];
  subtotal: number;
  tax_rate: number;
  tax_amount: number;
  discount_rate: number;
  discount_amount: number;
  total_amount: number;
  notes?: string;
  status: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface Service {
  id: string;
  name: string;
  description?: string;
  price: number;
  category?: string;
  subcategory?: string;
  isActive: boolean;
}

interface InvoiceEditModalProps {
  invoice: Invoice;
  language: 'en' | 'ar';
  onClose: () => void;
  onSuccess: () => void;
}

const InvoiceEditModal: React.FC<InvoiceEditModalProps> = ({ invoice, language, onClose, onSuccess }) => {
  const [services, setServices] = useState<Service[]>([]);
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>(invoice.items || []);
  const [customLogo, setCustomLogo] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [invoiceData, setInvoiceData] = useState({
    invoiceNumber: invoice.invoice_number,
    issueDate: invoice.issue_date,
    dueDate: invoice.due_date,
    clientName: invoice.client_name || '',
    clientEmail: invoice.client_email || '',
    clientPhone: invoice.client_phone || '',
    clientAddress: invoice.client_address || '',
    notes: invoice.notes || '',
    taxRate: invoice.tax_rate,
    discountRate: invoice.discount_rate,
    status: invoice.status
  });

  const invoiceRef = useRef<HTMLDivElement>(null);
  const isRTL = language === 'ar';

  // Get current user from localStorage to access boss ID
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Generate unique database key for current boss
  const getBossDataKey = (dataType: string) => {
    const currentUser = getCurrentUser();
    if (!currentUser) return null;
    return `spaceZone_boss_${currentUser.id}_${dataType}`;
  };

  // Load services and custom logo
  useEffect(() => {
    const loadServices = async () => {
      const currentUser = getCurrentUser();
      if (!currentUser) return;
      
      try {
        const result = await serviceService.getServices(currentUser.id);
        if (result.success) {
          const convertedServices = result.data.map((s: any) => ({
            id: s.id,
            name: s.name,
            description: s.description,
            price: s.price,
            category: s.category,
            subcategory: s.subcategory,
            isActive: s.is_active
          }));
          setServices(convertedServices);
        }
      } catch (error) {
        console.error('Error loading services:', error);
      }
    };

    const loadCustomLogo = () => {
      const logoKey = getBossDataKey('customLogo');
      if (!logoKey) return;
      
      const savedLogo = localStorage.getItem(logoKey);
      if (savedLogo) {
        try {
          const logoData = JSON.parse(savedLogo);
          setCustomLogo(logoData?.logoImage || null);
        } catch (error) {
          console.error('Error parsing logo:', error);
          setCustomLogo(null);
        }
      }
    };

    loadServices();
    loadCustomLogo();

    // Listen for logo updates
    const handleLogoUpdate = (event: CustomEvent) => {
      setCustomLogo(event.detail);
    };

    window.addEventListener('logoUpdated', handleLogoUpdate as EventListener);

    return () => {
      window.removeEventListener('logoUpdated', handleLogoUpdate as EventListener);
    };
  }, []);

  const translations = {
    en: {
      title: 'Edit Invoice',
      invoiceNumber: 'Invoice Number',
      issueDate: 'Issue Date',
      dueDate: 'Due Date',
      billTo: 'Bill To',
      clientName: 'Client Name',
      clientEmail: 'Client Email',
      clientPhone: 'Client Phone',
      clientAddress: 'Client Address',
      description: 'Description',
      itemName: 'Item Name',
      category: 'Category',
      subcategory: 'Subcategory',
      price: 'Unit Price',
      quantity: 'Qty',
      total: 'Total',
      subtotal: 'Subtotal',
      tax: 'Tax',
      discount: 'Discount',
      grandTotal: 'Grand Total',
      notes: 'Notes',
      taxRate: 'Tax Rate (%)',
      discountRate: 'Discount Rate (%)',
      downloadPDF: 'Download PDF',
      print: 'Print',
      save: 'Save Changes',
      close: 'Close',
      bhd: 'BHD',
      companyInfo: 'Space Zone Accounting',
      companyAddress: 'Business Management System',
      invoiceTerms: 'Payment is due within 30 days from the invoice date.',
      thankYou: 'Thank you for your business!',
      enterClientName: 'Enter client name',
      enterClientEmail: 'Enter client email',
      enterClientPhone: 'Enter client phone',
      enterClientAddress: 'Enter client address',
      enterNotes: 'Enter additional notes',
      invoiceUpdated: 'Invoice updated successfully',
      required: 'Required',
      addItem: 'Add Item',
      removeItem: 'Remove Item',
      editItem: 'Edit Item',
      enterItemName: 'Enter item name',
      enterCategory: 'Enter category',
      enterSubcategory: 'Enter subcategory',
      enterPrice: 'Enter unit price',
      items: 'Items',
      noItems: 'No items added',
      itemDetails: 'Item Details',
      status: 'Status',
      draft: 'Draft',
      sent: 'Sent',
      paid: 'Paid',
      overdue: 'Overdue',
      cancelled: 'Cancelled'
    },
    ar: {
      title: 'تعديل الفاتورة',
      invoiceNumber: 'رقم الفاتورة',
      issueDate: 'تاريخ الإصدار',
      dueDate: 'تاريخ الاستحقاق',
      billTo: 'فاتورة إلى',
      clientName: 'اسم العميل',
      clientEmail: 'بريد العميل الإلكتروني',
      clientPhone: 'هاتف العميل',
      clientAddress: 'عنوان العميل',
      description: 'الوصف',
      itemName: 'اسم العنصر',
      category: 'الفئة',
      subcategory: 'الفئة الفرعية',
      price: 'سعر الوحدة',
      quantity: 'الكمية',
      total: 'الإجمالي',
      subtotal: 'المجموع الفرعي',
      tax: 'الضريبة',
      discount: 'الخصم',
      grandTotal: 'الإجمالي النهائي',
      notes: 'ملاحظات',
      taxRate: 'معدل الضريبة (%)',
      discountRate: 'معدل الخصم (%)',
      downloadPDF: 'تحميل PDF',
      print: 'طباعة',
      save: 'حفظ التغييرات',
      close: 'إغلاق',
      bhd: 'د.ب',
      companyInfo: 'سبيس زون للمحاسبة',
      companyAddress: 'نظام إدارة الأعمال',
      invoiceTerms: 'الدفع مستحق خلال 30 يوماً من تاريخ الفاتورة.',
      thankYou: 'شكراً لك على تعاملك معنا!',
      enterClientName: 'أدخل اسم العميل',
      enterClientEmail: 'أدخل بريد العميل الإلكتروني',
      enterClientPhone: 'أدخل هاتف العميل',
      enterClientAddress: 'أدخل عنوان العميل',
      enterNotes: 'أدخل ملاحظات إضافية',
      invoiceUpdated: 'تم تحديث الفاتورة بنجاح',
      required: 'مطلوب',
      addItem: 'إضافة عنصر',
      removeItem: 'إزالة العنصر',
      editItem: 'تعديل العنصر',
      enterItemName: 'أدخل اسم العنصر',
      enterCategory: 'أدخل الفئة',
      enterSubcategory: 'أدخل الفئة الفرعية',
      enterPrice: 'أدخل سعر الوحدة',
      items: 'العناصر',
      noItems: 'لم يتم إضافة عناصر',
      itemDetails: 'تفاصيل العنصر',
      status: 'الحالة',
      draft: 'مسودة',
      sent: 'مرسل',
      paid: 'مدفوع',
      overdue: 'متأخر',
      cancelled: 'ملغي'
    }
  };

  const t = translations[language];

  // Calculate totals
  const subtotal = invoiceItems.reduce((sum, item) => sum + item.total, 0);
  const taxAmount = (subtotal * invoiceData.taxRate) / 100;
  const discountAmount = (subtotal * invoiceData.discountRate) / 100;
  const grandTotal = subtotal + taxAmount - discountAmount;

  const handleInputChange = (field: string, value: string | number) => {
    setInvoiceData(prev => ({ ...prev, [field]: value }));
  };

  // Add new item
  const addItem = () => {
    const newItem: InvoiceItem = {
      id: `item-${Date.now()}`,
      name: '',
      category: '',
      subcategory: '',
      price: 0,
      quantity: 1,
      total: 0
    };
    setInvoiceItems(prev => [...prev, newItem]);
  };

  // Remove item
  const removeItem = (itemId: string) => {
    setInvoiceItems(prev => prev.filter(item => item.id !== itemId));
  };

  // Update item
  const updateItem = (itemId: string, field: keyof InvoiceItem, value: string | number) => {
    setInvoiceItems(prev => prev.map(item => {
      if (item.id === itemId) {
        const updatedItem = { ...item, [field]: value };
        
        // Recalculate total when price or quantity changes
        if (field === 'price' || field === 'quantity') {
          updatedItem.total = updatedItem.price * updatedItem.quantity;
        }
        
        return updatedItem;
      }
      return item;
    }));
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!invoiceData.clientName.trim()) {
      setError('Client name is required');
      return;
    }

    if (invoiceItems.length === 0) {
      setError('Please add at least one item');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const currentUser = getCurrentUser();
      if (!currentUser) {
        setError('User not found');
        return;
      }

      // Prepare updated invoice data
      const updatedInvoiceData = {
        client_name: invoiceData.clientName,
        client_email: invoiceData.clientEmail || null,
        client_phone: invoiceData.clientPhone || null,
        client_address: invoiceData.clientAddress || null,
        issue_date: invoiceData.issueDate,
        due_date: invoiceData.dueDate,
        items: invoiceItems,
        subtotal: subtotal,
        tax_rate: invoiceData.taxRate,
        tax_amount: taxAmount,
        discount_rate: invoiceData.discountRate,
        discount_amount: discountAmount,
        total_amount: grandTotal,
        notes: invoiceData.notes || null,
        status: invoiceData.status
      };

      const result = await invoiceService.updateInvoice(invoice.id, updatedInvoiceData);

      if (result.success) {
        setSuccess(t.invoiceUpdated);
        setTimeout(() => {
          onSuccess();
          onClose();
        }, 1500);
      } else {
        setError(result.error || 'Failed to update invoice');
      }
    } catch (error) {
      console.error('Error updating invoice:', error);
      setError('Failed to update invoice. Please try again.');
    }
    
    setIsLoading(false);
  };

  const handleDownloadPDF = async () => {
    if (!invoiceRef.current) return;

    try {
      const canvas = await html2canvas(invoiceRef.current, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#f5f1eb'
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
      const imgX = (pdfWidth - imgWidth * ratio) / 2;
      const imgY = 0;

      pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
      pdf.save(`${invoiceData.invoiceNumber}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
    }
  };

  const handlePrint = () => {
    if (!invoiceRef.current) return;
    
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>${t.title} - ${invoiceData.invoiceNumber}</title>
          <style>
            body { 
              font-family: 'Arial', sans-serif; 
              margin: 0; 
              padding: 20px; 
              background-color: #f5f1eb;
            }
            .invoice-container { max-width: 800px; margin: 0 auto; }
            .no-print { display: none !important; }
            @media print {
              body { margin: 0; background-color: #f5f1eb; }
              .invoice-container { max-width: none; }
            }
          </style>
        </head>
        <body>
          ${invoiceRef.current.innerHTML}
        </body>
      </html>
    `);
    
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 250);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-6xl w-full max-h-[95vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className={`flex items-center justify-between p-6 border-b border-gray-200 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <div className="p-2 bg-blue-100 rounded-xl">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
            <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
              <h2 className="text-2xl font-bold text-gray-800">{t.title}</h2>
              <p className="text-gray-600 text-sm">#{invoiceData.invoiceNumber}</p>
            </div>
          </div>

          <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <button
              onClick={handleDownloadPDF}
              className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Download className="w-4 h-4" />
              {t.downloadPDF}
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Printer className="w-4 h-4" />
              {t.print}
            </button>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6">
          {/* Success/Error Messages */}
          {success && (
            <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-2xl mb-6 animate-fadeIn flex items-center gap-2">
              <Save className="w-5 h-5" />
              {success}
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl mb-6 animate-fadeIn">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Invoice Form */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Invoice Details */}
              <div className="space-y-4">
                <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {language === 'en' ? 'Invoice Details' : 'تفاصيل الفاتورة'}
                </h3>
                
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.invoiceNumber}
                  </label>
                  <input
                    type="text"
                    value={invoiceData.invoiceNumber}
                    readOnly
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 text-gray-700 cursor-not-allowed"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.issueDate}
                    </label>
                    <input
                      type="date"
                      value={invoiceData.issueDate}
                      onChange={(e) => handleInputChange('issueDate', e.target.value)}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.dueDate}
                    </label>
                    <input
                      type="date"
                      value={invoiceData.dueDate}
                      onChange={(e) => handleInputChange('dueDate', e.target.value)}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.status}
                  </label>
                  <select
                    value={invoiceData.status}
                    onChange={(e) => handleInputChange('status', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="draft">{t.draft}</option>
                    <option value="sent">{t.sent}</option>
                    <option value="paid">{t.paid}</option>
                    <option value="overdue">{t.overdue}</option>
                    <option value="cancelled">{t.cancelled}</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.taxRate}
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      value={invoiceData.taxRate}
                      onChange={(e) => handleInputChange('taxRate', parseFloat(e.target.value) || 0)}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.discountRate}
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      value={invoiceData.discountRate}
                      onChange={(e) => handleInputChange('discountRate', parseFloat(e.target.value) || 0)}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              {/* Client Details */}
              <div className="space-y-4">
                <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.billTo}
                </h3>
                
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.clientName} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={invoiceData.clientName}
                    onChange={(e) => handleInputChange('clientName', e.target.value)}
                    placeholder={t.enterClientName}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.clientEmail}
                  </label>
                  <input
                    type="email"
                    value={invoiceData.clientEmail}
                    onChange={(e) => handleInputChange('clientEmail', e.target.value)}
                    placeholder={t.enterClientEmail}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.clientPhone}
                  </label>
                  <input
                    type="tel"
                    value={invoiceData.clientPhone}
                    onChange={(e) => handleInputChange('clientPhone', e.target.value)}
                    placeholder={t.enterClientPhone}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.clientAddress}
                  </label>
                  <textarea
                    value={invoiceData.clientAddress}
                    onChange={(e) => handleInputChange('clientAddress', e.target.value)}
                    placeholder={t.enterClientAddress}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  />
                </div>
              </div>
            </div>

            {/* Items Section */}
            <div>
              <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.items}
                </h3>
                <button
                  type="button"
                  onClick={addItem}
                  className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <Plus className="w-4 h-4" />
                  {t.addItem}
                </button>
              </div>

              <div className="space-y-4">
                {invoiceItems.map((item, index) => (
                  <div key={item.id} className="bg-gray-50 rounded-2xl p-6 border border-gray-200">
                    <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <h4 className={`font-medium text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {language === 'en' ? `Item ${index + 1}` : `العنصر ${index + 1}`}
                      </h4>
                      {invoiceItems.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeItem(item.id)}
                          className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                          title={t.removeItem}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                      {/* Service Selection */}
                      <div className="lg:col-span-5 mb-4">
                        <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                          {language === 'en' ? 'Select Service/Product' : 'اختر الخدمة/المنتج'}
                        </label>
                        
                        {/* Structured Dropdown Flow */}
                        <div className="space-y-4">
                          {/* Step 1: Product/Service Selection */}
                          <div>
                            <label className={`block text-xs font-medium text-gray-600 mb-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                              {language === 'en' ? 'Step 1: Select Product/Service' : 'الخطوة 1: اختر المنتج/الخدمة'}
                            </label>
                            <select
                              value={item.serviceId || ''}
                              onChange={(e) => {
                                const serviceId = e.target.value;
                                updateItem(item.id, 'serviceId', serviceId);
                                
                                if (serviceId) {
                                  const selectedService = services.find(s => s.id === serviceId);
                                  if (selectedService) {
                                    updateItem(item.id, 'name', selectedService.name);
                                    updateItem(item.id, 'price', selectedService.price);
                                    updateItem(item.id, 'description', selectedService.description || '');
                                    // Don't auto-fill category and subcategory - let user choose
                                  }
                                } else {
                                  // Clear service-related data when custom is selected
                                  updateItem(item.id, 'name', '');
                                  updateItem(item.id, 'price', 0);
                                  updateItem(item.id, 'description', '');
                                }
                              }}
                              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                            >
                              <option value="">{language === 'en' ? 'Custom Item' : 'عنصر مخصص'}</option>
                              {/* عرض الأسماء الفريدة فقط */}
                              {Array.from(new Set(
                                services
                                  .filter(s => s.isActive && s.availability_active !== false)
                                  .map(s => s.name)
                              )).map(uniqueName => {
                                // العثور على أول خدمة بهذا الاسم لعرض السعر
                                const firstService = services.find(s => 
                                  s.name === uniqueName && 
                                  s.isActive && 
                                  s.availability_active !== false
                                );
                                return (
                                  <option key={uniqueName} value={firstService?.id || ''}>
                                    {uniqueName} - {firstService?.price || 0} {t.bhd}
                                  </option>
                                );
                              })}
                            </select>
                          </div>

                          {/* Step 2: Category Selection */}
                          <div>
                            <label className={`block text-xs font-medium text-gray-600 mb-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                              {language === 'en' ? 'Step 2: Select Category' : 'الخطوة 2: اختر الفئة'}
                            </label>
                            <select
                              value={item.selectedCategory || ''}
                              onChange={(e) => {
                                const selectedCategory = e.target.value;
                                updateItem(item.id, 'selectedCategory', selectedCategory);
                                updateItem(item.id, 'category', selectedCategory);
                                // Clear subcategory when category changes
                                updateItem(item.id, 'selectedSubcategory', '');
                                updateItem(item.id, 'subcategory', '');
                              }}
                              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                            >
                              <option value="">{language === 'en' ? 'Select Category' : 'اختر الفئة'}</option>
                              {/* عرض الفئات المرتبطة بالخدمة المختارة فقط */}
                              {item.serviceId ? (
                                // إذا تم اختيار خدمة محددة، عرض فئاتها فقط
                                Array.from(new Set(
                                  services
                                    .filter(s => 
                                      s.isActive && 
                                      s.name === item.name && 
                                      s.category
                                    )
                                    .map(s => s.category)
                                )).map(category => (
                                  <option key={category} value={category}>
                                    {category}
                                  </option>
                                ))
                              ) : (
                                // إذا لم يتم اختيار خدمة، عرض جميع الفئات
                                Array.from(new Set(
                                  services
                                    .filter(s => s.isActive && s.category)
                                    .map(s => s.category)
                                )).map(category => (
                                  <option key={category} value={category}>
                                    {category}
                                  </option>
                                ))
                              )}
                              <option value="custom">{language === 'en' ? 'Custom Category' : 'فئة مخصصة'}</option>
                            </select>
                          </div>

                          {/* Step 3: Subcategory Selection (only if category is selected) */}
                          {item.selectedCategory && (
                            <div>
                              <label className={`block text-xs font-medium text-gray-600 mb-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                                {language === 'en' ? 'Step 3: Select Subcategory' : 'الخطوة 3: اختر الفئة الفرعية'}
                              </label>
                              <select
                                value={item.selectedSubcategory || ''}
                                onChange={(e) => {
                                  const selectedSubcategory = e.target.value;
                                  updateItem(item.id, 'selectedSubcategory', selectedSubcategory);
                                  updateItem(item.id, 'subcategory', selectedSubcategory);
                                }}
                                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                              >
                                <option value="">{language === 'en' ? 'Select Subcategory' : 'اختر الفئة الفرعية'}</option>
                                {/* عرض الفئات الفرعية المرتبطة بالخدمة والفئة المختارة */}
                                {item.serviceId ? (
                                  // إذا تم اختيار خدمة محددة، عرض فئاتها الفرعية المرتبطة بالفئة المختارة
                                  Array.from(new Set(
                                    services
                                      .filter(s => 
                                        s.isActive && 
                                        s.name === item.name && 
                                        s.category === item.selectedCategory && 
                                        s.subcategory
                                      )
                                      .map(s => s.subcategory)
                                  )).map(subcategory => (
                                    <option key={subcategory} value={subcategory}>
                                      {subcategory}
                                    </option>
                                  ))
                                ) : (
                                  // إذا لم يتم اختيار خدمة، عرض جميع الفئات الفرعية للفئة المختارة
                                  Array.from(new Set(
                                    services
                                      .filter(s => s.isActive && s.category === item.selectedCategory && s.subcategory)
                                      .map(s => s.subcategory)
                                  )).map(subcategory => (
                                    <option key={subcategory} value={subcategory}>
                                      {subcategory}
                                    </option>
                                  ))
                                )}
                                <option value="custom">{language === 'en' ? 'Custom Subcategory' : 'فئة فرعية مخصصة'}</option>
                              </select>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Item Name */}
                      <div className="lg:col-span-2">
                        <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                          {t.itemName}
                        </label>
                        <input
                          type="text"
                          value={item.name}
                          onChange={(e) => updateItem(item.id, 'name', e.target.value)}
                          placeholder={t.enterItemName}
                          className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        />
                      </div>
                      
                      {/* Quantity */}
                      <div>
                        <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                          {t.quantity}
                        </label>
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => updateItem(item.id, 'quantity', parseInt(e.target.value) || 1)}
                          className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        />
                      </div>

                      {/* Total Amount */}
                      <div className="lg:col-span-2">
                        <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                          {t.total}
                        </label>
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          value={item.total}
                          onChange={(e) => updateItem(item.id, 'total', parseFloat(e.target.value) || 0)}
                          placeholder="Enter total amount"
                          className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        />
                      </div>
                    </div>

                    {/* Category and Subcategory */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                      <div>
                        <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                          {t.category} {item.selectedCategory === 'custom' ? `(${language === 'en' ? 'Custom' : 'مخصص'})` : ''}
                        </label>
                        <textarea
                          value={item.category}
                          onChange={(e) => updateItem(item.id, 'category', e.target.value)}
                          placeholder={t.enterCategory}
                          rows={3}
                          className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm resize-none"
                        />
                      </div>

                      <div>
                        <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                          {t.subcategory} {item.selectedSubcategory === 'custom' ? `(${language === 'en' ? 'Custom' : 'مخصص'})` : ''}
                        </label>
                        <textarea
                          value={item.subcategory || ''}
                          onChange={(e) => updateItem(item.id, 'subcategory', e.target.value)}
                          placeholder={t.enterSubcategory}
                          rows={3}
                          className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm resize-none"
                        />
                      </div>
                    </div>

                    {/* Item Total */}
                    <div className={`mt-4 pt-4 border-t border-gray-200 ${isRTL ? 'text-left' : 'text-right'}`}>
                      <div className="text-sm text-gray-600">{t.total}:</div>
                      <div className="text-lg font-bold text-blue-600">
                        {item.total.toLocaleString()} {t.bhd}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.notes}
              </label>
              <textarea
                value={invoiceData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                placeholder={t.enterNotes}
                rows={3}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              />
            </div>

            {/* Totals Summary */}
            <div className="bg-white rounded-2xl p-6 border border-gray-200">
              <div className="space-y-3">
                <div className={`flex justify-between items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <span className="text-gray-600">{t.subtotal}:</span>
                  <span className="font-semibold text-gray-800">{subtotal.toLocaleString()} {t.bhd}</span>
                </div>
                
                {invoiceData.taxRate > 0 && (
                  <div className={`flex justify-between items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <span className="text-gray-600">{t.tax} ({invoiceData.taxRate}%):</span>
                    <span className="font-semibold text-gray-800">{taxAmount.toLocaleString()} {t.bhd}</span>
                  </div>
                )}
                
                {invoiceData.discountRate > 0 && (
                  <div className={`flex justify-between items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <span className="text-red-600">{t.discount} ({invoiceData.discountRate}%):</span>
                    <span className="font-semibold text-red-600">-{discountAmount.toLocaleString()} {t.bhd}</span>
                  </div>
                )}
                
                <div className={`flex justify-between items-center pt-3 border-t border-gray-200 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <span className="text-lg font-bold text-gray-800">{t.grandTotal}:</span>
                  <span className="text-xl font-bold text-blue-600">{grandTotal.toLocaleString()} {t.bhd}</span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className={`flex gap-4 pt-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
              >
                {isLoading ? (
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    {language === 'en' ? 'Saving...' : 'جاري الحفظ...'}
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-2">
                    <Save className="w-5 h-5" />
                    {t.save}
                  </div>
                )}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
              >
                {t.close}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default InvoiceEditModal;