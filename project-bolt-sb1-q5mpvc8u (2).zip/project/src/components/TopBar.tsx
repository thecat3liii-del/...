import React from 'react';
import { Globe, Bell, LogOut, User } from 'lucide-react';

interface TopBarProps {
  language: 'en' | 'ar';
  onLanguageChange: () => void;
  onLogout: () => void;
  userProfileImage?: string;
  userName?: string;
  isSidebarCollapsed?: boolean;
}

const TopBar: React.FC<TopBarProps> = ({ language, onLanguageChange, onLogout, userProfileImage, userName, isSidebarCollapsed = false }) => {
  const isRTL = language === 'ar';

  // Get current user from localStorage to access profile image
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Generate unique database key for current boss
  const getBossDataKey = (dataType: string) => {
    const currentUser = getCurrentUser();
    if (!currentUser) return null;
    return `spaceZone_boss_${currentUser.id}_${dataType}`;
  };

  // Get profile image from localStorage
  const getProfileImage = () => {
    // First check if user has profileImageUrl from database
    const currentUser = getCurrentUser();
    if (currentUser?.profileImageUrl) return currentUser.profileImageUrl;
    
    if (userProfileImage) return userProfileImage;
    
    const profileKey = getBossDataKey('profile');
    if (!profileKey) return null;
    
    const savedProfile = localStorage.getItem(profileKey);
    if (savedProfile) {
      try {
        const profile = JSON.parse(savedProfile);
        return profile?.profileImage || null;
      } catch (error) {
        console.error('Error parsing profile:', error);
        return null;
      }
    }
    return null;
  };

  const profileImage = getProfileImage();

  return (
    <div className={`flex items-center gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
      {/* Profile Picture */}
      <div className="relative">
        <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-white shadow-lg bg-gradient-to-r from-blue-500 to-indigo-500 flex items-center justify-center">
          {profileImage ? (
            <img
              src={profileImage}
              alt={userName || 'Profile'}
              className="w-full h-full object-cover"
              onError={(e) => {
                // Fallback to initials if image fails to load
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
                target.nextElementSibling?.classList.remove('hidden');
              }}
            />
          ) : null}
          <div className={`${profileImage ? 'hidden' : 'flex'} items-center justify-center w-full h-full text-white font-semibold text-lg`}>
            {userName ? userName.charAt(0).toUpperCase() : <User className="w-6 h-6" />}
          </div>
        </div>
        
        {/* Online status indicator */}
        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
      </div>
      {/* Language Switch */}

      {/* Logout */}
      <button
        onClick={onLogout}
        className="flex items-center gap-2 bg-gradient-to-r from-red-500 to-rose-500 text-white px-4 py-2 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:from-red-600 hover:to-rose-600 group"
      >
        <LogOut className="w-4 h-4 group-hover:scale-110 transition-transform" />
        <span className="text-sm font-medium">
          {language === 'en' ? 'Logout' : 'خروج'}
        </span>
      </button>
    </div>
  );
};

export default TopBar;