import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Users, 
  Calendar,
  BarChart3,
  PieChart,
  Activity,
  Target,
  Award,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  Eye,
  FileText,
  CreditCard
} from 'lucide-react';
import StatCard from './StatCard';
import TransactionChart from './TransactionChart';
import RecentActivity from './RecentActivity';
import QuickActions from './QuickActions';
import PerformanceMetrics from './PerformanceMetrics';
import { clientService, transactionService } from '../lib/supabase';
import type { Transaction as SupabaseTransaction } from '../lib/supabase';

interface Transaction {
  id: string;
  type: 'revenue' | 'expense';
  amount: number;
  description: string;
  date: string;
  month: number;
  year: number;
}

interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  dateAdded: string;
  isActive: boolean;
}

interface User {
  id: string;
  fullName: string;
  email: string;
  role: 'boss' | 'employee';
}

interface DashboardProps {
  user: User;
  language: 'en' | 'ar';
  bossId?: string;
  onPageChange: (page: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, language, bossId, onPageChange }) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [clients, setClients] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedChartYear, setSelectedChartYear] = useState(new Date().getFullYear());
  const isRTL = language === 'ar';

  // Get current user from localStorage to access boss ID
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Generate unique database key for current boss
  const getBossDataKey = (dataType: string) => {
    const currentUser = getCurrentUser();
    if (!currentUser) return null;
    const targetBossId = bossId || currentUser.id;
    return `spaceZone_boss_${targetBossId}_${dataType}`;
  };

  const translations = {
    en: {
      welcome: 'Welcome back',
      dashboard: 'Dashboard',
      overview: 'Business Overview',
      totalRevenue: 'Total Revenue',
      totalExpenses: 'Total Expenses',
      netProfit: 'Net Profit',
      netLoss: 'Net Loss',
      totalClients: 'Total Clients',
      activeClients: 'Active Clients',
      thisMonth: 'This Month',
      lastMonth: 'Last Month',
      monthlyGrowth: 'Monthly Growth',
      profitMargin: 'Profit Margin',
      expenseRatio: 'Expense Ratio',
      clientGrowth: 'Client Growth',
      recentTransactions: 'Recent Transactions',
      quickActions: 'Quick Actions',
      performanceMetrics: 'Performance Metrics',
      financialSummary: 'Financial Summary',
      businessInsights: 'Business Insights',
      viewAll: 'View All',
      addTransaction: 'Add Transaction',
      viewReports: 'View Reports',
      manageClients: 'Manage Clients',
      bhd: 'BHD',
      noData: 'No data available',
      loadingData: 'Loading dashboard data...',
      goodMorning: 'Good Morning',
      goodAfternoon: 'Good Afternoon',
      goodEvening: 'Good Evening',
      todaysDate: "Today's Date",
      businessHealth: 'Business Health',
      excellent: 'Excellent',
      good: 'Good',
      average: 'Average',
      needsAttention: 'Needs Attention'
    },
    ar: {
      welcome: 'مرحباً بعودتك',
      dashboard: 'لوحة التحكم',
      overview: 'نظرة عامة على الأعمال',
      totalRevenue: 'إجمالي الإيرادات',
      totalExpenses: 'إجمالي المصروفات',
      netProfit: 'صافي الربح',
      netLoss: 'صافي الخسارة',
      totalClients: 'إجمالي العملاء',
      activeClients: 'العملاء النشطين',
      thisMonth: 'هذا الشهر',
      lastMonth: 'الشهر الماضي',
      monthlyGrowth: 'النمو الشهري',
      profitMargin: 'هامش الربح',
      expenseRatio: 'نسبة المصروفات',
      clientGrowth: 'نمو العملاء',
      recentTransactions: 'المعاملات الأخيرة',
      quickActions: 'الإجراءات السريعة',
      performanceMetrics: 'مقاييس الأداء',
      financialSummary: 'الملخص المالي',
      businessInsights: 'رؤى الأعمال',
      viewAll: 'عرض الكل',
      addTransaction: 'إضافة معاملة',
      viewReports: 'عرض التقارير',
      manageClients: 'إدارة العملاء',
      bhd: 'د.ب',
      noData: 'لا توجد بيانات متاحة',
      loadingData: 'جاري تحميل بيانات لوحة التحكم...',
      goodMorning: 'صباح الخير',
      goodAfternoon: 'مساء الخير',
      goodEvening: 'مساء الخير',
      todaysDate: 'تاريخ اليوم',
      businessHealth: 'صحة الأعمال',
      excellent: 'ممتاز',
      good: 'جيد',
      average: 'متوسط',
      needsAttention: 'يحتاج انتباه'
    }
  };

  const t = translations[language];

  // Load data from localStorage
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      
      // Get current user once at the beginning of the function
      const currentUser = getCurrentUser();
      
      // Load transactions from Supabase
      if (currentUser) {
        const targetBossId = bossId || currentUser.id;
        try {
          const result = await transactionService.getTransactions(targetBossId);
          if (result.success) {
            // Convert Supabase data to local format
            const convertedTransactions = result.data.map((t: SupabaseTransaction) => ({
              id: t.id,
              type: 'revenue' as const,
              amount: t.amount,
              description: t.description || '',
              date: t.transaction_date,
              month: t.month,
              year: t.year,
              cost: t.cost,
              vat: t.vat
            }));
            setTransactions(convertedTransactions);
          } else {
            console.error('Error loading transactions:', result.error);
            setTransactions([]);
          }
        } catch (error) {
          console.error('Error loading transactions:', error);
          setTransactions([]);
        }
      }

      // Load clients from Supabase
      if (currentUser) {
        const targetBossId = bossId || currentUser.id;
        try {
          const result = await clientService.getClients(targetBossId);
          if (result.success) {
            setClients(result.data);
          } else {
            console.error('Error loading clients:', result.error);
            setClients([]);
          }
        } catch (error) {
          console.error('Error loading clients:', error);
          setClients([]);
        }
      }

      setTimeout(() => setIsLoading(false), 1000);
    };

    loadData();

    // Listen for data updates
    const handleDataUpdate = () => loadData();

    return () => {
    };
  }, []);

  // Calculate financial metrics
  const calculateMetrics = () => {
    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();
    
    // Current month transactions
    const currentMonthTransactions = transactions.filter(
      t => t.month === currentMonth && t.year === currentYear
    );
    
    // Calculate revenue from all transactions (amount + vat)
    const currentMonthRevenue = currentMonthTransactions
      .reduce((sum, t) => sum + (t.amount || 0) + (t.vat || 0), 0);
    
    // Calculate expenses from all transactions (cost)
    const currentMonthExpenses = currentMonthTransactions
      .reduce((sum, t) => sum + (t.cost || 0), 0);

    // Last month transactions
    const lastMonth = currentMonth === 1 ? 12 : currentMonth - 1;
    const lastMonthYear = currentMonth === 1 ? currentYear - 1 : currentYear;
    
    const lastMonthTransactions = transactions.filter(
      t => t.month === lastMonth && t.year === lastMonthYear
    );
    
    const lastMonthRevenue = lastMonthTransactions
      .reduce((sum, t) => sum + (t.amount || 0) + (t.vat || 0), 0);

    // Total metrics
    const totalRevenue = transactions
      .reduce((sum, t) => sum + (t.amount || 0) + (t.vat || 0), 0);
    
    const totalExpenses = transactions
      .reduce((sum, t) => sum + (t.cost || 0), 0);

    const netProfit = totalRevenue - totalExpenses;
    const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;
    const expenseRatio = totalRevenue > 0 ? (totalExpenses / totalRevenue) * 100 : 0;

    // Growth calculations
    const revenueGrowth = lastMonthRevenue > 0 
      ? ((currentMonthRevenue - lastMonthRevenue) / lastMonthRevenue) * 100 
      : 0;

    // Client metrics
    const activeClients = clients.filter(c => c.is_active).length;
    const totalClients = clients.length;

    return {
      currentMonthRevenue,
      currentMonthExpenses,
      totalRevenue,
      totalExpenses,
      netProfit,
      profitMargin,
      expenseRatio,
      revenueGrowth,
      activeClients,
      totalClients
    };
  };

  const metrics = calculateMetrics();

  // Generate chart data
  const generateChartData = () => {
    const currentYear = selectedChartYear;
    return Array.from({ length: 12 }, (_, index) => {
      const month = index + 1;
      const monthTransactions = transactions.filter(
        t => t.month === month && t.year === currentYear
      );
      
      // Calculate revenue from amount + vat
      const revenue = monthTransactions
        .reduce((sum, t) => sum + (t.amount || 0) + (t.vat || 0), 0);
      
      // Calculate expenses from cost
      const expenses = monthTransactions
        .reduce((sum, t) => sum + (t.cost || 0), 0);

      const monthNames = {
        en: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        ar: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']
      };

      return {
        month: monthNames[language][index],
        revenue,
        expenses
      };
    });
  };

  const chartData = generateChartData();

  // Get greeting based on time
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return t.goodMorning;
    if (hour < 17) return t.goodAfternoon;
    return t.goodEvening;
  };

  // Get business health status
  const getBusinessHealth = () => {
    let score = 0;
    
    // Profitability (40 points)
    if (metrics.netProfit > 0) score += 40;
    else if (metrics.netProfit > -1000) score += 20;
    
    // Profit margin (30 points)
    if (metrics.profitMargin > 20) score += 30;
    else if (metrics.profitMargin > 10) score += 20;
    else if (metrics.profitMargin > 0) score += 10;
    
    // Growth (20 points)
    if (metrics.revenueGrowth > 10) score += 20;
    else if (metrics.revenueGrowth > 0) score += 10;
    
    // Activity (10 points)
    if (transactions.length > 50) score += 10;
    else if (transactions.length > 20) score += 5;

    if (score >= 80) return { text: t.excellent, color: 'text-green-600', bg: 'bg-green-100' };
    if (score >= 60) return { text: t.good, color: 'text-blue-600', bg: 'bg-blue-100' };
    if (score >= 40) return { text: t.average, color: 'text-yellow-600', bg: 'bg-yellow-100' };
    return { text: t.needsAttention, color: 'text-red-600', bg: 'bg-red-100' };
  };

  const businessHealth = getBusinessHealth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">{t.loadingData}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className={`bg-gradient-to-r from-blue-500 to-indigo-600 rounded-3xl p-8 text-white shadow-xl ${isRTL ? 'text-right' : 'text-left'}`}>
        <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div>
            <h1 className="text-3xl font-bold mb-2">
              {getGreeting()}, {user.fullName}!
            </h1>
            <p className="text-blue-100 text-lg mb-4">{t.welcome}</p>
            <div className={`flex items-center gap-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-200" />
                <span className="text-blue-100">
                  {new Date().toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </span>
              </div>
              <div className={`flex items-center gap-2 px-3 py-1 rounded-full ${businessHealth.bg} ${businessHealth.color}`}>
                <Activity className="w-4 h-4" />
                <span className="text-sm font-medium">{businessHealth.text}</span>
              </div>
            </div>
          </div>
          
          <div className="hidden md:block">
            <div className="w-32 h-32 bg-white/10 rounded-full flex items-center justify-center">
              <BarChart3 className="w-16 h-16 text-white/80" />
            </div>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title={t.totalRevenue}
          value={metrics.totalRevenue}
          icon={TrendingUp}
          color="bg-gradient-to-r from-green-500 to-emerald-500"
          currency={true}
          language={language}
        />
        
        <StatCard
          title={t.totalExpenses}
          value={metrics.totalExpenses}
          icon={TrendingDown}
          color="bg-gradient-to-r from-red-500 to-rose-500"
          currency={true}
          language={language}
        />
        
        <StatCard
          title={metrics.netProfit >= 0 ? t.netProfit : t.netLoss}
          value={Math.abs(metrics.netProfit)}
          icon={DollarSign}
          color={metrics.netProfit >= 0 ? "bg-gradient-to-r from-blue-500 to-indigo-500" : "bg-gradient-to-r from-orange-500 to-red-500"}
          currency={true}
          language={language}
        />
        
        <StatCard
          title={t.totalClients}
          value={metrics.totalClients}
          icon={Users}
          color="bg-gradient-to-r from-purple-500 to-pink-500"
          currency={false}
          language={language}
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Chart Section */}
        <div className="lg:col-span-2">
          <TransactionChart 
            data={chartData} 
            language={language} 
            selectedYear={selectedChartYear}
            onYearChange={setSelectedChartYear}
          />
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <QuickActions language={language} onPageChange={onPageChange} />
          <RecentActivity 
            transactions={transactions.slice(0, 5)} 
            language={language} 
          />
        </div>
      </div>

    </div>
  );
};

export default Dashboard;