import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  Download, 
  Edit3, 
  Trash2, 
  Users,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Eye,
  X,
  Save,
  AlertCircle,
  User,
  Building,
  Globe,
  MessageSquare,
  CheckCircle,
  ExternalLink,
  UserPlus,
  Star,
  DollarSign,
  Briefcase,
  Award,
  Shield,
  Clock,
  Package,
  Settings,
  FileText,
  Calculator
} from 'lucide-react';
import { authService, financialItemService } from '../lib/supabase';
import type { Employee, FinancialItem } from '../lib/supabase';
import EmployeeExpenseCard from './EmployeeExpenseCard';

interface EmployeesPageProps {
  language: 'en' | 'ar';
}

const EmployeesPage: React.FC<EmployeesPageProps> = ({ language }) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [financialItems, setFinancialItems] = useState<FinancialItem[]>([]);
  const [filteredEmployees, setFilteredEmployees] = useState<Employee[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [sortBy, setSortBy] = useState<'full_name' | 'email' | 'created_at' | 'salary'>('created_at');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showFinancialItemsModal, setShowFinancialItemsModal] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [viewingEmployee, setViewingEmployee] = useState<Employee | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const isRTL = language === 'ar';

  // Get current user from localStorage to access boss ID
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Form state for adding/editing employees
  const [employeeForm, setEmployeeForm] = useState({
    fullName: '',
    email: '',
    password: '',
    phone: '',
    salary: 0,
    description: '',
    residenceLocation: '',
    position: '',
    rating: 5,
    visa: '',
    transportationAllowance: 0,
    insurance: 0,
    yearsOfExperience: 0,
    skills: [] as string[],
    yearOfBirth: new Date().getFullYear() - 25,
    selectedFinancialItems: [] as string[]
  });

  // Financial item form state
  const [financialItemForm, setFinancialItemForm] = useState({
    name: '',
    description: '',
    defaultAmount: 0,
    frequency: 'monthly' as 'monthly' | 'yearly',
    category: ''
  });

  const [newSkill, setNewSkill] = useState('');

  const translations = {
    en: {
      title: 'Employees',
      subtitle: 'Manage your team members and their information',
      addEmployee: 'Add Employee',
      manageFinancialItems: 'Manage Financial Items',
      searchPlaceholder: 'Search employees...',
      filterAll: 'All Employees',
      filterActive: 'Active',
      filterInactive: 'Inactive',
      sortByName: 'Name',
      sortByEmail: 'Email',
      sortByDate: 'Date Added',
      sortBySalary: 'Salary',
      fullName: 'Full Name',
      email: 'Email',
      phone: 'Phone Number',
      salary: 'Monthly Salary',
      position: 'Position',
      rating: 'Rating',
      dateAdded: 'Date Added',
      status: 'Status',
      actions: 'Actions',
      active: 'Active',
      inactive: 'Inactive',
      edit: 'Edit',
      delete: 'Delete',
      view: 'View',
      save: 'Save',
      cancel: 'Cancel',
      close: 'Close',
      addNewEmployee: 'Add New Employee',
      editEmployee: 'Edit Employee',
      employeeDetails: 'Employee Details',
      enterFullName: 'Enter Full Name',
      enterEmail: 'Enter Email Address',
      enterPassword: 'Enter Password',
      enterPhone: 'Enter Phone Number',
      enterSalary: 'Enter Monthly Salary',
      enterDescription: 'Enter Employee Description',
      enterResidence: 'Enter Residence Location',
      enterPosition: 'Enter Position/Job Title',
      enterVisa: 'Enter Visa Information',
      enterTransportation: 'Enter Transportation Allowance',
      enterInsurance: 'Enter Insurance Amount',
      enterExperience: 'Enter Years of Experience',
      enterYearOfBirth: 'Enter Year of Birth',
      confirmDelete: 'Are you sure you want to delete this employee?',
      deleteEmployee: 'Delete Employee',
      employeeAdded: 'Employee added successfully',
      employeeUpdated: 'Employee updated successfully',
      employeeDeleted: 'Employee deleted successfully',
      fillRequired: 'Please fill all required fields',
      invalidEmail: 'Please enter a valid email address',
      emailExists: 'Email address already exists',
      noEmployees: 'No employees found',
      noEmployeesDesc: 'Start by adding your first employee',
      totalEmployees: 'Total Employees',
      activeEmployees: 'Active Employees',
      newThisMonth: 'New This Month',
      avgSalary: 'Average Salary',
      export: 'Export',
      print: 'Print',
      refresh: 'Refresh',
      required: 'Required',
      optional: 'Optional',
      personalInfo: 'Personal Information',
      workInfo: 'Work Information',
      financialInfo: 'Financial Information',
      additionalInfo: 'Additional Information',
      skills: 'Skills',
      addSkill: 'Add Skill',
      removeSkill: 'Remove',
      enterSkill: 'Enter skill (e.g., Excel, Communication)',
      bhd: 'BHD',
      years: 'years',
      experience: 'Experience',
      loadingEmployees: 'Loading employees...',
      errorLoading: 'Error loading employees',
      permissions: 'Permissions',
      // Financial Items translations
      financialItems: 'Financial Items',
      addFinancialItem: 'Add Financial Item',
      financialItemName: 'Item Name',
      financialItemDescription: 'Description',
      defaultAmount: 'Default Amount',
      frequency: 'Frequency',
      monthly: 'Monthly',
      yearly: 'Yearly',
      category: 'Category',
      enterItemName: 'Enter financial item name',
      enterItemDescription: 'Enter description',
      enterDefaultAmount: 'Enter default amount',
      enterCategory: 'Enter category',
      selectFinancialItems: 'Select Financial Items',
      selectedItems: 'Selected Items',
      availableItems: 'Available Financial Items',
      noFinancialItems: 'No financial items available',
      createFirstItem: 'Create your first financial item',
      financialItemAdded: 'Financial item added successfully',
      financialItemUpdated: 'Financial item updated successfully',
      financialItemDeleted: 'Financial item deleted successfully',
      itemNameExists: 'Financial item name already exists',
      manageItems: 'Manage Items',
      editFinancialItem: 'Edit Financial Item',
      deleteFinancialItem: 'Delete Financial Item',
      confirmDeleteItem: 'Are you sure you want to delete this financial item?',
      totalAmount: 'Total Amount',
      monthlyTotal: 'Monthly Total',
      yearlyTotal: 'Yearly Total',
      calculatedTotal: 'Calculated Total'
    },
    ar: {
      title: 'الموظفين',
      subtitle: 'إدارة أعضاء فريقك ومعلوماتهم',
      addEmployee: 'إضافة موظف',
      manageFinancialItems: 'إدارة البنود المالية',
      searchPlaceholder: 'البحث في الموظفين...',
      filterAll: 'جميع الموظفين',
      filterActive: 'نشط',
      filterInactive: 'غير نشط',
      sortByName: 'الاسم',
      sortByEmail: 'البريد الإلكتروني',
      sortByDate: 'تاريخ الإضافة',
      sortBySalary: 'الراتب',
      fullName: 'الاسم الكامل',
      email: 'البريد الإلكتروني',
      phone: 'رقم الهاتف',
      salary: 'الراتب الشهري',
      position: 'المنصب',
      rating: 'التقييم',
      dateAdded: 'تاريخ الإضافة',
      status: 'الحالة',
      actions: 'الإجراءات',
      active: 'نشط',
      inactive: 'غير نشط',
      edit: 'تعديل',
      delete: 'حذف',
      view: 'عرض',
      save: 'حفظ',
      cancel: 'إلغاء',
      close: 'إغلاق',
      addNewEmployee: 'إضافة موظف جديد',
      editEmployee: 'تعديل الموظف',
      employeeDetails: 'تفاصيل الموظف',
      enterFullName: 'أدخل الاسم الكامل',
      enterEmail: 'أدخل عنوان البريد الإلكتروني',
      enterPassword: 'أدخل كلمة المرور',
      enterPhone: 'أدخل رقم الهاتف',
      enterSalary: 'أدخل الراتب الشهري',
      enterDescription: 'أدخل وصف الموظف',
      enterResidence: 'أدخل مكان الإقامة',
      enterPosition: 'أدخل المنصب/المسمى الوظيفي',
      enterVisa: 'أدخل معلومات التأشيرة',
      enterTransportation: 'أدخل بدل المواصلات',
      enterInsurance: 'أدخل مبلغ التأمين',
      enterExperience: 'أدخل سنوات الخبرة',
      enterYearOfBirth: 'أدخل سنة الميلاد',
      confirmDelete: 'هل أنت متأكد من حذف هذا الموظف؟',
      deleteEmployee: 'حذف الموظف',
      employeeAdded: 'تم إضافة الموظف بنجاح',
      employeeUpdated: 'تم تحديث الموظف بنجاح',
      employeeDeleted: 'تم حذف الموظف بنجاح',
      fillRequired: 'يرجى ملء جميع الحقول المطلوبة',
      invalidEmail: 'يرجى إدخال عنوان بريد إلكتروني صحيح',
      emailExists: 'عنوان البريد الإلكتروني موجود بالفعل',
      noEmployees: 'لا يوجد موظفين',
      noEmployeesDesc: 'ابدأ بإضافة موظفك الأول',
      totalEmployees: 'إجمالي الموظفين',
      activeEmployees: 'الموظفين النشطين',
      newThisMonth: 'جديد هذا الشهر',
      avgSalary: 'متوسط الراتب',
      export: 'تصدير',
      print: 'طباعة',
      refresh: 'تحديث',
      required: 'مطلوب',
      optional: 'اختياري',
      personalInfo: 'المعلومات الشخصية',
      workInfo: 'معلومات العمل',
      financialInfo: 'المعلومات المالية',
      additionalInfo: 'معلومات إضافية',
      skills: 'المهارات',
      addSkill: 'إضافة مهارة',
      removeSkill: 'إزالة',
      enterSkill: 'أدخل مهارة (مثل: Excel، التواصل)',
      bhd: 'د.ب',
      years: 'سنوات',
      experience: 'الخبرة',
      loadingEmployees: 'جاري تحميل الموظفين...',
      errorLoading: 'خطأ في تحميل الموظفين',
      permissions: 'الصلاحيات',
      // Financial Items translations
      financialItems: 'البنود المالية',
      addFinancialItem: 'إضافة بند مالي',
      financialItemName: 'اسم البند',
      financialItemDescription: 'الوصف',
      defaultAmount: 'المبلغ الافتراضي',
      frequency: 'التكرار',
      monthly: 'شهري',
      yearly: 'سنوي',
      category: 'الفئة',
      enterItemName: 'أدخل اسم البند المالي',
      enterItemDescription: 'أدخل الوصف',
      enterDefaultAmount: 'أدخل المبلغ الافتراضي',
      enterCategory: 'أدخل الفئة',
      selectFinancialItems: 'اختر البنود المالية',
      selectedItems: 'البنود المختارة',
      availableItems: 'البنود المالية المتاحة',
      noFinancialItems: 'لا توجد بنود مالية متاحة',
      createFirstItem: 'أنشئ بندك المالي الأول',
      financialItemAdded: 'تم إضافة البند المالي بنجاح',
      financialItemUpdated: 'تم تحديث البند المالي بنجاح',
      financialItemDeleted: 'تم حذف البند المالي بنجاح',
      itemNameExists: 'اسم البند المالي موجود بالفعل',
      manageItems: 'إدارة البنود',
      editFinancialItem: 'تعديل البند المالي',
      deleteFinancialItem: 'حذف البند المالي',
      confirmDeleteItem: 'هل أنت متأكد من حذف هذا البند المالي؟',
      totalAmount: 'المبلغ الإجمالي',
      monthlyTotal: 'الإجمالي الشهري',
      yearlyTotal: 'الإجمالي السنوي',
      calculatedTotal: 'الإجمالي المحسوب'
    }
  };

  const t = translations[language];

  // Load employees and financial items from Supabase
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      const currentUser = getCurrentUser();
      
      if (!currentUser || currentUser.role !== 'boss') {
        setIsLoading(false);
        return;
      }

      try {
        // Load employees
        const employeesResult = await authService.getEmployees(currentUser.id);
        if (employeesResult.success) {
          setEmployees(employeesResult.data);
          setFilteredEmployees(employeesResult.data);
        } else {
          setError(employeesResult.error || t.errorLoading);
        }

        // Load financial items
        const financialItemsResult = await financialItemService.getFinancialItems(currentUser.id);
        if (financialItemsResult.success) {
          setFinancialItems(financialItemsResult.data);
        } else {
          console.error('Error loading financial items:', financialItemsResult.error);
        }
      } catch (error) {
        console.error('Error loading data:', error);
        setError(t.errorLoading);
      }
      
      setIsLoading(false);
    };

    loadData();
  }, []);

  // Filter and sort employees
  useEffect(() => {
    let filtered = [...employees];

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(employee =>
        employee.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        employee.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        employee.phone?.includes(searchTerm) ||
        employee.position?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(employee => 
        filterStatus === 'active' ? employee.is_active : !employee.is_active
      );
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'full_name':
          comparison = a.full_name.localeCompare(b.full_name);
          break;
        case 'email':
          comparison = a.email.localeCompare(b.email);
          break;
        case 'created_at':
          comparison = new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
          break;
        case 'salary':
          comparison = (a.salary || 0) - (b.salary || 0);
          break;
      }

      return sortOrder === 'asc' ? comparison : -comparison;
    });

    setFilteredEmployees(filtered);
  }, [employees, searchTerm, filterStatus, sortBy, sortOrder]);

  // Validate email format
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Handle financial item form submission
  const handleFinancialItemSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!financialItemForm.name || financialItemForm.defaultAmount <= 0) {
      setError(t.fillRequired);
      return;
    }

    const currentUser = getCurrentUser();
    if (!currentUser) {
      setError('User not found');
      return;
    }

    // Check if item name exists
    const nameExists = await financialItemService.checkFinancialItemNameExists(
      currentUser.id, 
      financialItemForm.name
    );
    
    if (nameExists) {
      setError(t.itemNameExists);
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const result = await financialItemService.addFinancialItem(currentUser.id, {
        name: financialItemForm.name,
        description: financialItemForm.description || undefined,
        default_amount: financialItemForm.defaultAmount,
        frequency: financialItemForm.frequency,
        category: financialItemForm.category || undefined,
        is_active: true
      });

      if (result.success) {
        setFinancialItems(prev => [...prev, result.data]);
        setSuccess(t.financialItemAdded);
        resetFinancialItemForm();
      } else {
        setError(result.error || 'Failed to add financial item');
      }
    } catch (error) {
      console.error('Error adding financial item:', error);
      setError('Failed to add financial item. Please try again.');
    }

    setIsLoading(false);
    setTimeout(() => setSuccess(''), 3000);
  };

  // Handle employee form submission
  const handleEmployeeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!employeeForm.fullName || !employeeForm.email || !employeeForm.password || !employeeForm.phone || employeeForm.salary <= 0) {
      setError(t.fillRequired);
      return;
    }

    if (!validateEmail(employeeForm.email)) {
      setError(t.invalidEmail);
      return;
    }

    const currentUser = getCurrentUser();
    if (!currentUser) {
      setError('User not found');
      return;
    }

    // Check if email exists
    const emailExists = await authService.checkEmailExists(employeeForm.email);
    if (emailExists && !editingEmployee) {
      setError(t.emailExists);
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const employeeData = {
        full_name: employeeForm.fullName,
        email: employeeForm.email,
        password: employeeForm.password,
        phone: employeeForm.phone,
        salary: employeeForm.salary,
        description: employeeForm.description || undefined,
        residence_location: employeeForm.residenceLocation || undefined,
        position: employeeForm.position || undefined,
        rating: employeeForm.rating,
        visa: employeeForm.visa || undefined,
        transportation_allowance: employeeForm.transportationAllowance,
        insurance: employeeForm.insurance,
        years_of_experience: employeeForm.yearsOfExperience,
        skills: employeeForm.skills,
        year_of_birth: employeeForm.yearOfBirth || undefined,
        is_active: true,
        permissions: {
          transactions: { view: false, add: false, edit: false, delete: false },
          clients: { view: false, add: false, edit: false, delete: false },
          suppliers: { view: false, add: false, edit: false, delete: false },
          services: { view: false, add: false, edit: false, delete: false },
          reports: { view: false, generate: false, export: false }
        }
      };

      if (editingEmployee) {
        // Update existing employee
        const result = await authService.updateEmployee(editingEmployee.id, employeeData);

        if (result.success) {
          const updatedEmployees = employees.map(employee => 
            employee.id === editingEmployee.id ? result.data : employee
          );
          setEmployees(updatedEmployees);
          setSuccess(t.employeeUpdated);
          setEditingEmployee(null);
        } else {
          setError(result.error || 'Failed to update employee');
        }
      } else {
        // Add new employee
        const result = await authService.addEmployee(currentUser.id, employeeData);

        if (result.success) {
          setEmployees(prev => [...prev, result.data]);
          setSuccess(t.employeeAdded);
        } else {
          setError(result.error || 'Failed to add employee');
        }
      }

      setIsLoading(false);
      setShowAddModal(false);
      resetEmployeeForm();

      setTimeout(() => setSuccess(''), 3000);
    } catch (error) {
      console.error('Error saving employee:', error);
      setError('Failed to save employee. Please try again.');
      setIsLoading(false);
    }
  };

  // Reset forms
  const resetEmployeeForm = () => {
    setEmployeeForm({
      fullName: '',
      email: '',
      password: '',
      phone: '',
      salary: 0,
      description: '',
      residenceLocation: '',
      position: '',
      rating: 5,
      visa: '',
      transportationAllowance: 0,
      insurance: 0,
      yearsOfExperience: 0,
      skills: [],
      yearOfBirth: new Date().getFullYear() - 25,
      selectedFinancialItems: []
    });
    setNewSkill('');
    setError('');
  };

  const resetFinancialItemForm = () => {
    setFinancialItemForm({
      name: '',
      description: '',
      defaultAmount: 0,
      frequency: 'monthly',
      category: ''
    });
  };

  // Handle edit
  const handleEdit = (employee: Employee) => {
    setEditingEmployee(employee);
    setEmployeeForm({
      fullName: employee.full_name,
      email: employee.email,
      password: employee.password,
      phone: employee.phone || '',
      salary: employee.salary || 0,
      description: employee.description || '',
      residenceLocation: employee.residence_location || '',
      position: employee.position || '',
      rating: employee.rating || 5,
      visa: employee.visa || '',
      transportationAllowance: employee.transportation_allowance || 0,
      insurance: employee.insurance || 0,
      yearsOfExperience: employee.years_of_experience || 0,
      skills: employee.skills || [],
      yearOfBirth: employee.year_of_birth || new Date().getFullYear() - 25,
      selectedFinancialItems: []
    });
    setShowAddModal(true);
  };

  // Handle delete
  const handleDelete = async (employeeId: string) => {
    if (window.confirm(t.confirmDelete)) {
      setIsLoading(true);
      
      try {
        const result = await authService.deleteEmployee(employeeId);
        
        if (result.success) {
          const updatedEmployees = employees.filter(employee => employee.id !== employeeId);
          setEmployees(updatedEmployees);
          setSuccess(t.employeeDeleted);
        } else {
          setError(result.error || 'Failed to delete employee');
        }
      } catch (error) {
        console.error('Error deleting employee:', error);
        setError('Failed to delete employee. Please try again.');
      }
      
      setIsLoading(false);
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  // Handle delete financial item
  const handleDeleteFinancialItem = async (itemId: string) => {
    if (window.confirm(t.confirmDeleteItem)) {
      try {
        const result = await financialItemService.deleteFinancialItem(itemId);
        
        if (result.success) {
          setFinancialItems(prev => prev.filter(item => item.id !== itemId));
          setSuccess(t.financialItemDeleted);
        } else {
          setError(result.error || 'Failed to delete financial item');
        }
      } catch (error) {
        console.error('Error deleting financial item:', error);
        setError('Failed to delete financial item');
      }
      
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  // Toggle employee status
  const toggleEmployeeStatus = async (employeeId: string) => {
    try {
      const employee = employees.find(emp => emp.id === employeeId);
      if (!employee) return;

      const result = await authService.updateEmployee(employeeId, {
        is_active: !employee.is_active
      });
      
      if (result.success) {
        const updatedEmployees = employees.map(emp => 
          emp.id === employeeId ? result.data : emp
        );
        setEmployees(updatedEmployees);
      } else {
        setError(result.error || 'Failed to update employee status');
        setTimeout(() => setError(''), 3000);
      }
    } catch (error) {
      console.error('Error updating employee status:', error);
      setError('Failed to update employee status');
      setTimeout(() => setError(''), 3000);
    }
  };

  // Add skill
  const addSkill = () => {
    if (newSkill.trim() && !employeeForm.skills.includes(newSkill.trim())) {
      setEmployeeForm(prev => ({
        ...prev,
        skills: [...prev.skills, newSkill.trim()]
      }));
      setNewSkill('');
    }
  };

  // Remove skill
  const removeSkill = (index: number) => {
    setEmployeeForm(prev => ({
      ...prev,
      skills: prev.skills.filter((_, i) => i !== index)
    }));
  };

  // Toggle financial item selection
  const toggleFinancialItem = (itemId: string) => {
    setEmployeeForm(prev => ({
      ...prev,
      selectedFinancialItems: prev.selectedFinancialItems.includes(itemId)
        ? prev.selectedFinancialItems.filter(id => id !== itemId)
        : [...prev.selectedFinancialItems, itemId]
    }));
  };

  // Calculate total for selected financial items
  const calculateSelectedItemsTotal = () => {
    const selectedItems = financialItems.filter(item => 
      employeeForm.selectedFinancialItems.includes(item.id)
    );
    
    const monthlyTotal = selectedItems
      .filter(item => item.frequency === 'monthly')
      .reduce((sum, item) => sum + item.default_amount, 0);
    
    const yearlyTotal = selectedItems
      .filter(item => item.frequency === 'yearly')
      .reduce((sum, item) => sum + item.default_amount, 0);

    return { monthlyTotal, yearlyTotal };
  };

  // Calculate summary statistics
  const totalEmployees = employees.length;
  const activeEmployees = employees.filter(e => e.is_active).length;
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const newThisMonth = employees.filter(employee => {
    const employeeDate = new Date(employee.created_at);
    return employeeDate.getMonth() === currentMonth && employeeDate.getFullYear() === currentYear;
  }).length;

  const avgSalary = employees.length > 0 
    ? employees.reduce((sum, e) => sum + (e.salary || 0), 0) / employees.length 
    : 0;

  // Render star rating
  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ));
  };

  if (isLoading && employees.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">{t.loadingEmployees}</p>
        </div>
      </div>
    );
  }

  const currentUser = getCurrentUser();
  const bossId = currentUser?.id;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{t.title}</h1>
          <p className="text-gray-600">{t.subtitle}</p>
        </div>

        <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <button
            onClick={() => setShowFinancialItemsModal(true)}
            className="flex items-center gap-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            <Calculator className="w-5 h-5" />
            {t.manageFinancialItems}
          </button>

          <button
            onClick={() => {
              resetEmployeeForm();
              setEditingEmployee(null);
              setShowAddModal(true);
            }}
            className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            <Plus className="w-5 h-5" />
            {t.addEmployee}
          </button>
        </div>
      </div>

      {/* Success/Error Messages */}
      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {/* Employee Expense Calculation Card */}
      <EmployeeExpenseCard language={language} bossId={bossId} />

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-indigo-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Users className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-blue-100 text-sm">{t.totalEmployees}</div>
              <div className="text-2xl font-bold">{totalEmployees}</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CheckCircle className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-green-100 text-sm">{t.activeEmployees}</div>
              <div className="text-2xl font-bold">{activeEmployees}</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Calendar className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-purple-100 text-sm">{t.newThisMonth}</div>
              <div className="text-2xl font-bold">{newThisMonth}</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-red-500 rounded-3xl p-6 text-white shadow-lg">
          <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <DollarSign className="w-8 h-8" />
            <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
              <div className="text-orange-100 text-sm">{t.avgSalary}</div>
              <div className="text-2xl font-bold">{avgSalary.toLocaleString()} {t.bhd}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-lg">
        <div className={`flex flex-col md:flex-row gap-4 ${isRTL ? 'md:flex-row-reverse' : ''}`}>
          {/* Search */}
          <div className="flex-1 relative">
            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5`} />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t.searchPlaceholder}
              className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200`}
            />
          </div>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as 'all' | 'active' | 'inactive')}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            <option value="all">{t.filterAll}</option>
            <option value="active">{t.filterActive}</option>
            <option value="inactive">{t.filterInactive}</option>
          </select>

          {/* Sort By */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'full_name' | 'email' | 'created_at' | 'salary')}
            className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          >
            <option value="full_name">{t.sortByName}</option>
            <option value="email">{t.sortByEmail}</option>
            <option value="created_at">{t.sortByDate}</option>
            <option value="salary">{t.sortBySalary}</option>
          </select>

          {/* Sort Order */}
          <button
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            className="px-4 py-3 bg-gray-100 hover:bg-gray-200 rounded-2xl transition-all duration-200 flex items-center gap-2"
          >
            {sortOrder === 'asc' ? '↑' : '↓'}
          </button>
        </div>
      </div>

      {/* Employees Table */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-lg overflow-hidden">
        {filteredEmployees.length === 0 ? (
          <div className="text-center py-16">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">{t.noEmployees}</h3>
            <p className="text-gray-500 mb-6">{t.noEmployeesDesc}</p>
            <button
              onClick={() => {
                resetEmployeeForm();
                setEditingEmployee(null);
                setShowAddModal(true);
              }}
              className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl mx-auto"
            >
              <Plus className="w-5 h-5" />
              {t.addEmployee}
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.fullName}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.email}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.phone}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.position}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.salary}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.status}
                  </th>
                  <th className={`py-4 px-6 font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.actions}
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredEmployees.map((employee, index) => (
                  <tr
                    key={employee.id}
                    className={`border-b border-gray-100 hover:bg-gray-50 transition-colors animate-fadeIn`}
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <td className={`py-4 px-6 font-medium text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-semibold">
                          {employee.full_name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-medium">{employee.full_name}</div>
                          {employee.rating && (
                            <div className="flex items-center gap-1 mt-1">
                              {renderStars(employee.rating)}
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-gray-400" />
                        {employee.email}
                      </div>
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-gray-400" />
                        {employee.phone || '-'}
                      </div>
                    </td>
                    <td className={`py-4 px-6 text-gray-600 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {employee.position ? (
                        <div className="flex items-center gap-2">
                          <Briefcase className="w-4 h-4 text-gray-400" />
                          {employee.position}
                        </div>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className={`py-4 px-6 text-gray-600 font-semibold ${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-2">
                        <DollarSign className="w-4 h-4 text-gray-400" />
                        {(employee.salary || 0).toLocaleString()} {t.bhd}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <button
                        onClick={() => toggleEmployeeStatus(employee.id)}
                        className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                          employee.is_active
                            ? 'bg-green-100 text-green-800 hover:bg-green-200'
                            : 'bg-red-100 text-red-800 hover:bg-red-200'
                        }`}
                      >
                        <div className={`w-2 h-2 rounded-full ${employee.is_active ? 'bg-green-500' : 'bg-red-500'}`}></div>
                        {employee.is_active ? t.active : t.inactive}
                      </button>
                    </td>
                    <td className="py-4 px-6">
                      <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <button
                          onClick={() => setViewingEmployee(employee)}
                          className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                          title={t.view}
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleEdit(employee)}
                          className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors duration-200"
                          title={t.edit}
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(employee.id)}
                          className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors duration-200"
                          title={t.delete}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Financial Items Management Modal */}
      {showFinancialItemsModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-fadeIn">
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-2xl font-bold text-gray-800">{t.financialItems}</h2>
              <button
                onClick={() => setShowFinancialItemsModal(false)}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Add Financial Item Form */}
            <div className="bg-gray-50 rounded-2xl p-6 mb-6">
              <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.addFinancialItem}
              </h3>

              <form onSubmit={handleFinancialItemSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.financialItemName} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={financialItemForm.name}
                      onChange={(e) => setFinancialItemForm(prev => ({ ...prev, name: e.target.value }))}
                      placeholder={t.enterItemName}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.defaultAmount} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={financialItemForm.defaultAmount}
                      onChange={(e) => setFinancialItemForm(prev => ({ ...prev, defaultAmount: parseFloat(e.target.value) || 0 }))}
                      placeholder={t.enterDefaultAmount}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.frequency} <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={financialItemForm.frequency}
                      onChange={(e) => setFinancialItemForm(prev => ({ ...prev, frequency: e.target.value as 'monthly' | 'yearly' }))}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                    >
                      <option value="monthly">{t.monthly}</option>
                      <option value="yearly">{t.yearly}</option>
                    </select>
                  </div>

                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.category} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="text"
                      value={financialItemForm.category}
                      onChange={(e) => setFinancialItemForm(prev => ({ ...prev, category: e.target.value }))}
                      placeholder={t.enterCategory}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.financialItemDescription} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <textarea
                    value={financialItemForm.description}
                    onChange={(e) => setFinancialItemForm(prev => ({ ...prev, description: e.target.value }))}
                    placeholder={t.enterItemDescription}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-emerald-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      {language === 'en' ? 'Adding...' : 'جاري الإضافة...'}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <Plus className="w-5 h-5" />
                      {t.addFinancialItem}
                    </div>
                  )}
                </button>
              </form>
            </div>

            {/* Financial Items List */}
            <div>
              <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.availableItems}
              </h3>

              {financialItems.length === 0 ? (
                <div className="text-center py-8">
                  <Calculator className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500 text-sm">{t.noFinancialItems}</p>
                  <p className="text-gray-400 text-xs mt-1">{t.createFirstItem}</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {financialItems.map((item) => (
                    <div key={item.id} className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
                      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                          <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-lg ${item.frequency === 'monthly' ? 'bg-blue-100' : 'bg-purple-100'}`}>
                              <DollarSign className={`w-4 h-4 ${item.frequency === 'monthly' ? 'text-blue-600' : 'text-purple-600'}`} />
                            </div>
                            <div>
                              <h4 className="font-semibold text-gray-800">{item.name}</h4>
                              {item.description && (
                                <p className="text-sm text-gray-600">{item.description}</p>
                              )}
                              <div className="flex items-center gap-4 mt-1">
                                <span className="text-sm font-medium text-gray-700">
                                  {item.default_amount.toLocaleString()} {t.bhd}
                                </span>
                                <span className={`text-xs px-2 py-1 rounded-full ${
                                  item.frequency === 'monthly' 
                                    ? 'bg-blue-100 text-blue-700' 
                                    : 'bg-purple-100 text-purple-700'
                                }`}>
                                  {item.frequency === 'monthly' ? t.monthly : t.yearly}
                                </span>
                                {item.category && (
                                  <span className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-600">
                                    {item.category}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          <button
                            onClick={() => handleDeleteFinancialItem(item.id)}
                            className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors duration-200"
                            title={t.deleteFinancialItem}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit Employee Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-6xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-fadeIn">
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-2xl font-bold text-gray-800">
                {editingEmployee ? t.editEmployee : t.addNewEmployee}
              </h2>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setEditingEmployee(null);
                  resetEmployeeForm();
                }}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl mb-4 animate-fadeIn">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-5 h-5" />
                  {error}
                </div>
              </div>
            )}

            <form onSubmit={handleEmployeeSubmit} className="space-y-8">
              {/* Personal Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.personalInfo}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Full Name - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.fullName} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={employeeForm.fullName}
                      onChange={(e) => setEmployeeForm(prev => ({ ...prev, fullName: e.target.value }))}
                      placeholder={t.enterFullName}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Email - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.email} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      value={employeeForm.email}
                      onChange={(e) => setEmployeeForm(prev => ({ ...prev, email: e.target.value }))}
                      placeholder={t.enterEmail}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Password - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {language === 'en' ? 'Password' : 'كلمة المرور'} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="password"
                      value={employeeForm.password}
                      onChange={(e) => setEmployeeForm(prev => ({ ...prev, password: e.target.value }))}
                      placeholder={t.enterPassword}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Phone - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.phone} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      value={employeeForm.phone}
                      onChange={(e) => setEmployeeForm(prev => ({ ...prev, phone: e.target.value }))}
                      placeholder={t.enterPhone}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Year of Birth - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {language === 'en' ? 'Year of Birth' : 'سنة الميلاد'} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="number"
                      min="1950"
                      max={new Date().getFullYear() - 16}
                      value={employeeForm.yearOfBirth}
                      onChange={(e) => setEmployeeForm(prev => ({ ...prev, yearOfBirth: parseInt(e.target.value) || new Date().getFullYear() - 25 }))}
                      placeholder={t.enterYearOfBirth}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Residence Location - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {language === 'en' ? 'Residence Location' : 'مكان الإقامة'} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="text"
                      value={employeeForm.residenceLocation}
                      onChange={(e) => setEmployeeForm(prev => ({ ...prev, residenceLocation: e.target.value }))}
                      placeholder={t.enterResidence}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>
              </div>

              {/* Work Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.workInfo}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Position - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.position} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="text"
                      value={employeeForm.position}
                      onChange={(e) => setEmployeeForm(prev => ({ ...prev, position: e.target.value }))}
                      placeholder={t.enterPosition}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Years of Experience - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {language === 'en' ? 'Years of Experience' : 'سنوات الخبرة'} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="50"
                      value={employeeForm.yearsOfExperience}
                      onChange={(e) => setEmployeeForm(prev => ({ ...prev, yearsOfExperience: parseInt(e.target.value) || 0 }))}
                      placeholder={t.enterExperience}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Rating - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.rating} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <select
                      value={employeeForm.rating}
                      onChange={(e) => setEmployeeForm(prev => ({ ...prev, rating: Number(e.target.value) }))}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    >
                      {[1, 2, 3, 4, 5].map(rating => (
                        <option key={rating} value={rating}>
                          {rating} {Array.from({ length: rating }, () => '⭐').join('')}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Visa - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {language === 'en' ? 'Visa Information' : 'معلومات التأشيرة'} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="text"
                      value={employeeForm.visa}
                      onChange={(e) => setEmployeeForm(prev => ({ ...prev, visa: e.target.value }))}
                      placeholder={t.enterVisa}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>

                {/* Description - Optional */}
                <div className="mt-6">
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {language === 'en' ? 'Employee Description' : 'وصف الموظف'} <span className="text-gray-400 text-xs">({t.optional})</span>
                  </label>
                  <textarea
                    value={employeeForm.description}
                    onChange={(e) => setEmployeeForm(prev => ({ ...prev, description: e.target.value }))}
                    placeholder={t.enterDescription}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-none"
                  />
                </div>
              </div>

              {/* Financial Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.financialInfo}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {/* Salary - Required */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.salary} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={employeeForm.salary}
                      onChange={(e) => setEmployeeForm(prev => ({ ...prev, salary: parseFloat(e.target.value) || 0 }))}
                      placeholder={t.enterSalary}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Transportation Allowance - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {language === 'en' ? 'Transportation Allowance' : 'بدل المواصلات'} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={employeeForm.transportationAllowance}
                      onChange={(e) => setEmployeeForm(prev => ({ ...prev, transportationAllowance: parseFloat(e.target.value) || 0 }))}
                      placeholder={t.enterTransportation}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Insurance - Optional */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {language === 'en' ? 'Insurance Amount' : 'مبلغ التأمين'} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={employeeForm.insurance}
                      onChange={(e) => setEmployeeForm(prev => ({ ...prev, insurance: parseFloat(e.target.value) || 0 }))}
                      placeholder={t.enterInsurance}
                      className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>

                {/* Financial Items Selection */}
                {financialItems.length > 0 && (
                  <div className="mt-6">
                    <label className={`block text-sm font-medium text-gray-700 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.selectFinancialItems} <span className="text-gray-400 text-xs">({t.optional})</span>
                    </label>
                    
                    <div className="bg-gray-50 rounded-2xl p-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {financialItems.map((item) => (
                          <div
                            key={item.id}
                            className={`flex items-center gap-3 p-3 rounded-xl border-2 transition-all duration-200 cursor-pointer ${
                              employeeForm.selectedFinancialItems.includes(item.id)
                                ? 'border-blue-500 bg-blue-50'
                                : 'border-gray-200 bg-white hover:border-gray-300'
                            }`}
                            onClick={() => toggleFinancialItem(item.id)}
                          >
                            <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                              employeeForm.selectedFinancialItems.includes(item.id)
                                ? 'border-blue-500 bg-blue-500'
                                : 'border-gray-300'
                            }`}>
                              {employeeForm.selectedFinancialItems.includes(item.id) && (
                                <CheckCircle className="w-3 h-3 text-white" />
                              )}
                            </div>
                            <div className="flex-1">
                              <div className="font-medium text-gray-800">{item.name}</div>
                              <div className="text-sm text-gray-600">
                                {item.default_amount.toLocaleString()} {t.bhd} - {item.frequency === 'monthly' ? t.monthly : t.yearly}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Selected Items Summary */}
                      {employeeForm.selectedFinancialItems.length > 0 && (
                        <div className="mt-4 p-4 bg-blue-50 rounded-xl border border-blue-200">
                          <h4 className={`font-semibold text-blue-800 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                            {t.calculatedTotal}
                          </h4>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-blue-600">{t.monthlyTotal}:</span>
                              <span className="font-semibold text-blue-800 ml-2">
                                {calculateSelectedItemsTotal().monthlyTotal.toLocaleString()} {t.bhd}
                              </span>
                            </div>
                            <div>
                              <span className="text-blue-600">{t.yearlyTotal}:</span>
                              <span className="font-semibold text-blue-800 ml-2">
                                {calculateSelectedItemsTotal().yearlyTotal.toLocaleString()} {t.bhd}
                              </span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Skills */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.skills} <span className="text-gray-400 text-xs">({t.optional})</span>
                </h3>
                
                {/* Add new skill */}
                <div className={`flex gap-3 mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <input
                    type="text"
                    value={newSkill}
                    onChange={(e) => setNewSkill(e.target.value)}
                    placeholder={t.enterSkill}
                    className="flex-1 px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
                  />
                  <button
                    type="button"
                    onClick={addSkill}
                    className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-2xl font-medium hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl"
                  >
                    <Plus className="w-4 h-4" />
                    {t.addSkill}
                  </button>
                </div>

                {/* Display added skills */}
                {employeeForm.skills.length > 0 && (
                  <div className="bg-gray-50 rounded-2xl p-4">
                    <div className="flex flex-wrap gap-2">
                      {employeeForm.skills.map((skill, index) => (
                        <div
                          key={index}
                          className="flex items-center gap-2 bg-white px-3 py-2 rounded-xl border border-gray-200 shadow-sm"
                        >
                          <Award className="w-4 h-4 text-blue-500" />
                          <span className="text-sm font-medium text-gray-700">{skill}</span>
                          <button
                            type="button"
                            onClick={() => removeSkill(index)}
                            className="text-red-500 hover:text-red-700 transition-colors"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                    <div className="text-sm text-gray-500 mt-2">
                      {employeeForm.skills.length} {language === 'en' ? 'skills' : 'مهارات'}
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className={`flex gap-4 pt-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      {language === 'en' ? 'Saving...' : 'جاري الحفظ...'}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <Save className="w-5 h-5" />
                      {t.save}
                    </div>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingEmployee(null);
                    resetEmployeeForm();
                  }}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Employee Modal */}
      {viewingEmployee && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-fadeIn">
            <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h2 className="text-2xl font-bold text-gray-800">{t.employeeDetails}</h2>
              <button
                onClick={() => setViewingEmployee(null)}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-6">
              {/* Employee Header */}
              <div className={`flex items-center gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-bold text-2xl">
                  {viewingEmployee.full_name.charAt(0).toUpperCase()}
                </div>
                <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                  <h3 className="text-2xl font-bold text-gray-800">{viewingEmployee.full_name}</h3>
                  <p className="text-gray-600">{viewingEmployee.email}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <div className={`w-2 h-2 rounded-full ${viewingEmployee.is_active ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span className={`text-sm ${viewingEmployee.is_active ? 'text-green-600' : 'text-red-600'}`}>
                      {viewingEmployee.is_active ? t.active : t.inactive}
                    </span>
                  </div>
                </div>
              </div>

              {/* Personal Information */}
              <div className="bg-gray-50 rounded-2xl p-6">
                <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.personalInfo}
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Phone className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-700">{viewingEmployee.phone || 'N/A'}</span>
                  </div>
                  {viewingEmployee.residence_location && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <MapPin className="w-5 h-5 text-gray-400" />
                      <span className="text-gray-700">{viewingEmployee.residence_location}</span>
                    </div>
                  )}
                  {viewingEmployee.year_of_birth && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <Calendar className="w-5 h-5 text-gray-400" />
                      <span className="text-gray-700">
                        {language === 'en' ? 'Born in' : 'مولود في'} {viewingEmployee.year_of_birth}
                      </span>
                    </div>
                  )}
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Calendar className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-700">
                      {language === 'en' ? 'Joined' : 'انضم في'} {new Date(viewingEmployee.created_at).toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Work Information */}
              <div className="bg-gray-50 rounded-2xl p-6">
                <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.workInfo}
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {viewingEmployee.position && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <Briefcase className="w-5 h-5 text-gray-400" />
                      <span className="text-gray-700">{viewingEmployee.position}</span>
                    </div>
                  )}
                  {viewingEmployee.years_of_experience !== undefined && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <Award className="w-5 h-5 text-gray-400" />
                      <span className="text-gray-700">
                        {viewingEmployee.years_of_experience} {t.years} {t.experience}
                      </span>
                    </div>
                  )}
                  {viewingEmployee.rating && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <Star className="w-5 h-5 text-gray-400" />
                      <div className="flex items-center gap-1">
                        {renderStars(viewingEmployee.rating)}
                        <span className="text-sm text-gray-600 ml-1">({viewingEmployee.rating})</span>
                      </div>
                    </div>
                  )}
                  {viewingEmployee.visa && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <FileText className="w-5 h-5 text-gray-400" />
                      <span className="text-gray-700">{viewingEmployee.visa}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Financial Information */}
              <div className="bg-gray-50 rounded-2xl p-6">
                <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.financialInfo}
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <DollarSign className="w-5 h-5 text-gray-400" />
                    <div>
                      <div className="text-sm text-gray-600">{t.salary}</div>
                      <div className="font-semibold text-gray-800">
                        {(viewingEmployee.salary || 0).toLocaleString()} {t.bhd}
                      </div>
                    </div>
                  </div>
                  {(viewingEmployee.transportation_allowance || 0) > 0 && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <Package className="w-5 h-5 text-gray-400" />
                      <div>
                        <div className="text-sm text-gray-600">
                          {language === 'en' ? 'Transportation' : 'المواصلات'}
                        </div>
                        <div className="font-semibold text-gray-800">
                          {(viewingEmployee.transportation_allowance || 0).toLocaleString()} {t.bhd}
                        </div>
                      </div>
                    </div>
                  )}
                  {(viewingEmployee.insurance || 0) > 0 && (
                    <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <Shield className="w-5 h-5 text-gray-400" />
                      <div>
                        <div className="text-sm text-gray-600">
                          {language === 'en' ? 'Insurance' : 'التأمين'}
                        </div>
                        <div className="font-semibold text-gray-800">
                          {(viewingEmployee.insurance || 0).toLocaleString()} {t.bhd}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Skills */}
              {viewingEmployee.skills && viewingEmployee.skills.length > 0 && (
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.skills}
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {viewingEmployee.skills.map((skill, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center gap-2 px-3 py-2 bg-blue-100 text-blue-800 rounded-xl text-sm font-medium"
                      >
                        <Award className="w-3 h-3" />
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Description */}
              {viewingEmployee.description && (
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h4 className={`font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {language === 'en' ? 'Description' : 'الوصف'}
                  </h4>
                  <p className="text-gray-700 whitespace-pre-wrap">{viewingEmployee.description}</p>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className={`flex gap-4 mt-8 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <button
                onClick={() => {
                  setViewingEmployee(null);
                  handleEdit(viewingEmployee);
                }}
                className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                <div className="flex items-center justify-center gap-2">
                  <Edit3 className="w-5 h-5" />
                  {t.edit}
                </div>
              </button>
              <button
                onClick={() => setViewingEmployee(null)}
                className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
              >
                {t.close}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeesPage;