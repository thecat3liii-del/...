import React, { useState, useRef, useEffect } from 'react';
import { X, Download, Printer, Truck, Calendar, User, Mail, Phone, MapPin, Hash, Save, Plus, Trash2, Package } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { serviceService, deliveryNoteService } from '../lib/supabase';

interface DeliveryItem {
  id: string;
  name: string;
  category: string;
  subcategory?: string;
  quantity: number;
  description?: string;
}

interface DeliveryNote {
  id: string;
  boss_id: string;
  delivery_number: string;
  client_id?: string;
  client_name?: string;
  client_email?: string;
  client_phone?: string;
  client_address?: string;
  delivery_address?: string;
  delivery_date: string;
  items: DeliveryItem[];
  notes?: string;
  driver_name?: string;
  driver_phone?: string;
  recipient_name?: string;
  recipient_email?: string;
  recipient_phone?: string;
  recipient_signature?: string;
  status: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface Service {
  id: string;
  name: string;
  description?: string;
  price: number;
  category?: string;
  subcategory?: string;
  isActive: boolean;
}

interface DeliveryNoteEditModalProps {
  deliveryNote: DeliveryNote;
  language: 'en' | 'ar';
  onClose: () => void;
  onSuccess: () => void;
}

const DeliveryNoteEditModal: React.FC<DeliveryNoteEditModalProps> = ({ deliveryNote, language, onClose, onSuccess }) => {
  const [services, setServices] = useState<Service[]>([]);
  const [deliveryItems, setDeliveryItems] = useState<DeliveryItem[]>(deliveryNote.items || []);
  const [customLogo, setCustomLogo] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [deliveryData, setDeliveryData] = useState({
    deliveryNumber: deliveryNote.delivery_number,
    deliveryDate: deliveryNote.delivery_date,
    clientName: deliveryNote.client_name || '',
    clientEmail: deliveryNote.client_email || '',
    clientPhone: deliveryNote.client_phone || '',
    clientAddress: deliveryNote.client_address || '',
    deliveryAddress: deliveryNote.delivery_address || '',
    notes: deliveryNote.notes || '',
    driverName: deliveryNote.driver_name || '',
    driverPhone: deliveryNote.driver_phone || '',
    recipientName: deliveryNote.recipient_name || '',
    recipientEmail: deliveryNote.recipient_email || '',
    recipientPhone: deliveryNote.recipient_phone || '',
    recipientSignature: deliveryNote.recipient_signature || '',
    status: deliveryNote.status
  });

  const deliveryRef = useRef<HTMLDivElement>(null);
  const isRTL = language === 'ar';

  // Get current user from localStorage to access boss ID
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Generate unique database key for current boss
  const getBossDataKey = (dataType: string) => {
    const currentUser = getCurrentUser();
    if (!currentUser) return null;
    return `spaceZone_boss_${currentUser.id}_${dataType}`;
  };

  // Load services and custom logo
  useEffect(() => {
    const loadServices = async () => {
      const currentUser = getCurrentUser();
      if (!currentUser) return;
      
      try {
        const result = await serviceService.getServices(currentUser.id);
        if (result.success) {
          const convertedServices = result.data.map((s: any) => ({
            id: s.id,
            name: s.name,
            description: s.description,
            price: s.price,
            category: s.category,
            subcategory: s.subcategory,
            isActive: s.is_active
          }));
          setServices(convertedServices);
        }
      } catch (error) {
        console.error('Error loading services:', error);
      }
    };

    const loadCustomLogo = () => {
      const logoKey = getBossDataKey('customLogo');
      if (!logoKey) return;
      
      const savedLogo = localStorage.getItem(logoKey);
      if (savedLogo) {
        try {
          const logoData = JSON.parse(savedLogo);
          setCustomLogo(logoData?.logoImage || null);
        } catch (error) {
          console.error('Error parsing logo:', error);
          setCustomLogo(null);
        }
      }
    };

    loadServices();
    loadCustomLogo();

    // Listen for logo updates
    const handleLogoUpdate = (event: CustomEvent) => {
      setCustomLogo(event.detail);
    };

    window.addEventListener('logoUpdated', handleLogoUpdate as EventListener);

    return () => {
      window.removeEventListener('logoUpdated', handleLogoUpdate as EventListener);
    };
  }, []);

  const translations = {
    en: {
      title: 'Edit Delivery Note',
      deliveryNumber: 'Delivery Number',
      deliveryDate: 'Delivery Date',
      deliverTo: 'Deliver To',
      clientName: 'Client Name',
      clientEmail: 'Client Email',
      clientPhone: 'Client Phone',
      clientAddress: 'Client Address',
      deliveryAddress: 'Delivery Address',
      description: 'Description',
      itemName: 'Item Name',
      category: 'Category',
      subcategory: 'Subcategory',
      quantity: 'Quantity',
      notes: 'Notes',
      driverName: 'Driver Name',
      driverPhone: 'Driver Phone',
      recipientName: 'Recipient Name',
      recipientEmail: 'Recipient Email',
      recipientPhone: 'Recipient Phone',
      recipientSignature: 'Recipient Signature',
      downloadPDF: 'Download PDF',
      print: 'Print',
      save: 'Save Changes',
      close: 'Close',
      companyInfo: 'Space Zone Delivery',
      companyAddress: 'Business Management System',
      deliveryTerms: 'Please check all items upon delivery and sign below to confirm receipt.',
      thankYou: 'Thank you for your business!',
      enterClientName: 'Enter client name',
      enterClientEmail: 'Enter client email',
      enterClientPhone: 'Enter client phone',
      enterClientAddress: 'Enter client address',
      enterDeliveryAddress: 'Enter delivery address',
      enterNotes: 'Enter delivery notes',
      enterDriverName: 'Enter driver name',
      enterDriverPhone: 'Enter driver phone',
      enterRecipientName: 'Enter recipient name',
      enterRecipientEmail: 'Enter recipient email',
      enterRecipientPhone: 'Enter recipient phone',
      enterSignature: 'Enter recipient signature',
      deliveryUpdated: 'Delivery note updated successfully',
      required: 'Required',
      addItem: 'Add Item',
      removeItem: 'Remove Item',
      editItem: 'Edit Item',
      enterItemName: 'Enter item name',
      enterCategory: 'Enter category',
      enterSubcategory: 'Enter subcategory',
      enterDescription: 'Enter item description',
      items: 'Items',
      noItems: 'No items added',
      itemDetails: 'Item Details',
      deliveryDetails: 'Delivery Details',
      recipientDetails: 'Recipient Details',
      signatureSection: 'Signature Section',
      receivedBy: 'Received By',
      signedBy: 'Signed By',
      dateReceived: 'Date Received',
      status: 'Status',
      pending: 'Pending',
      inTransit: 'In Transit',
      delivered: 'Delivered',
      cancelled: 'Cancelled'
    },
    ar: {
      title: 'تعديل إشعار التسليم',
      deliveryNumber: 'رقم التسليم',
      deliveryDate: 'تاريخ التسليم',
      deliverTo: 'التسليم إلى',
      clientName: 'اسم العميل',
      clientEmail: 'بريد العميل الإلكتروني',
      clientPhone: 'هاتف العميل',
      clientAddress: 'عنوان العميل',
      deliveryAddress: 'عنوان التسليم',
      description: 'الوصف',
      itemName: 'اسم العنصر',
      category: 'الفئة',
      subcategory: 'الفئة الفرعية',
      quantity: 'الكمية',
      notes: 'ملاحظات',
      driverName: 'اسم السائق',
      driverPhone: 'هاتف السائق',
      recipientName: 'اسم المستلم',
      recipientEmail: 'بريد المستلم الإلكتروني',
      recipientPhone: 'هاتف المستلم',
      recipientSignature: 'توقيع المستلم',
      downloadPDF: 'تحميل PDF',
      print: 'طباعة',
      save: 'حفظ التغييرات',
      close: 'إغلاق',
      companyInfo: 'سبيس زون للتوصيل',
      companyAddress: 'نظام إدارة الأعمال',
      deliveryTerms: 'يرجى فحص جميع العناصر عند التسليم والتوقيع أدناه لتأكيد الاستلام.',
      thankYou: 'شكراً لك على تعاملك معنا!',
      enterClientName: 'أدخل اسم العميل',
      enterClientEmail: 'أدخل بريد العميل الإلكتروني',
      enterClientPhone: 'أدخل هاتف العميل',
      enterClientAddress: 'أدخل عنوان العميل',
      enterDeliveryAddress: 'أدخل عنوان التسليم',
      enterNotes: 'أدخل ملاحظات التسليم',
      enterDriverName: 'أدخل اسم السائق',
      enterDriverPhone: 'أدخل هاتف السائق',
      enterRecipientName: 'أدخل اسم المستلم',
      enterRecipientEmail: 'أدخل بريد المستلم الإلكتروني',
      enterRecipientPhone: 'أدخل هاتف المستلم',
      enterSignature: 'أدخل توقيع المستلم',
      deliveryUpdated: 'تم تحديث إشعار التسليم بنجاح',
      required: 'مطلوب',
      addItem: 'إضافة عنصر',
      removeItem: 'إزالة العنصر',
      editItem: 'تعديل العنصر',
      enterItemName: 'أدخل اسم العنصر',
      enterCategory: 'أدخل الفئة',
      enterSubcategory: 'أدخل الفئة الفرعية',
      enterDescription: 'أدخل وصف العنصر',
      items: 'العناصر',
      noItems: 'لم يتم إضافة عناصر',
      itemDetails: 'تفاصيل العنصر',
      deliveryDetails: 'تفاصيل التسليم',
      recipientDetails: 'تفاصيل المستلم',
      signatureSection: 'قسم التوقيع',
      receivedBy: 'استلم بواسطة',
      signedBy: 'وقع بواسطة',
      dateReceived: 'تاريخ الاستلام',
      status: 'الحالة',
      pending: 'في الانتظار',
      inTransit: 'في الطريق',
      delivered: 'تم التسليم',
      cancelled: 'ملغي'
    }
  };

  const t = translations[language];

  const handleInputChange = (field: string, value: string | number) => {
    setDeliveryData(prev => ({ ...prev, [field]: value }));
  };

  // Add new item
  const addItem = () => {
    const newItem: DeliveryItem = {
      id: `item-${Date.now()}`,
      name: '',
      category: '',
      subcategory: '',
      quantity: 1,
      description: ''
    };
    setDeliveryItems(prev => [...prev, newItem]);
  };

  // Remove item
  const removeItem = (itemId: string) => {
    setDeliveryItems(prev => prev.filter(item => item.id !== itemId));
  };

  // Update item
  const updateItem = (itemId: string, field: keyof DeliveryItem, value: string | number) => {
    setDeliveryItems(prev => prev.map(item => {
      if (item.id === itemId) {
        return { ...item, [field]: value };
      }
      return item;
    }));
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!deliveryData.clientName.trim()) {
      setError('Client name is required');
      return;
    }

    if (deliveryItems.length === 0) {
      setError('Please add at least one item');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const currentUser = getCurrentUser();
      if (!currentUser) {
        setError('User not found');
        return;
      }

      // Prepare updated delivery note data
      const updatedDeliveryData = {
        client_name: deliveryData.clientName,
        client_email: deliveryData.clientEmail || null,
        client_phone: deliveryData.clientPhone || null,
        client_address: deliveryData.clientAddress || null,
        delivery_address: deliveryData.deliveryAddress || null,
        delivery_date: deliveryData.deliveryDate,
        items: deliveryItems,
        notes: deliveryData.notes || null,
        driver_name: deliveryData.driverName || null,
        driver_phone: deliveryData.driverPhone || null,
        recipient_name: deliveryData.recipientName || null,
        recipient_email: deliveryData.recipientEmail || null,
        recipient_phone: deliveryData.recipientPhone || null,
        recipient_signature: deliveryData.recipientSignature || null,
        status: deliveryData.status
      };

      const result = await deliveryNoteService.updateDeliveryNote(deliveryNote.id, updatedDeliveryData);

      if (result.success) {
        setSuccess(t.deliveryUpdated);
        setTimeout(() => {
          onSuccess();
          onClose();
        }, 1500);
      } else {
        setError(result.error || 'Failed to update delivery note');
      }
    } catch (error) {
      console.error('Error updating delivery note:', error);
      setError('Failed to update delivery note. Please try again.');
    }
    
    setIsLoading(false);
  };

  const handleDownloadPDF = async () => {
    if (!deliveryRef.current) return;

    try {
      const canvas = await html2canvas(deliveryRef.current, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#f5f1eb'
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
      const imgX = (pdfWidth - imgWidth * ratio) / 2;
      const imgY = 0;

      pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
      pdf.save(`${deliveryData.deliveryNumber}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
    }
  };

  const handlePrint = () => {
    if (!deliveryRef.current) return;
    
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>${t.title} - ${deliveryData.deliveryNumber}</title>
          <style>
            body { 
              font-family: 'Arial', sans-serif; 
              margin: 0; 
              padding: 20px; 
              background-color: #f5f1eb;
            }
            .delivery-container { max-width: 800px; margin: 0 auto; }
            .no-print { display: none !important; }
            @media print {
              body { margin: 0; background-color: #f5f1eb; }
              .delivery-container { max-width: none; }
            }
          </style>
        </head>
        <body>
          ${deliveryRef.current.innerHTML}
        </body>
      </html>
    `);
    
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 250);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-6xl w-full max-h-[95vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className={`flex items-center justify-between p-6 border-b border-gray-200 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <div className="p-2 bg-orange-100 rounded-xl">
              <Truck className="w-6 h-6 text-orange-600" />
            </div>
            <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
              <h2 className="text-2xl font-bold text-gray-800">{t.title}</h2>
              <p className="text-gray-600 text-sm">#{deliveryData.deliveryNumber}</p>
            </div>
          </div>

          <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <button
              onClick={handleDownloadPDF}
              className="flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Download className="w-4 h-4" />
              {t.downloadPDF}
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Printer className="w-4 h-4" />
              {t.print}
            </button>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6">
          {/* Success/Error Messages */}
          {success && (
            <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-2xl mb-6 animate-fadeIn flex items-center gap-2">
              <Save className="w-5 h-5" />
              {success}
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl mb-6 animate-fadeIn">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Delivery Form */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Delivery Details */}
              <div className="space-y-4">
                <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.deliveryDetails}
                </h3>
                
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.deliveryNumber}
                  </label>
                  <input
                    type="text"
                    value={deliveryData.deliveryNumber}
                    readOnly
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 text-gray-700 cursor-not-allowed"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.deliveryDate}
                  </label>
                  <input
                    type="date"
                    value={deliveryData.deliveryDate}
                    onChange={(e) => handleInputChange('deliveryDate', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.status}
                  </label>
                  <select
                    value={deliveryData.status}
                    onChange={(e) => handleInputChange('status', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  >
                    <option value="pending">{t.pending}</option>
                    <option value="in_transit">{t.inTransit}</option>
                    <option value="delivered">{t.delivered}</option>
                    <option value="cancelled">{t.cancelled}</option>
                  </select>
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.driverName}
                  </label>
                  <input
                    type="text"
                    value={deliveryData.driverName}
                    onChange={(e) => handleInputChange('driverName', e.target.value)}
                    placeholder={t.enterDriverName}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.driverPhone}
                  </label>
                  <input
                    type="tel"
                    value={deliveryData.driverPhone}
                    onChange={(e) => handleInputChange('driverPhone', e.target.value)}
                    placeholder={t.enterDriverPhone}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>
              </div>

              {/* Client Details */}
              <div className="space-y-4">
                <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.deliverTo}
                </h3>
                
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.clientName} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={deliveryData.clientName}
                    onChange={(e) => handleInputChange('clientName', e.target.value)}
                    placeholder={t.enterClientName}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.clientEmail}
                  </label>
                  <input
                    type="email"
                    value={deliveryData.clientEmail}
                    onChange={(e) => handleInputChange('clientEmail', e.target.value)}
                    placeholder={t.enterClientEmail}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.clientPhone}
                  </label>
                  <input
                    type="tel"
                    value={deliveryData.clientPhone}
                    onChange={(e) => handleInputChange('clientPhone', e.target.value)}
                    placeholder={t.enterClientPhone}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.deliveryAddress}
                  </label>
                  <textarea
                    value={deliveryData.deliveryAddress}
                    onChange={(e) => handleInputChange('deliveryAddress', e.target.value)}
                    placeholder={t.enterDeliveryAddress}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                  />
                </div>
              </div>

              {/* Recipient Details */}
              <div className="space-y-4">
                <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.recipientDetails}
                </h3>
                
                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.recipientName}
                  </label>
                  <input
                    type="text"
                    value={deliveryData.recipientName}
                    onChange={(e) => handleInputChange('recipientName', e.target.value)}
                    placeholder={t.enterRecipientName}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.recipientEmail}
                  </label>
                  <input
                    type="email"
                    value={deliveryData.recipientEmail}
                    onChange={(e) => handleInputChange('recipientEmail', e.target.value)}
                    placeholder={t.enterRecipientEmail}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.recipientPhone}
                  </label>
                  <input
                    type="tel"
                    value={deliveryData.recipientPhone}
                    onChange={(e) => handleInputChange('recipientPhone', e.target.value)}
                    placeholder={t.enterRecipientPhone}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                    {t.recipientSignature}
                  </label>
                  <input
                    type="text"
                    value={deliveryData.recipientSignature}
                    onChange={(e) => handleInputChange('recipientSignature', e.target.value)}
                    placeholder={t.enterSignature}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            {/* Items Section */}
            <div>
              <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.items}
                </h3>
                <button
                  type="button"
                  onClick={addItem}
                  className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <Plus className="w-4 h-4" />
                  {t.addItem}
                </button>
              </div>

              <div className="space-y-4">
                {deliveryItems.map((item, index) => (
                  <div key={item.id} className="bg-gray-50 rounded-2xl p-6 border border-gray-200">
                    <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <h4 className={`font-medium text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {language === 'en' ? `Item ${index + 1}` : `العنصر ${index + 1}`}
                      </h4>
                      {deliveryItems.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeItem(item.id)}
                          className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                          title={t.removeItem}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {/* Item Name */}
                      <div>
                        <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                          {t.itemName}
                        </label>
                        <input
                          type="text"
                          value={item.name}
                          onChange={(e) => updateItem(item.id, 'name', e.target.value)}
                          placeholder={t.enterItemName}
                          className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
                        />
                      </div>

                      {/* Quantity */}
                      <div>
                        <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                          {t.quantity}
                        </label>
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => updateItem(item.id, 'quantity', parseInt(e.target.value) || 1)}
                          className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
                        />
                      </div>

                      {/* Category */}
                      <div>
                        <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                          {t.category}
                        </label>
                        <textarea
                          value={item.category}
                          onChange={(e) => updateItem(item.id, 'category', e.target.value)}
                          placeholder={t.enterCategory}
                          rows={3}
                          className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm resize-none"
                        />
                      </div>
                    </div>

                    {/* Subcategory - Full width below other inputs */}
                    <div className="mt-4">
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {t.subcategory}
                      </label>
                      <textarea
                        value={item.subcategory || ''}
                        onChange={(e) => updateItem(item.id, 'subcategory', e.target.value)}
                        placeholder={t.enterSubcategory}
                        rows={4}
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm resize-none"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.notes}
              </label>
              <textarea
                value={deliveryData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                placeholder={t.enterNotes}
                rows={3}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
              />
            </div>

            {/* Action Buttons */}
            <div className={`flex gap-4 pt-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 bg-gradient-to-r from-orange-500 to-red-500 text-white py-3 px-6 rounded-2xl font-semibold hover:from-orange-600 hover:to-red-600 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
              >
                {isLoading ? (
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    {language === 'en' ? 'Saving...' : 'جاري الحفظ...'}
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-2">
                    <Save className="w-5 h-5" />
                    {t.save}
                  </div>
                )}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-6 rounded-2xl font-semibold transition-all duration-300"
              >
                {t.close}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default DeliveryNoteEditModal;