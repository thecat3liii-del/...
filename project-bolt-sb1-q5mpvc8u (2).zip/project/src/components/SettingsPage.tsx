import React, { useState, useEffect, useRef } from 'react';
import { 
  Settings, 
  User, 
  Mail, 
  Lock, 
  Globe, 
  Palette, 
  Upload, 
  Save, 
  Eye, 
  EyeOff,
  Camera,
  X,
  CheckCircle,
  AlertCircle,
  RefreshCw,
  Download,
  Trash2,
  Edit3,
  Image as ImageIcon
} from 'lucide-react';
import { profileService, settingsService } from '../lib/supabase';

interface SettingsPageProps {
  language: 'en' | 'ar';
  onLanguageChange: () => void;
}

const SettingsPage: React.FC<SettingsPageProps> = ({ language, onLanguageChange }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'appearance' | 'system'>('profile');
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  const isRTL = language === 'ar';

  // Get current user from localStorage
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Generate unique database key for current boss
  const getBossDataKey = (dataType: string) => {
    const currentUser = getCurrentUser();
    if (!currentUser) return null;
    return `spaceZone_boss_${currentUser.id}_${dataType}`;
  };

  // Profile form state
  const [profileForm, setProfileForm] = useState({
    fullName: '',
    email: '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
    profileImage: null as string | null
  });

  // Theme settings state
  const [themeSettings, setThemeSettings] = useState({
    backgroundColor: '#f8fafc',
    iconStyle: 'light',
    customLogo: null as string | null
  });

  // System settings state
  const [systemSettings, setSystemSettings] = useState({
    language: language,
    autoSave: true,
    notifications: true,
    dataBackup: true
  });

  const translations = {
    en: {
      title: 'Settings',
      subtitle: 'Manage your account and application preferences',
      profile: 'Profile',
      appearance: 'Appearance',
      system: 'System',
      personalInfo: 'Personal Information',
      fullName: 'Full Name',
      email: 'Email Address',
      changePassword: 'Change Password',
      currentPassword: 'Current Password',
      newPassword: 'New Password',
      confirmPassword: 'Confirm New Password',
      profilePicture: 'Profile Picture',
      uploadPhoto: 'Upload Photo',
      removePhoto: 'Remove Photo',
      themeSettings: 'Theme Settings',
      backgroundColor: 'Background Color',
      iconStyle: 'Icon Style',
      customLogo: 'Custom Logo',
      uploadLogo: 'Upload Logo',
      removeLogo: 'Remove Logo',
      light: 'Light',
      dark: 'Dark',
      soft: 'Soft',
      systemPreferences: 'System Preferences',
      language: 'Language',
      autoSave: 'Auto Save',
      notifications: 'Notifications',
      dataBackup: 'Data Backup',
      save: 'Save Changes',
      saving: 'Saving...',
      cancel: 'Cancel',
      settingsUpdated: 'Settings updated successfully',
      profileUpdated: 'Profile updated successfully',
      passwordChanged: 'Password changed successfully',
      errorUpdating: 'Error updating settings',
      invalidEmail: 'Please enter a valid email address',
      emailExists: 'Email address already exists',
      passwordTooShort: 'Password must be at least 6 characters',
      passwordMismatch: 'Passwords do not match',
      currentPasswordRequired: 'Current password is required',
      fillAllFields: 'Please fill all required fields',
      enterFullName: 'Enter your full name',
      enterEmail: 'Enter your email address',
      enterCurrentPassword: 'Enter your current password',
      enterNewPassword: 'Enter new password',
      confirmNewPassword: 'Confirm new password',
      chooseFile: 'Choose File',
      noFileChosen: 'No file chosen',
      maxFileSize: 'Maximum file size: 5MB',
      supportedFormats: 'Supported formats: JPG, PNG, GIF',
      previewImage: 'Preview Image',
      english: 'English',
      arabic: 'العربية',
      enabled: 'Enabled',
      disabled: 'Disabled',
      resetToDefault: 'Reset to Default',
      exportSettings: 'Export Settings',
      importSettings: 'Import Settings',
      dangerZone: 'Danger Zone',
      deleteAccount: 'Delete Account',
      deleteAccountDesc: 'Permanently delete your account and all data',
      confirmDelete: 'Are you sure you want to delete your account?',
      typeDeleteToConfirm: 'Type "DELETE" to confirm',
      accountDeleted: 'Account deleted successfully'
    },
    ar: {
      title: 'الإعدادات',
      subtitle: 'إدارة حسابك وتفضيلات التطبيق',
      profile: 'الملف الشخصي',
      appearance: 'المظهر',
      system: 'النظام',
      personalInfo: 'المعلومات الشخصية',
      fullName: 'الاسم الكامل',
      email: 'عنوان البريد الإلكتروني',
      changePassword: 'تغيير كلمة المرور',
      currentPassword: 'كلمة المرور الحالية',
      newPassword: 'كلمة المرور الجديدة',
      confirmPassword: 'تأكيد كلمة المرور الجديدة',
      profilePicture: 'صورة الملف الشخصي',
      uploadPhoto: 'رفع صورة',
      removePhoto: 'إزالة الصورة',
      themeSettings: 'إعدادات المظهر',
      backgroundColor: 'لون الخلفية',
      iconStyle: 'نمط الأيقونات',
      customLogo: 'شعار مخصص',
      uploadLogo: 'رفع شعار',
      removeLogo: 'إزالة الشعار',
      light: 'فاتح',
      dark: 'داكن',
      soft: 'ناعم',
      systemPreferences: 'تفضيلات النظام',
      language: 'اللغة',
      autoSave: 'الحفظ التلقائي',
      notifications: 'الإشعارات',
      dataBackup: 'نسخ احتياطي للبيانات',
      save: 'حفظ التغييرات',
      saving: 'جاري الحفظ...',
      cancel: 'إلغاء',
      settingsUpdated: 'تم تحديث الإعدادات بنجاح',
      profileUpdated: 'تم تحديث الملف الشخصي بنجاح',
      passwordChanged: 'تم تغيير كلمة المرور بنجاح',
      errorUpdating: 'خطأ في تحديث الإعدادات',
      invalidEmail: 'يرجى إدخال عنوان بريد إلكتروني صحيح',
      emailExists: 'عنوان البريد الإلكتروني موجود بالفعل',
      passwordTooShort: 'يجب أن تكون كلمة المرور 6 أحرف على الأقل',
      passwordMismatch: 'كلمات المرور غير متطابقة',
      currentPasswordRequired: 'كلمة المرور الحالية مطلوبة',
      fillAllFields: 'يرجى ملء جميع الحقول المطلوبة',
      enterFullName: 'أدخل اسمك الكامل',
      enterEmail: 'أدخل عنوان بريدك الإلكتروني',
      enterCurrentPassword: 'أدخل كلمة المرور الحالية',
      enterNewPassword: 'أدخل كلمة المرور الجديدة',
      confirmNewPassword: 'أكد كلمة المرور الجديدة',
      chooseFile: 'اختر ملف',
      noFileChosen: 'لم يتم اختيار ملف',
      maxFileSize: 'الحد الأقصى لحجم الملف: 5 ميجابايت',
      supportedFormats: 'الصيغ المدعومة: JPG, PNG, GIF',
      previewImage: 'معاينة الصورة',
      english: 'English',
      arabic: 'العربية',
      enabled: 'مفعل',
      disabled: 'معطل',
      resetToDefault: 'إعادة تعيين افتراضي',
      exportSettings: 'تصدير الإعدادات',
      importSettings: 'استيراد الإعدادات',
      dangerZone: 'منطقة الخطر',
      deleteAccount: 'حذف الحساب',
      deleteAccountDesc: 'حذف حسابك وجميع البيانات نهائياً',
      confirmDelete: 'هل أنت متأكد من حذف حسابك؟',
      typeDeleteToConfirm: 'اكتب "DELETE" للتأكيد',
      accountDeleted: 'تم حذف الحساب بنجاح'
    }
  };

  const t = translations[language];

  // Load user data and settings
  useEffect(() => {
    const currentUser = getCurrentUser();
    if (currentUser) {
      setProfileForm(prev => ({
        ...prev,
        fullName: currentUser.fullName || '',
        email: currentUser.email || '',
        profileImage: currentUser.profileImageUrl || null
      }));

      // Load profile settings
      const profileKey = getBossDataKey('profile');
      if (profileKey) {
        const savedProfile = localStorage.getItem(profileKey);
        if (savedProfile) {
          try {
            const profile = JSON.parse(savedProfile);
            setProfileForm(prev => ({
              ...prev,
              profileImage: profile?.profileImage || prev.profileImage
            }));
          } catch (error) {
            console.error('Error parsing profile:', error);
          }
        }
      }

      // Load theme settings
      const themeKey = getBossDataKey('theme');
      if (themeKey) {
        const savedTheme = localStorage.getItem(themeKey);
        if (savedTheme) {
          try {
            const theme = JSON.parse(savedTheme);
            setThemeSettings(theme);
          } catch (error) {
            console.error('Error parsing theme:', error);
          }
        }
      }

      // Load system settings
      const systemKey = getBossDataKey('system');
      if (systemKey) {
        const savedSystem = localStorage.getItem(systemKey);
        if (savedSystem) {
          try {
            const system = JSON.parse(savedSystem);
            setSystemSettings(prev => ({ ...prev, ...system }));
          } catch (error) {
            console.error('Error parsing system settings:', error);
          }
        }
      }
    }
  }, []);

  // Validate email format
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Handle profile form submission
  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const currentUser = getCurrentUser();
    if (!currentUser) {
      setError('User not found');
      return;
    }

    // Validate required fields for basic info update
    if (!profileForm.fullName || !profileForm.email) {
      setError(t.fillAllFields);
      return;
    }

    if (!validateEmail(profileForm.email)) {
      setError(t.invalidEmail);
      return;
    }

    // If changing password, validate password fields
    const isChangingPassword = profileForm.currentPassword || profileForm.newPassword || profileForm.confirmPassword;
    
    if (isChangingPassword) {
      if (!profileForm.currentPassword) {
        setError(t.currentPasswordRequired);
        return;
      }

      if (!profileForm.newPassword) {
        setError(t.fillAllFields);
        return;
      }

      if (profileForm.newPassword.length < 6) {
        setError(t.passwordTooShort);
        return;
      }

      if (profileForm.newPassword !== profileForm.confirmPassword) {
        setError(t.passwordMismatch);
        return;
      }

      // Verify current password
      if (profileForm.currentPassword !== currentUser.password) {
        setError('Current password is incorrect');
        return;
      }
    }

    setIsLoading(true);
    setError('');

    try {
      // Check if email exists (excluding current user)
      const emailExists = await profileService.checkEmailExistsForUpdate(
        profileForm.email, 
        currentUser.id, 
        currentUser.role
      );
      
      if (emailExists) {
        setError(t.emailExists);
        setIsLoading(false);
        return;
      }

      // Prepare update data
      const updateData: any = {
        full_name: profileForm.fullName,
        email: profileForm.email
      };

      // Add password to update if changing
      if (isChangingPassword && profileForm.newPassword) {
        updateData.password = profileForm.newPassword;
      }

      // Add profile image if exists
      if (profileForm.profileImage) {
        updateData.profile_image_url = profileForm.profileImage;
      }

      // Update profile in database
      const result = currentUser.role === 'boss' 
        ? await profileService.updateBossProfile(currentUser.id, updateData)
        : await profileService.updateEmployeeProfile(currentUser.id, updateData);

      if (result.success) {
        // Update localStorage with new data
        const updatedUser = {
          ...currentUser,
          fullName: profileForm.fullName,
          email: profileForm.email,
          profileImageUrl: profileForm.profileImage
        };

        // Update password in localStorage if changed
        if (isChangingPassword && profileForm.newPassword) {
          updatedUser.password = profileForm.newPassword;
        }

        localStorage.setItem('currentUser', JSON.stringify(updatedUser));

        // Save profile settings to localStorage
        const profileKey = getBossDataKey('profile');
        if (profileKey) {
          const profileSettings = {
            profileImage: profileForm.profileImage,
            lastUpdated: new Date().toISOString()
          };
          localStorage.setItem(profileKey, JSON.stringify(profileSettings));
        }

        // Clear password fields
        setProfileForm(prev => ({
          ...prev,
          currentPassword: '',
          newPassword: '',
          confirmPassword: ''
        }));

        setSuccess(isChangingPassword ? t.passwordChanged : t.profileUpdated);
      } else {
        setError(result.error || t.errorUpdating);
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      setError(t.errorUpdating);
    }

    setIsLoading(false);
    setTimeout(() => setSuccess(''), 3000);
  };

  // Handle theme settings save
  const handleThemeSave = () => {
    setIsLoading(true);
    
    try {
      const themeKey = getBossDataKey('theme');
      if (themeKey) {
        localStorage.setItem(themeKey, JSON.stringify(themeSettings));
        
        // Apply theme changes to CSS variables
        document.documentElement.style.setProperty('--home-bg-color', themeSettings.backgroundColor);
        document.documentElement.style.setProperty('--icon-style', themeSettings.iconStyle);
        
        // Dispatch custom event for theme change
        window.dispatchEvent(new CustomEvent('themeChanged', { detail: themeSettings }));
        
        setSuccess(t.settingsUpdated);
      }
    } catch (error) {
      console.error('Error saving theme:', error);
      setError(t.errorUpdating);
    }
    
    setIsLoading(false);
    setTimeout(() => setSuccess(''), 3000);
  };

  // Handle system settings save
  const handleSystemSave = () => {
    setIsLoading(true);
    
    try {
      const systemKey = getBossDataKey('system');
      if (systemKey) {
        localStorage.setItem(systemKey, JSON.stringify(systemSettings));
        setSuccess(t.settingsUpdated);
      }
    } catch (error) {
      console.error('Error saving system settings:', error);
      setError(t.errorUpdating);
    }
    
    setIsLoading(false);
    setTimeout(() => setSuccess(''), 3000);
  };

  // Handle profile image upload
  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file size (5MB max)
    if (file.size > 5 * 1024 * 1024) {
      setError('File size must be less than 5MB');
      return;
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const currentUser = getCurrentUser();
      if (!currentUser) {
        setError('User not found');
        setIsLoading(false);
        return;
      }

      // Upload to Supabase Storage
      const result = await settingsService.saveProfileImage(currentUser.id, file);
      
      if (result.success) {
        setProfileForm(prev => ({ ...prev, profileImage: result.url }));
        setSuccess('Profile image uploaded successfully');
      } else {
        // Fallback to base64 for local storage
        const reader = new FileReader();
        reader.onload = (e) => {
          const base64 = e.target?.result as string;
          setProfileForm(prev => ({ ...prev, profileImage: base64 }));
          setSuccess('Profile image uploaded successfully');
        };
        reader.readAsDataURL(file);
      }
    } catch (error) {
      console.error('Error uploading image:', error);
      
      // Fallback to base64 for local storage
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        setProfileForm(prev => ({ ...prev, profileImage: base64 }));
        setSuccess('Profile image uploaded successfully');
      };
      reader.readAsDataURL(file);
    }

    setIsLoading(false);
    setTimeout(() => setSuccess(''), 3000);
  };

  // Handle logo upload
  const handleLogoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file size (5MB max)
    if (file.size > 5 * 1024 * 1024) {
      setError('File size must be less than 5MB');
      return;
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const currentUser = getCurrentUser();
      if (!currentUser) {
        setError('User not found');
        setIsLoading(false);
        return;
      }

      // Upload to Supabase Storage
      const result = await settingsService.saveCustomLogo(currentUser.id, file);
      
      if (result.success) {
        setThemeSettings(prev => ({ ...prev, customLogo: result.url }));
        
        // Save to localStorage
        const logoKey = getBossDataKey('customLogo');
        if (logoKey) {
          const logoData = { logoImage: result.url };
          localStorage.setItem(logoKey, JSON.stringify(logoData));
          
          // Dispatch custom event for logo update
          window.dispatchEvent(new CustomEvent('logoUpdated', { detail: result.url }));
        }
        
        setSuccess('Custom logo uploaded successfully');
      } else {
        // Fallback to base64 for local storage
        const reader = new FileReader();
        reader.onload = (e) => {
          const base64 = e.target?.result as string;
          setThemeSettings(prev => ({ ...prev, customLogo: base64 }));
          
          // Save to localStorage
          const logoKey = getBossDataKey('customLogo');
          if (logoKey) {
            const logoData = { logoImage: base64 };
            localStorage.setItem(logoKey, JSON.stringify(logoData));
            
            // Dispatch custom event for logo update
            window.dispatchEvent(new CustomEvent('logoUpdated', { detail: base64 }));
          }
          
          setSuccess('Custom logo uploaded successfully');
        };
        reader.readAsDataURL(file);
      }
    } catch (error) {
      console.error('Error uploading logo:', error);
      
      // Fallback to base64 for local storage
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        setThemeSettings(prev => ({ ...prev, customLogo: base64 }));
        
        // Save to localStorage
        const logoKey = getBossDataKey('customLogo');
        if (logoKey) {
          const logoData = { logoImage: base64 };
          localStorage.setItem(logoKey, JSON.stringify(logoData));
          
          // Dispatch custom event for logo update
          window.dispatchEvent(new CustomEvent('logoUpdated', { detail: base64 }));
        }
        
        setSuccess('Custom logo uploaded successfully');
      };
      reader.readAsDataURL(file);
    }

    setIsLoading(false);
    setTimeout(() => setSuccess(''), 3000);
  };

  // Remove profile image
  const handleRemoveImage = async () => {
    setIsLoading(true);
    
    try {
      const currentUser = getCurrentUser();
      if (currentUser && profileForm.profileImage) {
        // Try to delete from Supabase Storage if it's a Supabase URL
        if (profileForm.profileImage.includes('supabase')) {
          await settingsService.deleteProfileImage(profileForm.profileImage);
        }
      }
      
      setProfileForm(prev => ({ ...prev, profileImage: null }));
      
      // Remove from localStorage
      const profileKey = getBossDataKey('profile');
      if (profileKey) {
        const savedProfile = localStorage.getItem(profileKey);
        if (savedProfile) {
          try {
            const profile = JSON.parse(savedProfile);
            delete profile.profileImage;
            localStorage.setItem(profileKey, JSON.stringify(profile));
          } catch (error) {
            console.error('Error updating profile:', error);
          }
        }
      }
      
      setSuccess('Profile image removed successfully');
    } catch (error) {
      console.error('Error removing image:', error);
      setError('Error removing image');
    }
    
    setIsLoading(false);
    setTimeout(() => setSuccess(''), 3000);
  };

  // Remove custom logo
  const handleRemoveLogo = async () => {
    setIsLoading(true);
    
    try {
      if (themeSettings.customLogo) {
        // Try to delete from Supabase Storage if it's a Supabase URL
        if (themeSettings.customLogo.includes('supabase')) {
          await settingsService.deleteCustomLogo(themeSettings.customLogo);
        }
      }
      
      setThemeSettings(prev => ({ ...prev, customLogo: null }));
      
      // Remove from localStorage
      const logoKey = getBossDataKey('customLogo');
      if (logoKey) {
        localStorage.removeItem(logoKey);
        
        // Dispatch custom event for logo removal
        window.dispatchEvent(new CustomEvent('logoUpdated', { detail: null }));
      }
      
      setSuccess('Custom logo removed successfully');
    } catch (error) {
      console.error('Error removing logo:', error);
      setError('Error removing logo');
    }
    
    setIsLoading(false);
    setTimeout(() => setSuccess(''), 3000);
  };

  const tabs = [
    { id: 'profile', label: t.profile, icon: User },
    { id: 'appearance', label: t.appearance, icon: Palette },
    { id: 'system', label: t.system, icon: Settings }
  ];

  const backgroundColors = [
    { name: 'Light Gray', value: '#f8fafc', preview: 'bg-slate-50' },
    { name: 'Blue', value: '#eff6ff', preview: 'bg-blue-50' },
    { name: 'Green', value: '#f0fdf4', preview: 'bg-green-50' },
    { name: 'Purple', value: '#faf5ff', preview: 'bg-purple-50' },
    { name: 'Pink', value: '#fdf2f8', preview: 'bg-pink-50' },
    { name: 'Yellow', value: '#fffbeb', preview: 'bg-amber-50' }
  ];

  const iconStyles = [
    { name: t.light, value: 'light' },
    { name: t.dark, value: 'dark' },
    { name: t.soft, value: 'soft' }
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
        <h1 className="text-3xl font-bold text-gray-800 mb-2">{t.title}</h1>
        <p className="text-gray-600">{t.subtitle}</p>
      </div>

      {/* Success/Error Messages */}
      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl animate-fadeIn flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {/* Tabs */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-lg overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className={`flex ${isRTL ? 'flex-row-reverse' : ''}`}>
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-3 px-8 py-4 font-medium transition-all duration-200 ${
                    activeTab === tab.id
                      ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50'
                      : 'text-gray-600 hover:text-gray-800 hover:bg-gray-50'
                  } ${isRTL ? 'flex-row-reverse' : ''}`}
                >
                  <Icon className="w-5 h-5" />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-8">
          {/* Profile Tab */}
          {activeTab === 'profile' && (
            <form onSubmit={handleProfileSubmit} className="space-y-8">
              {/* Profile Picture Section */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.profilePicture}
                </h3>
                
                <div className={`flex items-center gap-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className="relative">
                    <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-white shadow-lg bg-gradient-to-r from-blue-500 to-indigo-500 flex items-center justify-center">
                      {profileForm.profileImage ? (
                        <img
                          src={profileForm.profileImage}
                          alt="Profile"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <User className="w-12 h-12 text-white" />
                      )}
                    </div>
                    
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="absolute -bottom-2 -right-2 p-2 bg-blue-500 hover:bg-blue-600 text-white rounded-full shadow-lg transition-all duration-200 hover:scale-110"
                    >
                      <Camera className="w-4 h-4" />
                    </button>
                  </div>

                  <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                    <div className="space-y-3">
                      <div className={`flex gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
                        >
                          <Upload className="w-4 h-4" />
                          {t.uploadPhoto}
                        </button>
                        
                        {profileForm.profileImage && (
                          <button
                            type="button"
                            onClick={handleRemoveImage}
                            className="flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
                          >
                            <Trash2 className="w-4 h-4" />
                            {t.removePhoto}
                          </button>
                        )}
                      </div>
                      
                      <div className="text-sm text-gray-500">
                        <p>{t.maxFileSize}</p>
                        <p>{t.supportedFormats}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>

              {/* Personal Information */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.personalInfo}
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Full Name */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.fullName}
                    </label>
                    <input
                      type="text"
                      value={profileForm.fullName}
                      onChange={(e) => setProfileForm(prev => ({ ...prev, fullName: e.target.value }))}
                      placeholder={t.enterFullName}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.email}
                    </label>
                    <input
                      type="email"
                      value={profileForm.email}
                      onChange={(e) => setProfileForm(prev => ({ ...prev, email: e.target.value }))}
                      placeholder={t.enterEmail}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>
              </div>

              {/* Change Password Section */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.changePassword}
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Current Password */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.currentPassword}
                    </label>
                    <div className="relative">
                      <input
                        type={showCurrentPassword ? 'text' : 'password'}
                        value={profileForm.currentPassword}
                        onChange={(e) => setProfileForm(prev => ({ ...prev, currentPassword: e.target.value }))}
                        placeholder={t.enterCurrentPassword}
                        className="w-full px-4 py-3 pr-12 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                      >
                        {showCurrentPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                  </div>

                  {/* New Password */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.newPassword}
                    </label>
                    <div className="relative">
                      <input
                        type={showNewPassword ? 'text' : 'password'}
                        value={profileForm.newPassword}
                        onChange={(e) => setProfileForm(prev => ({ ...prev, newPassword: e.target.value }))}
                        placeholder={t.enterNewPassword}
                        className="w-full px-4 py-3 pr-12 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                      >
                        {showNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                  </div>

                  {/* Confirm Password */}
                  <div>
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.confirmPassword}
                    </label>
                    <div className="relative">
                      <input
                        type={showConfirmPassword ? 'text' : 'password'}
                        value={profileForm.confirmPassword}
                        onChange={(e) => setProfileForm(prev => ({ ...prev, confirmPassword: e.target.value }))}
                        placeholder={t.confirmNewPassword}
                        className="w-full px-4 py-3 pr-12 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                      >
                        {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Save Button */}
              <div className={`flex gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      {t.saving}
                    </>
                  ) : (
                    <>
                      <Save className="w-5 h-5" />
                      {t.save}
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* Appearance Tab */}
          {activeTab === 'appearance' && (
            <div className="space-y-8">
              {/* Custom Logo Section */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.customLogo}
                </h3>
                
                <div className={`flex items-center gap-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className="relative">
                    <div className="w-24 h-24 rounded-xl overflow-hidden border-4 border-white shadow-lg bg-gradient-to-r from-gray-100 to-gray-200 flex items-center justify-center">
                      {themeSettings.customLogo ? (
                        <img
                          src={themeSettings.customLogo}
                          alt="Custom Logo"
                          className="w-full h-full object-contain"
                        />
                      ) : (
                        <ImageIcon className="w-12 h-12 text-gray-400" />
                      )}
                    </div>
                    
                    <button
                      type="button"
                      onClick={() => logoInputRef.current?.click()}
                      className="absolute -bottom-2 -right-2 p-2 bg-blue-500 hover:bg-blue-600 text-white rounded-full shadow-lg transition-all duration-200 hover:scale-110"
                    >
                      <Camera className="w-4 h-4" />
                    </button>
                  </div>

                  <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                    <div className="space-y-3">
                      <div className={`flex gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <button
                          type="button"
                          onClick={() => logoInputRef.current?.click()}
                          className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
                        >
                          <Upload className="w-4 h-4" />
                          {t.uploadLogo}
                        </button>
                        
                        {themeSettings.customLogo && (
                          <button
                            type="button"
                            onClick={handleRemoveLogo}
                            className="flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
                          >
                            <Trash2 className="w-4 h-4" />
                            {t.removeLogo}
                          </button>
                        )}
                      </div>
                      
                      <div className="text-sm text-gray-500">
                        <p>{t.maxFileSize}</p>
                        <p>{t.supportedFormats}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <input
                  ref={logoInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
              </div>

              {/* Background Color */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.backgroundColor}
                </h3>
                
                <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
                  {backgroundColors.map((color) => (
                    <button
                      key={color.value}
                      type="button"
                      onClick={() => setThemeSettings(prev => ({ ...prev, backgroundColor: color.value }))}
                      className={`relative w-16 h-16 rounded-xl border-4 transition-all duration-200 hover:scale-110 ${
                        themeSettings.backgroundColor === color.value
                          ? 'border-blue-500 shadow-lg'
                          : 'border-gray-200 hover:border-gray-300'
                      } ${color.preview}`}
                    >
                      {themeSettings.backgroundColor === color.value && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <CheckCircle className="w-6 h-6 text-blue-500" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Icon Style */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.iconStyle}
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {iconStyles.map((style) => (
                    <button
                      key={style.value}
                      type="button"
                      onClick={() => setThemeSettings(prev => ({ ...prev, iconStyle: style.value }))}
                      className={`p-4 rounded-xl border-2 transition-all duration-200 ${
                        themeSettings.iconStyle === style.value
                          ? 'border-blue-500 bg-blue-50 text-blue-700'
                          : 'border-gray-200 hover:border-gray-300 text-gray-700'
                      }`}
                    >
                      <div className="text-center">
                        <div className="font-medium">{style.name}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Save Button */}
              <div className={`flex gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <button
                  type="button"
                  onClick={handleThemeSave}
                  disabled={isLoading}
                  className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      {t.saving}
                    </>
                  ) : (
                    <>
                      <Save className="w-5 h-5" />
                      {t.save}
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* System Tab */}
          {activeTab === 'system' && (
            <div className="space-y-8">
              {/* System Preferences */}
              <div>
                <h3 className={`text-lg font-semibold text-gray-800 mb-4 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.systemPreferences}
                </h3>
                
                <div className="space-y-4">
                  {/* Auto Save */}
                  <div className={`flex items-center justify-between p-4 bg-gray-50 rounded-xl ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="font-medium text-gray-800">{t.autoSave}</div>
                      <div className="text-sm text-gray-600">
                        {language === 'en' 
                          ? 'Automatically save changes as you work'
                          : 'حفظ التغييرات تلقائياً أثناء العمل'
                        }
                      </div>
                    </div>
                    
                    <button
                      type="button"
                      onClick={() => setSystemSettings(prev => ({ ...prev, autoSave: !prev.autoSave }))}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                        systemSettings.autoSave ? 'bg-blue-600' : 'bg-gray-300'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          systemSettings.autoSave ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Notifications */}
                  <div className={`flex items-center justify-between p-4 bg-gray-50 rounded-xl ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="font-medium text-gray-800">{t.notifications}</div>
                      <div className="text-sm text-gray-600">
                        {language === 'en' 
                          ? 'Receive notifications for important events'
                          : 'تلقي إشعارات للأحداث المهمة'
                        }
                      </div>
                    </div>
                    
                    <button
                      type="button"
                      onClick={() => setSystemSettings(prev => ({ ...prev, notifications: !prev.notifications }))}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                        systemSettings.notifications ? 'bg-blue-600' : 'bg-gray-300'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          systemSettings.notifications ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Data Backup */}
                  <div className={`flex items-center justify-between p-4 bg-gray-50 rounded-xl ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                      <div className="font-medium text-gray-800">{t.dataBackup}</div>
                      <div className="text-sm text-gray-600">
                        {language === 'en' 
                          ? 'Automatically backup your data regularly'
                          : 'نسخ احتياطي تلقائي للبيانات بانتظام'
                        }
                      </div>
                    </div>
                    
                    <button
                      type="button"
                      onClick={() => setSystemSettings(prev => ({ ...prev, dataBackup: !prev.dataBackup }))}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                        systemSettings.dataBackup ? 'bg-blue-600' : 'bg-gray-300'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          systemSettings.dataBackup ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>

              {/* Save Button */}
              <div className={`flex gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <button
                  type="button"
                  onClick={handleSystemSave}
                  disabled={isLoading}
                  className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-600 hover:to-indigo-600 transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      {t.saving}
                    </>
                  ) : (
                    <>
                      <Save className="w-5 h-5" />
                      {t.save}
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Developer Information Section */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/20">
        <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
          <h3 className="text-xl font-bold text-gray-800 mb-6">
            {language === 'en' ? 'Developer Information' : 'معلومات المطورين'}
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === 'en' ? 'Developers' : 'المطورون'}
                </label>
                <div className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-800 font-medium">
                  SPACE ZONE TEAM
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === 'en' ? 'Version' : 'النسخة'}
                </label>
                <div className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-800 font-medium">
                  0.1
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === 'en' ? 'Email' : 'الإيميل'}
                </label>
                <div className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-800 font-medium">
                  spacezonemedia@gmail.com
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === 'en' ? 'Phone Number' : 'رقم الهاتف'}
                </label>
                <div className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-800 font-medium">
                  +973 37155515
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-6 text-center">
            <p className="text-gray-600 text-sm">
              {language === 'en' ? 'Good Luck' : 'حظاً موفقاً'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;