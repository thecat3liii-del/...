import React, { useState, useRef, useEffect } from 'react';
import { X, Download, Printer, Truck, Calendar, User, Mail, Phone, MapPin, Hash, Save, Plus, Trash2, Package, FileSignature as Signature, FileText } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { serviceService } from '../lib/supabase';
import { numberingService } from '../lib/numberingService';
import { deliveryNoteService } from '../lib/supabase';

interface Transaction {
  id: string;
  amount: number;
  cost: number;
  vat?: number;
  profit: number;
  clientId?: string;
  clientName?: string;
  supplierId?: string;
  supplierName?: string;
  serviceIds?: string[];
  serviceNames?: string[];
  date: string;
  paymentMethod?: string;
  status?: string;
  description?: string;
  priority?: string;
  month: number;
  year: number;
  category?: string;
  vatPercentage?: number;
  totalWithVat?: number;
}

interface Service {
  id: string;
  name: string;
  description?: string;
  price: number;
  category?: string;
  subcategory?: string;
  isActive: boolean;
}

interface DeliveryItem {
  id: string;
  name: string;
  category: string;
  subcategory?: string;
  quantity: number;
  description?: string;
}

interface DeliveryNoteModalProps {
  transaction: Transaction;
  language: 'en' | 'ar';
  onClose: () => void;
  onDeliveryCreated?: () => void;
}

const DeliveryNoteModal: React.FC<DeliveryNoteModalProps> = ({ transaction, language, onClose, onDeliveryCreated }) => {
  const [services, setServices] = useState<Service[]>([]);
  const [deliveryItems, setDeliveryItems] = useState<DeliveryItem[]>([]);
  const [customLogo, setCustomLogo] = useState<string | null>(null);
  const [isLoadingNumber, setIsLoadingNumber] = useState(true);
  const [deliveryData, setDeliveryData] = useState({
    deliveryNumber: '',
    deliveryDate: new Date().toISOString().split('T')[0],
    clientName: transaction.clientName || '',
    clientEmail: '',
    clientPhone: '',
    clientAddress: '',
    deliveryAddress: '',
    notes: '',
    driverName: '',
    driverPhone: '',
    recipientName: '',
    recipientEmail: '',
    recipientPhone: '',
    recipientSignature: ''
  });

  const [isSaved, setIsSaved] = useState(false);
  const deliveryRef = useRef<HTMLDivElement>(null);
  const isRTL = language === 'ar';

  // Get current user from localStorage to access boss ID
  const getCurrentUser = () => {
    const savedUser = localStorage.getItem('currentUser');
    return savedUser ? JSON.parse(savedUser) : null;
  };

  // Generate unique database key for current boss
  const getBossDataKey = (dataType: string) => {
    const currentUser = getCurrentUser();
    if (!currentUser) return null;
    return `spaceZone_boss_${currentUser.id}_${dataType}`;
  };

  // Load services and initialize delivery items
  useEffect(() => {
    const loadDeliveryNumber = async () => {
      const currentUser = getCurrentUser();
      if (!currentUser) {
        setIsLoadingNumber(false);
        return;
      }

      try {
        // Use transaction-specific delivery number to ensure consistency
        const nextNumber = await numberingService.getTransactionDeliveryNumber(currentUser.id, transaction.id);
        setDeliveryData(prev => ({ ...prev, deliveryNumber: nextNumber }));
      } catch (error) {
        console.error('Error loading delivery number:', error);
        setDeliveryData(prev => ({ ...prev, deliveryNumber: 'DN-1000' }));
      }
      
      setIsLoadingNumber(false);
    };

    const saveDeliveryToDatabase = async () => {
      if (isSaved) return; // تجنب الحفظ المتكرر
      
      const currentUser = getCurrentUser();
      if (!currentUser) return;

      try {
        const deliveryDataToSave = {
          deliveryNumber: deliveryData.deliveryNumber,
          clientId: null,
          clientName: deliveryData.clientName,
          clientEmail: deliveryData.clientEmail,
          clientPhone: deliveryData.clientPhone,
          clientAddress: deliveryData.clientAddress,
          deliveryAddress: deliveryData.deliveryAddress,
          deliveryDate: deliveryData.deliveryDate,
          items: deliveryItems,
          notes: deliveryData.notes,
          driverName: deliveryData.driverName,
          driverPhone: deliveryData.driverPhone,
          recipientName: deliveryData.recipientName,
          recipientEmail: deliveryData.recipientEmail,
          recipientPhone: deliveryData.recipientPhone,
          recipientSignature: deliveryData.recipientSignature,
          status: 'pending'
        };
        
        const saveResult = await numberingService.saveDeliveryNote(currentUser.id, deliveryDataToSave);
        if (saveResult.success) {
          setIsSaved(true);
        }
      } catch (error) {
        console.error('Error saving delivery note to database:', error);
      }
    };

    const loadServices = () => {
      const loadData = async () => {
        const currentUser = getCurrentUser();
        if (!currentUser) return;
        
        try {
          const result = await serviceService.getServices(currentUser.id);
          if (result.success) {
            // Convert Supabase data to local format
            const convertedServices = result.data.map((s: any) => ({
              id: s.id,
              name: s.name,
              description: s.description,
              price: s.price,
              category: s.category,
              subcategory: s.subcategory,
              isActive: s.is_active
            }));
            setServices(convertedServices);
          } else {
            console.error('Error loading services:', result.error);
            setServices([]);
          }
        } catch (error) {
          console.error('Error loading services:', error);
          setServices([]);
        }
      };
      
      loadData();
    };

    // Load custom logo
    const loadCustomLogo = () => {
      const logoKey = getBossDataKey('customLogo');
      if (!logoKey) return;
      
      const savedLogo = localStorage.getItem(logoKey);
      if (savedLogo) {
        try {
          const logoData = JSON.parse(savedLogo);
          setCustomLogo(logoData?.logoImage || null);
        } catch (error) {
          console.error('Error parsing logo:', error);
          setCustomLogo(null);
        }
      }
    };

    loadDeliveryNumber();
    loadServices();
    loadCustomLogo();
    
    // حفظ إشعار التسليم في قاعدة البيانات فور تحميل الرقم
    if (!isLoadingNumber && deliveryData.deliveryNumber && !isSaved) {
      saveDeliveryToDatabase();
    }


    // Listen for logo updates
    const handleLogoUpdate = (event: CustomEvent) => {
      setCustomLogo(event.detail);
    };

    window.addEventListener('logoUpdated', handleLogoUpdate as EventListener);

    return () => {
      window.removeEventListener('logoUpdated', handleLogoUpdate as EventListener);
    };
  }, [transaction]);

  // Initialize delivery items from transaction details - separate useEffect to ensure services are loaded
  useEffect(() => {
    if (services.length === 0) return; // Wait for services to load

    // Initialize delivery items from transaction services with complete details
    if (transaction.serviceIds && transaction.serviceIds.length > 0) {
      const initialItems = transaction.serviceIds.map((serviceId, index) => {
        const service = services.find((s: Service) => s.id === serviceId);
        const serviceName = service?.name || transaction.serviceNames?.[index] || '';
        
        return {
          id: `item-${index}`,
          name: serviceName,
          category: service?.category || transaction.category || '',
          subcategory: service?.subcategory || '',
          quantity: 1,
          description: service?.description || transaction.description || '',
          price: service?.price || transaction.amount || 0,
          vat: transaction.vat || 0,
          vatPercentage: transaction.vatPercentage || 0
        };
      });
      setDeliveryItems(initialItems);
    } else {
      // Create item from transaction details
      const transactionItem = {
        id: 'item-0',
        name: transaction.description || 'Service/Product',
        category: transaction.category || '',
        subcategory: '',
        quantity: 1,
        description: transaction.description || '',
        price: transaction.amount || 0,
        vat: transaction.vat || 0,
        vatPercentage: transaction.vatPercentage || 0
      };
      setDeliveryItems([transactionItem]);
    }
  }, [transaction, services]);
  // حفظ إشعار التسليم عند تغيير الرقم
  useEffect(() => {
    if (!isLoadingNumber && deliveryData.deliveryNumber && !isSaved) {
      const saveDeliveryToDatabase = async () => {
        const currentUser = getCurrentUser();
        if (!currentUser) return;

        try {
          const deliveryDataToSave = {
            deliveryNumber: deliveryData.deliveryNumber,
            clientId: null,
            clientName: deliveryData.clientName,
            clientEmail: deliveryData.clientEmail,
            clientPhone: deliveryData.clientPhone,
            clientAddress: deliveryData.clientAddress,
            deliveryAddress: deliveryData.deliveryAddress,
            deliveryDate: deliveryData.deliveryDate,
            items: deliveryItems,
            notes: deliveryData.notes,
            driverName: deliveryData.driverName,
            driverPhone: deliveryData.driverPhone,
            recipientName: deliveryData.recipientName,
            recipientEmail: deliveryData.recipientEmail,
            recipientPhone: deliveryData.recipientPhone,
            recipientSignature: deliveryData.recipientSignature,
            status: 'pending'
          };
          
          const saveResult = await numberingService.saveDeliveryNote(currentUser.id, deliveryDataToSave);
          if (saveResult.success) {
            setIsSaved(true);
          }
        } catch (error) {
          console.error('Error saving delivery note to database:', error);
        }
      };
      
      saveDeliveryToDatabase();
    }
  }, [deliveryData.deliveryNumber, isLoadingNumber, isSaved]);

  const translations = {
    en: {
      deliveryNote: 'Delivery Note',
      deliveryNumber: 'Delivery Number',
      deliveryDate: 'Delivery Date',
      deliverTo: 'Deliver To',
      clientName: 'Client Name',
      clientEmail: 'Client Email',
      clientPhone: 'Client Phone',
      clientAddress: 'Client Address',
      deliveryAddress: 'Delivery Address',
      description: 'Description',
      itemName: 'Item Name',
      category: 'Category',
      subcategory: 'Subcategory',
      quantity: 'Quantity',
      notes: 'Notes',
      driverName: 'Driver Name',
      driverPhone: 'Driver Phone',
      recipientName: 'Recipient Name',
      recipientEmail: 'Recipient Email',
      recipientPhone: 'Recipient Phone',
      recipientSignature: 'Recipient Signature',
      downloadPDF: 'Download PDF',
      print: 'Print',
      save: 'Save Delivery Note',
      close: 'Close',
      companyInfo: 'Space Zone Delivery',
      companyAddress: 'Business Management System',
      deliveryTerms: 'Please check all items upon delivery and sign below to confirm receipt.',
      thankYou: 'Thank you for your business!',
      enterClientName: 'Enter client name',
      enterClientEmail: 'Enter client email',
      enterClientPhone: 'Enter client phone',
      enterClientAddress: 'Enter client address',
      enterDeliveryAddress: 'Enter delivery address',
      enterNotes: 'Enter delivery notes',
      enterDriverName: 'Enter driver name',
      enterDriverPhone: 'Enter driver phone',
      enterRecipientName: 'Enter recipient name',
      enterRecipientEmail: 'Enter recipient email',
      enterRecipientPhone: 'Enter recipient phone',
      enterSignature: 'Enter recipient signature',
      deliveryGenerated: 'Delivery note generated successfully',
      required: 'Required',
      addItem: 'Add Item',
      removeItem: 'Remove Item',
      editItem: 'Edit Item',
      enterItemName: 'Enter item name',
      enterCategory: 'Enter category',
      enterSubcategory: 'Enter subcategory',
      enterDescription: 'Enter item description',
      items: 'Items',
      noItems: 'No items added',
      itemDetails: 'Item Details',
      deliveryDetails: 'Delivery Details',
      recipientDetails: 'Recipient Details',
      signatureSection: 'Signature Section',
      receivedBy: 'Received By',
      signedBy: 'Signed By',
      dateReceived: 'Date Received'
    },
    ar: {
      deliveryNote: 'إشعار التسليم',
      deliveryNumber: 'رقم التسليم',
      deliveryDate: 'تاريخ التسليم',
      deliverTo: 'التسليم إلى',
      clientName: 'اسم العميل',
      clientEmail: 'بريد العميل الإلكتروني',
      clientPhone: 'هاتف العميل',
      clientAddress: 'عنوان العميل',
      deliveryAddress: 'عنوان التسليم',
      description: 'الوصف',
      itemName: 'اسم العنصر',
      category: 'الفئة',
      subcategory: 'الفئة الفرعية',
      quantity: 'الكمية',
      notes: 'ملاحظات',
      driverName: 'اسم السائق',
      driverPhone: 'هاتف السائق',
      recipientName: 'اسم المستلم',
      recipientEmail: 'بريد المستلم الإلكتروني',
      recipientPhone: 'هاتف المستلم',
      recipientSignature: 'توقيع المستلم',
      downloadPDF: 'تحميل PDF',
      print: 'طباعة',
      save: 'حفظ إشعار التسليم',
      close: 'إغلاق',
      companyInfo: 'سبيس زون للتوصيل',
      companyAddress: 'نظام إدارة الأعمال',
      deliveryTerms: 'يرجى فحص جميع العناصر عند التسليم والتوقيع أدناه لتأكيد الاستلام.',
      thankYou: 'شكراً لك على تعاملك معنا!',
      enterClientName: 'أدخل اسم العميل',
      enterClientEmail: 'أدخل بريد العميل الإلكتروني',
      enterClientPhone: 'أدخل هاتف العميل',
      enterClientAddress: 'أدخل عنوان العميل',
      enterDeliveryAddress: 'أدخل عنوان التسليم',
      enterNotes: 'أدخل ملاحظات التسليم',
      enterDriverName: 'أدخل اسم السائق',
      enterDriverPhone: 'أدخل هاتف السائق',
      enterRecipientName: 'أدخل اسم المستلم',
      enterRecipientEmail: 'أدخل بريد المستلم الإلكتروني',
      enterRecipientPhone: 'أدخل هاتف المستلم',
      enterSignature: 'أدخل توقيع المستلم',
      deliveryGenerated: 'تم إنشاء إشعار التسليم بنجاح',
      required: 'مطلوب',
      addItem: 'إضافة عنصر',
      removeItem: 'إزالة العنصر',
      editItem: 'تعديل العنصر',
      enterItemName: 'أدخل اسم العنصر',
      enterCategory: 'أدخل الفئة',
      enterSubcategory: 'أدخل الفئة الفرعية',
      enterDescription: 'أدخل وصف العنصر',
      items: 'العناصر',
      noItems: 'لم يتم إضافة عناصر',
      itemDetails: 'تفاصيل العنصر',
      deliveryDetails: 'تفاصيل التسليم',
      recipientDetails: 'تفاصيل المستلم',
      signatureSection: 'قسم التوقيع',
      receivedBy: 'استلم بواسطة',
      signedBy: 'وقع بواسطة',
      dateReceived: 'تاريخ الاستلام'
    }
  };

  const t = translations[language];

  const handleInputChange = (field: string, value: string | number) => {
    setDeliveryData(prev => ({ ...prev, [field]: value }));
  };

  // Add new item
  const addItem = () => {
    const newItem: DeliveryItem = {
      id: `item-${Date.now()}`,
      name: '',
      category: '',
      subcategory: '',
      quantity: 1,
      description: ''
    };
    setDeliveryItems(prev => [...prev, newItem]);
  };

  // Remove item
  const removeItem = (itemId: string) => {
    setDeliveryItems(prev => prev.filter(item => item.id !== itemId));
  };

  // Update item
  const updateItem = (itemId: string, field: keyof DeliveryItem, value: string | number) => {
    setDeliveryItems(prev => prev.map(item => {
      if (item.id === itemId) {
        return { ...item, [field]: value };
      }
      return item;
    }));
  };

  const handleDownloadPDF = async () => {
    if (!deliveryRef.current) return;

    try {
      const canvas = await html2canvas(deliveryRef.current, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#f5f1eb'
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
      const imgX = (pdfWidth - imgWidth * ratio) / 2;
      const imgY = 0;

      pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
      pdf.save(`${deliveryData.deliveryNumber}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
    }
  };

  const handlePrint = () => {
    if (!deliveryRef.current) return;
    
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>${t.deliveryNote} - ${deliveryData.deliveryNumber}</title>
          <style>
            body { 
              font-family: 'Arial', sans-serif; 
              margin: 0; 
              padding: 20px; 
              background-color: #f5f1eb;
            }
            .delivery-container { max-width: 800px; margin: 0 auto; }
            .no-print { display: none !important; }
            @media print {
              body { margin: 0; background-color: #f5f1eb; }
              .delivery-container { max-width: none; }
            }
          </style>
        </head>
        <body>
          ${deliveryRef.current.innerHTML}
        </body>
      </html>
    `);
    
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
      
      // Notify parent component that delivery note was created
      if (onDeliveryCreated) {
        onDeliveryCreated();
      }
    }, 250);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-6xl w-full max-h-[95vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className={`flex items-center justify-between p-6 border-b border-gray-200 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <div className="p-2 bg-orange-100 rounded-xl">
              <Truck className="w-6 h-6 text-orange-600" />
            </div>
            <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
              <h2 className="text-2xl font-bold text-gray-800">{t.deliveryNote}</h2>
              <p className="text-gray-600 text-sm">#{deliveryData.deliveryNumber}</p>
            </div>
          </div>

          <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <button
              onClick={handleDownloadPDF}
              className="flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Download className="w-4 h-4" />
              {t.downloadPDF}
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Printer className="w-4 h-4" />
              {t.print}
            </button>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6">
          {/* Delivery Form */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Delivery Details */}
            <div className="space-y-4">
              <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.deliveryDetails}
              </h3>
              
              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.deliveryNumber}
                </label>
                {isLoadingNumber ? (
                  <div className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-gray-500">Loading number...</span>
                  </div>
                ) : (
                  <input
                    type="text"
                    value={deliveryData.deliveryNumber}
                    readOnly
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-50 text-gray-700 cursor-not-allowed"
                  />
                )}
              </div>

              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.deliveryDate}
                </label>
                <input
                  type="date"
                  value={deliveryData.deliveryDate}
                  onChange={(e) => handleInputChange('deliveryDate', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.driverName}
                </label>
                <input
                  type="text"
                  value={deliveryData.driverName}
                  onChange={(e) => handleInputChange('driverName', e.target.value)}
                  placeholder={t.enterDriverName}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.driverPhone}
                </label>
                <input
                  type="tel"
                  value={deliveryData.driverPhone}
                  onChange={(e) => handleInputChange('driverPhone', e.target.value)}
                  placeholder={t.enterDriverPhone}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Client Details */}
            <div className="space-y-4">
              <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.deliverTo}
              </h3>
              
              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.clientName} <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={deliveryData.clientName}
                  onChange={(e) => handleInputChange('clientName', e.target.value)}
                  placeholder={t.enterClientName}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.clientEmail}
                </label>
                <input
                  type="email"
                  value={deliveryData.clientEmail}
                  onChange={(e) => handleInputChange('clientEmail', e.target.value)}
                  placeholder={t.enterClientEmail}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.clientPhone}
                </label>
                <input
                  type="tel"
                  value={deliveryData.clientPhone}
                  onChange={(e) => handleInputChange('clientPhone', e.target.value)}
                  placeholder={t.enterClientPhone}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.deliveryAddress}
                </label>
                <textarea
                  value={deliveryData.deliveryAddress}
                  onChange={(e) => handleInputChange('deliveryAddress', e.target.value)}
                  placeholder={t.enterDeliveryAddress}
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                />
              </div>
            </div>

            {/* Recipient Details */}
            <div className="space-y-4">
              <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.recipientDetails}
              </h3>
              
              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.recipientName}
                </label>
                <input
                  type="text"
                  value={deliveryData.recipientName}
                  onChange={(e) => handleInputChange('recipientName', e.target.value)}
                  placeholder={t.enterRecipientName}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.recipientEmail}
                </label>
                <input
                  type="email"
                  value={deliveryData.recipientEmail}
                  onChange={(e) => handleInputChange('recipientEmail', e.target.value)}
                  placeholder={t.enterRecipientEmail}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.recipientPhone}
                </label>
                <input
                  type="tel"
                  value={deliveryData.recipientPhone}
                  onChange={(e) => handleInputChange('recipientPhone', e.target.value)}
                  placeholder={t.enterRecipientPhone}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t.recipientSignature}
                </label>
                <input
                  type="text"
                  value={deliveryData.recipientSignature}
                  onChange={(e) => handleInputChange('recipientSignature', e.target.value)}
                  placeholder={t.enterSignature}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {/* Items Section */}
          <div className="mb-8">
            <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h3 className={`text-lg font-semibold text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                {t.items}
              </h3>
              <button
                onClick={addItem}
                className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                <Plus className="w-4 h-4" />
                {t.addItem}
              </button>
            </div>

            <div className="space-y-4">
              {deliveryItems.map((item, index) => (
                <div key={item.id} className="bg-gray-50 rounded-2xl p-6 border border-gray-200">
                  <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <h4 className={`font-medium text-gray-800 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {language === 'en' ? `Item ${index + 1}` : `العنصر ${index + 1}`}
                    </h4>
                    {deliveryItems.length > 1 && (
                      <button
                        onClick={() => removeItem(item.id)}
                        className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                        title={t.removeItem}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                    {/* Service Selection */}
                    <div className="lg:col-span-5 mb-4">
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {language === 'en' ? 'Select Service/Product' : 'اختر الخدمة/المنتج'}
                      </label>
                      <select
                        onChange={(e) => {
                          const selectedService = services.find(s => s.id === e.target.value);
                          if (selectedService) {
                            updateItem(item.id, 'name', selectedService.name);
                            updateItem(item.id, 'category', selectedService.category || '');
                            updateItem(item.id, 'subcategory', selectedService.subcategory || '');
                            updateItem(item.id, 'description', selectedService.description || '');
                          }
                        }}
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      >
                        <option value="">{language === 'en' ? 'Custom Item' : 'عنصر مخصص'}</option>
                        {services.filter(s => s.isActive && s.availability_active !== false).map(service => (
                          <option key={service.id} value={service.id}>
                            {service.name} {service.category ? `(${service.category})` : ''}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Item Name */}
                    <div>
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {t.itemName}
                      </label>
                      <input
                        type="text"
                        value={item.name}
                        onChange={(e) => updateItem(item.id, 'name', e.target.value)}
                        placeholder={t.enterItemName}
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
                      />
                    </div>

                    {/* Quantity */}
                      <div className="lg:col-span-3">
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {t.quantity}
                      </label>
                      <input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) => updateItem(item.id, 'quantity', parseInt(e.target.value) || 1)}
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
                      />
                    </div>

                  </div>

                  {/* Subcategory - Full width below other inputs */}
                  <div className="mt-4">
                    <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {t.subcategory}
                    </label>
                    <textarea
                      value={item.subcategory || ''}
                      onChange={(e) => updateItem(item.id, 'subcategory', e.target.value)}
                      placeholder={t.enterSubcategory}
                      rows={6}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm resize-none"
                    />
                  </div>

                  {/* Category - Full-width textarea below other inputs */}
                  <div className="mt-4">
                      <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
                        {t.category}
                      </label>
                      <textarea
                        value={item.category}
                        onChange={(e) => updateItem(item.id, 'category', e.target.value)}
                        placeholder={t.enterCategory}
                        rows={6}
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm resize-none"
                      />
                  </div>

                  {/* Transaction Details Display */}
                  <div className="mt-4 p-3 bg-orange-50 rounded-lg border border-orange-200">
                    <div className="text-xs text-orange-800 font-medium mb-2">
                      {language === 'en' ? 'Transaction Details:' : 'تفاصيل المعاملة:'}
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs text-orange-700">
                      {transaction.amount && (
                        <div>
                          <span className="font-medium">{language === 'en' ? 'Amount:' : 'المبلغ:'}</span> {transaction.amount.toLocaleString()} BHD
                        </div>
                      )}
                      {transaction.vat && transaction.vat > 0 && (
                        <div>
                          <span className="font-medium">{language === 'en' ? 'VAT:' : 'ضريبة القيمة المضافة:'}</span> {transaction.vat.toLocaleString()} BHD ({transaction.vatPercentage || 0}%)
                        </div>
                      )}
                      {transaction.cost && (
                        <div>
                          <span className="font-medium">{language === 'en' ? 'Cost:' : 'التكلفة:'}</span> {transaction.cost.toLocaleString()} BHD
                        </div>
                      )}
                      {transaction.profit && (
                        <div>
                          <span className="font-medium">{language === 'en' ? 'Profit:' : 'الربح:'}</span> {transaction.profit.toLocaleString()} BHD
                        </div>
                      )}
                      {transaction.paymentMethod && (
                        <div>
                          <span className="font-medium">{language === 'en' ? 'Payment:' : 'طريقة الدفع:'}</span> {transaction.paymentMethod}
                        </div>
                      )}
                      {transaction.priority && (
                        <div>
                          <span className="font-medium">{language === 'en' ? 'Priority:' : 'الأولوية:'}</span> {transaction.priority}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div className="mb-8">
            <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
              {t.notes}
            </label>
            <textarea
              value={deliveryData.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              placeholder={t.enterNotes}
              rows={3}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
            />
          </div>

          {/* Delivery Note Preview */}
          <div 
            ref={deliveryRef}
            className="relative w-full max-w-[210mm] mx-auto bg-[#f5f1eb] shadow-2xl"
            style={{ 
              fontFamily: 'Arial, sans-serif',
              aspectRatio: '210/297',
              minHeight: '297mm',
              width: '210mm',
              padding: '12mm',
              boxSizing: 'border-box'
            }}
          >
            {/* Background Decorative Elements */}
            <div className="absolute top-0 right-0 w-24 h-24 opacity-30">
              <svg viewBox="0 0 200 200" className="w-full h-full">
                <path
                  d="M20,20 Q50,10 80,20 T140,30 Q170,40 180,70 T170,130 Q160,160 130,170 T70,160 Q40,150 30,120 T40,60 Q50,30 80,20"
                  fill="none"
                  stroke="#d97706"
                  strokeWidth="1.5"
                  opacity="0.6"
                />
                <path
                  d="M30,30 Q60,20 90,30 T150,40 Q180,50 190,80 T180,140 Q170,170 140,180 T80,170 Q50,160 40,130 T50,70 Q60,40 90,30"
                  fill="none"
                  stroke="#d97706"
                  strokeWidth="1"
                  opacity="0.4"
                />
              </svg>
            </div>

            <div className="absolute bottom-0 left-0 w-20 h-20 opacity-25">
              <svg viewBox="0 0 150 150" className="w-full h-full">
                <path
                  d="M10,10 Q25,5 40,10 T70,15 Q85,20 90,35 T85,65 Q80,80 65,85 T35,80 Q20,75 15,60 T20,30 Q25,15 40,10"
                  fill="none"
                  stroke="#d97706"
                  strokeWidth="1.2"
                  opacity="0.5"
                />
              </svg>
            </div>

            {/* Logo */}
            <div className="absolute top-4 left-4">
              {customLogo ? (
                <div className="w-16 h-16 rounded-xl overflow-hidden border-2 border-gray-200 bg-white flex items-center justify-center shadow-lg">
                  <img
                    src={customLogo}
                    alt="Custom Logo"
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
              ) : (
                <div className="w-16 h-16 bg-black rounded-full flex items-center justify-center relative">
                  <div className="absolute inset-0 border-2 border-yellow-400 rounded-full animate-pulse opacity-60"></div>
                  <div className="absolute inset-1 border border-yellow-300 rounded-full opacity-40"></div>
                  <div className="text-center">
                    <div className="text-yellow-400 font-bold text-[10px] leading-tight">SPACE</div>
                    <div className="text-white font-bold text-[10px] leading-tight">ZONE</div>
                  </div>
                </div>
              )}
            </div>

            {/* Title */}
            <div className="text-center mt-6 mb-8">
              <h1 
                className="text-3xl font-light tracking-[0.3em] text-gray-700"
                style={{ 
                  fontFamily: 'Arial, sans-serif',
                  letterSpacing: '0.3em',
                  fontWeight: '300'
                }}
              >
                DELIVERY NOTE
              </h1>
            </div>

            {/* Deliver To and Details Section */}
            <div className="flex justify-between items-start mb-8">
              <div>
                <div 
                  className="text-gray-500 text-xs font-light tracking-wider mb-3"
                  style={{ letterSpacing: '0.1em' }}
                >
                  DELIVER TO:
                </div>
                <div className="text-gray-800 space-y-1">
                  <div className="font-medium text-base">{deliveryData.clientName || 'Client Name'}</div>
                  {deliveryData.clientEmail && <div className="text-xs">{deliveryData.clientEmail}</div>}
                  {deliveryData.clientPhone && <div className="text-xs">{deliveryData.clientPhone}</div>}
                  {deliveryData.deliveryAddress && <div className="text-xs">{deliveryData.deliveryAddress}</div>}
                </div>
              </div>

              <div className="text-center space-y-1">
                <div>
                  <div className="text-gray-500 text-xs font-light tracking-wider text-center">NO.</div>
                  <div className="text-gray-800 font-medium text-sm text-center">{deliveryData.deliveryNumber}</div>
                </div>
                <div>
                  <div className="text-gray-500 text-xs font-light tracking-wider text-center">DATE.</div>
                  <div className="text-gray-800 font-medium text-sm text-center">
                    {new Date(deliveryData.deliveryDate).toLocaleDateString('en-US')}
                  </div>
                </div>
                {deliveryData.driverName && (
                  <div>
                    <div className="text-gray-500 text-xs font-light tracking-wider text-center">DRIVER.</div>
                    <div className="text-gray-800 font-medium text-sm text-center">{deliveryData.driverName}</div>
                  </div>
                )}
              </div>
            </div>

            {/* Table */}
            <div className="mb-8">
              {/* Table Header */}
              <div className="grid grid-cols-12 gap-1 border-b border-gray-300 pb-2 mb-4">
                <div 
                  className="col-span-1 text-gray-600 text-xs font-light tracking-wider text-center"
                  style={{ letterSpacing: '0.1em' }}
                >
                  S.N
                </div>
                <div 
                  className="col-span-8 text-gray-600 text-xs font-light tracking-wider text-center"
                  style={{ letterSpacing: '0.1em' }}
                >
                  DESCRIPTION
                </div>
                <div 
                  className="col-span-3 text-gray-600 text-xs font-light tracking-wider text-center"
                  style={{ letterSpacing: '0.1em' }}
                >
                  QTY
                </div>
              </div>

              {/* Table Content */}
              <div className="space-y-2 min-h-[200px]">
                {deliveryItems.map((item, index) => (
                  <div key={item.id} className="grid grid-cols-12 gap-1 py-2 border-b border-gray-100">
                    <div className="col-span-1 text-gray-800 text-xs text-center">{index + 1}</div>
                    <div className="col-span-8 text-gray-800 text-xs pl-40">
                      <div className="font-bold text-sm text-left">{item.name || 'Item Name'}</div>
                      {item.category && (
                        <div className="text-sm text-gray-700 mt-1 text-left whitespace-pre-wrap font-bold">
                          {item.category}
                        </div>
                      )}
                      {item.subcategory && (
                        <div className="text-sm text-gray-700 mt-1 text-left">
                          <div className="whitespace-pre-wrap font-bold">{item.subcategory}</div>
                        </div>
                      )}
                      {item.description && (
                        <div className="text-sm text-gray-600 mt-1 text-left font-bold">
                          {item.description}
                        </div>
                      )}
                    </div>
                    <div className="col-span-3 text-gray-800 text-xs text-center">{item.quantity}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Notes Section */}
            {deliveryData.notes && (
              <div className="mb-8">
                <div className="text-gray-600 text-xs font-light tracking-wider mb-2">NOTES:</div>
                <div className="text-gray-800 text-xs whitespace-pre-wrap">{deliveryData.notes}</div>
              </div>
            )}

            {/* Signature Section */}
            <div className="mb-8">
              <div className="text-gray-600 text-xs font-light tracking-wider mb-4">SIGNATURE SECTION:</div>
              <div className="grid grid-cols-2 gap-12">
                {/* اسم المستلم */}
                <div>
                  <div className="text-gray-500 text-xs font-light tracking-wider mb-2">RECIPIENT NAME:</div>
                      <div className="lg:col-span-2">
                    <div className="text-gray-800 text-xs font-medium">
                      {deliveryData.recipientName || '____________________________'}
                    </div>
                  </div>
                  {/* التاريخ تحت اسم المستلم */}
                  <div className="mt-4">
                    <div className="text-gray-500 text-xs font-light tracking-wider mb-2">DATE:</div>
                    <div className="border-b border-gray-400 pb-1 min-h-[20px]">
                      <div className="text-gray-800 text-xs font-medium">
                        {new Date().toLocaleDateString('en-US')}
                      </div>
                    </div>
                  </div>
                </div>

                {/* توقيع المستلم */}
                <div>
                  <div className="text-gray-500 text-xs font-light tracking-wider mb-2">RECIPIENT SIGNATURE:</div>
                  <div className="border-b border-gray-400 pb-1 mb-2 min-h-[25px]">
                    <div className="text-gray-800 text-xs font-medium">
                      {deliveryData.recipientSignature || '____________________________'}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer Section */}
            <div className="absolute bottom-4 left-4 right-4">
              {/* Terms */}
              <div className="text-center mb-4">
                <div className="text-gray-600 text-xs mb-2">{t.deliveryTerms}</div>
              </div>

              {/* Contact Section */}
              <div className="text-center mb-4">
                <div 
                  className="text-gray-700 text-xs font-light tracking-wider mb-1"
                  style={{ letterSpacing: '0.15em' }}
                >
                  CONTACT US FOR MORE DETAIL
                </div>
                <div className="text-gray-600 text-xs">
                  Contact NO: 00973-37155515<br />
                  Call and WhatsApp
                </div>
              </div>

              {/* Thank You Section */}
              <div className="text-center">
                <div className="text-sm">
                  <span className="text-black font-medium">Thank You For </span>
                  <span className="text-yellow-600 font-medium">Your Business </span>
                  <span className="text-black font-bold">SPACE ZONE</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeliveryNoteModal;