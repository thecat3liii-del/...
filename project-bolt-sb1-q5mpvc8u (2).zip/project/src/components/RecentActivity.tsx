import React from 'react';
import { Clock, TrendingUp, TrendingDown, Eye, ArrowRight } from 'lucide-react';

interface Transaction {
  id: string;
  type: 'revenue' | 'expense';
  amount: number;
  description: string;
  date: string;
}

interface RecentActivityProps {
  transactions: Transaction[];
  language: 'en' | 'ar';
}

const RecentActivity: React.FC<RecentActivityProps> = ({ transactions, language }) => {
  const isRTL = language === 'ar';

  const translations = {
    en: {
      title: 'Recent Activity',
      subtitle: 'Latest transactions',
      viewAll: 'View All',
      noActivity: 'No recent activity',
      revenue: 'Revenue',
      expense: 'Expense',
      today: 'Today',
      yesterday: 'Yesterday',
      daysAgo: 'days ago',
      bhd: 'BHD'
    },
    ar: {
      title: 'النشاط الأخير',
      subtitle: 'أحدث المعاملات',
      viewAll: 'عرض الكل',
      noActivity: 'لا يوجد نشاط حديث',
      revenue: 'إيراد',
      expense: 'مصروف',
      today: 'اليوم',
      yesterday: 'أمس',
      daysAgo: 'أيام مضت',
      bhd: 'د.ب'
    }
  };

  const t = translations[language];

  const formatDate = (dateString: string) => {
    if (!dateString) return t.today;
    
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return t.today;
    
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) return t.today;
    if (diffDays === 2) return t.yesterday;
    if (diffDays <= 7) return `${diffDays - 1} ${t.daysAgo}`;
    
    return date.toLocaleDateString(language === 'en' ? 'en-US' : 'ar-SA', {
      month: 'short',
      day: 'numeric'
    });
  };

  const getTransactionIcon = (type: 'revenue' | 'expense') => {
    return type === 'revenue' ? TrendingUp : TrendingDown;
  };

  const getTransactionColor = (type: 'revenue' | 'expense') => {
    return type === 'revenue' 
      ? 'text-green-600 bg-green-100' 
      : 'text-red-600 bg-red-100';
  };

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/50">
      <div className={`flex items-center justify-between mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
          <h3 className="text-xl font-bold text-gray-800 mb-1">{t.title}</h3>
          <p className="text-gray-600 text-sm">{t.subtitle}</p>
        </div>
        
        <button className={`flex items-center gap-2 text-blue-600 hover:text-blue-800 text-sm font-medium transition-colors duration-200 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <span>{t.viewAll}</span>
          <ArrowRight className={`w-4 h-4 ${isRTL ? 'rotate-180' : ''}`} />
        </button>
      </div>

      <div className="space-y-4">
        {transactions.length === 0 ? (
          <div className="text-center py-8">
            <Clock className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 text-sm">{t.noActivity}</p>
          </div>
        ) : (
          transactions.map((transaction, index) => {
            const Icon = getTransactionIcon(transaction.type);
            const colorClass = getTransactionColor(transaction.type);
            
            return (
              <div
                key={transaction.id}
                className={`group flex items-center gap-4 p-4 rounded-xl hover:bg-gray-50 transition-all duration-200 cursor-pointer animate-fadeIn ${isRTL ? 'flex-row-reverse' : ''}`}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className={`p-2 rounded-lg ${colorClass} group-hover:scale-110 transition-transform duration-200`}>
                  <Icon className="w-4 h-4" />
                </div>
                
                <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                  <p className="font-medium text-gray-800 text-sm mb-1 group-hover:text-gray-900 transition-colors">
                    {transaction.description}
                  </p>
                  <div className={`flex items-center gap-2 text-xs text-gray-500 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Clock className="w-3 h-3" />
                    <span>{formatDate(transaction.date)}</span>
                    <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
                    <span className={transaction.type === 'revenue' ? 'text-green-600' : 'text-red-600'}>
                      {transaction.type === 'revenue' ? t.revenue : t.expense}
                    </span>
                  </div>
                </div>
                
                <div className={`${isRTL ? 'text-left' : 'text-right'}`}>
                  <p className={`font-bold text-sm ${
                    transaction.type === 'revenue' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {transaction.type === 'revenue' ? '+' : '-'}{transaction.amount.toLocaleString()} {t.bhd}
                  </p>
                </div>
                
                <Eye className="w-4 h-4 text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
              </div>
            );
          })
        )}
      </div>

      {transactions.length > 0 && (
        <div className="mt-6 pt-4 border-t border-gray-200">
          <div className={`flex items-center justify-between text-sm ${isRTL ? 'flex-row-reverse' : ''}`}>
            <span className="text-gray-600">
              {language === 'en' 
                ? `Showing ${Math.min(5, transactions.length)} of ${transactions.length} transactions`
                : `عرض ${Math.min(5, transactions.length)} من ${transactions.length} معاملة`
              }
            </span>
            <button className="text-blue-600 hover:text-blue-800 font-medium transition-colors duration-200">
              {t.viewAll}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default RecentActivity;