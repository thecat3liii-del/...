import React, { useState, useEffect } from 'react';
import { 
  Target, 
  TrendingUp, 
  Calendar, 
  Award, 
  Zap, 
  Users,
  DollarSign,
  Activity,
  ChevronUp,
  ChevronDown
} from 'lucide-react';

interface Transaction {
  id: string;
  type: 'revenue' | 'expense';
  amount: number;
  description: string;
  date: string;
  month: number;
  year: number;
}

interface Client {
  id: string;
  name: string;
  email: string;
}

interface PerformanceMetricsProps {
  transactions: Transaction[];
  clients: Client[];
  language: 'en' | 'ar';
}

const PerformanceMetrics: React.FC<PerformanceMetricsProps> = ({ 
  transactions, 
  clients, 
  language 
}) => {
  const [selectedPeriod, setSelectedPeriod] = useState<'week' | 'month' | 'quarter'>('month');
  const [animatedValues, setAnimatedValues] = useState({
    efficiency: 0,
    growth: 0,
    satisfaction: 0,
    productivity: 0
  });
  
  const isRTL = language === 'ar';

  const translations = {
    en: {
      title: 'Performance Overview',
      subtitle: 'Key performance indicators',
      efficiency: 'Business Efficiency',
      growth: 'Growth Rate',
      satisfaction: 'Client Satisfaction',
      productivity: 'Productivity Score',
      week: 'This Week',
      month: 'This Month',
      quarter: 'This Quarter',
      excellent: 'Excellent',
      good: 'Good',
      average: 'Average',
      needsImprovement: 'Needs Improvement',
      vsLastPeriod: 'vs last period',
      target: 'Target',
      achieved: 'Achieved',
      onTrack: 'On Track',
      behindTarget: 'Behind Target'
    },
    ar: {
      title: 'نظرة عامة على الأداء',
      subtitle: 'مؤشرات الأداء الرئيسية',
      efficiency: 'كفاءة الأعمال',
      growth: 'معدل النمو',
      satisfaction: 'رضا العملاء',
      productivity: 'نقاط الإنتاجية',
      week: 'هذا الأسبوع',
      month: 'هذا الشهر',
      quarter: 'هذا الربع',
      excellent: 'ممتاز',
      good: 'جيد',
      average: 'متوسط',
      needsImprovement: 'يحتاج تحسين',
      vsLastPeriod: 'مقارنة بالفترة السابقة',
      target: 'الهدف',
      achieved: 'تم تحقيقه',
      onTrack: 'على المسار الصحيح',
      behindTarget: 'خلف الهدف'
    }
  };

  const t = translations[language];

  // Calculate performance metrics
  const calculateMetrics = () => {
    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();
    
    // Business Efficiency (based on profit margin)
    const totalRevenue = transactions
      .filter(t => t.type === 'revenue')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const totalExpenses = transactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const profitMargin = totalRevenue > 0 ? ((totalRevenue - totalExpenses) / totalRevenue) * 100 : 0;
    const efficiency = Math.min(100, Math.max(0, profitMargin + 50)); // Normalize to 0-100

    // Growth Rate (month over month)
    const currentMonthRevenue = transactions
      .filter(t => t.type === 'revenue' && t.month === currentMonth && t.year === currentYear)
      .reduce((sum, t) => sum + t.amount, 0);
    
    const lastMonth = currentMonth === 1 ? 12 : currentMonth - 1;
    const lastMonthYear = currentMonth === 1 ? currentYear - 1 : currentYear;
    
    const lastMonthRevenue = transactions
      .filter(t => t.type === 'revenue' && t.month === lastMonth && t.year === lastMonthYear)
      .reduce((sum, t) => sum + t.amount, 0);
    
    const growthRate = lastMonthRevenue > 0 
      ? ((currentMonthRevenue - lastMonthRevenue) / lastMonthRevenue) * 100 
      : 0;
    
    const normalizedGrowth = Math.min(100, Math.max(0, growthRate + 50)); // Normalize to 0-100

    // Client Satisfaction (simulated based on client retention and transaction frequency)
    const avgTransactionsPerClient = clients.length > 0 ? transactions.length / clients.length : 0;
    const satisfaction = Math.min(100, Math.max(0, (avgTransactionsPerClient * 10) + 60));

    // Productivity Score (based on transaction volume and frequency)
    const transactionsThisMonth = transactions
      .filter(t => t.month === currentMonth && t.year === currentYear).length;
    
    const productivity = Math.min(100, Math.max(0, (transactionsThisMonth * 5) + 40));

    return {
      efficiency: Math.round(efficiency),
      growth: Math.round(normalizedGrowth),
      satisfaction: Math.round(satisfaction),
      productivity: Math.round(productivity)
    };
  };

  const metrics = calculateMetrics();

  // Animate values on mount
  useEffect(() => {
    const duration = 2000;
    const steps = 60;
    const interval = duration / steps;

    const timers = Object.keys(metrics).map((key, index) => {
      return setTimeout(() => {
        let current = 0;
        const target = metrics[key as keyof typeof metrics];
        const increment = target / steps;

        const timer = setInterval(() => {
          current += increment;
          if (current >= target) {
            setAnimatedValues(prev => ({ ...prev, [key]: target }));
            clearInterval(timer);
          } else {
            setAnimatedValues(prev => ({ ...prev, [key]: Math.floor(current) }));
          }
        }, interval);
      }, index * 200);
    });

    return () => timers.forEach(timer => clearTimeout(timer));
  }, [transactions, clients]);

  const getPerformanceLevel = (score: number) => {
    if (score >= 80) return { text: t.excellent, color: 'text-green-600', bg: 'bg-green-100' };
    if (score >= 65) return { text: t.good, color: 'text-blue-600', bg: 'bg-blue-100' };
    if (score >= 50) return { text: t.average, color: 'text-yellow-600', bg: 'bg-yellow-100' };
    return { text: t.needsImprovement, color: 'text-red-600', bg: 'bg-red-100' };
  };

  const performanceItems = [
    {
      key: 'efficiency',
      title: t.efficiency,
      value: animatedValues.efficiency,
      icon: Target,
      color: 'from-blue-500 to-indigo-500',
      target: 75,
      change: 5.2
    },
    {
      key: 'growth',
      title: t.growth,
      value: animatedValues.growth,
      icon: TrendingUp,
      color: 'from-green-500 to-emerald-500',
      target: 60,
      change: 12.8
    },
    {
      key: 'satisfaction',
      title: t.satisfaction,
      value: animatedValues.satisfaction,
      icon: Users,
      color: 'from-purple-500 to-pink-500',
      target: 85,
      change: -2.1
    },
    {
      key: 'productivity',
      title: t.productivity,
      value: animatedValues.productivity,
      icon: Zap,
      color: 'from-orange-500 to-red-500',
      target: 70,
      change: 8.5
    }
  ];

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/20">
      {/* Header */}
      <div className={`flex items-center justify-between mb-8 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
          <h3 className="text-2xl font-bold text-gray-800 mb-2">{t.title}</h3>
          <p className="text-gray-600 text-sm">{t.subtitle}</p>
        </div>

        {/* Period Selector */}
        <div className="flex items-center bg-gray-100 rounded-xl p-1">
          {(['week', 'month', 'quarter'] as const).map((period) => (
            <button
              key={period}
              onClick={() => setSelectedPeriod(period)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                selectedPeriod === period
                  ? 'bg-white shadow-sm text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              {t[period]}
            </button>
          ))}
        </div>
      </div>

      {/* Performance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {performanceItems.map((item, index) => {
          const Icon = item.icon;
          const level = getPerformanceLevel(item.value);
          const isAboveTarget = item.value >= item.target;
          
          return (
            <div
              key={item.key}
              className={`relative overflow-hidden bg-gradient-to-br ${item.color} rounded-2xl p-6 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 animate-fadeIn`}
              style={{ animationDelay: `${index * 150}ms` }}
            >
              {/* Background Pattern */}
              <div className="absolute inset-0 opacity-10">
                <div className="absolute top-0 right-0 w-32 h-32 bg-white rounded-full transform translate-x-16 -translate-y-16"></div>
                <div className="absolute bottom-0 left-0 w-24 h-24 bg-white rounded-full transform -translate-x-12 translate-y-12"></div>
              </div>

              <div className="relative z-10">
                <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <Icon className="w-8 h-8" />
                  <div className={`flex items-center gap-1 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    {item.change > 0 ? (
                      <ChevronUp className="w-4 h-4 text-green-300" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-red-300" />
                    )}
                    <span className="text-sm font-medium">
                      {Math.abs(item.change)}%
                    </span>
                  </div>
                </div>

                <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                  <h4 className="text-lg font-semibold mb-2">{item.title}</h4>
                  
                  {/* Animated Progress */}
                  <div className="flex items-end gap-2 mb-3">
                    <span className="text-3xl font-bold">{item.value}</span>
                    <span className="text-lg opacity-80">%</span>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-white/20 rounded-full h-2 mb-3">
                    <div
                      className="bg-white rounded-full h-2 transition-all duration-1000 ease-out"
                      style={{ width: `${item.value}%` }}
                    ></div>
                  </div>

                  {/* Target Indicator */}
                  <div className={`flex items-center justify-between text-sm ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <span className="opacity-80">{t.target}: {item.target}%</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      isAboveTarget 
                        ? 'bg-green-500/20 text-green-100' 
                        : 'bg-orange-500/20 text-orange-100'
                    }`}>
                      {isAboveTarget ? t.achieved : t.behindTarget}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Performance Summary */}
      <div className="bg-gradient-to-r from-gray-50 to-blue-50 rounded-2xl p-6">
        <div className={`flex items-center gap-4 mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div className="p-3 bg-blue-100 rounded-xl">
            <Activity className="w-6 h-6 text-blue-600" />
          </div>
          <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
            <h4 className="text-lg font-semibold text-gray-800">
              {language === 'en' ? 'Overall Performance' : 'الأداء العام'}
            </h4>
            <p className="text-gray-600 text-sm">
              {language === 'en' 
                ? 'Based on your current metrics and trends'
                : 'بناءً على مقاييسك واتجاهاتك الحالية'
              }
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white/80 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Award className="w-5 h-5 text-yellow-500" />
              <span className="font-medium text-gray-800">
                {language === 'en' ? 'Top Performer' : 'الأداء الأفضل'}
              </span>
            </div>
            <p className="text-sm text-gray-600">
              {performanceItems.reduce((prev, current) => 
                prev.value > current.value ? prev : current
              ).title}
            </p>
          </div>

          <div className="bg-white/80 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Target className="w-5 h-5 text-blue-500" />
              <span className="font-medium text-gray-800">
                {language === 'en' ? 'Targets Met' : 'الأهداف المحققة'}
              </span>
            </div>
            <p className="text-sm text-gray-600">
              {performanceItems.filter(item => item.value >= item.target).length} / {performanceItems.length}
            </p>
          </div>

          <div className="bg-white/80 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-5 h-5 text-green-500" />
              <span className="font-medium text-gray-800">
                {language === 'en' ? 'Avg Growth' : 'متوسط النمو'}
              </span>
            </div>
            <p className="text-sm text-gray-600">
              +{(performanceItems.reduce((sum, item) => sum + item.change, 0) / performanceItems.length).toFixed(1)}%
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerformanceMetrics;