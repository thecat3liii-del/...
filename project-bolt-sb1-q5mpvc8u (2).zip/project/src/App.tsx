import React, { useState, useEffect } from 'react';
import { User, Building2, Eye, EyeOff, Mail, Lock, UserPlus, LogIn, Globe } from 'lucide-react';
import { User as AppUser } from './types';
import { supabase, authService, employeeDetailedPermissionService } from './lib/supabase';
import ForgotPasswordPage from './components/ForgotPasswordPage';
import { passwordResetService } from './lib/passwordResetService';
import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import Dashboard from './components/Dashboard';
import TransactionPage from './components/TransactionPage';
import FinancialReports from './components/FinancialReports';
import ClientsPage from './components/ClientsPage';
import EmployeesPage from './components/EmployeesPage';
import EmployeePermissions from './components/EmployeePermissions';
import SuppliersPage from './components/SuppliersPage';
import ServicesPage from './components/ServicesPage';
import QuotationInvoicePage from './components/QuotationInvoicePage';
import TaskManagementPage from './components/TaskManagementPage';
import SettingsPage from './components/SettingsPage';

const App: React.FC = () => {
  const [language, setLanguage] = useState<'en' | 'ar'>('en');
  const [currentUser, setCurrentUser] = useState<AppUser | null>(null);
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedRole, setSelectedRole] = useState<'boss' | 'employee' | null>(null);
  const [isLoginMode, setIsLoginMode] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);

  // تنظيف الرموز المنتهية الصلاحية عند تحميل التطبيق
  useEffect(() => {
    passwordResetService.cleanupExpiredCodes();
  }, []);
  const [employeeDetailedAccess, setEmployeeDetailedAccess] = useState<{ [pageName: string]: { view: boolean; add: boolean; edit: boolean; delete: boolean } }>({});

  // Boss registration form state
  const [bossForm, setBossForm] = useState({
    fullName: '',
    email: '',
    password: '',
  });

  // Employee login form state
  const [employeeForm, setEmployeeForm] = useState({
    email: '',
    password: '',
  });

  // Form validation states
  const [bossValidation, setBossValidation] = useState({
    fullName: { isValid: false, message: '' },
    email: { isValid: false, message: '' },
    password: { isValid: false, message: '' },
  });

  const [employeeValidation, setEmployeeValidation] = useState({
    email: { isValid: false, message: '' },
    password: { isValid: false, message: '' },
  });

  const translations = {
    en: {
      title: 'Space Zone',
      subtitle: 'Accounting Management System',
      selectRole: 'Select Your Role',
      boss: 'Management (Admin)',
      employee: 'Employee',
      bossDesc: 'Create and manage your account',
      employeeDesc: 'Access your workspace',
      bossLoginDesc: 'Login to your admin account',
      createAccount: 'Create Account',
      login: 'Login',
      switchToLogin: 'Already have an account? Login',
      switchToRegister: 'Need an account? Create one',
      fullName: 'Full Name',
      email: 'Email Address',
      password: 'Password',
      createAccountBtn: 'Create Account',
      loginBtn: 'Login',
      backToRoles: 'Back to Role Selection',
      language: 'Language',
      loading: 'Processing...',
      accountCreated: 'Account created successfully! Please login.',
      loginSuccess: 'Login successful! Redirecting...',
      accessDenied: 'Access denied. Please ask your Boss to add you first.',
      invalidCredentials: 'Invalid email or password.',
      fillAllFields: 'Please fill all fields correctly.',
      invalidEmail: 'Please enter a valid email address.',
      passwordTooShort: 'Password must be at least 6 characters.',
      nameRequired: 'Full name is required.',
    },
    ar: {
      title: 'سبيس زون',
      subtitle: 'نظام إدارة المحاسبة',
      selectRole: 'اختر دورك',
      boss: 'المدير (المسؤول)',
      employee: 'الموظف',
      bossDesc: 'إنشاء وإدارة حسابك',
      employeeDesc: 'الوصول إلى مساحة العمل',
      bossLoginDesc: 'تسجيل الدخول إلى حساب المدير',
      createAccount: 'إنشاء حساب',
      login: 'تسجيل الدخول',
      switchToLogin: 'لديك حساب بالفعل؟ سجل الدخول',
      switchToRegister: 'تحتاج حساب؟ أنشئ واحداً',
      fullName: 'الاسم الكامل',
      email: 'عنوان البريد الإلكتروني',
      password: 'كلمة المرور',
      createAccountBtn: 'إنشاء حساب',
      loginBtn: 'تسجيل الدخول',
      backToRoles: 'العودة لاختيار الدور',
      language: 'اللغة',
      loading: 'جاري المعالجة...',
      accountCreated: 'تم إنشاء الحساب بنجاح! يرجى تسجيل الدخول.',
      loginSuccess: 'تم تسجيل الدخول بنجاح! جاري التحويل...',
      accessDenied: 'تم رفض الوصول. يرجى مطالبة المدير بإضافتك أولاً.',
      invalidCredentials: 'بريد إلكتروني أو كلمة مرور غير صحيحة.',
      fillAllFields: 'يرجى ملء جميع الحقول بشكل صحيح.',
      invalidEmail: 'يرجى إدخال عنوان بريد إلكتروني صحيح.',
      passwordTooShort: 'يجب أن تكون كلمة المرور 6 أحرف على الأقل.',
      nameRequired: 'الاسم الكامل مطلوب.',
    },
  };

  const t = translations[language];
  const isRTL = language === 'ar';

  // Check for existing user session on app load
  useEffect(() => {
    const checkSession = async () => {
      // Load employee page permissions if user is an employee
      const loadEmployeeDetailedPermissions = async (userId: string) => {
        try {
          const result = await employeeDetailedPermissionService.getEmployeeDetailedPermissions(userId);
          if (result.success) {
            const permissions = result.data.reduce((acc, permission) => {
              acc[permission.page_name] = {
                view: permission.can_view,
                add: permission.can_add,
                edit: permission.can_edit,
                delete: permission.can_delete
              };
              return acc;
            }, {} as { [pageName: string]: { view: boolean; add: boolean; edit: boolean; delete: boolean } });
            setEmployeeDetailedAccess(permissions);
          }
        } catch (error) {
          console.error('Error loading employee detailed permissions:', error);
        }
      };

      const savedUser = localStorage.getItem('currentUser');
      if (savedUser) {
        try {
          const user = JSON.parse(savedUser);
          // التحقق من صحة الجلسة مع قاعدة البيانات
          if (user.role === 'boss') {
            const { success } = await authService.loginBoss(user.email, user.password);
            if (success) {
              setCurrentUser(user);
              // Boss has access to all pages
              setEmployeeDetailedAccess({
                'home': { view: true, add: true, edit: true, delete: true },
                'transactions': { view: true, add: true, edit: true, delete: true },
                'quotations-invoices': { view: true, add: true, edit: true, delete: true },
                'reports': { view: true, add: true, edit: true, delete: true },
                'clients': { view: true, add: true, edit: true, delete: true },
                'employees': { view: true, add: true, edit: true, delete: true },
                'permissions': { view: true, add: true, edit: true, delete: true },
                'suppliers': { view: true, add: true, edit: true, delete: true },
                'services': { view: true, add: true, edit: true, delete: true },
                'settings': { view: true, add: true, edit: true, delete: true }
              });
            } else {
              localStorage.removeItem('currentUser');
            }
          } else if (user.role === 'employee') {
            const { success } = await authService.loginEmployee(user.email, user.password);
            if (success) {
              setCurrentUser(user);
              await loadEmployeeDetailedPermissions(user.id);
            } else {
              localStorage.removeItem('currentUser');
            }
          }
        } catch (error) {
          console.error('Error validating session:', error);
          localStorage.removeItem('currentUser');
        }
      }
    };

    checkSession();
    
    // Load sidebar state from localStorage
    const savedSidebarState = localStorage.getItem('sidebarCollapsed');
    if (savedSidebarState) {
      try {
        setIsSidebarCollapsed(JSON.parse(savedSidebarState));
      } catch (error) {
        console.error('Error parsing sidebar state:', error);
        setIsSidebarCollapsed(false);
      }
    }
  }, []);
  
  // Save sidebar state to localStorage
  useEffect(() => {
    localStorage.setItem('sidebarCollapsed', JSON.stringify(isSidebarCollapsed));
  }, [isSidebarCollapsed]);

  // Generate unique database key for each boss
  const getBossDataKey = (bossId: string, dataType: string) => {
    return `spaceZone_Management_${bossId}_${dataType}`;
  };

  // Get current boss's data key
  const getCurrentBossDataKey = (dataType: string) => {
    if (!currentUser || currentUser.role !== 'boss') return null;
    return getBossDataKey(currentUser.id, dataType);
  };

  // Local database functions
  // تم نقل جميع وظائف قاعدة البيانات إلى Supabase

  // Validation functions
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validateBossForm = (field?: string) => {
    const validation = { ...bossValidation };

    if (!field || field === 'fullName') {
      if (bossForm.fullName.trim().length < 2) {
        validation.fullName = { isValid: false, message: t.nameRequired };
      } else {
        validation.fullName = { isValid: true, message: '' };
      }
    }

    if (!field || field === 'email') {
      if (!validateEmail(bossForm.email)) {
        validation.email = { isValid: false, message: t.invalidEmail };
      } else {
        validation.email = { isValid: true, message: '' };
      }
    }

    if (!field || field === 'password') {
      if (bossForm.password.length < 6) {
        validation.password = { isValid: false, message: t.passwordTooShort };
      } else {
        validation.password = { isValid: true, message: '' };
      }
    }

    setBossValidation(validation);
    return validation.fullName.isValid && validation.email.isValid && validation.password.isValid;
  };

  const validateEmployeeForm = (field?: string) => {
    const validation = { ...employeeValidation };

    if (!field || field === 'email') {
      if (!validateEmail(employeeForm.email)) {
        validation.email = { isValid: false, message: t.invalidEmail };
      } else {
        validation.email = { isValid: true, message: '' };
      }
    }

    if (!field || field === 'password') {
      if (employeeForm.password.length < 1) {
        validation.password = { isValid: false, message: 'Password is required' };
      } else {
        validation.password = { isValid: true, message: '' };
      }
    }

    setEmployeeValidation(validation);
    return validation.email.isValid && validation.password.isValid;
  };

  // Form handlers
  const handleBossInputChange = (field: string, value: string) => {
    setBossForm(prev => ({ ...prev, [field]: value }));
    setError('');
    setTimeout(() => validateBossForm(field), 100);
  };

  const handleEmployeeInputChange = (field: string, value: string) => {
    setEmployeeForm(prev => ({ ...prev, [field]: value }));
    setError('');
    setTimeout(() => validateEmployeeForm(field), 100);
  };

  const handleBossSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateBossForm()) {
      setError(t.fillAllFields);
      return;
    }

    // التحقق من وجود البريد الإلكتروني في قاعدة البيانات
    const emailExists = await authService.checkEmailExists(bossForm.email);
    if (emailExists) {
      setError('Email already exists. Please use a different email.');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // تسجيل المدير في قاعدة البيانات
      const result = await authService.registerBoss(
        bossForm.fullName,
        bossForm.email,
        bossForm.password
      );

      if (result.success) {
        setIsLoading(false);
        setSuccess(t.accountCreated);
        setBossForm({ fullName: '', email: '', password: '' });
        
        setTimeout(() => {
          setSuccess('');
          setIsLoginMode(true);
        }, 2000);
      } else {
        setIsLoading(false);
        setError(result.error || 'Failed to create account. Please try again.');
      }
    } catch (error) {
      setIsLoading(false);
      setError('Failed to create account. Please try again.');
    }
  };

  const handleEmployeeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateEmployeeForm()) {
      setError(t.fillAllFields);
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // تسجيل دخول الموظف من قاعدة البيانات
      const result = await authService.loginEmployee(
        employeeForm.email,
        employeeForm.password
      );

      if (result.success && result.user) {
        const user: AppUser = {
          id: result.user.id,
          fullName: result.user.full_name,
          email: result.user.email,
          password: result.user.password,
          role: 'employee',
          bossId: result.user.boss_id
        };

        setIsLoading(false);
        setSuccess(t.loginSuccess);
        setCurrentUser(user);
        
        // Load page permissions for employee
        if (result.user) {
          const permissionsResult = await employeeDetailedPermissionService.getEmployeeDetailedPermissions(result.user.id);
          if (permissionsResult.success) {
            const permissions = permissionsResult.data.reduce((acc, permission) => {
              acc[permission.page_name] = {
                view: permission.can_view,
                add: permission.can_add,
                edit: permission.can_edit,
                delete: permission.can_delete
              };
              return acc;
            }, {} as { [pageName: string]: { view: boolean; add: boolean; edit: boolean; delete: boolean } });
            setEmployeeDetailedAccess(permissions);
          }
        }
        
        setTimeout(() => {
          localStorage.setItem('currentUser', JSON.stringify(user));
        }, 1500);
      } else {
        setIsLoading(false);
        setError(t.accessDenied);
      }
    } catch (error) {
      setIsLoading(false);
      setError('Login failed. Please try again.');
    }
  };

  const handleBossLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateEmployeeForm()) {
      setError(t.fillAllFields);
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // تسجيل دخول المدير من قاعدة البيانات
      const result = await authService.loginBoss(
        employeeForm.email,
        employeeForm.password
      );

      if (result.success && result.user) {
        const user: AppUser = {
          id: result.user.id,
          fullName: result.user.full_name,
          email: result.user.email,
          password: result.user.password,
          role: 'boss'
        };

        setIsLoading(false);
        setSuccess(t.loginSuccess);
        setCurrentUser(user);
        
        // Boss has access to all pages
        setEmployeeDetailedAccess({
          'home': { view: true, add: true, edit: true, delete: true },
          'transactions': { view: true, add: true, edit: true, delete: true },
          'quotations-invoices': { view: true, add: true, edit: true, delete: true },
          'reports': { view: true, add: true, edit: true, delete: true },
          'clients': { view: true, add: true, edit: true, delete: true },
          'employees': { view: true, add: true, edit: true, delete: true },
          'permissions': { view: true, add: true, edit: true, delete: true },
          'suppliers': { view: true, add: true, edit: true, delete: true },
          'services': { view: true, add: true, edit: true, delete: true },
          'settings': { view: true, add: true, edit: true, delete: true }
        });
        
        setTimeout(() => {
          localStorage.setItem('currentUser', JSON.stringify(user));
        }, 1500);
      } else {
        setIsLoading(false);
        setError(t.invalidCredentials);
      }
    } catch (error) {
      setIsLoading(false);
      setError('Login failed. Please try again.');
    }
  };

  const resetForms = () => {
    setBossForm({ fullName: '', email: '', password: '' });
    setEmployeeForm({ email: '', password: '' });
    setError('');
    setSuccess('');
    setShowPassword(false);
  };

  const handleRoleSelect = (role: 'boss' | 'employee') => {
    setSelectedRole(role);
    setIsLoginMode(role === 'employee');
    resetForms();
  };

  const handleBackToRoles = () => {
    setSelectedRole(null);
    setIsLoginMode(false);
    resetForms();
  };

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    setCurrentUser(null);
    setCurrentPage('home');
    setSelectedRole(null);
    setIsLoginMode(false);
    resetForms();
  };

  // Derive form validity from validation state objects
  const isBossFormValid = bossValidation.fullName.isValid && bossValidation.email.isValid && bossValidation.password.isValid;
  const isEmployeeFormValid = employeeValidation.email.isValid && employeeValidation.password.isValid;

  useEffect(() => {
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language, isRTL]);

  // Get boss data for employee access
  const getBossDataForEmployee = () => {
    if (currentUser?.role === 'employee' && (currentUser as any).bossId) {
      return (currentUser as any).bossId;
    }
    return currentUser?.id;
  };

  // Check if current user has access to a page
  const hasPageAccess = (pageName: string, action: 'view' | 'add' | 'edit' | 'delete' = 'view'): boolean => {
    if (currentUser?.role === 'boss') return true;
    return employeeDetailedAccess[pageName]?.[action] || false;
  };

  // If user is logged in, show a simple welcome message
  if (currentUser) {
    return (
      <div className={`min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 relative overflow-hidden ${isRTL ? 'font-arabic' : 'font-english'}`}>
        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-gradient-to-r from-blue-200 to-indigo-200 rounded-full mix-blend-multiply filter blur-xl opacity-40 animate-float-slow"></div>
          <div className="absolute top-1/3 right-1/4 w-48 h-48 bg-gradient-to-r from-purple-200 to-pink-200 rounded-full mix-blend-multiply filter blur-xl opacity-35 animate-float-medium animation-delay-2000"></div>
          <div className="absolute bottom-1/4 left-1/3 w-56 h-56 bg-gradient-to-r from-teal-200 to-cyan-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-float-fast animation-delay-4000"></div>
        </div>

        {/* Sidebar */}
        <Sidebar 
          language={language} 
          currentPage={currentPage} 
          onPageChange={setCurrentPage} 
          userRole={currentUser.role}
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        />

        {/* Main Content */}
        <div className={`${isRTL ? (isSidebarCollapsed ? 'mr-16' : 'mr-64') : (isSidebarCollapsed ? 'ml-16' : 'ml-64')} min-h-screen relative z-10 transition-all duration-300 ease-in-out`}>
          {/* Top Bar */}
          <div className={`sticky top-0 z-30 bg-white/80 backdrop-blur-sm border-b border-gray-200 px-8 py-4`}>
            <div className={`flex justify-end ${isRTL ? 'flex-row-reverse' : ''}`}>
              <TopBar 
                language={language}
                onLanguageChange={() => setLanguage(language === 'en' ? 'ar' : 'en')}
                onLogout={handleLogout}
                userProfileImage={undefined}
                userName={currentUser.fullName}
                isSidebarCollapsed={isSidebarCollapsed}
              />
            </div>
          </div>

          {/* Page Content */}
          <div className="p-8">
            {currentPage === 'home' && (
              <Dashboard user={currentUser} language={language} bossId={getBossDataForEmployee()} onPageChange={setCurrentPage} />
            )}
            {currentPage === 'transactions' && hasPageAccess('transactions') && (
              <TransactionPage 
                language={language} 
                bossId={getBossDataForEmployee()} 
                userPermissions={currentUser?.role === 'boss' ? { view: true, add: true, edit: true, delete: true } : employeeDetailedAccess['transactions']}
              />
            )}
            {currentPage === 'quotations-invoices' && hasPageAccess('quotations-invoices') && (
              <QuotationInvoicePage 
                language={language} 
                bossId={getBossDataForEmployee()}
                userPermissions={currentUser?.role === 'boss' ? { view: true, add: true, edit: true, delete: true } : employeeDetailedAccess['quotations-invoices']}
              />
            )}
            {currentPage === 'tasks-projects' && hasPageAccess('tasks-projects') && (
              <TaskManagementPage 
                language={language} 
                bossId={getBossDataForEmployee()}
                userPermissions={currentUser?.role === 'boss' ? { view: true, add: true, edit: true, delete: true } : employeeDetailedAccess['tasks-projects']}
              />
            )}
            {currentPage === 'reports' && hasPageAccess('reports') && (
              <FinancialReports 
                language={language} 
                bossId={getBossDataForEmployee()}
                userPermissions={currentUser?.role === 'boss' ? { view: true, add: true, edit: true, delete: true } : employeeDetailedAccess['reports']}
              />
            )}
            {currentPage === 'clients' && hasPageAccess('clients') && (
              <ClientsPage 
                language={language} 
                bossId={getBossDataForEmployee()}
                userPermissions={currentUser?.role === 'boss' ? { view: true, add: true, edit: true, delete: true } : employeeDetailedAccess['clients']}
              />
            )}
            {currentPage === 'employees' && currentUser.role === 'boss' && (
              <EmployeesPage language={language} />
            )}
            {currentPage === 'permissions' && currentUser.role === 'boss' && (
              <EmployeePermissions language={language} />
            )}
            {currentPage === 'suppliers' && hasPageAccess('suppliers') && (
              <SuppliersPage 
                language={language} 
                bossId={getBossDataForEmployee()}
                userPermissions={currentUser?.role === 'boss' ? { view: true, add: true, edit: true, delete: true } : employeeDetailedAccess['suppliers']}
              />
            )}
            {currentPage === 'services' && hasPageAccess('services') && (
              <ServicesPage 
                language={language} 
                bossId={getBossDataForEmployee()}
                userPermissions={currentUser?.role === 'boss' ? { view: true, add: true, edit: true, delete: true } : employeeDetailedAccess['services']}
              />
            )}
            {currentPage === 'settings' && hasPageAccess('settings') && (
              <SettingsPage 
                language={language} 
                onLanguageChange={() => setLanguage(language === 'en' ? 'ar' : 'en')}
                userPermissions={currentUser?.role === 'boss' ? { view: true, add: true, edit: true, delete: true } : employeeDetailedAccess['settings']}
              />
            )}
            
            {/* Access Denied Message */}
            {!hasPageAccess(currentPage) && currentPage !== 'home' && (
              <div className="flex items-center justify-center min-h-96">
                <div className="text-center">
                  <div className="w-24 h-24 bg-gradient-to-r from-red-500 to-rose-500 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Lock className="w-12 h-12 text-white" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-800 mb-4">
                    {language === 'en' ? 'Access Denied' : 'تم رفض الوصول'}
                  </h2>
                  <p className="text-gray-600 text-lg">
                    {language === 'en' 
                      ? 'You do not have permission to access this page. Please contact your administrator.'
                      : 'ليس لديك صلاحية للوصول إلى هذه الصفحة. يرجى الاتصال بالمدير.'
                    }
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (showForgotPassword) {
    return (
      <ForgotPasswordPage
        language={language}
        onBack={() => setShowForgotPassword(false)}
      />
    );
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 relative overflow-hidden ${isRTL ? 'font-arabic' : 'font-english'}`}>
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Primary floating circles */}
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-gradient-to-r from-blue-200 to-indigo-200 rounded-full mix-blend-multiply filter blur-xl opacity-40 animate-float-slow"></div>
        <div className="absolute top-1/3 right-1/4 w-48 h-48 bg-gradient-to-r from-purple-200 to-pink-200 rounded-full mix-blend-multiply filter blur-xl opacity-35 animate-float-medium animation-delay-2000"></div>
        <div className="absolute bottom-1/4 left-1/3 w-56 h-56 bg-gradient-to-r from-teal-200 to-cyan-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-float-fast animation-delay-4000"></div>
        <div className="absolute bottom-1/3 right-1/3 w-40 h-40 bg-gradient-to-r from-rose-200 to-orange-200 rounded-full mix-blend-multiply filter blur-xl opacity-25 animate-float-slow animation-delay-6000"></div>
        
        {/* Secondary ambient circles */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-r from-indigo-100 to-blue-100 rounded-full mix-blend-multiply filter blur-2xl opacity-20 animate-pulse-slow"></div>
        <div className="absolute top-20 left-20 w-32 h-32 bg-gradient-to-r from-violet-200 to-purple-200 rounded-full mix-blend-multiply filter blur-lg opacity-30 animate-float-medium animation-delay-1000"></div>
        <div className="absolute bottom-20 right-20 w-36 h-36 bg-gradient-to-r from-emerald-200 to-teal-200 rounded-full mix-blend-multiply filter blur-lg opacity-25 animate-float-fast animation-delay-3000"></div>
        <div className="absolute top-2/3 left-10 w-28 h-28 bg-gradient-to-r from-sky-200 to-blue-200 rounded-full mix-blend-multiply filter blur-lg opacity-35 animate-float-slow animation-delay-5000"></div>
      </div>

      {/* Language Switch */}
      <div className={`absolute top-6 ${isRTL ? 'left-6' : 'right-6'} z-10`}>
        <button
          onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
          className="flex items-center gap-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:bg-white group"
        >
          <Globe className="w-4 h-4 text-slate-600 group-hover:text-blue-600 transition-colors" />
          <span className="text-sm font-medium text-slate-700 group-hover:text-blue-700">
            {language === 'en' ? 'العربية' : 'English'}
          </span>
        </button>
      </div>

      <div className="relative z-10 flex items-center justify-center min-h-screen p-4">
        <div className="w-full max-w-md">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-6 shadow-xl mb-6">
              <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-2">
                {t.title}
              </h1>
              <p className="text-slate-600 text-lg">{t.subtitle}</p>
            </div>
          </div>

          {/* Role Selection */}
          {!selectedRole && (
            <div className="animate-fadeIn">
              <h2 className="text-2xl font-semibold text-center text-slate-800 mb-8">{t.selectRole}</h2>
              
              <div className="space-y-4">
                <button
                  onClick={() => handleRoleSelect('boss')}
                  className="w-full bg-white/80 backdrop-blur-sm hover:bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 group transform hover:-translate-y-1"
                >
                  <div className="flex items-center gap-4">
                    <div className="bg-gradient-to-r from-blue-500 to-indigo-500 p-3 rounded-xl group-hover:scale-110 transition-transform duration-300">
                      <Building2 className="w-6 h-6 text-white" />
                    </div>
                    <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <h3 className="font-semibold text-slate-800 text-lg">{t.boss}</h3>
                      <p className="text-slate-600 text-sm">{isLoginMode ? t.bossLoginDesc : t.bossDesc}</p>
                    </div>
                  </div>
                </button>

                <button
                  onClick={() => handleRoleSelect('employee')}
                  className="w-full bg-white/80 backdrop-blur-sm hover:bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 group transform hover:-translate-y-1"
                >
                  <div className="flex items-center gap-4">
                    <div className="bg-gradient-to-r from-emerald-500 to-teal-500 p-3 rounded-xl group-hover:scale-110 transition-transform duration-300">
                      <User className="w-6 h-6 text-white" />
                    </div>
                    <div className={`flex-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                      <h3 className="font-semibold text-slate-800 text-lg">{t.employee}</h3>
                      <p className="text-slate-600 text-sm">{t.employeeDesc}</p>
                    </div>
                  </div>
                </button>
              </div>
            </div>
          )}

          {/* Boss Registration/Login Form */}
          {selectedRole === 'boss' && !isLoginMode && (
            <div className="animate-slideIn">
              <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl p-8">
                <div className="text-center mb-6">
                  <div className="bg-gradient-to-r from-blue-500 to-indigo-500 p-3 rounded-xl inline-block mb-4">
                    <Building2 className="w-8 h-8 text-white" />
                  </div>
                  <h2 className="text-2xl font-semibold text-slate-800">{t.createAccount}</h2>
                </div>

                <form onSubmit={handleBossSubmit} className="space-y-4">
                  {/* Full Name */}
                  <div>
                    <div className="relative">
                      <div className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 z-10`}>
                        <User className={`w-5 h-5 transition-colors duration-200 ${
                          bossForm.fullName ? 'text-blue-600' : 'text-slate-400'
                        }`} />
                      </div>
                      <input
                        type="text"
                        value={bossForm.fullName}
                        onChange={(e) => handleBossInputChange('fullName', e.target.value)}
                        placeholder={t.fullName}
                        className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white/50 backdrop-blur-sm ${
                          bossValidation.fullName.message && !bossValidation.fullName.isValid ? 'border-red-300 ring-1 ring-red-200' : ''
                        }`}
                      />
                    </div>
                    {bossValidation.fullName.message && !bossValidation.fullName.isValid && (
                      <p className="text-red-500 text-sm mt-1 animate-fadeIn">{bossValidation.fullName.message}</p>
                    )}
                  </div>

                  {/* Email */}
                  <div>
                    <div className="relative">
                      <div className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 z-10`}>
                        <Mail className={`w-5 h-5 transition-colors duration-200 ${
                          bossForm.email ? 'text-blue-600' : 'text-slate-400'
                        }`} />
                      </div>
                      <input
                        type="email"
                        value={bossForm.email}
                        onChange={(e) => handleBossInputChange('email', e.target.value)}
                        placeholder={t.email}
                        className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white/50 backdrop-blur-sm ${
                          bossValidation.email.message && !bossValidation.email.isValid ? 'border-red-300 ring-1 ring-red-200' : ''
                        }`}
                      />
                    </div>
                    {bossValidation.email.message && !bossValidation.email.isValid && (
                      <p className="text-red-500 text-sm mt-1 animate-fadeIn">{bossValidation.email.message}</p>
                    )}
                  </div>

                  {/* Password */}
                  <div>
                    <div className="relative">
                      <div className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 z-10`}>
                        <Lock className={`w-5 h-5 transition-colors duration-200 ${
                          bossForm.password ? 'text-blue-600' : 'text-slate-400'
                        }`} />
                      </div>
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={bossForm.password}
                        onChange={(e) => handleBossInputChange('password', e.target.value)}
                        placeholder={t.password}
                        className={`w-full ${isRTL ? 'pr-12 pl-12' : 'pl-12 pr-12'} py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white/50 backdrop-blur-sm ${
                          bossValidation.password.message && !bossValidation.password.isValid ? 'border-red-300 ring-1 ring-red-200' : ''
                        }`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className={`absolute ${isRTL ? 'left-3' : 'right-3'} top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors duration-200`}
                      >
                        {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                    {bossValidation.password.message && !bossValidation.password.isValid && (
                      <p className="text-red-500 text-sm mt-1 animate-fadeIn">{bossValidation.password.message}</p>
                    )}
                  </div>

                  {/* Error/Success Messages */}
                  {error && (
                    <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl animate-fadeIn">
                      {error}
                    </div>
                  )}
                  
                  {success && (
                    <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl animate-fadeIn">
                      {success}
                    </div>
                  )}

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isLoading || !isBossFormValid}
                    className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed transform hover:-translate-y-0.5 shadow-lg hover:shadow-xl"
                  >
                    {isLoading ? (
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        {t.loading}
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-2">
                        <UserPlus className="w-5 h-5" />
                        {t.createAccountBtn}
                      </div>
                    )}
                  </button>

                  {/* Back Button */}
                  <button
                    type="button"
                    onClick={handleBackToRoles}
                    className="w-full text-slate-600 hover:text-slate-800 py-2 transition-colors duration-200"
                  >
                    {t.backToRoles}
                  </button>

                  {/* Switch to Login */}
                  <button
                    type="button"
                    onClick={() => setIsLoginMode(true)}
                    className="w-full text-blue-600 hover:text-blue-800 py-2 transition-colors duration-200 font-medium"
                  >
                    {t.switchToLogin}
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* Boss Login Form */}
          {selectedRole === 'boss' && isLoginMode && (
            <div className="animate-slideIn">
              <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl p-8">
                <div className="text-center mb-6">
                  <div className="bg-gradient-to-r from-blue-500 to-indigo-500 p-3 rounded-xl inline-block mb-4">
                    <Building2 className="w-8 h-8 text-white" />
                  </div>
                  <h2 className="text-2xl font-semibold text-slate-800">{t.login}</h2>
                </div>

                <form onSubmit={handleBossLoginSubmit} className="space-y-4">
                  {/* Email */}
                  <div>
                    <div className="relative">
                      <div className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 z-10`}>
                        <Mail className={`w-5 h-5 transition-colors duration-200 ${
                          employeeForm.email ? 'text-blue-600' : 'text-slate-400'
                        }`} />
                      </div>
                      <input
                        type="email"
                        value={employeeForm.email}
                        onChange={(e) => handleEmployeeInputChange('email', e.target.value)}
                        placeholder={t.email}
                        className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white/50 backdrop-blur-sm ${
                          employeeValidation.email.message && !employeeValidation.email.isValid ? 'border-red-300 ring-1 ring-red-200' : ''
                        }`}
                      />
                    </div>
                    {employeeValidation.email.message && !employeeValidation.email.isValid && (
                      <p className="text-red-500 text-sm mt-1 animate-fadeIn">{employeeValidation.email.message}</p>
                    )}
                  </div>

                  {/* Password */}
                  <div>
                    <div className="relative">
                      <div className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 z-10`}>
                        <Lock className={`w-5 h-5 transition-colors duration-200 ${
                          employeeForm.password ? 'text-blue-600' : 'text-slate-400'
                        }`} />
                      </div>
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={employeeForm.password}
                        onChange={(e) => handleEmployeeInputChange('password', e.target.value)}
                        placeholder={t.password}
                        className={`w-full ${isRTL ? 'pr-12 pl-12' : 'pl-12 pr-12'} py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white/50 backdrop-blur-sm ${
                          employeeValidation.password.message && !employeeValidation.password.isValid ? 'border-red-300 ring-1 ring-red-200' : ''
                        }`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className={`absolute ${isRTL ? 'left-3' : 'right-3'} top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors duration-200`}
                      >
                        {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                    {employeeValidation.password.message && !employeeValidation.password.isValid && (
                      <p className="text-red-500 text-sm mt-1 animate-fadeIn">{employeeValidation.password.message}</p>
                    )}
                  </div>

                  {/* Error/Success Messages */}
                  {error && (
                    <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl animate-fadeIn">
                      {error}
                    </div>
                  )}
                  
                  {success && (
                    <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl animate-fadeIn">
                      {success}
                    </div>
                  )}

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isLoading || !isEmployeeFormValid}
                    className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed transform hover:-translate-y-0.5 shadow-lg hover:shadow-xl"
                  >
                    {isLoading ? (
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        {t.loading}
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-2">
                        <LogIn className="w-5 h-5" />
                        {t.loginBtn}
                      </div>
                    )}
                  </button>

                  {/* Forgot Password Button */}
                  <button
                    type="button"
                    onClick={() => setShowForgotPassword(true)}
                    className="w-full text-slate-300 hover:text-white py-3 px-6 rounded-2xl font-medium hover:bg-white/10 transition-all duration-300 text-sm"
                  >
                    {language === 'en' ? 'Forgot Password?' : 'نسيت كلمة المرور؟'}
                  </button>

                  {/* Back Button */}
                  <button
                    type="button"
                    onClick={handleBackToRoles}
                    className="w-full text-slate-600 hover:text-slate-800 py-2 transition-colors duration-200"
                  >
                    {t.backToRoles}
                  </button>

                  {/* Switch to Register */}
                  <button
                    type="button"
                    onClick={() => setIsLoginMode(false)}
                    className="w-full text-blue-600 hover:text-blue-800 py-2 transition-colors duration-200 font-medium"
                  >
                    {t.switchToRegister}
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* Employee Login Form */}
          {selectedRole === 'employee' && isLoginMode && (
            <div className="animate-slideIn">
              <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl p-8">
                <div className="text-center mb-6">
                  <div className="bg-gradient-to-r from-emerald-500 to-teal-500 p-3 rounded-xl inline-block mb-4">
                    <User className="w-8 h-8 text-white" />
                  </div>
                  <h2 className="text-2xl font-semibold text-slate-800">{t.login}</h2>
                </div>

                <form onSubmit={handleEmployeeSubmit} className="space-y-4">
                  {/* Email */}
                  <div>
                    <div className="relative">
                      <div className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 z-10`}>
                        <Mail className={`w-5 h-5 transition-colors duration-200 ${
                          employeeForm.email ? 'text-emerald-600' : 'text-slate-400'
                        }`} />
                      </div>
                      <input
                        type="email"
                        value={employeeForm.email}
                        onChange={(e) => handleEmployeeInputChange('email', e.target.value)}
                        placeholder={t.email}
                        className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all duration-200 bg-white/50 backdrop-blur-sm ${
                          employeeValidation.email.message && !employeeValidation.email.isValid ? 'border-red-300 ring-1 ring-red-200' : ''
                        }`}
                      />
                    </div>
                    {employeeValidation.email.message && !employeeValidation.email.isValid && (
                      <p className="text-red-500 text-sm mt-1 animate-fadeIn">{employeeValidation.email.message}</p>
                    )}
                  </div>

                  {/* Password */}
                  <div>
                    <div className="relative">
                      <div className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 z-10`}>
                        <Lock className={`w-5 h-5 transition-colors duration-200 ${
                          employeeForm.password ? 'text-emerald-600' : 'text-slate-400'
                        }`} />
                      </div>
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={employeeForm.password}
                        onChange={(e) => handleEmployeeInputChange('password', e.target.value)}
                        placeholder={t.password}
                        className={`w-full ${isRTL ? 'pr-12 pl-12' : 'pl-12 pr-12'} py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all duration-200 bg-white/50 backdrop-blur-sm ${
                          employeeValidation.password.message && !employeeValidation.password.isValid ? 'border-red-300 ring-1 ring-red-200' : ''
                        }`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className={`absolute ${isRTL ? 'left-3' : 'right-3'} top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors duration-200`}
                      >
                        {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                    {employeeValidation.password.message && !employeeValidation.password.isValid && (
                      <p className="text-red-500 text-sm mt-1 animate-fadeIn">{employeeValidation.password.message}</p>
                    )}
                  </div>

                  {/* Error/Success Messages */}
                  {error && (
                    <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl animate-fadeIn">
                      {error}
                    </div>
                  )}
                  
                  {success && (
                    <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl animate-fadeIn">
                      {success}
                    </div>
                  )}

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isLoading || !isEmployeeFormValid}
                    className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-emerald-700 hover:to-teal-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed transform hover:-translate-y-0.5 shadow-lg hover:shadow-xl"
                  >
                    {isLoading ? (
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        {t.loading}
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-2">
                        <LogIn className="w-5 h-5" />
                        {t.loginBtn}
                      </div>
                    )}
                  </button>

                  {/* Back Button */}
                  <button
                    type="button"
                    onClick={handleBackToRoles}
                    className="w-full text-slate-600 hover:text-slate-800 py-2 transition-colors duration-200"
                  >
                    {t.backToRoles}
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default App;