// Shared type definitions for the Space Zone application

export interface User {
  id: string;
  fullName: string;
  email: string;
  password: string;
  role: 'boss' | 'employee';
  bossId?: string; // For employee users to reference their boss
}

export interface Transaction {
  id: string;
  amount: number;
  cost: number;
  vat?: number;
  profit: number;
  clientId?: string;
  clientName?: string;
  supplierId?: string;
  supplierName?: string;
  serviceId?: string;
  serviceName?: string;
  date: string;
  paymentMethod?: string;
  status?: string;
  description?: string;
  priority?: string;
  invoiceNumber?: string;
  deliveryNumber?: string;
  invoiceGenerated?: boolean;
  deliveryGenerated?: boolean;
  month: number;
  year: number;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  address?: string;
  dateAdded: string;
  isActive: boolean;
}

export interface Supplier {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  website?: string;
  address?: string;
  contactPerson?: string;
  paymentMethod?: string;
  rating?: number;
  supplierProvides: string[];
  notes?: string;
  dateAdded: string;
  totalOrders?: number;
  totalAmount?: number;
  isActive: boolean;
}

export interface Service {
  id: string;
  name?: string;
  description?: string;
  price?: number;
  category?: string;
  subcategory?: string;
  vat?: number;
  storageDuration?: string;
  isActive: boolean;
  dateAdded: string;
}

export interface ServiceCategory {
  id: string;
  name: string;
  subcategories: string[];
  dateAdded: string;
}

export interface Employee {
  id: string;
  fullName: string;
  email: string;
  password: string;
  dateAdded: string;
  isActive: boolean;
  permissions: {
    transactions: {
      view: boolean;
      add: boolean;
      edit: boolean;
      delete: boolean;
    };
    clients: {
      view: boolean;
      add: boolean;
      edit: boolean;
      delete: boolean;
    };
    suppliers: {
      view: boolean;
      add: boolean;
      edit: boolean;
      delete: boolean;
    };
    services: {
      view: boolean;
      add: boolean;
      edit: boolean;
      delete: boolean;
    };
    reports: {
      view: boolean;
      generate: boolean;
      export: boolean;
    };
  };
}