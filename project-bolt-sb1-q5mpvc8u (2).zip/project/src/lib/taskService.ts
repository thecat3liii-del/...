import { supabase } from './supabase';

// Project types
export interface Project {
  id: string;
  boss_id: string;
  name: string;
  description?: string;
  start_date: string;
  end_date?: string;
  status: 'planning' | 'active' | 'on_hold' | 'completed' | 'cancelled';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  budget?: number;
  progress: number;
  color?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Task types
export interface Task {
  id: string;
  boss_id: string;
  project_id?: string;
  title: string;
  description?: string;
  start_date: string;
  end_date?: string;
  start_time?: string;
  end_time?: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled' | 'on_hold';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assigned_to?: string;
  category?: string;
  tags: string[];
  reminder_date?: string;
  is_recurring: boolean;
  recurrence_pattern?: 'daily' | 'weekly' | 'monthly' | 'yearly';
  completion_percentage: number;
  estimated_hours?: number;
  actual_hours?: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Task comment types
export interface TaskComment {
  id: string;
  task_id: string;
  user_id: string;
  user_name: string;
  comment: string;
  created_at: string;
}

// Project service functions
export const projectService = {
  // Add project
  async addProject(bossId: string, projectData: Omit<Project, 'id' | 'boss_id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from('projects')
        .insert([
          {
            boss_id: bossId,
            name: projectData.name,
            description: projectData.description || null,
            start_date: projectData.start_date,
            end_date: projectData.end_date || null,
            status: projectData.status,
            priority: projectData.priority,
            budget: projectData.budget || null,
            progress: projectData.progress,
            color: projectData.color || '#3b82f6',
            is_active: projectData.is_active
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get projects for boss
  async getProjects(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('boss_id', bossId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update project
  async updateProject(projectId: string, updates: Partial<Project>) {
    try {
      const updateData: any = {};
      
      if (updates.name !== undefined) updateData.name = updates.name;
      if (updates.description !== undefined) updateData.description = updates.description;
      if (updates.start_date !== undefined) updateData.start_date = updates.start_date;
      if (updates.end_date !== undefined) updateData.end_date = updates.end_date;
      if (updates.status !== undefined) updateData.status = updates.status;
      if (updates.priority !== undefined) updateData.priority = updates.priority;
      if (updates.budget !== undefined) updateData.budget = updates.budget;
      if (updates.progress !== undefined) updateData.progress = updates.progress;
      if (updates.color !== undefined) updateData.color = updates.color;
      if (updates.is_active !== undefined) updateData.is_active = updates.is_active;

      const { data, error } = await supabase
        .from('projects')
        .update(updateData)
        .eq('id', projectId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete project
  async deleteProject(projectId: string) {
    try {
      const { error } = await supabase
        .from('projects')
        .delete()
        .eq('id', projectId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Toggle project status
  async toggleProjectStatus(projectId: string) {
    try {
      const { data: currentProject, error: fetchError } = await supabase
        .from('projects')
        .select('is_active')
        .eq('id', projectId)
        .single();

      if (fetchError) throw fetchError;

      const { data, error } = await supabase
        .from('projects')
        .update({ is_active: !currentProject.is_active })
        .eq('id', projectId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};

// Task service functions
export const taskService = {
  // Add task
  async addTask(bossId: string, taskData: Omit<Task, 'id' | 'boss_id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .insert([
          {
            boss_id: bossId,
            project_id: taskData.project_id || null,
            title: taskData.title,
            description: taskData.description || null,
            start_date: taskData.start_date,
            end_date: taskData.end_date || null,
            start_time: taskData.start_time || null,
            end_time: taskData.end_time || null,
            status: taskData.status,
            priority: taskData.priority,
            assigned_to: taskData.assigned_to || null,
            category: taskData.category || null,
            tags: taskData.tags,
            reminder_date: taskData.reminder_date || null,
            is_recurring: taskData.is_recurring,
            recurrence_pattern: taskData.recurrence_pattern || null,
            completion_percentage: taskData.completion_percentage,
            estimated_hours: taskData.estimated_hours || null,
            actual_hours: taskData.actual_hours || null,
            is_active: taskData.is_active
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get tasks for boss
  async getTasks(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .select(`
          *,
          project:projects(name, color),
          assigned_employee:employees(full_name)
        `)
        .eq('boss_id', bossId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get tasks by date range
  async getTasksByDateRange(bossId: string, startDate: string, endDate: string) {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .select(`
          *,
          project:projects(name, color),
          assigned_employee:employees(full_name)
        `)
        .eq('boss_id', bossId)
        .gte('start_date', startDate)
        .lte('start_date', endDate)
        .eq('is_active', true)
        .order('start_date', { ascending: true });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update task
  async updateTask(taskId: string, updates: Partial<Task>) {
    try {
      const updateData: any = {};
      
      if (updates.project_id !== undefined) updateData.project_id = updates.project_id;
      if (updates.title !== undefined) updateData.title = updates.title;
      if (updates.description !== undefined) updateData.description = updates.description;
      if (updates.start_date !== undefined) updateData.start_date = updates.start_date;
      if (updates.end_date !== undefined) updateData.end_date = updates.end_date;
      if (updates.start_time !== undefined) updateData.start_time = updates.start_time;
      if (updates.end_time !== undefined) updateData.end_time = updates.end_time;
      if (updates.status !== undefined) updateData.status = updates.status;
      if (updates.priority !== undefined) updateData.priority = updates.priority;
      if (updates.assigned_to !== undefined) updateData.assigned_to = updates.assigned_to;
      if (updates.category !== undefined) updateData.category = updates.category;
      if (updates.tags !== undefined) updateData.tags = updates.tags;
      if (updates.reminder_date !== undefined) updateData.reminder_date = updates.reminder_date;
      if (updates.is_recurring !== undefined) updateData.is_recurring = updates.is_recurring;
      if (updates.recurrence_pattern !== undefined) updateData.recurrence_pattern = updates.recurrence_pattern;
      if (updates.completion_percentage !== undefined) updateData.completion_percentage = updates.completion_percentage;
      if (updates.estimated_hours !== undefined) updateData.estimated_hours = updates.estimated_hours;
      if (updates.actual_hours !== undefined) updateData.actual_hours = updates.actual_hours;
      if (updates.is_active !== undefined) updateData.is_active = updates.is_active;

      const { data, error } = await supabase
        .from('tasks')
        .update(updateData)
        .eq('id', taskId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete task
  async deleteTask(taskId: string) {
    try {
      const { error } = await supabase
        .from('tasks')
        .delete()
        .eq('id', taskId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Toggle task status
  async toggleTaskStatus(taskId: string) {
    try {
      const { data: currentTask, error: fetchError } = await supabase
        .from('tasks')
        .select('is_active')
        .eq('id', taskId)
        .single();

      if (fetchError) throw fetchError;

      const { data, error } = await supabase
        .from('tasks')
        .update({ is_active: !currentTask.is_active })
        .eq('id', taskId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};

// Task comments service functions
export const taskCommentService = {
  // Add comment
  async addComment(taskId: string, userId: string, userName: string, comment: string) {
    try {
      const { data, error } = await supabase
        .from('task_comments')
        .insert([
          {
            task_id: taskId,
            user_id: userId,
            user_name: userName,
            comment: comment
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get comments for task
  async getTaskComments(taskId: string) {
    try {
      const { data, error } = await supabase
        .from('task_comments')
        .select('*')
        .eq('task_id', taskId)
        .order('created_at', { ascending: true });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete comment
  async deleteComment(commentId: string) {
    try {
      const { error } = await supabase
        .from('task_comments')
        .delete()
        .eq('id', commentId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};