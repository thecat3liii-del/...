import { supabase } from './supabase';
import emailjs from '@emailjs/browser';
import { emailService } from './emailService';

// EmailJS Configuration
const EMAILJS_CONFIG = {
  serviceId: 'service_ohtwfr1',
  templateId: 'template_mej43mu',
  publicKey: 'A_pI7Vi2oYJ2KnP8z'
};

// Initialize EmailJS
emailjs.init(EMAILJS_CONFIG.publicKey);

// Password reset service functions
export const passwordResetService = {
  // إرسال رمز إعادة تعيين كلمة المرور باستخدام الاسم الكامل
  async sendResetCode(fullName: string): Promise<{ success: boolean; error?: string; message?: string; email?: string }> {
    try {
      // تنظيف الاسم من المسافات الزائدة
      const cleanFullName = fullName.trim();
      
      if (!cleanFullName || cleanFullName.length < 2) {
        return { 
          success: false, 
          error: 'Please enter a valid full name' 
        };
      }

      // التحقق من وجود المدير بهذا الاسم الكامل
      const { data: boss, error: bossError } = await supabase
        .from('bosses')
        .select('id, email, full_name')
        .eq('full_name', cleanFullName)
        .single();

      if (bossError || !boss) {
        return { 
          success: false, 
          error: 'Account name not found in our system. Please check the name and try again.' 
        };
      }

      // تنظيف الرموز المنتهية الصلاحية أو المستخدمة للمدير
      await supabase
        .from('password_reset_codes')
        .delete()
        .eq('boss_id', boss.id)
        .or('expires_at.lt.now(),is_used.eq.true');

      // توليد رمز جديد (6 أرقام)
      const resetCode = Math.floor(100000 + Math.random() * 900000).toString();
      
      // Set expiration time (10 minutes from now as per requirements)
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

      // حفظ الرمز في قاعدة البيانات
      const { error: insertError } = await supabase
        .from('password_reset_codes')
        .insert([
          {
            boss_id: boss.id,
            email: boss.email,
            reset_code: resetCode,
            expires_at: expiresAt,
            is_used: false
          }
        ]);

      if (insertError) {
        console.error('Error saving reset code:', insertError);
        return { 
          success: false, 
          error: 'Failed to generate reset code. Please try again.' 
        };
      }

      // Send email using EmailJS service
      const emailResult = await emailService.sendPasswordResetEmail({
        user_email: boss.email,
        user_name: boss.full_name,
        reset_code: resetCode
      });

      if (emailResult.success) {
        return {
          success: true,
          message: emailResult.message || `Reset code sent successfully to ${boss.email}`,
          email: boss.email
        };
      } else {
        // Fallback for testing - show code in console and error message
        console.log('🔢 Reset code for testing:', resetCode);
        console.log('📧 Email:', boss.email);
        
        return {
          success: false,
          error: `${emailResult.error} For testing, use code: ${resetCode}`,
          email: boss.email
        };
      }

    } catch (error: any) {
      console.error('Error in sendResetCode:', error);
      return { 
        success: false, 
        error: 'Failed to send reset code. Please try again.' 
      };
    }
  },

  // التحقق من رمز إعادة التعيين
  async verifyResetCode(fullName: string, resetCode: string): Promise<{ success: boolean; error?: string; bossId?: string; email?: string }> {
    try {
      // تنظيف المدخلات
      const cleanFullName = fullName.trim();
      const cleanResetCode = resetCode.trim();

      if (!cleanFullName || !cleanResetCode) {
        return { 
          success: false, 
          error: 'Please provide both name and reset code' 
        };
      }

      if (cleanResetCode.length !== 6 || !/^\d{6}$/.test(cleanResetCode)) {
        return { 
          success: false, 
          error: 'Reset code must be 6 digits' 
        };
      }

      // البحث عن المدير بالاسم الكامل أولاً
      const { data: boss, error: bossError } = await supabase
        .from('bosses')
        .select('id, email, full_name')
        .eq('full_name', cleanFullName)
        .single();

      if (bossError || !boss) {
        return { 
          success: false, 
          error: 'Account name not found' 
        };
      }

      // البحث عن الرمز في قاعدة البيانات
      const { data: resetRecord, error: fetchError } = await supabase
        .from('password_reset_codes')
        .select('id, boss_id, expires_at, is_used')
        .eq('email', boss.email)
        .eq('reset_code', cleanResetCode)
        .eq('is_used', false)
        .single();

      if (fetchError || !resetRecord) {
        return { 
          success: false, 
          error: 'Invalid or expired reset code. Please request a new one.' 
        };
      }

      // التحقق من انتهاء الصلاحية
      const now = new Date();
      const expiresAt = new Date(resetRecord.expires_at);
      
      if (now > expiresAt) {
        // Delete expired code (10 minutes)
        await supabase
          .from('password_reset_codes')
          .delete()
          .eq('id', resetRecord.id);

        return { 
          success: false, 
          error: 'Reset code has expired (10 minutes). Please request a new one.' 
        };
      }

      return { 
        success: true, 
        bossId: resetRecord.boss_id,
        email: boss.email
      };

    } catch (error: any) {
      console.error('Error in verifyResetCode:', error);
      return { 
        success: false, 
        error: 'Failed to verify reset code. Please try again.' 
      };
    }
  },

  // إعادة تعيين كلمة المرور
  async resetPassword(fullName: string, resetCode: string, newPassword: string): Promise<{ success: boolean; error?: string; message?: string }> {
    try {
      // تنظيف المدخلات
      const cleanFullName = fullName.trim();
      const cleanResetCode = resetCode.trim();
      const cleanNewPassword = newPassword.trim();

      if (!cleanFullName || !cleanResetCode || !cleanNewPassword) {
        return { 
          success: false, 
          error: 'Please fill all required fields' 
        };
      }

      if (cleanNewPassword.length < 6) {
        return { 
          success: false, 
          error: 'Password must be at least 6 characters long'
        };
      }

      // التحقق من الرمز أولاً
      const verifyResult = await this.verifyResetCode(cleanFullName, cleanResetCode);
      
      if (!verifyResult.success) {
        return verifyResult;
      }

      // تحديث كلمة المرور في قاعدة البيانات
      const { error: updateError } = await supabase
        .from('bosses')
        .update({ 
          password: cleanNewPassword,
          updated_at: new Date().toISOString()
        })
        .eq('id', verifyResult.bossId);

      if (updateError) {
        console.error('Error updating password:', updateError);
        return { 
          success: false, 
          error: 'Failed to update password. Please try again.' 
        };
      }

      // تمييز الرمز كمستخدم وحذف جميع الرموز الأخرى للمدير
      await supabase
        .from('password_reset_codes')
        .update({ is_used: true })
        .eq('email', verifyResult.email)
        .eq('reset_code', cleanResetCode);

      // حذف جميع الرموز الأخرى للمدير
      await supabase
        .from('password_reset_codes')
        .delete()
        .eq('boss_id', verifyResult.bossId)
        .neq('reset_code', cleanResetCode);

      return { 
        success: true, 
        message: 'Password updated successfully! You can now login with your new password.' 
      };

    } catch (error: any) {
      console.error('Error in resetPassword:', error);
      return { 
        success: false, 
        error: 'Failed to reset password. Please try again.' 
      };
    }
  },

  // Clean up expired codes (called periodically) - now 10 minutes
  async cleanupExpiredCodes(): Promise<void> {
    try {
      const { error } = await supabase
        .from('password_reset_codes')
        .delete()
        .or('expires_at.lt.now(),is_used.eq.true');

      if (error) {
        console.error('Error cleaning up expired codes:', error);
      }
    } catch (error) {
      console.error('Error in cleanupExpiredCodes:', error);
    }
  },

  // Check code status (10 minute expiration)
  async checkCodeStatus(email: string, resetCode: string): Promise<{ valid: boolean; expired: boolean; used: boolean }> {
    try {
      const { data: resetRecord } = await supabase
        .from('password_reset_codes')
        .select('expires_at, is_used')
        .eq('email', email)
        .eq('reset_code', resetCode)
        .single();

      if (!resetRecord) {
        return { valid: false, expired: false, used: false };
      }

      const now = new Date();
      const expiresAt = new Date(resetRecord.expires_at);
      const expired = now > expiresAt;

      return {
        valid: !expired && !resetRecord.is_used,
        expired: expired,
        used: resetRecord.is_used
      };
    } catch (error) {
      console.error('Error checking code status:', error);
      return { valid: false, expired: false, used: false };
    }
  }
};