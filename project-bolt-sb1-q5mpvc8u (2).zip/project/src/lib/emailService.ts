import emailjs from '@emailjs/browser';

// EmailJS Configuration - ⚠️ CRITICAL: Verify these values before deployment
const EMAILJS_CONFIG = {
  serviceId: 'service_ohtwfr1',
  templateId: 'template_mej43mu',
  publicKey: 'A_pI7Vi2oYJ2KnP8z'
};

// Initialize EmailJS
emailjs.init(EMAILJS_CONFIG.publicKey);

export interface EmailParams {
  user_email: string;  // Recipient's registered email (mandatory)
  user_name: string;   // Recipient full name
  reset_code: string;  // 6-digit reset code
}

export const emailService = {
  /**
   * Send password reset email using EmailJS
   * ⚠️ CRITICAL: Test with real email before enabling for all users
   */
  async sendPasswordResetEmail(params: EmailParams): Promise<{ success: boolean; error?: string; message?: string }> {
    try {
      // Validate required parameters
      if (!params.user_email || !params.user_name || !params.reset_code) {
        return {
          success: false,
          error: 'Missing required email parameters'
        };
      }

      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(params.user_email)) {
        return {
          success: false,
          error: 'Invalid email format'
        };
      }

      // Validate reset code format (6 digits)
      if (!/^\d{6}$/.test(params.reset_code)) {
        return {
          success: false,
          error: 'Reset code must be 6 digits'
        };
      }

      console.log('📧 EmailJS: Preparing to send email...');
      console.log('📧 Service ID:', EMAILJS_CONFIG.serviceId);
      console.log('📧 Template ID:', EMAILJS_CONFIG.templateId);
      console.log('📧 To:', params.user_email);
      console.log('👤 Name:', params.user_name);
      console.log('🔢 Code:', params.reset_code);

      // Send email via EmailJS
      const response = await emailjs.send(
        EMAILJS_CONFIG.serviceId,
        EMAILJS_CONFIG.templateId,
        {
          user_email: params.user_email,
          user_name: params.user_name,
          reset_code: params.reset_code
        },
        EMAILJS_CONFIG.publicKey
      );

      console.log('✅ EmailJS Response:', response);

      // Check if email was sent successfully
      if (response.status === 200) {
        return {
          success: true,
          message: `Password reset code sent successfully to ${params.user_email}`
        };
      } else {
        throw new Error(`EmailJS returned status: ${response.status} - ${response.text}`);
      }

    } catch (error: any) {
      console.error('❌ EmailJS Error:', error);
      
      // Return detailed error information for debugging
      return {
        success: false,
        error: `Failed to send email: ${error.message || 'Unknown error'}`
      };
    }
  },

  /**
   * Test EmailJS configuration
   * ⚠️ Use this to verify setup before going live
   */
  async testEmailConfiguration(): Promise<{ success: boolean; error?: string; message?: string }> {
    try {
      // Test with dummy data
      const testParams = {
        user_email: 'test@example.com',
        user_name: 'Test User',
        reset_code: '123456'
      };

      console.log('🧪 Testing EmailJS configuration...');
      console.log('📧 Service ID:', EMAILJS_CONFIG.serviceId);
      console.log('📧 Template ID:', EMAILJS_CONFIG.templateId);
      console.log('🔑 Public Key:', EMAILJS_CONFIG.publicKey.substring(0, 8) + '...');

      // This will validate the configuration without actually sending
      const response = await emailjs.send(
        EMAILJS_CONFIG.serviceId,
        EMAILJS_CONFIG.templateId,
        testParams,
        EMAILJS_CONFIG.publicKey
      );

      return {
        success: response.status === 200,
        message: response.status === 200 
          ? 'EmailJS configuration is valid' 
          : `Configuration test failed: ${response.status}`
      };

    } catch (error: any) {
      return {
        success: false,
        error: `Configuration test failed: ${error.message}`
      };
    }
  },

  /**
   * Validate EmailJS configuration
   */
  validateConfiguration(): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!EMAILJS_CONFIG.serviceId || EMAILJS_CONFIG.serviceId === 'service_ohtwfr1') {
      errors.push('Service ID not configured or using default value');
    }

    if (!EMAILJS_CONFIG.templateId || EMAILJS_CONFIG.templateId === 'template_mej43mu') {
      errors.push('Template ID not configured or using default value');
    }

    if (!EMAILJS_CONFIG.publicKey || EMAILJS_CONFIG.publicKey === 'A_pI7Vi2oYJ2KnP8z') {
      errors.push('Public Key not configured or using default value');
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }
};