import { createClient } from '@supabase/supabase-js';
import { quotationService } from './quotationService';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Boss {
  id: string;
  full_name: string;
  email: string;
  password: string;
  created_at: string;
  updated_at: string;
}

export interface Employee {
  id: string;
  boss_id: string;
  full_name: string;
  email: string;
  password: string;
  phone: string;
  salary: number;
  description?: string;
  residence_location?: string;
  position?: string;
  rating?: number;
  visa?: string;
  transportation_allowance?: number;
  insurance?: number;
  years_of_experience?: number;
  skills?: string[];
  year_of_birth?: number;
  is_active: boolean;
  permissions: {
    transactions: {
      view: boolean;
      add: boolean;
      edit: boolean;
      delete: boolean;
    };
    clients: {
      view: boolean;
      add: boolean;
      edit: boolean;
      delete: boolean;
    };
    suppliers: {
      view: boolean;
      add: boolean;
      edit: boolean;
      delete: boolean;
    };
    services: {
      view: boolean;
      add: boolean;
      edit: boolean;
      delete: boolean;
    };
    reports: {
      view: boolean;
      generate: boolean;
      export: boolean;
    };
  };
  created_at: string;
  updated_at: string;
}

export interface EmployeeExpense {
  id: string;
  employee_id: string;
  boss_id: string;
  expense_type: string;
  amount: number;
  frequency: 'monthly' | 'yearly';
  description?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Client {
  id: string;
  boss_id: string;
  name: string;
  email: string;
  phone: string;
  address?: string;
  company?: string;
  website?: string;
  social_media?: { platform: string; url: string }[];
  notes?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Supplier {
  id: string;
  boss_id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  website?: string;
  address?: string;
  contact_person?: string;
  payment_method?: string;
  rating: number;
  supplier_provides: string[];
  notes?: string;
  total_orders: number;
  total_amount: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Auth functions
export const authService = {
  // Register boss
  async registerBoss(fullName: string, email: string, password: string) {
    try {
      const { data, error } = await supabase
        .from('bosses')
        .insert([
          {
            full_name: fullName,
            email: email.toLowerCase(),
            password: password // في التطبيق الحقيقي يجب تشفير كلمة المرور
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Login boss
  async loginBoss(email: string, password: string) {
    try {
      const { data, error } = await supabase
        .from('bosses')
        .select('*')
        .eq('email', email.toLowerCase())
        .eq('password', password)
        .single();

      if (error) throw error;
      if (!data) throw new Error('Invalid credentials');

      return { success: true, user: data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Login employee
  async loginEmployee(email: string, password: string) {
    try {
      const { data, error } = await supabase
        .from('employees')
        .select('*')
        .eq('email', email.toLowerCase())
        .eq('password', password)
        .eq('is_active', true)
        .single();

      if (error) throw error;
      if (!data) throw new Error('Invalid credentials or account inactive');

      return { success: true, user: data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Check if email exists
  async checkEmailExists(email: string) {
    try {
      // Check in bosses table
      const { data: bossData } = await supabase
        .from('bosses')
        .select('id')
        .eq('email', email.toLowerCase())
        .maybeSingle();

      if (bossData) return true;

      // Check in employees table
      const { data: employeeData } = await supabase
        .from('employees')
        .select('id')
        .eq('email', email.toLowerCase())
        .maybeSingle();

      return !!employeeData;
    } catch (error) {
      return false;
    }
  },

  // Add employee (by boss)
  async addEmployee(bossId: string, employeeData: Omit<Employee, 'id' | 'boss_id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from('employees')
        .insert([
          {
            boss_id: bossId,
            full_name: employeeData.full_name,
            email: employeeData.email.toLowerCase(),
            password: employeeData.password,
            phone: employeeData.phone,
            salary: employeeData.salary,
            description: employeeData.description || null,
            residence_location: employeeData.residence_location || null,
            position: employeeData.position || null,
            rating: employeeData.rating || 5,
            visa: employeeData.visa || null,
            transportation_allowance: employeeData.transportation_allowance || 0,
            insurance: employeeData.insurance || 0,
            years_of_experience: employeeData.years_of_experience || 0,
            skills: employeeData.skills || [],
            year_of_birth: employeeData.year_of_birth || null,
            is_active: employeeData.is_active,
            permissions: employeeData.permissions
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get employees for boss
  async getEmployees(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('employees')
        .select('*')
        .eq('boss_id', bossId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update employee
  async updateEmployee(employeeId: string, updates: Partial<Employee>) {
    try {
      const { data, error } = await supabase
        .from('employees')
        .update(updates)
        .eq('id', employeeId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete employee
  async deleteEmployee(employeeId: string) {
    try {
      const { error } = await supabase
        .from('employees')
        .delete()
        .eq('id', employeeId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};

// Client functions
export const clientService = {
  // Add client
  async addClient(bossId: string, clientData: Omit<Client, 'id' | 'boss_id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from('clients')
        .insert([
          {
            boss_id: bossId,
            name: clientData.name,
            email: clientData.email.toLowerCase(),
            phone: clientData.phone,
            address: clientData.address || null,
            company: clientData.company || null,
            website: clientData.website || null,
            social_media: clientData.social_media || [],
            notes: clientData.notes || null,
            is_active: clientData.is_active
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get clients for boss
  async getClients(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('clients')
        .select('*')
        .eq('boss_id', bossId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update client
  async updateClient(clientId: string, updates: Partial<Client>) {
    try {
      const { data, error } = await supabase
        .from('clients')
        .update(updates)
        .eq('id', clientId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete client
  async deleteClient(clientId: string) {
    try {
      const { error } = await supabase
        .from('clients')
        .delete()
        .eq('id', clientId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Check if client email exists for a boss
  async checkClientEmailExists(bossId: string, email: string, excludeId?: string) {
    try {
      let query = supabase
        .from('clients')
        .select('id')
        .eq('boss_id', bossId)
        .eq('email', email.toLowerCase());

      if (excludeId) {
        query = query.neq('id', excludeId);
      }

      const { data } = await query.maybeSingle();
      return !!data;
    } catch (error) {
      return false;
    }
  },

  // Toggle client status
  async toggleClientStatus(clientId: string) {
    try {
      // First get current status
      const { data: currentClient, error: fetchError } = await supabase
        .from('clients')
        .select('is_active')
        .eq('id', clientId)
        .single();

      if (fetchError) throw fetchError;

      // Update status
      const { data, error } = await supabase
        .from('clients')
        .update({ is_active: !currentClient.is_active })
        .eq('id', clientId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};

// Supplier functions
export const supplierService = {
  // Add supplier
  async addSupplier(bossId: string, supplierData: Omit<Supplier, 'id' | 'boss_id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from('suppliers')
        .insert([
          {
            boss_id: bossId,
            name: supplierData.name,
            company: supplierData.company,
            email: supplierData.email.toLowerCase(),
            phone: supplierData.phone,
            website: supplierData.website || null,
            address: supplierData.address || null,
            contact_person: supplierData.contact_person || null,
            payment_method: supplierData.payment_method || null,
            rating: supplierData.rating,
            supplier_provides: supplierData.supplier_provides,
            notes: supplierData.notes || null,
            total_orders: supplierData.total_orders,
            total_amount: supplierData.total_amount,
            is_active: supplierData.is_active,
            selected_service_ids: supplierData.selected_service_ids || []
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get suppliers for boss
  async getSuppliers(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('suppliers')
        .select('*')
        .eq('boss_id', bossId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update supplier
  async updateSupplier(supplierId: string, updates: Partial<Supplier>) {
    try {
      const { data, error } = await supabase
        .from('suppliers')
        .update(updates)
        .eq('id', supplierId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete supplier
  async deleteSupplier(supplierId: string) {
    try {
      const { error } = await supabase
        .from('suppliers')
        .delete()
        .eq('id', supplierId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Check if supplier email exists for a boss
  async checkSupplierEmailExists(bossId: string, email: string, excludeId?: string) {
    try {
      let query = supabase
        .from('suppliers')
        .select('id')
        .eq('boss_id', bossId)
        .eq('email', email.toLowerCase());

      if (excludeId) {
        query = query.neq('id', excludeId);
      }

      const { data } = await query.maybeSingle();
      return !!data;
    } catch (error) {
      return false;
    }
  },

  // Toggle supplier status
  async toggleSupplierStatus(supplierId: string) {
    try {
      // First get current status
      const { data: currentSupplier, error: fetchError } = await supabase
        .from('suppliers')
        .select('is_active')
        .eq('id', supplierId)
        .single();

      if (fetchError) throw fetchError;

      // Update status
      const { data, error } = await supabase
        .from('suppliers')
        .update({ is_active: !currentSupplier.is_active })
        .eq('id', supplierId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};

// Transaction types
export interface Transaction {
  id: string;
  boss_id: string;
  amount: number;
  cost: number;
  vat?: number;
  profit: number;
  client_id?: string;
  client_name?: string;
  supplier_id?: string;
  supplier_name?: string;
  service_ids?: string[];
  service_names?: string[];
  transaction_date: string;
  payment_method?: string;
  status?: string;
  description?: string;
  priority?: string;
  category?: string;
  vat_percentage?: number;
  total_with_vat?: number;
  month: number;
  year: number;
  invoice_number?: string;
  delivery_number?: string;
  invoice_generated?: boolean;
  delivery_generated?: boolean;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Transaction functions
export const transactionService = {
  // Add transaction
  async addTransaction(bossId: string, transactionData: Omit<Transaction, 'id' | 'boss_id' | 'created_at' | 'updated_at' | 'month' | 'year'>) {
    try {
      const { data, error } = await supabase
        .from('transactions')
        .insert([
          {
            boss_id: bossId,
            amount: transactionData.amount,
            cost: transactionData.cost,
            vat: transactionData.vat || 0,
            profit: transactionData.profit,
            client_id: transactionData.client_id || null,
            client_name: transactionData.client_name || null,
            supplier_id: transactionData.supplier_id || null,
            supplier_name: transactionData.supplier_name || null,
            service_ids: transactionData.service_ids || [],
            service_names: transactionData.service_names || [],
            transaction_date: transactionData.transaction_date,
            payment_method: transactionData.payment_method || null,
            status: transactionData.status || null,
            description: transactionData.description || null,
            priority: transactionData.priority || null,
            category: transactionData.category || null,
            vat_percentage: transactionData.vat_percentage || 0,
            total_with_vat: transactionData.total_with_vat || 0,
            is_active: transactionData.is_active
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get transactions for boss
  async getTransactions(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('transactions')
        .select('*')
        .eq('boss_id', bossId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update transaction
  async updateTransaction(transactionId: string, updates: Partial<Transaction>) {
    try {
      const { data, error } = await supabase
        .from('transactions')
        .update(updates)
        .eq('id', transactionId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete transaction
  async deleteTransaction(transactionId: string) {
    try {
      // First get the transaction to check for invoice and delivery numbers
      const { data: transaction, error: fetchError } = await supabase
        .from('transactions')
        .select('invoice_number, delivery_number')
        .eq('id', transactionId)
        .single();

      if (fetchError) throw fetchError;

      // Delete related invoices if they exist
      if (transaction.invoice_number) {
        await supabase
          .from('invoices')
          .delete()
          .eq('invoice_number', transaction.invoice_number);
      }

      // Delete related delivery notes if they exist
      if (transaction.delivery_number) {
        await supabase
          .from('delivery_notes')
          .delete()
          .eq('delivery_number', transaction.delivery_number);
      }

      // Now delete the transaction
      const { error } = await supabase
        .from('transactions')
        .delete()
        .eq('id', transactionId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Toggle transaction status
  async toggleTransactionStatus(transactionId: string) {
    try {
      // First get current status
      const { data: currentTransaction, error: fetchError } = await supabase
        .from('transactions')
        .select('is_active')
        .eq('id', transactionId)
        .single();

      if (fetchError) throw fetchError;

      // Update status
      const { data, error } = await supabase
        .from('transactions')
        .update({ is_active: !currentTransaction.is_active })
        .eq('id', transactionId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};

// Employee Expense functions
export const employeeExpenseService = {
  // Add employee expense
  async addEmployeeExpense(bossId: string, expenseData: Omit<EmployeeExpense, 'id' | 'boss_id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from('employee_expenses')
        .insert([
          {
            boss_id: bossId,
            employee_id: expenseData.employee_id,
            expense_type: expenseData.expense_type,
            amount: expenseData.amount,
            frequency: expenseData.frequency,
            description: expenseData.description || null,
            is_active: expenseData.is_active
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get employee expenses for boss
  async getEmployeeExpenses(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('employee_expenses')
        .select('*')
        .eq('boss_id', bossId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get expenses for specific employee
  async getExpensesForEmployee(employeeId: string) {
    try {
      const { data, error } = await supabase
        .from('employee_expenses')
        .select('*')
        .eq('employee_id', employeeId)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update employee expense
  async updateEmployeeExpense(expenseId: string, updates: Partial<EmployeeExpense>) {
    try {
      const { data, error } = await supabase
        .from('employee_expenses')
        .update(updates)
        .eq('id', expenseId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete employee expense
  async deleteEmployeeExpense(expenseId: string) {
    try {
      const { error } = await supabase
        .from('employee_expenses')
        .delete()
        .eq('id', expenseId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Calculate financial summary for all employees
  async calculateFinancialSummary(bossId: string) {
    try {
      // Get all employees
      const employeesResult = await authService.getEmployees(bossId);
      if (!employeesResult.success) throw new Error(employeesResult.error);
      
      const employees = employeesResult.data;
      
      // Get all employee expenses
      const expensesResult = await this.getEmployeeExpenses(bossId);
      if (!expensesResult.success) throw new Error(expensesResult.error);
      
      const expenses = expensesResult.data;
      
      // Calculate totals
      let totalMonthlyCost = 0;
      let totalYearlyCost = 0;
      
      // Add employee salaries (monthly)
      employees.forEach(employee => {
        if (employee.is_active) {
          totalMonthlyCost += employee.salary || 0;
          totalMonthlyCost += employee.transportation_allowance || 0;
          totalMonthlyCost += employee.insurance || 0;
          
          // Add yearly costs (salary * 12 + visa calculation)
          totalYearlyCost += (employee.salary || 0) * 12;
          totalYearlyCost += (employee.transportation_allowance || 0) * 12;
          totalYearlyCost += (employee.insurance || 0) * 12;
          
          // Visa calculation (once per year based on monthly salary)
          if (employee.visa && employee.salary > 0) {
            totalYearlyCost += employee.salary; // One month salary for visa
          }
        }
      });
      
      // Add other expenses
      expenses.forEach(expense => {
        if (expense.is_active) {
          if (expense.frequency === 'monthly') {
            totalMonthlyCost += expense.amount;
            totalYearlyCost += expense.amount * 12;
          } else if (expense.frequency === 'yearly') {
            totalYearlyCost += expense.amount;
          }
        }
      });
      
      return {
        success: true,
        data: {
          totalMonthlyCost,
          totalYearlyCost,
          employeeCount: employees.filter(emp => emp.is_active).length,
          totalEmployees: employees.length
        }
      };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};

// Service types
export interface Service {
  id: string;
  boss_id: string;
  name: string;
  description?: string;
  price: number;
  category?: string;
  subcategory?: string;
  vat?: number;
  storage_duration?: string;
  image_media?: string;
  availability_active?: boolean;
  expiration_validity?: string;
  subtypes_variants?: any[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface ServiceCategory {
  id: string;
  boss_id: string;
  name: string;
  subcategories: string[];
  created_at: string;
  updated_at: string;
}

// Financial Item types
export interface FinancialItem {
  id: string;
  boss_id: string;
  name: string;
  description?: string;
  default_amount: number;
  frequency: 'monthly' | 'yearly';
  category?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Invoice and Delivery Note types for the UI
export interface Invoice {
  id: string;
  boss_id: string;
  invoice_number: string;
  client_id?: string;
  client_name?: string;
  client_email?: string;
  client_phone?: string;
  client_address?: string;
  issue_date: string;
  due_date: string;
  items: any[];
  subtotal: number;
  tax_rate?: number;
  tax_amount?: number;
  discount_rate?: number;
  discount_amount?: number;
  total_amount: number;
  notes?: string;
  status: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface DeliveryNote {
  id: string;
  boss_id: string;
  delivery_number: string;
  client_id?: string;
  client_name?: string;
  client_email?: string;
  client_phone?: string;
  client_address?: string;
  delivery_address?: string;
  delivery_date: string;
  items: any[];
  notes?: string;
  driver_name?: string;
  driver_phone?: string;
  recipient_name?: string;
  recipient_email?: string;
  recipient_phone?: string;
  recipient_signature?: string;
  status: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Invoice service functions
export const invoiceService = {
  // Get invoices for boss
  async getInvoices(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('invoices')
        .select('*')
        .eq('boss_id', bossId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update invoice
  async updateInvoice(invoiceId: string, updates: any) {
    try {
      const { data, error } = await supabase
        .from('invoices')
        .update(updates)
        .eq('id', invoiceId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete invoice
  async deleteInvoice(invoiceId: string) {
    try {
      const { error } = await supabase
        .from('invoices')
        .delete()
        .eq('id', invoiceId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete invoice by number
  async deleteInvoiceByNumber(bossId: string, invoiceNumber: string) {
    try {
      const { error } = await supabase
        .from('invoices')
        .delete()
        .eq('boss_id', bossId)
        .eq('invoice_number', invoiceNumber);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};

// Delivery note service functions
export const deliveryNoteService = {
  // Get delivery notes for boss
  async getDeliveryNotes(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('delivery_notes')
        .select('*')
        .eq('boss_id', bossId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update delivery note
  async updateDeliveryNote(deliveryNoteId: string, updates: any) {
    try {
      const { data, error } = await supabase
        .from('delivery_notes')
        .update(updates)
        .eq('id', deliveryNoteId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete delivery note
  async deleteDeliveryNote(deliveryNoteId: string) {
    try {
      const { error } = await supabase
        .from('delivery_notes')
        .delete()
        .eq('id', deliveryNoteId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete delivery note by number
  async deleteDeliveryNoteByNumber(bossId: string, deliveryNumber: string) {
    try {
      const { error } = await supabase
        .from('delivery_notes')
        .delete()
        .eq('boss_id', bossId)
        .eq('delivery_number', deliveryNumber);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};

// Service functions
export const serviceService = {
  // Add service
  async addService(bossId: string, serviceData: Omit<Service, 'id' | 'boss_id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from('services')
        .insert([
          {
            boss_id: bossId,
            name: serviceData.name,
            description: serviceData.description || null,
            price: serviceData.price,
            category: serviceData.category || null,
            subcategory: serviceData.subcategory || null,
            vat: serviceData.vat || null,
            storage_duration: serviceData.storage_duration || null,
            subtypes_variants: serviceData.subtypes_variants || [],
            image_media: serviceData.image_media || null,
            availability_active: serviceData.availability_active !== undefined ? serviceData.availability_active : true,
            expiration_validity: serviceData.expiration_validity || null,
            is_active: serviceData.is_active
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get services for boss
  async getServices(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('services')
        .select('*')
        .eq('boss_id', bossId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update service
  async updateService(serviceId: string, updates: Partial<Service>) {
    try {
      const { data, error } = await supabase
        .from('services')
        .update(updates)
        .eq('id', serviceId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete service
  async deleteService(serviceId: string) {
    try {
      const { error } = await supabase
        .from('services')
        .delete()
        .eq('id', serviceId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Check if service name exists for a boss
  async checkServiceNameExists(bossId: string, name: string, excludeId?: string) {
    try {
      let query = supabase
        .from('services')
        .select('id')
        .eq('boss_id', bossId)
        .eq('name', name);

      if (excludeId) {
        query = query.neq('id', excludeId);
      }

      const { data } = await query.maybeSingle();
      return !!data;
    } catch (error) {
      return false;
    }
  },

  // Toggle service status
  async toggleServiceStatus(serviceId: string) {
    try {
      // First get current status
      const { data: currentService, error: fetchError } = await supabase
        .from('services')
        .select('is_active')
        .eq('id', serviceId)
        .single();

      if (fetchError) throw fetchError;

      // Update status
      const { data, error } = await supabase
        .from('services')
        .update({ is_active: !currentService.is_active })
        .eq('id', serviceId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};

// Profile and Settings functions
export const profileService = {
  // Update boss profile
  async updateBossProfile(bossId: string, updates: { full_name?: string; email?: string; password?: string; profile_image_url?: string }) {
    try {
      // تحديث البيانات في قاعدة البيانات
      const { data, error } = await supabase
        .from('bosses')
        .update(updates)
        .eq('id', bossId)
        .select()
        .single();

      if (error) throw error;
      
      // تحديث localStorage فوراً بعد نجاح التحديث في قاعدة البيانات
      const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
      if (currentUser.id === bossId) {
        const updatedUser = {
          ...currentUser,
          fullName: updates.full_name || currentUser.fullName,
          email: updates.email || currentUser.email,
          password: updates.password || currentUser.password,
          profileImageUrl: updates.profile_image_url || currentUser.profileImageUrl
        };
        localStorage.setItem('currentUser', JSON.stringify(updatedUser));
      }
      
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update employee profile
  async updateEmployeeProfile(employeeId: string, updates: { full_name?: string; email?: string; password?: string; profile_image_url?: string }) {
    try {
      // تحديث البيانات في قاعدة البيانات
      const { data, error } = await supabase
        .from('employees')
        .update(updates)
        .eq('id', employeeId)
        .select()
        .single();

      if (error) throw error;
      
      // تحديث localStorage فوراً بعد نجاح التحديث في قاعدة البيانات
      const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
      if (currentUser.id === employeeId) {
        const updatedUser = {
          ...currentUser,
          fullName: updates.full_name || currentUser.fullName,
          email: updates.email || currentUser.email,
          password: updates.password || currentUser.password,
          profileImageUrl: updates.profile_image_url || currentUser.profileImageUrl
        };
        localStorage.setItem('currentUser', JSON.stringify(updatedUser));
      }
      
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Check if email exists (excluding current user)
  async checkEmailExistsForUpdate(email: string, currentUserId: string, userType: 'boss' | 'employee') {
    try {
      if (userType === 'boss') {
        const { data } = await supabase
          .from('bosses')
          .select('id')
          .eq('email', email.toLowerCase())
          .neq('id', currentUserId)
          .maybeSingle();
        return !!data;
      } else {
        const { data } = await supabase
          .from('employees')
          .select('id')
          .eq('email', email.toLowerCase())
          .neq('id', currentUserId)
          .maybeSingle();
        return !!data;
      }
    } catch (error) {
      return false;
    }
  },

  // Get user profile data
  async getUserProfile(userId: string, userType: 'boss' | 'employee') {
    try {
      const table = userType === 'boss' ? 'bosses' : 'employees';
      const { data, error } = await supabase
        .from(table)
        .select('*')
        .eq('id', userId)
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Hash password (simple implementation - in production use bcrypt)
  hashPassword(password: string): string {
    // Simple hash implementation - in production, use proper bcrypt
    return btoa(password + 'spaceZoneSalt2024');
  },

  // Verify password
  verifyPassword(password: string, hashedPassword: string): boolean {
    return this.hashPassword(password) === hashedPassword;
  }
};

// Settings storage functions
export const settingsService = {
  // Save profile image to Supabase storage
  async saveProfileImage(userId: string, imageFile: File) {
    try {
      const fileExt = imageFile.name.split('.').pop();
      const fileName = `profile_${userId}_${Date.now()}.${fileExt}`;
      
      const { data, error } = await supabase.storage
        .from('profile-images')
        .upload(fileName, imageFile);

      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage
        .from('profile-images')
        .getPublicUrl(fileName);

      return { success: true, url: publicUrl };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete profile image from Supabase storage
  async deleteProfileImage(imageUrl: string) {
    try {
      // Extract file name from URL
      const fileName = imageUrl.split('/').pop();
      if (!fileName) throw new Error('Invalid image URL');

      const { error } = await supabase.storage
        .from('profile-images')
        .remove([fileName]);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Save custom logo to Supabase storage
  async saveCustomLogo(userId: string, imageFile: File) {
    try {
      const fileExt = imageFile.name.split('.').pop();
      const fileName = `logo_${userId}_${Date.now()}.${fileExt}`;
      
      const { data, error } = await supabase.storage
        .from('custom-logos')
        .upload(fileName, imageFile);

      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage
        .from('custom-logos')
        .getPublicUrl(fileName);

      return { success: true, url: publicUrl };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete custom logo from Supabase storage
  async deleteCustomLogo(imageUrl: string) {
    try {
      // Extract file name from URL
      const fileName = imageUrl.split('/').pop();
      if (!fileName) throw new Error('Invalid image URL');

      const { error } = await supabase.storage
        .from('custom-logos')
        .remove([fileName]);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Convert base64 to File object
  base64ToFile(base64String: string, fileName: string): File {
    const arr = base64String.split(',');
    const mime = arr[0].match(/:(.*?);/)?.[1] || 'image/png';
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], fileName, { type: mime });
  }
};

// Financial Item functions
export const financialItemService = {
  // Add financial item
  async addFinancialItem(bossId: string, itemData: Omit<FinancialItem, 'id' | 'boss_id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from('financial_items')
        .insert([
          {
            boss_id: bossId,
            name: itemData.name,
            description: itemData.description || null,
            default_amount: itemData.default_amount,
            frequency: itemData.frequency,
            category: itemData.category || null,
            is_active: itemData.is_active
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get financial items for boss
  async getFinancialItems(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('financial_items')
        .select('*')
        .eq('boss_id', bossId)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update financial item
  async updateFinancialItem(itemId: string, updates: Partial<FinancialItem>) {
    try {
      const { data, error } = await supabase
        .from('financial_items')
        .update(updates)
        .eq('id', itemId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete financial item
  async deleteFinancialItem(itemId: string) {
    try {
      const { error } = await supabase
        .from('financial_items')
        .delete()
        .eq('id', itemId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Check if financial item name exists for a boss
  async checkFinancialItemNameExists(bossId: string, name: string, excludeId?: string) {
    try {
      let query = supabase
        .from('financial_items')
        .select('id')
        .eq('boss_id', bossId)
        .eq('name', name);

      if (excludeId) {
        query = query.neq('id', excludeId);
      }

      const { data } = await query.maybeSingle();
      return !!data;
    } catch (error) {
      return false;
    }
  },

  // Toggle financial item status
  async toggleFinancialItemStatus(itemId: string) {
    try {
      // First get current status
      const { data: currentItem, error: fetchError } = await supabase
        .from('financial_items')
        .select('is_active')
        .eq('id', itemId)
        .single();

      if (fetchError) throw fetchError;

      // Update status
      const { data, error } = await supabase
        .from('financial_items')
        .update({ is_active: !currentItem.is_active })
        .eq('id', itemId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};

// Employee Page Permissions types
export interface EmployeePagePermission {
  id: string;
  employee_id: string;
  boss_id: string;
  page_name: string;
  is_allowed: boolean;
  created_at: string;
  updated_at: string;
}

// Employee Page Permissions functions
export const employeePagePermissionService = {
  // Get page permissions for an employee
  async getEmployeePagePermissions(employeeId: string) {
    try {
      const { data, error } = await supabase
        .from('employee_page_permissions')
        .select('*')
        .eq('employee_id', employeeId)
        .order('page_name');

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get all employees' page permissions for a boss
  async getAllEmployeesPagePermissions(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('employee_page_permissions')
        .select('*')
        .eq('boss_id', bossId)
        .order('employee_id, page_name');

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update page permission for an employee
  async updateEmployeePagePermission(employeeId: string, pageName: string, isAllowed: boolean) {
    try {
      const { data, error } = await supabase
        .from('employee_page_permissions')
        .update({ is_allowed: isAllowed })
        .eq('employee_id', employeeId)
        .eq('page_name', pageName)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Check if employee has access to a specific page
  async checkPageAccess(employeeId: string, pageName: string) {
    try {
      const { data, error } = await supabase
        .from('employee_page_permissions')
        .select('is_allowed')
        .eq('employee_id', employeeId)
        .eq('page_name', pageName)
        .maybeSingle();

      if (error) throw error;
      return { success: true, isAllowed: data?.is_allowed || false };
    } catch (error: any) {
      return { success: false, error: error.message, isAllowed: false };
    }
  },

  // Bulk update permissions for an employee
  async bulkUpdateEmployeePermissions(employeeId: string, permissions: { [pageName: string]: boolean }) {
    try {
      const updatePromises = Object.entries(permissions).map(([pageName, isAllowed]) =>
        this.updateEmployeePagePermission(employeeId, pageName, isAllowed)
      );

      const results = await Promise.all(updatePromises);
      const hasErrors = results.some(result => !result.success);

      if (hasErrors) {
        throw new Error('Some permissions failed to update');
      }

      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};

// Employee Detailed Permissions types
export interface EmployeeDetailedPermission {
  id: string;
  employee_id: string;
  boss_id: string;
  page_name: string;
  can_view: boolean;
  can_add: boolean;
  can_edit: boolean;
  can_delete: boolean;
  created_at: string;
  updated_at: string;
}

// Employee Detailed Permissions functions
export const employeeDetailedPermissionService = {
  // Get detailed permissions for an employee
  async getEmployeeDetailedPermissions(employeeId: string) {
    try {
      const { data, error } = await supabase
        .from('employee_detailed_permissions')
        .select('*')
        .eq('employee_id', employeeId)
        .order('page_name');

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get all employees' detailed permissions for a boss
  async getAllEmployeesDetailedPermissions(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('employee_detailed_permissions')
        .select('*')
        .eq('boss_id', bossId)
        .order('employee_id, page_name');

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update detailed permission for an employee
  async updateEmployeeDetailedPermission(employeeId: string, pageName: string, permissions: {
    can_view?: boolean;
    can_add?: boolean;
    can_edit?: boolean;
    can_delete?: boolean;
  }) {
    try {
      const { data, error } = await supabase
        .from('employee_detailed_permissions')
        .update(permissions)
        .eq('employee_id', employeeId)
        .eq('page_name', pageName)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Check if employee has specific permission for a page
  async checkDetailedPageAccess(employeeId: string, pageName: string, action: 'view' | 'add' | 'edit' | 'delete') {
    try {
      const { data, error } = await supabase
        .from('employee_detailed_permissions')
        .select(`can_${action}`)
        .eq('employee_id', employeeId)
        .eq('page_name', pageName)
        .maybeSingle();

      if (error) throw error;
      return { success: true, hasAccess: data?.[`can_${action}`] || false };
    } catch (error: any) {
      return { success: false, error: error.message, hasAccess: false };
    }
  },

  // Bulk update permissions for an employee on a specific page
  async bulkUpdateEmployeePagePermissions(employeeId: string, pageName: string, permissions: {
    can_view: boolean;
    can_add: boolean;
    can_edit: boolean;
    can_delete: boolean;
  }) {
    try {
      const { data, error } = await supabase
        .from('employee_detailed_permissions')
        .update(permissions)
        .eq('employee_id', employeeId)
        .eq('page_name', pageName)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};

// Service Category functions
export const serviceCategoryService = {
  // Add service category
  async addServiceCategory(bossId: string, categoryData: Omit<ServiceCategory, 'id' | 'boss_id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from('service_categories')
        .insert([
          {
            boss_id: bossId,
            name: categoryData.name,
            subcategories: categoryData.subcategories
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get service categories for boss
  async getServiceCategories(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('service_categories')
        .select('*')
        .eq('boss_id', bossId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update service category
  async updateServiceCategory(categoryId: string, updates: Partial<ServiceCategory>) {
    try {
      const { data, error } = await supabase
        .from('service_categories')
        .update(updates)
        .eq('id', categoryId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete service category
  async deleteServiceCategory(categoryId: string) {
    try {
      const { error } = await supabase
        .from('service_categories')
        .delete()
        .eq('id', categoryId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Check if category name exists for a boss
  async checkCategoryNameExists(bossId: string, name: string, excludeId?: string) {
    try {
      let query = supabase
        .from('service_categories')
        .select('id')
        .eq('boss_id', bossId)
        .eq('name', name);

      if (excludeId) {
        query = query.neq('id', excludeId);
      }

      const { data } = await query.maybeSingle();
      return !!data;
    } catch (error) {
      return false;
    }
  }
};