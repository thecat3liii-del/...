import { supabase } from './supabase';

// Service for managing sequential numbering for invoices, quotations, and delivery notes
export const numberingService = {
  // Get or generate invoice number for a specific transaction
  async getTransactionInvoiceNumber(bossId: string, transactionId: string): Promise<string> {
    try {
      // First check if this transaction already has an invoice number
      const { data: transaction, error: transactionError } = await supabase
        .from('transactions')
        .select('invoice_number, invoice_generated')
        .eq('id', transactionId)
        .eq('boss_id', bossId)
        .single();

      if (transactionError) throw transactionError;

      // If transaction already has an invoice number, return it
      if (transaction.invoice_number) {
        return transaction.invoice_number;
      }

      // Generate new invoice number
      const newInvoiceNumber = await this.getNextInvoiceNumber(bossId);

      // Update the transaction with the new invoice number
      const { error: updateError } = await supabase
        .from('transactions')
        .update({ 
          invoice_number: newInvoiceNumber,
          invoice_generated: true 
        })
        .eq('id', transactionId);

      if (updateError) throw updateError;

      return newInvoiceNumber;
    } catch (error) {
      console.error('Error getting transaction invoice number:', error);
      return await this.getNextInvoiceNumber(bossId);
    }
  },

  // Get or generate delivery number for a specific transaction
  async getTransactionDeliveryNumber(bossId: string, transactionId: string): Promise<string> {
    try {
      // First check if this transaction already has a delivery number
      const { data: transaction, error: transactionError } = await supabase
        .from('transactions')
        .select('delivery_number, delivery_generated')
        .eq('id', transactionId)
        .eq('boss_id', bossId)
        .single();

      if (transactionError) throw transactionError;

      // If transaction already has a delivery number, return it
      if (transaction.delivery_number) {
        return transaction.delivery_number;
      }

      // Generate new delivery number
      const newDeliveryNumber = await this.getNextDeliveryNumber(bossId);

      // Update the transaction with the new delivery number
      const { error: updateError } = await supabase
        .from('transactions')
        .update({ 
          delivery_number: newDeliveryNumber,
          delivery_generated: true 
        })
        .eq('id', transactionId);

      if (updateError) throw updateError;

      return newDeliveryNumber;
    } catch (error) {
      console.error('Error getting transaction delivery number:', error);
      return await this.getNextDeliveryNumber(bossId);
    }
  },

  // Get next invoice number
  async getNextInvoiceNumber(bossId: string): Promise<string> {
    try {
      // Get all invoice numbers for this boss from both invoices and transactions tables
      const { data, error } = await supabase
        .from('transactions')
        .select('invoice_number')
        .eq('boss_id', bossId)
        .not('invoice_number', 'is', null)
        .order('invoice_number', { ascending: true });

      if (error) throw error;

      if (!data || data.length === 0) {
        // First invoice starts at 1000
        return 'INV-1000';
      }

      // Extract all numbers and find the first gap or next number
      const existingNumbers = data
        .map(invoice => {
          const match = invoice.invoice_number.match(/INV-(\d+)/);
          return match ? parseInt(match[1]) : null;
        })
        .filter(num => num !== null)
        .sort((a, b) => a - b);

      // Find the first gap in the sequence starting from 1000
      let nextNumber = 1000;
      for (const num of existingNumbers) {
        if (num === nextNumber) {
          nextNumber++;
        } else if (num > nextNumber) {
          // Found a gap, use the current nextNumber
          break;
        }
      }

      return `INV-${nextNumber}`;
    } catch (error) {
      console.error('Error getting next invoice number:', error);
      return 'INV-1000';
    }
  },

  // Get next quotation number
  async getNextQuotationNumber(bossId: string): Promise<string> {
    try {
      // Get the highest quotation number for this boss
      const { data, error } = await supabase
        .from('quotations')
        .select('quotation_number')
        .eq('boss_id', bossId)
        .order('created_at', { ascending: false })
        .limit(1);

      if (error) throw error;

      if (!data || data.length === 0) {
        // First quotation starts at 1000
        return 'QUO-1000';
      }

      // Extract number from the last quotation
      const lastQuotationNumber = data[0].quotation_number;
      const numberMatch = lastQuotationNumber.match(/QUO-(\d+)/);
      
      if (numberMatch) {
        const lastNumber = parseInt(numberMatch[1]);
        const nextNumber = lastNumber + 1; // زيادة بـ1 فقط
        return `QUO-${nextNumber}`;
      }

      // Fallback if pattern doesn't match
      return 'QUO-1000';
    } catch (error) {
      console.error('Error getting next quotation number:', error);
      return 'QUO-1000';
    }
  },

  // Get next delivery note number
  async getNextDeliveryNumber(bossId: string): Promise<string> {
    try {
      // Get all delivery numbers for this boss from both delivery_notes and transactions tables
      const { data, error } = await supabase
        .from('transactions')
        .select('delivery_number')
        .eq('boss_id', bossId)
        .not('delivery_number', 'is', null)
        .order('delivery_number', { ascending: true });

      if (error) throw error;

      if (!data || data.length === 0) {
        // First delivery note starts at 1000
        return 'DN-1000';
      }

      // Extract all numbers and find the first gap or next number
      const existingNumbers = data
        .map(delivery => {
          const match = delivery.delivery_number.match(/DN-(\d+)/);
          return match ? parseInt(match[1]) : null;
        })
        .filter(num => num !== null)
        .sort((a, b) => a - b);

      // Find the first gap in the sequence starting from 1000
      let nextNumber = 1000;
      for (const num of existingNumbers) {
        if (num === nextNumber) {
          nextNumber++;
        } else if (num > nextNumber) {
          // Found a gap, use the current nextNumber
          break;
        }
      }

      return `DN-${nextNumber}`;
    } catch (error) {
      console.error('Error getting next delivery number:', error);
      return 'DN-1000';
    }
  },

  // Save invoice to database (to track numbering)
  async saveInvoice(bossId: string, invoiceData: any) {
    try {
      const { data, error } = await supabase
        .from('invoices')
        .insert([
          {
            boss_id: bossId,
            invoice_number: invoiceData.invoiceNumber,
            client_id: invoiceData.clientId || null,
            client_name: invoiceData.clientName,
            client_email: invoiceData.clientEmail || null,
            client_phone: invoiceData.clientPhone || null,
            client_address: invoiceData.clientAddress || null,
            issue_date: invoiceData.issueDate,
            due_date: invoiceData.dueDate,
            items: invoiceData.items,
            subtotal: invoiceData.subtotal,
            tax_rate: invoiceData.taxRate,
            tax_amount: invoiceData.taxAmount,
            discount_rate: invoiceData.discountRate,
            discount_amount: invoiceData.discountAmount,
            total_amount: invoiceData.totalAmount,
            notes: invoiceData.notes || null,
            status: invoiceData.status || 'draft',
            is_active: true
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Save delivery note to database (to track numbering)
  async saveDeliveryNote(bossId: string, deliveryData: any) {
    try {
      const { data, error } = await supabase
        .from('delivery_notes')
        .insert([
          {
            boss_id: bossId,
            delivery_number: deliveryData.deliveryNumber,
            client_id: deliveryData.clientId || null,
            client_name: deliveryData.clientName,
            client_email: deliveryData.clientEmail || null,
            client_phone: deliveryData.clientPhone || null,
            client_address: deliveryData.clientAddress || null,
            delivery_address: deliveryData.deliveryAddress || null,
            delivery_date: deliveryData.deliveryDate,
            items: deliveryData.items,
            notes: deliveryData.notes || null,
            driver_name: deliveryData.driverName || null,
            driver_phone: deliveryData.driverPhone || null,
            recipient_name: deliveryData.recipientName || null,
            recipient_email: deliveryData.recipientEmail || null,
            recipient_phone: deliveryData.recipientPhone || null,
            recipient_signature: deliveryData.recipientSignature || null,
            status: deliveryData.status || 'pending',
            is_active: true
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
};