import { supabase } from './supabase';
import { numberingService } from './numberingService';

// Quotation types
export interface QuotationItem {
  id: string;
  name: string;
  category: string;
  subcategory?: string;
  total: number;
  description?: string;
  serviceId?: string;
  selectedCategory?: string;
  selectedSubcategory?: string;
}

export interface Quotation {
  id: string;
  boss_id: string;
  quotation_number: string;
  client_id?: string;
  client_name?: string;
  client_email?: string;
  client_phone?: string;
  client_address?: string;
  issue_date: string;
  valid_until: string;
  items: QuotationItem[];
  subtotal: number;
  tax_rate: number;
  tax_amount: number;
  discount_rate: number;
  discount_amount: number;
  total_amount: number;
  notes?: string;
  status: 'draft' | 'sent' | 'accepted' | 'rejected' | 'expired';
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Quotation service functions
export const quotationService = {
  // Add quotation
  async addQuotation(bossId: string, quotationData: Omit<Quotation, 'id' | 'boss_id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from('quotations')
        .insert([
          {
            boss_id: bossId,
            quotation_number: quotationData.quotation_number,
            client_id: quotationData.client_id || null,
            client_name: quotationData.client_name || null,
            client_email: quotationData.client_email || null,
            client_phone: quotationData.client_phone || null,
            client_address: quotationData.client_address || null,
            issue_date: quotationData.issue_date,
            valid_until: quotationData.valid_until,
            items: quotationData.items,
            subtotal: quotationData.subtotal,
            tax_rate: quotationData.tax_rate,
            tax_amount: quotationData.tax_amount,
            discount_rate: quotationData.discount_rate,
            discount_amount: quotationData.discount_amount,
            total_amount: quotationData.total_amount,
            notes: quotationData.notes || null,
            status: quotationData.status,
            is_active: quotationData.is_active
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Get quotations for boss
  async getQuotations(bossId: string) {
    try {
      const { data, error } = await supabase
        .from('quotations')
        .select('*')
        .eq('boss_id', bossId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Update quotation
  async updateQuotation(quotationId: string, updates: Partial<Quotation>) {
    try {
      // Ensure we're updating the correct fields with proper data types
      const updateData: any = {};
      
      // Map the updates to match database column names
      if (updates.quotation_number !== undefined) updateData.quotation_number = updates.quotation_number;
      if (updates.client_id !== undefined) updateData.client_id = updates.client_id;
      if (updates.client_name !== undefined) updateData.client_name = updates.client_name;
      if (updates.client_email !== undefined) updateData.client_email = updates.client_email;
      if (updates.client_phone !== undefined) updateData.client_phone = updates.client_phone;
      if (updates.client_address !== undefined) updateData.client_address = updates.client_address;
      if (updates.issue_date !== undefined) updateData.issue_date = updates.issue_date;
      if (updates.valid_until !== undefined) updateData.valid_until = updates.valid_until;
      if (updates.items !== undefined) updateData.items = updates.items;
      if (updates.subtotal !== undefined) updateData.subtotal = updates.subtotal;
      if (updates.tax_rate !== undefined) updateData.tax_rate = updates.tax_rate;
      if (updates.tax_amount !== undefined) updateData.tax_amount = updates.tax_amount;
      if (updates.discount_rate !== undefined) updateData.discount_rate = updates.discount_rate;
      if (updates.discount_amount !== undefined) updateData.discount_amount = updates.discount_amount;
      if (updates.total_amount !== undefined) updateData.total_amount = updates.total_amount;
      if (updates.notes !== undefined) updateData.notes = updates.notes;
      if (updates.status !== undefined) updateData.status = updates.status;
      if (updates.is_active !== undefined) updateData.is_active = updates.is_active;

      const { data, error } = await supabase
        .from('quotations')
        .update(updateData)
        .eq('id', quotationId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Delete quotation
  async deleteQuotation(quotationId: string) {
    try {
      const { error } = await supabase
        .from('quotations')
        .delete()
        .eq('id', quotationId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Check if quotation number exists for a boss
  async checkQuotationNumberExists(bossId: string, quotationNumber: string, excludeId?: string) {
    try {
      let query = supabase
        .from('quotations')
        .select('id')
        .eq('boss_id', bossId)
        .eq('quotation_number', quotationNumber);

      if (excludeId) {
        query = query.neq('id', excludeId);
      }

      const { data } = await query.maybeSingle();
      return !!data;
    } catch (error) {
      return false;
    }
  },

  // Toggle quotation status
  async toggleQuotationStatus(quotationId: string) {
    try {
      // First get current status
      const { data: currentQuotation, error: fetchError } = await supabase
        .from('quotations')
        .select('is_active')
        .eq('id', quotationId)
        .single();

      if (fetchError) throw fetchError;

      // Update status
      const { data, error } = await supabase
        .from('quotations')
        .update({ is_active: !currentQuotation.is_active })
        .eq('id', quotationId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  // Generate unique quotation number
  async generateQuotationNumber(bossId: string): Promise<string> {
    return await numberingService.getNextQuotationNumber(bossId);
  }
};